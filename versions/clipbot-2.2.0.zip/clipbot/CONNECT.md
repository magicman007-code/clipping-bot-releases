# Connect your own AI and software

Everything here is optional, set in **Settings**, and stored only on your computer
(`<work folder>/_settings/connections.json`). Keys are only ever sent to the service they belong to.

## Your AI (titles, translations, prompt help, skills, and a second opinion on picks)

With nothing set up, Clipbot uses a **free built-in AI** (Pollinations, no key). It's slow (one request about
every 30 seconds) and the clip text goes to that public service. Pick **Off** to switch AI off completely, or
connect one of these:

| Provider | What to enter |
|---|---|
| Anthropic (Claude) | your API key; model `claude-haiku-5-5` (cheap, fast) or `claude-sonnet-5-5` (sharper) |
| OpenAI | your API key and a model name from OpenAI |
| OpenRouter | one key for hundreds of models; model name as OpenRouter lists it |
| Google Gemini, Groq, xAI, DeepSeek, Mistral | your key for that service and a model name from its list |
| Ollama | free and runs on your computer: install Ollama, pull a model, type its name. No key. |
| Other | any OpenAI-compatible server: its base URL (`https://…/v1`), key and model |

With **Let my AI re-rank auto-clip picks** on, the top ~15 moments' transcripts go to your AI together with what
Clipbot has learned about your taste (clips you liked or rejected and why, the streamer's lore, their studied
clips). It scores each moment 1-10 with a reason; that's blended into the ranking. It can only reorder moments that
already passed the quality bar. Clipbot checks whether the AI's favourites are the ones you keep and gives it more or
less weight over time.

## Your own scorer (any software)

Point Clipbot at any URL that can take a POST: your own model, a script on your computer
(`http://localhost:...`), or an automation flow (n8n, Make, Zapier webhooks). Clipbot sends:

```json
{"app": "clipbot", "version": 1, "candidates": [
  {"id": 0, "start": 812.4, "end": 851.0, "text": "transcript of the moment", "score": 7.2,
   "tags": ["reaction", "chat"], "chat_z": 6.1}
]}
```

and expects back (within 60 s):

```json
[{"id": 0, "score": 8.5, "why": "huge payoff"}]
```

(or `{"scores": [...]}`). Scores are 0-10. Unknown ids and out-of-range scores are ignored; if the scorer is down,
auto-clip carries on without it. A token, if set, is sent as `Authorization: Bearer <token>`. The starting weight
(default 0.4) is how much your scorer counts; after 8 rated clips Clipbot learns the weight from what you keep.

Minimal example (Python, run with `python3 scorer.py`, then use `http://localhost:8000`):

```python
import json, http.server
class H(http.server.BaseHTTPRequestHandler):
    def do_POST(self):
        req = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        out = [{"id": c["id"], "score": 9 if "chat" in c["tags"] else 5, "why": "chat reacted" if "chat" in c["tags"] else ""}
               for c in req["candidates"]]
        self.send_response(200); self.send_header("Content-Type", "application/json"); self.end_headers()
        self.wfile.write(json.dumps(out).encode())
http.server.HTTPServer(("127.0.0.1", 8000), H).serve_forever()
```

## Webhook (when clips are done)

Clipbot POSTs JSON when a clip renders or an auto-clip run finishes: send it to Discord, Zapier, Make, n8n or your
own server to post, upload or notify.

## Chat replay

YouTube and Twitch VOD chat is fetched automatically (Twitch can refuse; then export it with TwitchDownloader).
For Kick, drop a chat file on the New screen. Accepted: TwitchDownloader `.json`, YouTube `live_chat.json`,
`[{"t": seconds, "text": "..."}]`, or text lines like `0:01:23, message`.

## Subscriber-only VODs

Pick your browser under Settings so downloads use your logins (close that browser first if downloads fail).

## Posting

**Phone:** nothing to set up. Export, Send to my phone, scan the QR code on the same Wi-Fi.

**Posting folder (TikTok / Instagram / YouTube through a scheduler):** Settings, Posting, choose a folder. Use a
folder that syncs (Google Drive, Dropbox, OneDrive). Each clip arrives as `name.mp4` + `name.txt` (title,
description, hashtags) + `name.json`. Point Buffer, Later, Metricool, Make or Zapier at that folder to post on a
schedule. (TikTok and Instagram only let approved apps post directly, which is why this goes through those tools.)

**YouTube upload (5 minutes, free):**
1. Go to console.cloud.google.com, create a project.
2. APIs & Services, Library: enable **YouTube Data API v3**.
3. OAuth consent screen: External, add your own Google account as a test user.
4. Credentials, Create credentials, OAuth client ID, application type **Desktop app**. Copy the client ID and secret.
5. Clipbot Settings, Posting: paste both, Save, then **Connect YouTube** and allow it in the Google tab.
Uploads can be public, unlisted, private or scheduled. Their views are tracked automatically.

**View tracking:** paste any post link in Export, How did it do. Clipbot reads public view counts (YouTube, TikTok,
Instagram, Twitch, Kick) every few hours for 14 days and feeds them to its learning. Instagram sometimes needs
your browser's login (Settings, Subscriber-only VODs, pick your browser).

**Phone alerts:** install ntfy (iOS / Android, free), subscribe to a hard-to-guess name, paste the same name in
Settings, Posting, Save, Test.


## Skills (teach the AI your taste)
Settings -> Skills. A skill has three plain-language fields: **what makes a great clip**, **skip these** and **title
style**. When you pick a skill for an auto-clip run, the first two go to the AI with the moments it scores, and the
title style shapes its title ideas. Write rules you can check: "the payoff lands within 20 seconds" works better
than "make it viral". Rate clips 👍/👎 as well: ratings and skills work together.

## Prompt help
**Help me write this** (auto-clip "What should it clip?" and the thumbnail AI scene) and **Write it for me** (skills)
send your rough idea to your AI with rules for that kind of prompt and show writing tips. With AI off you still get
the tips.

## AI images (thumbnails)
- **Free (no key):** AI scene backgrounds come from a free public image service (Pollinations). Don't put
  anything private in the scene text.
- **OpenAI key:** sharper images (`gpt-image-1`) and **AI remix**, which redraws the real frame.
- "Let the AI draw people and text too" is off by default. Only turn it on for people who agreed to be shown.

## What each platform's API allows (checked November 2026)
| Platform | What's possible | What it takes |
|---|---|---|
| YouTube | Upload and schedule Shorts and videos (built in: Post it -> YouTube) | Your own free Google Cloud project and OAuth client. New, unverified projects upload as **private** until Google audits them. The daily quota covers a handful of uploads. |
| TikTok | Content Posting API: Direct Post, or Upload to your TikTok inbox as a draft that you finish in the app | Your own TikTok developer app. Until TikTok audits it, Direct Post only posts **private** videos. |
| Instagram | Graph API can publish Reels | A Business (professional) account linked to a Facebook Page, and a Meta app. Publishing to accounts other than your own needs Meta app review. 100 posts per 24 hours. |
| X | Media upload and posting | Paid: the free tier closed to new projects in February 2026, and each post is billed. |
| Twitch | Create Clip and Create Clip From VOD (open beta), Download Clip | A token from the broadcaster or an editor of the channel (`clips:edit` / `channel:manage:clips`). |
| Kick | No official clip or posting API for this | Clipbot reads Kick through its public pages. |

Until those apps are set up, use **Send to my phone** (QR code) or a **posting folder** watched by Buffer, Later,
Make or Zapier.

## TikTok (post from Clipbot)
1. Go to developers.tiktok.com, sign in, then **Manage apps -> Connect an app**. Choose platform **Desktop**.
2. Add the products **Login Kit** and **Content Posting API**, and turn on **Direct Post** in the Content Posting API settings.
3. Under Login Kit, add the redirect URI `http://127.0.0.1:*/oauth/tiktok/` (the star lets any port work).
4. Add the scopes `user.info.basic`, `video.upload`, `video.publish` and `video.list` (`video.list` lets Clipbot read your TikTok views). Under Sandbox, add your TikTok
   account as a target user.
5. Copy the **Client key** and **Client secret** into Clipbot (Settings -> Posting -> TikTok), press Save, then **Connect
   TikTok** and allow it.

In a clip's Export tab -> Post it:
- **Send as draft** puts the video in your TikTok inbox. Open TikTok, tap the notification, then add sounds and post.
  TikTok allows 5 drafts waiting per day.
- **Post to TikTok…** posts straight away. You pick who can see it, which interactions to allow, and whether it's AI or
  commercial content. Until TikTok reviews your app, posts can only be **Only me**, and your account must be set to
  private while posting. To post publicly, submit the app for review in the TikTok developer portal.

## Twitch (real Twitch clips from the live viewer)
1. dev.twitch.tv -> Your Console -> **Register Your Application**. Set **Client Type: Public**, set the OAuth Redirect
   URL to `http://localhost`, and choose any category.
2. Paste the **Client ID** into Clipbot (Settings -> Posting -> Twitch), press Save, then **Connect Twitch**. A Twitch
   page opens with a code to confirm.
3. In the live viewer, **Twitch clip** makes a real clip of the last 30 seconds on that channel. You need to be the
   broadcaster or an editor of the channel.

## Scheduling
Schedule posts… works with whatever is connected: YouTube (scheduled on YouTube itself), TikTok (drafts sent at the
time), and your posting folder (files copied at the time, ready for Buffer, Later, Metricool or Zapier to pick up).
Clipbot needs to be open for TikTok drafts and the posting folder.

## Instagram
Instagram's official API only publishes Reels from a public web link to the video. Clipbot runs on your computer
and has no public link, so for Instagram use **Send to my phone** or the posting folder (Buffer, Later and Metricool
post to Instagram).


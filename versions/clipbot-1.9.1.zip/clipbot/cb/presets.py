"""Style presets, campaign rules, and sharing them (plus streamer lore) with other clippers.

Presets   <work_root>/_presets/<slug>.json   {"name", "style": {caption/headline/banner/look settings}, "notes"}
          Save a clip's look once; apply it to any clip, or to every clip of an auto-clip run, channel watch or
          live session. Only look-and-feel settings are kept - never times, words, text layers or framing boxes.
Campaigns <work_root>/_campaigns/<slug>.json {"name", "preset", "rules": {...}, "notes"}
          The rules a clipping campaign pays for (length, shape, captions, banner handle, hashtags, words that must
          be in the title, no watermark). check() says, for each clip, which rules pass and how to fix the rest.
Sharing   bundle() -> one .clipbot.json file with chosen presets, campaigns and lore profiles; load_bundle() reads one.
          Files are validated: unknown keys are dropped, sizes are capped, nothing in them is executed.
"""
import json
import os
import re
import time

from .common import load_config

STYLE_KEYS = ("captions", "caption_font", "caption_size", "caption_color", "accent", "caption_outline",
              "caption_outline_color", "caption_bold", "caption_italic", "caption_shadow", "caption_spacing",
              "caption_y", "uppercase", "censor", "headline_font", "headline_color", "headline_bg", "banner",
              "grade", "watermark", "progress", "aspect", "also_aspects", "layout", "speed", "tighten",
              "volume_db", "music", "teaser", "open_punch", "hook")
RULE_KEYS = {"min_seconds": float, "max_seconds": float, "aspect": str, "captions": bool, "banner_handle": str,
             "hashtags": list, "title_words": list, "no_watermark": bool, "headline": bool}
MAX_FILE = 512 * 1024


def _dir(kind):
    d = os.path.join(load_config()["work_root"], "_" + kind)
    os.makedirs(d, exist_ok=True)
    return d


def slug(name):
    s = re.sub(r"[^\w-]+", "_", str(name or "").strip().lower()).strip("_")[:60]
    if not s:
        raise ValueError("give it a name")
    return s


def _safe(v, depth=0):
    """Plain JSON data only, size-capped (shared files come from other people)."""
    if depth > 6:
        return None
    if isinstance(v, (bool, int, float)) or v is None:
        return v
    if isinstance(v, str):
        return v[:2000]
    if isinstance(v, list):
        return [_safe(x, depth + 1) for x in v[:100]]
    if isinstance(v, dict):
        return {str(k)[:60]: _safe(x, depth + 1) for k, x in list(v.items())[:100]}
    return None


# ------------------------------------------------------------------ presets
def style_of(spec):
    return {k: _safe(spec[k]) for k in STYLE_KEYS if k in spec and spec[k] is not None}


def list_presets():
    out = []
    for f in sorted(os.listdir(_dir("presets"))):
        if f.endswith(".json"):
            try:
                p = json.load(open(os.path.join(_dir("presets"), f)))
                out.append({"name": p["name"], "slug": f[:-5], "keys": sorted(p.get("style", {})), "notes": p.get("notes", "")})
            except Exception:
                continue
    return out


def load_preset(name):
    if not name:
        return None
    p = os.path.join(_dir("presets"), slug(name) + ".json")
    if not os.path.exists(p):
        return None
    try:
        return json.load(open(p))
    except Exception:
        return None


def save_preset(name, spec=None, style=None, notes=""):
    st = style_of(spec or {}) if style is None else {k: _safe(v) for k, v in (style or {}).items() if k in STYLE_KEYS}
    if not st:
        raise ValueError("nothing to save - style a clip first")
    p = {"name": str(name).strip()[:60], "style": st, "notes": str(notes or "")[:500], "saved": int(time.time())}
    path = os.path.join(_dir("presets"), slug(name) + ".json")
    tmp = path + ".tmp"
    json.dump(p, open(tmp, "w"), indent=1)
    os.replace(tmp, path)
    return p


def delete(kind, name):
    p = os.path.join(_dir(kind), slug(name) + ".json")
    if os.path.exists(p):
        os.remove(p)
        return True
    return False


def apply(spec, name_or_preset):
    """Return a copy of spec with the preset's look applied (times, words and text layers untouched)."""
    pr = load_preset(name_or_preset) if isinstance(name_or_preset, str) else name_or_preset
    if not pr:
        return dict(spec)
    out = dict(spec)
    for k, v in (pr.get("style") or {}).items():
        if k in STYLE_KEYS:
            out[k] = json.loads(json.dumps(v))
    out["preset"] = pr.get("name")
    return out


# ------------------------------------------------------------------ campaigns
def _rules(r):
    out = {}
    for k, t in RULE_KEYS.items():
        if k not in (r or {}) or r[k] in (None, "", []):
            continue
        v = r[k]
        try:
            if t is float:
                v = float(v)
            elif t is bool:
                v = bool(v)
            elif t is list:
                v = [str(x).strip()[:60] for x in (v if isinstance(v, list) else re.split(r"[,\s]+", str(v))) if str(x).strip()][:20]
            else:
                v = str(v).strip()[:60]
        except (TypeError, ValueError):
            raise ValueError("%s isn't valid" % k.replace("_", " "))
        out[k] = v
    if out.get("min_seconds") and out.get("max_seconds") and out["min_seconds"] > out["max_seconds"]:
        raise ValueError("minimum length is longer than the maximum")
    return out


def list_campaigns():
    out = []
    for f in sorted(os.listdir(_dir("campaigns"))):
        if f.endswith(".json"):
            try:
                c = json.load(open(os.path.join(_dir("campaigns"), f)))
                out.append(c)
            except Exception:
                continue
    return out


def load_campaign(name):
    if not name:
        return None
    p = os.path.join(_dir("campaigns"), slug(name) + ".json")
    try:
        return json.load(open(p)) if os.path.exists(p) else None
    except Exception:
        return None


def save_campaign(name, rules, preset=None, notes=""):
    c = {"name": str(name).strip()[:60], "rules": _rules(rules), "preset": (str(preset)[:60] if preset else None),
         "notes": str(notes or "")[:1000], "saved": int(time.time())}
    path = os.path.join(_dir("campaigns"), slug(name) + ".json")
    tmp = path + ".tmp"
    json.dump(c, open(tmp, "w"), indent=1)
    os.replace(tmp, path)
    return c


def clip_length(spec):
    segs = spec.get("segments") or [[spec.get("start", 0), spec.get("end", 0)]]
    return sum(max(0.0, float(b) - float(a)) for a, b in segs) / max(0.25, float(spec.get("speed") or 1.0))


def check(spec, campaign, title=None, caption_text=None):
    """[{rule, ok, detail}] for one clip against a campaign's rules."""
    c = load_campaign(campaign) if isinstance(campaign, str) else campaign
    if not c:
        return []
    r = c.get("rules") or {}
    out = []
    dur = clip_length(spec)
    if "min_seconds" in r:
        out.append({"rule": "At least %gs long" % r["min_seconds"], "ok": dur >= r["min_seconds"] - 0.05,
                    "detail": "%.1fs - drag the clip's end on the timeline" % dur})
    if "max_seconds" in r:
        out.append({"rule": "At most %gs long" % r["max_seconds"], "ok": dur <= r["max_seconds"] + 0.05,
                    "detail": "%.1fs - trim it on the timeline" % dur})
    if r.get("aspect"):
        a = spec.get("aspect") or "9:16"
        out.append({"rule": "Shape %s" % r["aspect"], "ok": a == r["aspect"], "detail": "it's %s - change it in Clip, Shape" % a})
    if r.get("captions"):
        on = (spec.get("captions") or "karaoke") != "none"
        out.append({"rule": "Has captions", "ok": on, "detail": "captions are off - pick a style in the Captions tab"})
    if r.get("headline"):
        out.append({"rule": "Has a headline", "ok": bool((spec.get("headline") or "").strip()),
                    "detail": "type one in Clip, Headline"})
    if r.get("banner_handle"):
        b = spec.get("banner") or {}
        h = str(b.get("handle") or b.get("text") or "").lstrip("@/").lower()
        want = r["banner_handle"].lstrip("@/").lower()
        out.append({"rule": "Banner shows @%s" % want, "ok": bool(b) and want in h,
                    "detail": "add the banner in Look, Streamer banner, with handle %s" % want})
    if r.get("no_watermark"):
        out.append({"rule": "No watermark", "ok": not spec.get("watermark"), "detail": "remove it in Look"})
    text = " ".join(str(x) for x in (title or spec.get("title") or "", caption_text or spec.get("description") or "",
                                     spec.get("hashtags") or "") if x)
    low = text.lower()
    for tag in r.get("hashtags") or []:
        t = "#" + tag.lstrip("#").lower()
        out.append({"rule": "Post text has %s" % t, "ok": t in low,
                    "detail": "add it to the title or caption in Export"})
    for w in r.get("title_words") or []:
        out.append({"rule": "Title mentions \"%s\"" % w, "ok": w.lower() in low, "detail": "add it to the title in Export"})
    return out


# ------------------------------------------------------------------ sharing
def bundle(presets=(), campaigns=(), lore=()):
    from . import lore as _lore
    data = {"clipbot_share": 1, "made": int(time.time()), "presets": [], "campaigns": [], "lore": []}
    for n in presets:
        p = load_preset(n)
        if p:
            data["presets"].append(p)
    for n in campaigns:
        c = load_campaign(n)
        if c:
            data["campaigns"].append(c)
    for n in lore:
        p = _lore.load(n)
        if p:
            p = {k: v for k, v in p.items() if k in ("streamer", "names", "aliases", "phrases", "notes", "style")}
            data["lore"].append(p)
    if not (data["presets"] or data["campaigns"] or data["lore"]):
        raise ValueError("pick at least one preset, campaign or streamer to share")
    return data


def load_bundle(raw, overwrite=False):
    """Import a shared file. Returns what was added / skipped. Existing items are kept unless overwrite."""
    from . import lore as _lore
    if isinstance(raw, (bytes, str)):
        if len(raw) > MAX_FILE:
            raise ValueError("that file is too big to be a Clipbot share file")
        try:
            raw = json.loads(raw)
        except ValueError:
            raise ValueError("that isn't a Clipbot share file (not JSON)")
    if not isinstance(raw, dict) or raw.get("clipbot_share") != 1:
        raise ValueError("that isn't a Clipbot share file")
    res = {"added": [], "skipped": []}
    for p in (raw.get("presets") or [])[:50]:
        if not isinstance(p, dict) or not p.get("name"):
            continue
        if load_preset(p["name"]) and not overwrite:
            res["skipped"].append("preset " + str(p["name"])[:60])
            continue
        try:
            save_preset(p["name"], style=p.get("style") or {}, notes=p.get("notes", ""))
            res["added"].append("preset " + str(p["name"])[:60])
        except ValueError:
            res["skipped"].append("preset " + str(p["name"])[:60])
    for c in (raw.get("campaigns") or [])[:50]:
        if not isinstance(c, dict) or not c.get("name"):
            continue
        if load_campaign(c["name"]) and not overwrite:
            res["skipped"].append("campaign " + str(c["name"])[:60])
            continue
        try:
            save_campaign(c["name"], c.get("rules") or {}, c.get("preset"), c.get("notes", ""))
            res["added"].append("campaign " + str(c["name"])[:60])
        except ValueError:
            res["skipped"].append("campaign " + str(c["name"])[:60])
    for p in (raw.get("lore") or [])[:50]:
        if not isinstance(p, dict) or not p.get("streamer"):
            continue
        if _lore.load(p["streamer"]) and not overwrite:
            res["skipped"].append("lore " + str(p["streamer"])[:60])
            continue
        clean = {k: _safe(v) for k, v in p.items() if k in ("streamer", "names", "aliases", "phrases", "notes", "style")}
        _lore.save(clean)
        res["added"].append("lore " + str(p["streamer"])[:60])
    return res

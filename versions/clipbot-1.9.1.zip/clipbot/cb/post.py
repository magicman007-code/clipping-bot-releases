"""Getting clips out, and finding out how they did.

  Phone       start_handoff(): a short-lived link on your home Wi-Fi + QR code. Scan it, the clip opens on your phone
              with its caption ready to copy, post from the TikTok / Instagram / YouTube app. Only that one file is
              reachable, with an unguessable token, for 30 minutes.
  Folder      to_folder(): the MP4 + a .txt caption (+ .json details) into a folder you pick. Point it at a Google
              Drive / Dropbox folder and Buffer, Later, Metricool, Make or Zapier can post from there on a schedule.
  YouTube     direct upload with your own Google OAuth client (Desktop app type; see CONNECT.md), optionally scheduled
              (publishAt). Uses the official YouTube Data API v3 resumable upload.
  Tracking    track() remembers a posted link for a clip; refresh() reads its public view count (YouTube API for your
              uploads, otherwise yt-dlp, which reads views from YouTube, TikTok, Instagram, Twitch and Kick pages) and
              feeds it to the learning loop as a 'performance' event - no typing views in.
"""
import json
import os
import re
import secrets
import shutil
import socket
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

from .common import load_config, log

# ------------------------------------------------------------------ phone handoff
HANDOFF_TTL = 30 * 60
_HO = {"server": None, "port": None, "ip": None, "tokens": {}}
_HO_LOCK = threading.Lock()


def lan_ip():
    """This computer's address on the local network (no packets are sent)."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))
        ip = s.getsockname()[0]
    except OSError:
        ip = "127.0.0.1"
    finally:
        s.close()
    return ip


def _page(tok, t):
    cap = (t.get("caption") or "").replace("&", "&amp;").replace("<", "&lt;")
    name = os.path.basename(t["path"]).replace("&", "&amp;").replace("<", "&lt;")
    return ("""<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Clipbot clip</title><style>body{margin:0;background:#000;color:#f3f3f1;font:16px/1.45 -apple-system,system-ui,sans-serif;padding:16px}
video{width:100%%;max-height:70vh;border-radius:14px;background:#111}a,button{display:block;width:100%%;box-sizing:border-box;margin-top:12px;padding:14px;border-radius:999px;
border:0;font:600 16px system-ui;text-align:center;text-decoration:none}a{background:#fff;color:#000}button{background:#202023;color:#fff}
pre{white-space:pre-wrap;background:#151517;border-radius:12px;padding:12px;font:14px/1.45 system-ui}p{color:#8f8f97;font-size:13px}</style></head><body>
<video src="/f/%s" controls playsinline></video>
<a href="/f/%s" download="%s">Save video</a>
<button onclick="navigator.clipboard.writeText(document.getElementById('c').textContent).then(()=>this.textContent='Caption copied')">Copy caption</button>
<pre id="c">%s</pre><p>Save the video, then post it from the TikTok, Instagram or YouTube app and paste the caption.
This link stops working in 30 minutes.</p></body></html>""" % (tok, tok, name, cap)).encode()


def _serve():
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def do_GET(self):
            m = re.match(r"^/(p|f)/([A-Za-z0-9_-]{16,64})$", self.path.split("?")[0])
            t = _HO["tokens"].get(m.group(2)) if m else None
            if not t or t["exp"] < time.time() or not os.path.isfile(t["path"]):
                self.send_response(404)
                self.end_headers()
                self.wfile.write(b"This link has expired. Make a new one in Clipbot.")
                return
            if m.group(1) == "p":
                body = _page(m.group(2), t)
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return
            size = os.path.getsize(t["path"])
            a, b = 0, size - 1
            rng = re.match(r"bytes=(\d*)-(\d*)", self.headers.get("Range") or "")
            if rng and (rng.group(1) or rng.group(2)):        # phones stream video with Range requests
                if rng.group(1):
                    a = int(rng.group(1))
                    b = int(rng.group(2)) if rng.group(2) else size - 1
                else:
                    a = max(0, size - int(rng.group(2)))
                b = min(b, size - 1)
                if a > b:
                    self.send_response(416)
                    self.end_headers()
                    return
                self.send_response(206)
                self.send_header("Content-Range", "bytes %d-%d/%d" % (a, b, size))
            else:
                self.send_response(200)
            self.send_header("Content-Type", "video/mp4")
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Length", str(b - a + 1))
            self.end_headers()
            with open(t["path"], "rb") as f:
                f.seek(a)
                left = b - a + 1
                while left > 0:
                    chunk = f.read(min(1 << 16, left))
                    if not chunk:
                        break
                    try:
                        self.wfile.write(chunk)
                    except (BrokenPipeError, ConnectionResetError):
                        return
                    left -= len(chunk)

    ip = lan_ip()
    srv = ThreadingHTTPServer((ip, 0), H)
    srv.daemon_threads = True
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    _HO.update(server=srv, port=srv.server_address[1], ip=ip)


def start_handoff(path, caption=""):
    if not os.path.isfile(path):
        raise ValueError("render the clip first")
    with _HO_LOCK:
        now = time.time()
        _HO["tokens"] = {k: v for k, v in _HO["tokens"].items() if v["exp"] > now}
        if not _HO["server"]:
            _serve()
        tok = secrets.token_urlsafe(18)
        _HO["tokens"][tok] = {"path": os.path.abspath(path), "caption": caption[:3000], "exp": now + HANDOFF_TTL}
    url = "http://%s:%d/p/%s" % (_HO["ip"], _HO["port"], tok)
    qr = None
    try:
        import segno
        qr = segno.make(url, error="m").svg_inline(scale=6, dark="#000", light="#fff", border=2)
    except Exception as e:
        log("QR code unavailable: %s" % e)
    return {"url": url, "qr_svg": qr, "expires_in": HANDOFF_TTL, "local_only": _HO["ip"].startswith("127.")}


def caption_text(spec):
    parts = [(spec.get("title") or spec.get("headline") or "").strip(), (spec.get("description") or "").strip(),
             (spec.get("hashtags") or "").strip()]
    return "\n\n".join(p for p in parts if p)


# ------------------------------------------------------------------ posting folder
def to_folder(path, spec, folder, project=""):
    folder = os.path.abspath(os.path.expanduser(folder or ""))
    if not folder or not os.path.isdir(folder):
        raise ValueError("choose an existing folder in Settings -> Posting folder")
    if not os.path.isfile(path):
        raise ValueError("render the clip first")
    base = re.sub(r"[^\w.-]+", "_", "%s_%s" % (project, spec.get("name") or "clip")).strip("_")[:80] or "clip"
    dst = os.path.join(folder, base + ".mp4")
    shutil.copy2(path, dst + ".part")
    os.replace(dst + ".part", dst)          # tools that watch the folder never see half a file
    open(os.path.join(folder, base + ".txt"), "w", encoding="utf-8").write(caption_text(spec) + "\n")
    json.dump({"title": spec.get("title") or spec.get("headline") or "", "description": spec.get("description") or "",
               "hashtags": spec.get("hashtags") or "", "seconds": round(float(spec.get("end", 0)) - float(spec.get("start", 0)), 1),
               "aspect": spec.get("aspect") or "9:16", "campaign": spec.get("campaign"), "video": base + ".mp4"},
              open(os.path.join(folder, base + ".json"), "w"), indent=1)
    return {"video": dst, "caption": os.path.join(folder, base + ".txt")}


# ------------------------------------------------------------------ YouTube (official Data API v3)
YT_AUTH = "https://accounts.google.com/o/oauth2/v2/auth"
YT_TOKEN = "https://oauth2.googleapis.com/token"
YT_UPLOAD = "https://www.googleapis.com/upload/youtube/v3/videos"
YT_API = "https://www.googleapis.com/youtube/v3"
YT_SCOPES = "https://www.googleapis.com/auth/youtube.upload https://www.googleapis.com/auth/youtube.readonly"


def _yt():
    from .connect import get
    return get().get("youtube") or {}


def yt_auth_url(redirect, state):
    yt = _yt()
    if not yt.get("client_id"):
        raise ValueError("paste your Google OAuth client ID and secret first (Settings -> YouTube)")
    return YT_AUTH + "?" + urllib.parse.urlencode({
        "client_id": yt["client_id"], "redirect_uri": redirect, "response_type": "code", "scope": YT_SCOPES,
        "access_type": "offline", "prompt": "consent", "state": state})


def _post_form(url, data, timeout=30):
    req = urllib.request.Request(url, data=urllib.parse.urlencode(data).encode(), method="POST",
                                 headers={"Content-Type": "application/x-www-form-urlencoded"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read())


def yt_finish_auth(code, redirect, token_url=None):
    from .connect import save
    yt = _yt()
    j = _post_form(token_url or YT_TOKEN, {"code": code, "client_id": yt["client_id"], "client_secret": yt.get("client_secret", ""),
                                           "redirect_uri": redirect, "grant_type": "authorization_code"})
    if not j.get("refresh_token"):
        raise RuntimeError("Google didn't return a refresh token - remove Clipbot's access in your Google account and connect again")
    save({"youtube": {"refresh_token": j["refresh_token"]}})
    return True


def _yt_access(token_url=None):
    yt = _yt()
    if not yt.get("refresh_token"):
        raise RuntimeError("connect YouTube first (Settings -> YouTube -> Connect)")
    try:
        j = _post_form(token_url or YT_TOKEN, {"refresh_token": yt["refresh_token"], "client_id": yt["client_id"],
                                               "client_secret": yt.get("client_secret", ""), "grant_type": "refresh_token"})
    except urllib.error.HTTPError as e:
        raise RuntimeError("YouTube sign-in expired or was revoked - connect again (%s)" % e.code)
    return j["access_token"]


def yt_upload(path, title, description="", tags=(), privacy="public", publish_at=None, upload_url=None, token_url=None,
              chunk=8 << 20):
    """Resumable upload. publish_at (ISO 8601, UTC) schedules it: uploaded as private, goes public at that time."""
    if not os.path.isfile(path):
        raise ValueError("render the clip first")
    tok = _yt_access(token_url)
    status = {"privacyStatus": "private" if publish_at else (privacy if privacy in ("public", "unlisted", "private") else "public"),
              "selfDeclaredMadeForKids": False}
    if publish_at:
        status["publishAt"] = publish_at
    meta = {"snippet": {"title": (title or "Clip")[:100], "description": (description or "")[:4900],
                        "tags": [t.lstrip("#")[:30] for t in tags][:15], "categoryId": "20"}, "status": status}
    size = os.path.getsize(path)
    req = urllib.request.Request((upload_url or YT_UPLOAD) + "?uploadType=resumable&part=snippet,status",
                                 data=json.dumps(meta).encode(), method="POST",
                                 headers={"Authorization": "Bearer " + tok, "Content-Type": "application/json; charset=UTF-8",
                                          "X-Upload-Content-Type": "video/mp4", "X-Upload-Content-Length": str(size)})
    with urllib.request.urlopen(req, timeout=60) as r:
        loc = r.headers.get("Location")
    if not loc:
        raise RuntimeError("YouTube didn't accept the upload")
    sent, res = 0, None
    with open(path, "rb") as f:
        while sent < size:
            data = f.read(chunk)
            end = sent + len(data) - 1
            for attempt in range(4):
                req = urllib.request.Request(loc, data=data, method="PUT", headers={
                    "Content-Length": str(len(data)), "Content-Range": "bytes %d-%d/%d" % (sent, end, size)})
                try:
                    with urllib.request.urlopen(req, timeout=300) as r:
                        res = json.loads(r.read() or b"{}")
                    break
                except urllib.error.HTTPError as e:
                    if e.code == 308:                # chunk received, keep going
                        break
                    if e.code >= 500 and attempt < 3:
                        time.sleep(2 ** attempt)
                        continue
                    raise RuntimeError("YouTube upload failed (%s): %s" % (e.code, e.read()[:200]))
                except OSError:
                    if attempt < 3:
                        time.sleep(2 ** attempt)
                        continue
                    raise
            sent = end + 1
    vid = (res or {}).get("id")
    if not vid:
        raise RuntimeError("YouTube didn't return a video id")
    return {"id": vid, "url": "https://youtube.com/shorts/" + vid, "scheduled": publish_at}


def yt_stats(ids, api=None):
    tok = _yt_access()
    req = urllib.request.Request((api or YT_API) + "/videos?part=statistics&id=" + ",".join(ids[:50]),
                                 headers={"Authorization": "Bearer " + tok})
    with urllib.request.urlopen(req, timeout=30) as r:
        j = json.loads(r.read())
    return {it["id"]: int(it.get("statistics", {}).get("viewCount", 0)) for it in j.get("items", [])}


# ------------------------------------------------------------------ view tracking
def _posts_path():
    d = os.path.join(load_config()["work_root"], "_learning")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "posts.json")


_PL = threading.Lock()


def posts():
    try:
        return json.load(open(_posts_path()))
    except Exception:
        return []


def _save_posts(ps):
    tmp = _posts_path() + ".tmp"
    json.dump(ps, open(tmp, "w"), indent=1)
    os.replace(tmp, _posts_path())


def platform_of(url):
    u = url.lower()
    for k, pat in (("YouTube", "youtu"), ("TikTok", "tiktok.com"), ("Instagram", "instagram.com"), ("X", "x.com/"),
                   ("X", "twitter.com"), ("Kick", "kick.com"), ("Twitch", "twitch.tv"), ("Facebook", "facebook.com")):
        if pat in u:
            return k
    return "Other"


def track(url, project_dir, clip_name):
    url = (url or "").strip()
    if not re.match(r"https?://[^\s]+$", url):
        raise ValueError("paste the full link of the post (https://...)")
    with _PL:
        ps = [p for p in posts() if not (p["project"] == project_dir and p["clip"] == clip_name and p["url"] == url)]
        ps.append({"url": url, "platform": platform_of(url), "project": project_dir, "clip": clip_name,
                   "added": int(time.time()), "checked": 0, "views": None, "history": []})
        _save_posts(ps)
    return ps[-1]


def untrack(url):
    with _PL:
        ps = posts()
        keep = [p for p in ps if p["url"] != url]
        _save_posts(keep)
        return len(ps) - len(keep)


def read_views(url, cfg=None):
    """Public view count of a post (None if the site won't say)."""
    m = re.search(r"(?:youtube\.com/(?:shorts/|watch\?v=)|youtu\.be/)([\w-]{11})", url)
    if m and (_yt().get("refresh_token")):
        try:
            return yt_stats([m.group(1)]).get(m.group(1))
        except Exception as e:
            log("YouTube stats failed, trying the page: %s" % e)
    from .common import run
    from .fetch import _ytdlp_base
    r = run(_ytdlp_base(cfg or load_config()) + ["--skip-download", "--dump-single-json", "--no-playlist", url],
            timeout=120, check=False)
    if r.returncode != 0:
        raise RuntimeError(((r.stderr or "").strip().splitlines() or ["couldn't read the post"])[-1][:200])
    j = json.loads(r.stdout or "{}")
    v = j.get("view_count")
    return int(v) if v is not None else None


def refresh(force=False, reader=None, now=None):
    """Check views of posts that are due (every 6 h for 14 days). Feeds each new count to the learning loop."""
    from . import learn
    reader = reader or read_views
    now = now or time.time()
    done = []
    for p in posts():
        due = force or (now - p.get("checked", 0) > 6 * 3600 and now - p.get("added", now) < 14 * 86400)
        if not due:
            continue
        try:
            v = reader(p["url"])
            err = None
        except Exception as e:
            v, err = None, str(e)[:200]
        with _PL:
            ps = posts()
            for q in ps:
                if q["url"] == p["url"] and q["clip"] == p["clip"] and q["project"] == p["project"]:
                    q["checked"] = int(now)
                    q["error"] = err
                    if v is not None:
                        q["views"] = v
                        q["history"] = (q.get("history") or [])[-40:] + [[int(now), v]]
            _save_posts(ps)
        if v is not None:
            spec = _spec(p["project"], p["clip"])
            if spec is not None:
                learn.record("performance", spec, p["project"], views=float(v), platform=p["platform"], auto=True)
            done.append({"url": p["url"], "views": v})
    return done


def _spec(project, clip):
    try:
        for s in json.load(open(os.path.join(project, "specs.json"))):
            if s.get("name") == clip:
                return s
    except Exception:
        pass
    return None


class Tracker:
    """Background view checks while the editor is open."""
    def __init__(self, minutes=30):
        self.minutes = minutes
        self.stop = threading.Event()

    def run(self):
        while not self.stop.wait(self.minutes * 60):
            try:
                if posts():
                    n = refresh()
                    if n:
                        log("views: updated %d post(s)" % len(n))
            except Exception as e:
                log("view check failed: %s" % e)

"""Shared helpers: subprocess, probing, config + state files."""
import json
import os
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG_PATH = os.path.join(ROOT, "config.json")
STATE_PATH = os.path.join(ROOT, "state.json")
FONT_DIR = os.path.join(ROOT, "fonts")           # bundled OFL fonts (no admin rights needed)
YUNET = os.path.join(ROOT, "models", "yunet.onnx")
FPS = 30
VERSION = "0.9.0-beta (2026-11-03)"

# Homebrew's plain "ffmpeg" is a slim build without libass/freetype (no burned-in captions or text); the full
# build ("brew install ffmpeg-full") is keg-only, so put it first on PATH for us, yt-dlp and every subprocess.
for _d in ("/opt/homebrew/opt/ffmpeg-full/bin", "/usr/local/opt/ffmpeg-full/bin", os.path.join(ROOT, "bin")):
    if os.path.isfile(os.path.join(_d, "ffmpeg")) and _d not in os.environ.get("PATH", "").split(os.pathsep)[:1]:
        os.environ["PATH"] = _d + os.pathsep + os.environ.get("PATH", "")


class CmdError(RuntimeError):
    pass


def log(*a):
    print(*a, file=sys.stderr, flush=True)


def run(cmd, timeout=1800, check=True, quiet=True):
    """Run a command. Raises CmdError on non-zero exit (never fail silently)."""
    if not quiet:
        log("+ " + " ".join(str(c) for c in cmd))
    r = subprocess.run([str(c) for c in cmd], capture_output=True, text=True, timeout=timeout)
    if check and r.returncode != 0:
        raise CmdError("command failed (%d): %s\n%s" % (r.returncode, " ".join(str(c) for c in cmd[:8]),
                                                          (r.stderr or r.stdout)[-2000:]))
    return r


def ffmpeg(args, timeout=1800):
    return run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error"] + list(args), timeout=timeout)


# ---- video encoder: the computer's hardware encoder when it really works, else libx264
SW_FINAL = ["-c:v", "libx264", "-preset", "medium", "-crf", "18"]
HW_CANDIDATES = [   # (name, args) - bitrates sized for 1080x1920 30 fps social clips (well above what platforms keep)
    ("h264_videotoolbox", ["-c:v", "h264_videotoolbox", "-b:v", "14M", "-maxrate", "20M", "-bufsize", "28M",
                           "-profile:v", "high", "-allow_sw", "0"]),
    ("h264_nvenc", ["-c:v", "h264_nvenc", "-preset", "p5", "-tune", "hq", "-rc", "vbr", "-cq", "19", "-b:v", "0",
                    "-maxrate", "20M", "-bufsize", "28M", "-profile:v", "high"]),
    ("h264_qsv", ["-c:v", "h264_qsv", "-global_quality", "20", "-look_ahead", "1", "-maxrate", "20M"]),
]
_HW = {}


def hw_encoder(cfg=None):
    """(name, args) of a hardware H.264 encoder that actually encodes on this computer, or (None, None).
    Tested once per run with a tiny real encode (an encoder can be compiled in with no GPU behind it).
    Settings: "hw_encode": "auto" (default) | "off"."""
    if (cfg or {}).get("hw_encode", "auto") == "off":
        return None, None
    if "pick" in _HW:
        return _HW["pick"]
    _HW["pick"] = (None, None)
    for name, args in HW_CANDIDATES:
        try:
            r = run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-f", "lavfi", "-i",
                     "testsrc2=s=1080x1920:r=30:d=0.5", "-pix_fmt", "yuv420p"] + args + ["-f", "null", "-"],
                    timeout=40, check=False)
            if r.returncode == 0:
                _HW["pick"] = (name, args)
                log("video: using the %s hardware encoder" % name)
                break
        except Exception:
            continue
    return _HW["pick"]


def encode_with_fallback(build, cfg=None, timeout=3600):
    """build(video_args) -> ffmpeg arg list. Encodes with the hardware encoder when there is one; if that fails for
    any reason, encodes again with libx264, so hardware can only ever make a render faster, never break it.
    Returns the encoder name used."""
    name, args = hw_encoder(cfg)
    if name:
        try:
            ffmpeg(build(args), timeout=timeout)
            return name
        except Exception as e:
            log("video: %s failed (%s); using the software encoder" % (name, str(e)[:120]))
            _HW["pick"] = (None, None)          # don't keep trying a broken encoder this run
    ffmpeg(build(SW_FINAL), timeout=timeout)
    return "libx264"


def probe(path):
    """-> dict(width, height, duration, fps, has_audio)"""
    r = run(["ffprobe", "-v", "error", "-show_entries",
             "stream=codec_type,width,height,r_frame_rate:format=duration", "-of", "json", path])
    j = json.loads(r.stdout)
    v = next((s for s in j.get("streams", []) if s.get("codec_type") == "video"), {})
    a = any(s.get("codec_type") == "audio" for s in j.get("streams", []))
    num, _, den = (v.get("r_frame_rate") or "30/1").partition("/")
    fps = float(num) / float(den or 1) if float(den or 1) else 30.0
    return {"width": int(v.get("width") or 0), "height": int(v.get("height") or 0),
            "duration": float(j.get("format", {}).get("duration") or 0), "fps": fps, "has_audio": a}


def fpath(p):
    """Path as an ffmpeg filter option value (ass=filename=, drawtext=fontfile=, fontsdir=). Escaped for both
    levels ffmpeg parses (option value, then filtergraph), so Windows drives (C:), spaces, apostrophes
    (C:/Users/John's PC), commas and brackets all work. Use it UNQUOTED: filename=%s"""
    p = os.path.abspath(p).replace("\\", "/")
    p = "".join("\\" + c if c in "\\':" else c for c in p)          # level 1: option value
    return "".join("\\" + c if c in "\\'[],;" else c for c in p)    # level 2: filtergraph


def concat_path(p):
    """Path for an ffmpeg concat list: forward slashes, single-quoted, apostrophes escaped ('\\'')."""
    return "'%s'" % os.path.abspath(p).replace("\\", "/").replace("'", "'\\''")


def safe_remove(path):
    """Delete a temp file if the folder allows it (synced/mounted folders may refuse deletes)."""
    try:
        os.remove(path)
    except OSError:
        pass


def load_json(path, default):
    if not os.path.exists(path):
        return default
    with open(path) as f:
        txt = f.read().strip()
    return json.loads(txt) if txt else default


def save_json(path, obj, indent=1, backup=False):
    """Write JSON so a crash, a full disk or two threads saving at once never leave a half-written file:
    write a private temp file, flush it to disk, then swap it in. backup=True keeps the previous version as .bak."""
    import threading as _th
    data = json.dumps(obj, indent=indent)       # ASCII-only (\u escapes), so any reader on any OS decodes it; fails before touching the disk if obj is bad
    tmp = "%s.%d.%d.tmp" % (path, os.getpid(), _th.get_ident())
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(data)
            f.flush()
            try:
                os.fsync(f.fileno())
            except OSError:
                pass
        if backup and os.path.exists(path):
            try:
                import shutil
                shutil.copyfile(path, path + ".bak")
            except OSError:
                pass
        for i in range(6):                     # Windows: a reader holding the file open makes replace fail briefly
            try:
                os.replace(tmp, path)
                return
            except PermissionError:
                if i == 5:
                    raise
                time.sleep(0.05 * (i + 1))
    finally:
        if os.path.exists(tmp):
            try:
                os.remove(tmp)
            except OSError:
                pass


def load_store(path, default, kind=None):
    """Read a JSON store. A damaged file is set aside as <name>.broken-<time> (so nothing is silently overwritten and
    the data can be recovered) and the default is returned. kind (list/dict) also rejects the wrong shape."""
    if not os.path.exists(path):
        return default
    try:
        with open(path, encoding="utf-8") as f:
            txt = f.read().strip()
        val = json.loads(txt) if txt else default
        if kind is not None and not isinstance(val, kind):
            raise ValueError("expected %s" % kind.__name__)
        return val
    except (ValueError, UnicodeDecodeError) as e:
        bad = "%s.broken-%d" % (path, int(time.time()))
        n = 1
        while os.path.exists(bad):                # never replace an earlier damaged copy
            bad = "%s.broken-%d-%d" % (path, int(time.time()), n)
            n += 1
        try:
            os.replace(path, bad)
            log("%s was damaged (%s); kept it as %s and started fresh" % (os.path.basename(path), e, os.path.basename(bad)))
        except OSError:
            pass
        return default
    except OSError:
        return default


def load_config():
    cfg = load_json(CONFIG_PATH, {})
    cfg.setdefault("channels", [])
    cfg.setdefault("work_root", "~/Clipbot")
    wr = os.path.expanduser(os.environ.get("CLIPBOT_WORK_ROOT", cfg["work_root"]))
    parent = os.path.dirname(wr.rstrip("/")) or "/"
    if not (os.path.isdir(wr) and os.access(wr, os.W_OK)) and not os.access(parent, os.W_OK):
        wr = os.path.expanduser("~/Clipbot")       # e.g. the cloud default on a tester's laptop
    cfg["work_root"] = wr
    cfg.setdefault("whisper_model", "small")
    cfg.setdefault("max_height", 1080)
    cfg.setdefault("also_aspects", ["16:9"])      # every final render also gets a 1920x1080 landscape version
    cfg.setdefault("max_new_per_channel", 2)
    cfg.setdefault("max_download_attempts", 6)
    try:                                   # spellings the user taught by fixing words ("Fix it everywhere")
        learned = load_json(os.path.join(wr, "_settings", "vocab.json"), [])
        if learned:
            cfg["vocab"] = list(dict.fromkeys(list(cfg.get("vocab") or []) + [str(v) for v in learned][:300]))
    except Exception:
        pass
    return cfg


def load_state():
    st = load_json(STATE_PATH, {})
    st.setdefault("seen_video_ids", [])
    st.setdefault("pending", {})   # id -> {url, title, channel, attempts, last_error, first_seen}
    st.setdefault("failed", {})    # gave up after max attempts
    return st


def save_state(st):
    save_json(STATE_PATH, st)


def now_iso():
    return time.strftime("%Y-%m-%dT%H:%M:%S")

"""Candidate-moment finder.

Proposes sentence-snapped windows (never starts or ends mid-sentence) ranked by
transparent features, and writes candidates.md for the picker (you) to READ.
The ranking is a first-pass filter; final selection still uses the 5-trait filter
in title_and_style_playbook.md.

Fixes vs. the old scorer:
  * whole-word/phrase regex matching ("market cap" no longer scores as "no cap",
    "you" no longer scores as "yo", "applied" no longer scores as "lied")
  * phrase-dense windows no longer win just by containing more speech (rates, not sums)
  * audio energy is z-scored against a ROLLING baseline, so a stream that gets
    louder over time doesn't put every pick in the last hour
  * windows are scored as a whole (setup + payoff), with a bonus for ending on a beat
  * niche lexicons (crypto/trading, gaming, podcast) instead of one generic list
"""
import json
import os
import re
import wave

import numpy as np

from .common import ffmpeg, save_json
from .transcribe import sentences_from_words, ts

LEX = {
    "humor": r"haha+|ha ha|lol|lmao+|lmfao|i'?m dead|i'?m crying|hilarious|bruh+|no cap|deadass|"
             r"that'?s crazy|you'?re (?:so )?(?:wrong|funny)|stop it|i can'?t breathe|\(laugh\w*\)|\[laugh\w*\]",
    "drama": r"what the (?:hell|fuck|heck)|are you serious|how could you|you lied|liar|exposed|beef|"
             r"red flag|i'?m (?:so )?done|get out|kicked (?:me |him |her )?out|cops?|police|911|"
             r"scam(?:med|mer)?|stole|betray\w*|fight|argu\w+",
    "shock": r"no way|oh my (?:god|gosh)|holy (?:shit|crap|moly)|wait what|what\?!|watch this|wait for it|"
             r"guess what|out of nowhere|did (?:that|you) just|oh no|i almost (?:died|lost)|plot twist|"
             r"i can'?t believe|you won'?t believe|let'?s go+",
    "story": r"one time|true story|so (?:basically|i was)|i remember|turns out|and then|the craziest|"
             r"the worst|the best part|long story short|what happened was|swear to god",
    "events": r"gift(?:ed)? (?:\w+ )?subs?|\bsubs?\b|raid(?:ed|ing)?|donat\w+|super ?chat|bits|thank(?:s| you) for the|"
              r"(?:hype|bit) train|\bfollowers?\b|just (?:subbed|followed|donated)|\bmods?\b|banned|timed? ?out",
    # streamer reactions + "clip that": the moments chat clips (clipper guides; Twitch top-clip analysis)
    "reaction": r"clip (?:it|that|this)|somebody clip|chat,? (?:clip|look|did you see|is this real)|is this real|"
                r"(?:chat,? )?(?:are|did) (?:you|y'?all) (?:seeing|see) (?:this|that)|look at (?:this|that)(?: chat)?|"
                r"this is (?:actually )?(?:crazy|insane|unreal|wild)|"
                r"ain'?t no way|no shot|bro what|bro+ (?:is|what|really|stop|i swear)|what was that|"
                r"(?:he|she|they|we|i)'?(?:s|re|m)? (?:so |actually )?cooked|it'?s (?:so )?over|we'?re (?:so )?back|"
                r"i'?m (?:shaking|screaming|losing it|actually crying)|what is going on|are you kidding|you'?re joking|"
                r"nah+ (?:bro|man|bruh|dude)|goated|that'?s insane|i'?m done|let me cook|first try|"
                r"how did (?:that|he|she|you) (?:just )?|that did not just happen",
    # genuine rage (top performer per clippers; must be real, so it's one signal among many)
    "rage": r"are you (?:kidding|serious) me|i'?m (?:so )?(?:mad|pissed|tilted|heated)|this game is|rigged|uninstall\w*|"
            r"i hate (?:this|it|you|that)|bullshit|ridiculous|i quit|i'?m quitting|(?:trash|garbage) (?:game|team|teammates?)|"
            r"worst (?:game|team|teammates?|luck)|throw\w* (?:my|the) (?:controller|keyboard|mouse)|every single time",
    # uncomfortable/embarrassing moments - the most common thread in Twitch's most-watched clips
    "awkward": r"awkward|embarrass\w*|cringe|i'?m so sorry|why would (?:you|i|he|she)|what are you doing|"
               r"oh (?:god|lord) no|please stop|don'?t (?:clip|look at) (?:that|this|me)|delete (?:that|the clip)|"
               r"that'?s not what i (?:meant|said)|my bad|oops|i didn'?t mean|caught (?:me|him|her|in 4k)|"
               r"swat\w*|someone'?s (?:at|knocking on) the door|is (?:my|the) mic on|i forgot (?:the|my) (?:stream|mic|camera)",
    "stakes": r"\$\s?\d[\d,.]*\s?(?:k|m|million|thousand|grand)?|\b\d+(?:\.\d+)?\s?(?:k|m)\b|"
              r"\b\d[\d,]*\s?(?:million|thousand|grand|dollars|bucks)\b|\b\d+x\b|\b\d+%|"
              r"(?:a|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|fifteen|twenty|thirty|forty|"
              r"fifty|hundred)(?:[ -]\w+)?\s(?:hundred |thousand |million )?(?:thousand|million|grand|k|dollars|bucks)\b",
}
NICHE = {
    "crypto": r"rug(?:ged| pull)?|market ?cap|liquidity|aped|ape(?:d)? in|dump(?:ed|ing)?|pump(?:ed|ing)?|"
              r"10x|100x|whale|dev sold|bundled|insider|sniped?|jeet\w*|bag(?:holder|s)?|moon(?:ed|ing)?|"
              r"wallet|profit|loss|liquidat\w+|sold (?:the|at)|bought (?:the|at)|round ?trip\w*",
    "gaming": r"clutch|1v\d|ace|one tap|rage quit|griefing|speedrun|world record|bossfight|diff\b|gg\b",
    "podcast": r"the truth is|nobody talks about|unpopular opinion|hot take|the reason (?:why|is)|"
               r"here'?s the thing|the problem is|i disagree|you'?re wrong",
}
# stream housekeeping: never a highlight for a stranger (intros, sponsor reads, "hit follow", goodbyes).
CHROME = r"starting soon|welcome (?:back|in)(?: to the stream| chat| guys| everybody)?|what'?s (?:up|good) (?:chat|guys|everybody|y'?all)|" \
                   r"let me know in (?:the )?chat|hit (?:that )?(?:follow|subscribe|like)|make sure (?:you|to) (?:follow|subscribe)|" \
                   r"be right back|\bbrb\b|that'?s (?:it|all) for (?:today|tonight)|see (?:you|y'?all) (?:guys )?(?:tomorrow|next)|" \
                   r"(?:check out|link (?:is )?in) (?:my|the) (?:link|discord|bio|description)|use (?:my )?code|sponsored by|" \
                   r"today'?s sponsor|turn on notifications|prime sub"
FILLER = set("um uh uhh umm like yeah so okay ok you know i mean right basically literally".split())
WEIGHTS = {"humor": 2.4, "drama": 2.2, "shock": 1.8, "story": 1.4, "stakes": 1.6, "niche": 1.2,
           "events": 1.3, "lore": 1.8, "reaction": 1.9, "rage": 1.7, "awkward": 2.1, "burst": 1.5, "chat": 2.2, "rel": 0.0}
# "events": stream moments viewers clip (gifted subs, raids, donations, bans). "lore": the streamer's own running
# jokes, nicknames and recurring people (see lore.py) - callbacks are what fans share. "rel": prompt relevance
# (prompt_clip.py) is scored separately, not as a lexicon hit.


DANGLING = re.compile(r"^(?:and|but|because|which|like i said|as i said|anyway|also|plus|so yeah|that'?s why|"
                      r"same (?:thing|with)|exactly|right,)\b", re.I)


def _rx(p):
    return re.compile(r"(?<![\w$])(?:%s)(?![\w])" % p, re.I)


def voice_energy(src, workdir, hop=0.5):
    """Voice-band RMS per `hop` seconds, z-scored vs a rolling 5-minute median/MAD baseline."""
    wav = os.path.join(workdir, "voiceband.wav")
    if not os.path.exists(wav):
        ffmpeg(["-i", src, "-vn", "-ac", "1", "-ar", "8000",
                "-af", "highpass=f=250,lowpass=f=3400", wav])
    with wave.open(wav, "rb") as wf:
        sr = wf.getframerate()
        x = np.frombuffer(wf.readframes(wf.getnframes()), dtype=np.int16).astype(np.float32)
    n = int(sr * hop)
    if len(x) < n:
        return np.zeros(1), hop
    frames = x[: len(x) // n * n].reshape(-1, n)
    db = 20 * np.log10(np.sqrt((frames ** 2).mean(1)) + 1.0)
    k = int(300 / hop)
    z = np.zeros_like(db)
    for i in range(0, len(db), 20):  # baseline recomputed every 10s - cheap and smooth enough
        lo, hi = max(0, i - k // 2), min(len(db), i + k // 2)
        seg = db[lo:hi]
        voiced = seg[seg > np.percentile(seg, 30)]  # ignore silence when building the baseline
        med = np.median(voiced) if len(voiced) else np.median(seg)
        mad = np.median(np.abs(voiced - med)) * 1.4826 + 1.0 if len(voiced) else 3.0
        z[i:i + 20] = (db[i:i + 20] - med) / mad
    return z, hop


def find_candidates(words, src, workdir, niche=(), min_len=15.0, max_len=58.0, top_k=12, energy=None,
                    lore=None, relevance=None, rel_min=None, rel_weight=7.0, sents=None, pick=True,
                    kind_w=None, chat=None, sounds=None):
    """lore: [regex terms] from lore.py. relevance: per-sentence 0..1 match to a prompt (prompt_clip.py);
    with rel_min only windows containing a sentence at/above it are kept, ranked mostly by relevance."""
    sents = sents or sentences_from_words(words)
    if not sents:
        return []
    z, hop = energy if energy is not None else voice_energy(src, workdir)
    rx = {k: _rx(v) for k, v in LEX.items()}
    nrx = [_rx(NICHE[n]) for n in niche if n in NICHE]
    lrx = _rx("|".join(lore)) if lore else None

    crx = _rx(CHROME)
    # chat counts only as much as it is busy (see chat.trust); a quiet chat's "spikes" are noise
    chat_w = chat.trust() if chat is not None and hasattr(chat, "trust") else 1.0
    # the room: laughter / cheering heard on the stream (sounds.py), relative to THIS stream's own background, so a
    # quiet streamer's real laugh counts as much as a loud one's. Measured: a second with laughter outranks one
    # without 93% of the time even under talk + crowd noise (AUC 0.93).
    room = None
    if sounds and sounds.get("t"):
        T = np.asarray(sounds["t"], float)
        Lr = np.maximum(np.asarray(sounds["laugh"], float), 0.8 * np.asarray(sounds.get("cheer", sounds["laugh"]), float))
        med = float(np.median(Lr))
        top = max(med + 0.03, float(np.quantile(Lr, 0.97)))
        room = (T, np.clip((Lr - med) / (top - med), 0.0, 1.5))
    # audio reaction burst: how far the voice jumps above the previous ~6 s (a scream, a laugh, a shout).
    # Audio + facecam were the strongest highlight signals in stream-highlight research (Ringer et al. 2018).
    look = max(2, int(6.0 / hop))
    jump = np.zeros_like(z)
    for i in range(look, len(z)):
        jump[i] = z[i] - np.median(z[i - look:i])

    def e_at(a, b):
        i, j = int(a / hop), max(int(a / hop) + 1, int(b / hop))
        seg = z[i:j]
        return seg if len(seg) else np.zeros(1)

    # per-sentence features
    feats = []
    for s in sents:
        t = s["text"]
        f = {k: len(r.findall(t)) for k, r in rx.items()}
        f["niche"] = sum(len(r.findall(t)) for r in nrx)
        f["chrome"] = len(crx.findall(t))
        i0, i1 = int(s["start"] / hop), max(int(s["start"] / hop) + 1, int(s["end"] / hop))
        jb = float(jump[i0:i1].max()) if i1 <= len(jump) and i1 > i0 else 0.0
        f["burst"] = 1 if jb >= 3.0 else 0
        f["lore"] = len(lrx.findall(t)) if lrx else 0
        f["chat"], f["chat_z"], f["chat_mood"] = 0, 0.0, None
        if chat is not None:              # chat replay (chat.py): did the audience react right after this line?
            cz, mood = chat.reaction(s["start"], s["end"])
            f["chat_z"], f["chat_mood"] = round(cz, 2), mood
            f["chat"] = 1 if (cz >= 3.0 and chat_w > 0) else 0
        f["chat_w"] = chat_w
        f["laugh_rel"], f["laughs"] = 0.0, 0
        if room is not None:              # a laugh lands during the line or just after it (the reaction to it)
            m = (room[0] >= s["start"]) & (room[0] <= s["end"] + 2.5)
            if m.any():
                f["laugh_rel"] = round(float(room[1][m].max()), 2)
                f["laughs"] = 1 if f["laugh_rel"] >= 0.7 else 0
        f["rel"] = float(relevance[len(feats)]) if relevance is not None else 0.0
        toks = re.findall(r"[a-z']+", t.lower())
        f["n"] = len(toks)
        f["filler"] = sum(1 for w in toks if w in FILLER) / max(1, len(toks))
        f["uniq"] = len(set(toks)) / max(1, len(toks))
        f["prob"] = float(np.mean([(words[i][3] if len(words[i]) > 3 else 0.9) for i in range(s["w0"], s["w1"] + 1)]))
        f["q"] = t.rstrip().endswith("?")
        en = e_at(s["start"], s["end"])
        f["e_peak"] = float(np.percentile(en, 90))
        f["e_mean"] = float(en.mean())
        feats.append(f)

    def fluff(f):   # a sentence that is mostly filler and carries no signal
        return f["filler"] > 0.3 and not any(f[k] for k in WEIGHTS) and f["e_peak"] < 1.5

    cands = []
    for i in range(len(sents)):
        if fluff(feats[i]) and not (relevance is not None and feats[i]["rel"] >= (rel_min or 1)):
            continue                      # never open on filler
        j = i
        while j < len(sents) and sents[j]["end"] - sents[i]["start"] < min_len:
            j += 1
        while j < len(sents) and sents[j]["end"] - sents[i]["start"] <= max_len:
            if not fluff(feats[j]):       # never end on filler either
                c = _score_window(sents, feats, words, i, j, kind_w)
                if relevance is not None:
                    rels = [feats[k]["rel"] for k in range(i, j + 1)]
                    best = max(rels)
                    if rel_min is not None and best < rel_min:
                        pass
                    else:
                        kb = i + int(np.argmax(rels))
                        # relevant sentence early-to-middle is best (setup after it), not the very last line
                        pos = (kb - i) / max(1, j - i)
                        c["relevance"] = round(best, 3)
                        c["match"] = sents[kb]["text"]
                        c["match_at"] = round(sents[kb]["start"], 2)
                        c["match_pos"] = round(pos, 2)
                        c["quality_raw"] = c["score"]
                        c["score"] = round(c["score"] + rel_weight * best + 1.5 * float(np.mean(rels))
                                           - (3.0 if pos > 0.85 and j > i else 0.0) - (1.5 if pos < 0.15 and i > 0 and j - i >= 3 else 0.0), 2)
                        cands.append(c)
                else:
                    cands.append(c)
            # only also consider one/two longer extensions; keeps it O(n)
            if sents[j]["end"] - sents[i]["start"] > min_len + 14:
                break
            j += 1
    cands.sort(key=lambda c: -c["score"])
    if not pick:
        return cands
    picked = []
    for c in cands:
        if any(_overlap(c, p) > 0.25 for p in picked):
            continue
        picked.append(c)
        if len(picked) >= top_k:
            break
    for r, c in enumerate(picked, 1):
        c["rank"] = r
    return picked


def _overlap(a, b):
    inter = max(0.0, min(a["end"], b["end"]) - max(a["start"], b["start"]))
    return inter / min(a["end"] - a["start"], b["end"] - b["start"])


def _score_window(sents, feats, words, i, j, kind_w=None):
    fs = feats[i:j + 1]
    a, b = sents[i]["start"], sents[j]["end"]
    dur = b - a
    content = 0.0
    tags = {}
    for k, w in WEIGHTS.items():
        if not w:
            continue
        hits = sum(f[k] for f in fs)
        if hits:
            tags[k] = hits
        w *= (kind_w or {}).get(k, 1.0)        # learned from this streamer's best clips (style.py)
        content += w * (1 - 0.6 ** hits) * 3.0  # diminishing returns: 1 hit=1.2w, 3 hits=2.35w
    n = sum(f["n"] for f in fs)
    filler = sum(f["filler"] * f["n"] for f in fs) / max(1, n)
    uniq = np.mean([f["uniq"] for f in fs])
    prob = np.mean([f["prob"] for f in fs])
    rate = n / max(1.0, dur)
    peaks = [f["e_peak"] for f in fs]
    energy = max(0.0, float(np.mean(sorted(peaks)[-3:])))
    # payoff: the loudest/funniest beat should land in the back half, not the setup
    back = fs[len(fs) // 2:]
    payoff = 0.0
    if back:
        payoff += 0.8 * max(0.0, max(f["e_peak"] for f in back) - np.mean(peaks))
        payoff += 1.5 * sum(1 for f in back if f["humor"] or f["shock"] or f["reaction"] or f["awkward"])
        payoff += 0.8 * sum(1 for f in back if f["burst"])
        payoff += 1.2 * sum(f.get("chat_w", 1.0) for f in back if f.get("chat"))
        payoff += 1.6 * sum(min(1.0, f.get("laugh_rel", 0.0)) for f in back if f.get("laughs"))
    # hook: first sentence carries information (stakes/question/shock), not filler
    f0 = fs[0]
    hook = 1.2 * bool(f0["stakes"] or f0["shock"] or f0["q"] or f0["drama"] or f0["reaction"] or f0["rage"]
                      or f0["awkward"]) - 2.0 * (f0["filler"] > 0.35)
    # stranger test: an opening that leans on something we didn't see ("and then he...", "like I said")
    if DANGLING.match(sents[i]["text"].strip()):
        hook -= 0.8
    hook *= (kind_w or {}).get("_hook", 1.0)        # learned: this user marks slow starts down (learn.py)
    # dead air inside the window: long pauses, plus stretches where nobody is clearly talking (mumbling, background
    # chatter the speech model barely caught) - the "30 s of nothing" that used to score as a candidate
    gaps = [sents[k + 1]["start"] - sents[k]["end"] for k in range(i, j)]
    dead = sum(g for g in gaps if g > 1.5)
    dead += sum(sents[k]["end"] - sents[k]["start"] for k in range(i, j + 1) if feats[k]["prob"] < 0.45)
    talk = 1.0 - dead / max(1.0, dur)
    # tail: does the moment END cleanly (pause or laugh right after)?
    nxt = sents[j + 1]["start"] - b if j + 1 < len(sents) else 3.0
    tail = 0.8 if nxt > 0.7 else 0.0
    # payoff-first: where is the last beat (laugh / shock / reaction / burst / chat spike / loudest line)?
    beat = [k for k in range(i, j + 1) if feats[k]["humor"] or feats[k]["shock"] or feats[k]["reaction"]
            or feats[k]["awkward"] or feats[k]["burst"] or feats[k].get("chat") or feats[k].get("laughs")]
    loud = max(range(i, j + 1), key=lambda k: feats[k]["e_peak"])
    if feats[loud]["e_peak"] >= 1.5:
        beat.append(loud)
    after = (b - sents[max(beat)]["end"]) if beat else 0.0            # seconds of tail after the last beat
    tail_pen = 0.35 * max(0.0, after - 3.0)                              # trim tails hard
    # length: 15-25 s is the sweet spot; every second past 25 costs a little, past 45 a lot
    len_pen = 0.6 if dur < 15 else 0.08 * max(0.0, dur - 25) + 0.15 * max(0.0, dur - 45)
    # ends mid-sentence (no full stop / ! / ?): the clip cuts someone off
    cut_end = 0.5 if not re.search(r"[.!?…\]\)\"']\s*$", sents[j]["text"].strip()) else 0.0
    chrome = sum(f["chrome"] for f in fs)
    rep = 0.0 if uniq > 0.45 else 4.0  # whisper hallucination loops
    texts = [sents[k]["text"] for k in range(i, j + 1)]
    pm, nv = payoff_magnitude(texts), novelty_distinct(texts)
    score = (content + 1.1 * energy + payoff + hook + tail + 0.25 * min(rate, 4.0)
             + 0.35 * pm + 0.25 * nv
             - 3.0 * filler - 0.8 * dead - len_pen - rep - 3.0 * max(0.0, 0.55 - prob) - 2.5 * min(2, chrome)
             - tail_pen - cut_end - 3.0 * max(0.0, 0.7 - talk))
    return {"start": round(a, 2), "end": round(b, 2), "dur": round(dur, 1), "score": round(float(score), 2),
            "tags": tags, "energy": round(energy, 2), "hook": round(hook, 1), "payoff": round(payoff, 1),
            "dead_air": round(dead, 1), "asr_conf": round(float(prob), 2), "talk": round(float(talk), 2),
            "has_beat": bool(beat), "after_beat": round(after, 1), "cut_end": bool(cut_end),
            "payoff_mag": round(pm, 1), "novelty": round(nv, 1),
            "tail": bool(tail), "filler": round(float(filler), 2), "chrome": int(chrome),
            "chat_z": round(max([f.get("chat_z", 0.0) for f in fs] or [0.0]), 2),
            "room_laugh": round(max([f.get("laugh_rel", 0.0) for f in fs] or [0.0]), 2),
            "chat_mood": next((f["chat_mood"] for f in sorted(fs, key=lambda f: -f.get("chat_z", 0)) if f.get("chat_mood")), None),
            "dangling": bool(DANGLING.match(sents[i]["text"].strip())),
            "sentences": [(sents[k]["start"], sents[k]["text"]) for k in range(i, j + 1)]}


def write_candidates(cands, workdir, title=""):
    save_json(os.path.join(workdir, "candidates.json"), cands)
    lines = ["# Candidate moments%s" % (" - " + title if title else ""), "",
             "First-pass ranking only. Read each one; keep the ones that pass the 5-trait filter",
             "(resolves, standalone, provokes, legible in frame 1, rewatchable). Trim with exact",
             "word times from words.json. Full text: transcript.txt.", ""]
    for c in cands:
        lines.append("## #%d  %s-%s  (%.0fs)  score %.1f" % (c["rank"], ts(c["start"]), ts(c["end"]), c["dur"], c["score"]))
        lines.append("tags: %s | energy %.1f | hook %.1f | payoff %.1f | payoff-mag %.1f/10 | novelty %.1f/10 | "
                     "dead air %.1fs | asr %.2f" % (
            ", ".join("%s×%d" % kv for kv in c["tags"].items()) or "-", c["energy"], c["hook"], c["payoff"],
            c.get("payoff_mag", 0), c.get("novelty", 0), c["dead_air"], c["asr_conf"]))
        lines.append("spec: \"start\": %.2f, \"end\": %.2f" % (c["start"], c["end"]))
        for t, s in c["sentences"]:
            lines.append("> [%s] %s" % (ts(t), s))
        lines.append("")
    p = os.path.join(workdir, "candidates.md")
    open(p, "w").write("\n".join(lines))
    return p


# ---------------------------------------------------------------- Muse-derived signals
# Adapted from Magic Clips (Muse) moment_signals.py. In Muse's held-out tests these were the
# two best STANDALONE signals; adding them to a scorer was never shown to beat noise, so they get
# a minority weight here and are printed separately in candidates.md for the picker to judge.
OUTCOME = re.compile(r"\b(won|wins|beat|beats|destroyed|proved|revealed|landed|hit|scored|pulled (it )?off|did it|"
                     r"made it|worked|failed|lost|lost it|admitted|exposed|caught|busted|saved|escaped|survived|"
                     r"finished|completed|got (him|her|them|it)|knocked (out|down)|clutched|rugged|dumped|sold|"
                     r"bought|10x(?:'?d)?|100x(?:'?d)?|went to|hit \d)\b", re.I)
REVEAL = re.compile(r"\b(turns out|plot twist|but then|suddenly|the truth is|here'?s what happened|that'?s why|"
                    r"that'?s how|it turns out|in the end|finally|at the last second)\b", re.I)
RESOLUTION = re.compile(r"\b(because|so (he|she|they|it|we)|which means|and then|so in the end)\b", re.I)
COMPLICATION = re.compile(r"\b(but|however|problem|struggl\w*|failed|lost|too late|hard|stuck|wrong|against)\b", re.I)
SETUP = re.compile(r"\?|\b(vs\.?|versus|beef|exposed|fake|fight|argu\w+|wait for it|here'?s why|you won'?t believe|"
                   r"guess what|one time|so i)\b", re.I)
NUMBER = re.compile(r"\$?\b\d+(?:[.,]\d+)?\s?(?:k|m|x|%)?\b|\b(?:hundred|thousand|million|billion)\b", re.I)
COMMON = set("""I The A An And But So Then This That It He She They We You My Our Your Oh Yeah Okay No Yes What Why How
When Where Who Like Just Well Now Bro Dude Guys Wait Look Okay Let Lets Let's Right""".split())


def _named(text):
    out = set()
    for sent in re.split(r"(?<=[.!?])\s+", text):
        toks = sent.split()
        for t in toks[1:]:
            w = re.sub(r"[^\w$]", "", t)
            if w[:1].isupper() and w not in COMMON and len(w) > 1:
                out.add(w)
    return out


def payoff_magnitude(sentences):
    """0..10: distinct outcome surfaces in the back 60%, numbers there, and
    setup -> complication -> resolution in order. Capped at 2 with no outcome at all."""
    if not sentences:
        return 0.0
    k = max(1, int(len(sentences) * 0.4))
    back = " ".join(sentences[k:]) if len(sentences) > 1 else sentences[0]
    surf = {m.group(0).lower() for r in (OUTCOME, REVEAL) for m in r.finditer(back)}
    mag = min(6.0, 2.0 * len(surf)) + min(2.0, 0.5 * len({m.group(0).lower() for m in NUMBER.finditer(back)}))
    n = len(sentences)
    t = max(1, -(-n // 3))
    first, mid, last = sentences[:t], sentences[t:2 * t], sentences[2 * t:]
    if (any(SETUP.search(x) for x in first) and any(COMPLICATION.search(x) for x in mid)
            and any(OUTCOME.search(x) or REVEAL.search(x) or RESOLUTION.search(x) for x in last)):
        mag += 2.0
    return min(10.0, mag) if surf else min(2.0, mag)


def novelty_distinct(sentences):
    """0..10: distinct payoff surfaces + named specifics + numbers, minus a penalty when one
    phrase dominates (repetition / ASR loops are not novelty)."""
    text = " ".join(sentences)
    counts = {}
    for r in (OUTCOME, REVEAL, RESOLUTION):
        for m in r.finditer(text):
            counts[m.group(0).lower()] = counts.get(m.group(0).lower(), 0) + 1
    sc = min(6.0, 1.5 * len(counts)) + min(2.0, 0.5 * len(_named(text))) + \
        min(2.0, 0.5 * len({m.group(0).lower() for m in NUMBER.finditer(text)}))
    tot = sum(counts.values())
    if tot and max(counts.values()) / tot > 0.5 and tot > 1:
        sc -= 2.0
    return max(0.0, min(10.0, sc))

"""VOD chat replay -> "chat exploded here" signal for auto-clip.

When chat suddenly floods (KEKW, LUL, W, "???", 💀...) a few seconds after something happens, that's the clearest
sign a moment landed with the audience - the same signal live clipping already uses (live.py). For VODs:

  fetch(url, workdir)   tries to get the replay chat automatically:
                          YouTube   yt-dlp's live_chat replay (streams/premieres that had live chat)
                          Twitch    Twitch's public comment feed (best effort - Twitch can refuse it)
                          Kick      not available automatically -> drop a chat file instead
  parse(path)           reads a chat file: yt-dlp live_chat.json, TwitchDownloader .json (the tool most
                        clippers already use), or a simple CSV/TXT of "time, message" lines
  Activity(msgs, dur)   per-second message rate + laugh/hype/shock emote counts, and spike() for a window

Chat lags what happened on stream by a few seconds, so a sentence is credited with the chat reaction that arrives
from 1 s to 8 s after it ends - and not with a spike that was already under way when it started.
"""
import csv
import io
import json
import os
import re
import urllib.request

import numpy as np

from .common import log, save_json

LAUGH = re.compile(r"\b(?:kekw|lul[sw]?|omegalul|lmf?ao+|lo+l+|haha+|xd+|icant|pepelaugh|kekl|lulw|dead)\b|😂|🤣|💀",
                   re.I)
HYPE = re.compile(r"(?:^|\s)(?:w+|pog(?:gers|champ|u)?|letsgo+|lets go+|clip (?:it|that)|clipped|goat(?:ed)?|"
                  r"insane|holy|sheesh)(?=\s|$|!)|🔥|🐐", re.I)
SHOCK = re.compile(r"\?{2,}|\b(?:wtf|what+|monkas|omg|nah+|bro+)\b|😳|😱|\bd:", re.I)
LAG = (1.0, 8.0)             # chat reacts this long after the moment (stream delay + typing)


# ------------------------------------------------------------------ parsing
def _yt_lines(lines):
    out = []
    for line in lines:
        try:
            j = json.loads(line)
        except ValueError:
            continue
        r = j.get("replayChatItemAction") or {}
        off = r.get("videoOffsetTimeMsec")
        if off is None:
            continue
        for a in r.get("actions") or []:
            item = ((a.get("addChatItemAction") or {}).get("item") or {})
            m = item.get("liveChatTextMessageRenderer") or item.get("liveChatPaidMessageRenderer") or {}
            runs = (m.get("message") or {}).get("runs") or []
            txt = "".join(x.get("text") or ((x.get("emoji") or {}).get("shortcuts") or [""])[0] for x in runs)
            if txt or item.get("liveChatPaidMessageRenderer"):
                out.append((float(off) / 1000.0, txt or "[super chat]"))
    return out


def _clock(s):
    p = [float(x) for x in s.split(":")]
    t = 0.0
    for x in p:
        t = t * 60 + x
    return t


def parse(path):
    """-> sorted [(seconds_from_start, text)]. Raises ValueError if the file isn't a chat log we understand."""
    raw = open(path, "rb").read()
    txt = raw.decode("utf-8", "replace").lstrip("﻿")
    msgs = []
    head = txt[:2000]
    if "replayChatItemAction" in head:
        msgs = _yt_lines(txt.splitlines())
    else:
        j = None
        try:
            j = json.loads(txt)
        except ValueError:
            pass
        if isinstance(j, dict) and isinstance(j.get("comments"), list):        # TwitchDownloader / Twitch GQL dump
            for c in j["comments"]:
                t = c.get("content_offset_seconds")
                body = (c.get("message") or {}).get("body")
                if body is None:
                    body = "".join(f.get("text", "") for f in (c.get("message") or {}).get("fragments") or [])
                if t is not None:
                    msgs.append((float(t), body or ""))
        elif isinstance(j, list):                                            # [{"t": 12.3, "text": "..."}]
            for c in j:
                if not isinstance(c, dict):
                    continue
                t = next((c[k] for k in ("t", "time", "offset", "seconds", "content_offset_seconds") if k in c), None)
                body = next((c[k] for k in ("text", "message", "body", "content") if k in c), "")
                if t is not None:
                    msgs.append((_clock(t) if isinstance(t, str) else float(t), str(body)))
        else:                                                                  # CSV / TXT lines
            line_rx = re.compile(r"^\s*\[?(\d+(?::\d{1,2}){0,2}(?:\.\d+)?)\]?\s*[,\t ]\s*(.*)$")
            rows = list(csv.reader(io.StringIO(txt))) if txt.count(",") > txt.count("\n") * 0.5 else None
            for line in (",".join(r) for r in rows) if rows else txt.splitlines():
                m = line_rx.match(line)
                if m:
                    msgs.append((_clock(m.group(1)), m.group(2)))
    if not msgs:
        raise ValueError("couldn't read any chat messages from %s (use a TwitchDownloader .json, a YouTube "
                         "live_chat.json, or lines like '0:01:23, message')" % os.path.basename(path))
    msgs.sort(key=lambda m: m[0])
    return msgs


def shift(msgs, offset, length=None):
    """Messages for a trimmed section: subtract its start; drop what falls outside."""
    out = [(t - offset, s) for t, s in msgs if t >= offset and (length is None or t - offset <= length + LAG[1])]
    return out


# ------------------------------------------------------------------ signal
class Activity:
    def __init__(self, msgs, dur=None):
        self.n = len(msgs)
        end = int(max(dur or 0, (msgs[-1][0] if msgs else 0))) + 2
        self.rate = np.zeros(end)
        self.laugh = np.zeros(end)
        self.hype = np.zeros(end)
        self.shock = np.zeros(end)
        for t, s in msgs:
            i = int(t)
            if 0 <= i < end:
                self.rate[i] += 1
                self.laugh[i] += bool(LAUGH.search(s))
                self.hype[i] += bool(HYPE.search(s))
                self.shock[i] += bool(SHOCK.search(s))
        k = np.ones(4) / 4.0
        self.smooth = np.convolve(self.rate, k, mode="same")
        # baseline: what chat normally looks like over the previous ~2 minutes (robust to earlier spikes)
        self.base = np.zeros(end)
        self.spread = np.ones(end)
        for i in range(end):
            w = self.smooth[max(0, i - 120):max(1, i - 5)]
            med = float(np.median(w)) if len(w) else 0.0
            mad = float(np.median(np.abs(w - med))) if len(w) else 0.0
            self.base[i] = med
            self.spread[i] = max(1.4826 * mad, 0.5, 0.35 * med)

    def z(self, a, b):
        i, j = max(0, int(a)), min(len(self.smooth), int(b) + 1)
        if j <= i:
            return 0.0
        return float(np.max((self.smooth[i:j] - self.base[i:j]) / self.spread[i:j]))

    def reaction(self, a, b):
        """Chat's reaction to something said in [a, b]: (spike z, dominant mood or None)."""
        lo, hi = a + LAG[0], b + LAG[1]
        z = self.z(lo, hi)
        if z >= 3.0 and self.z(a - 1, a) >= 0.6 * z:
            z = 0.0                       # chat was already exploding before this line began: not its reaction
        i, j = max(0, int(lo)), min(len(self.rate), int(hi) + 1)
        tot = float(self.rate[i:j].sum())
        if tot < 4:                       # two messages in a quiet chat is a "spike" statistically, not a reaction
            z = 0.0
        mood = None
        if tot >= 5:
            shares = {"laugh": self.laugh[i:j].sum() / tot, "hype": self.hype[i:j].sum() / tot,
                      "shock": self.shock[i:j].sum() / tot}
            k = max(shares, key=shares.get)
            mood = k if shares[k] >= 0.25 else None
        return z, mood

    def trust(self):
        """How much chat should count, 0..1, by how busy it is: a small streamer's chat (a few messages a minute)
        is too sparse to tell a reaction from noise, so the on-stream reaction (voice, laughter, words) decides."""
        per_min = 60.0 * self.n / max(1, len(self.rate))
        return float(min(1.0, max(0.0, (per_min - 3.0) / 27.0)))

    def summary(self):
        return {"messages": self.n, "per_min": round(60.0 * self.n / max(1, len(self.rate)), 1),
                "trust": round(self.trust(), 2)}


# ------------------------------------------------------------------ fetching
TW_CLIENT = "kimne78kx3ncx6brgo4mv6wki5h1ko"           # Twitch's public web client id
TW_HASH = "b70a3591ff0f4e0313d126c6a1502d79a1c02baebb288227c582044aa76adf6a"


def _twitch_vod_id(url):
    m = re.search(r"twitch\.tv/(?:videos/|\w+/v/|\w+/video/)(\d+)", url)
    return m.group(1) if m else None


def fetch_twitch(vod, out, max_pages=4000, timeout=20):
    comments, cursor, pages = [], None, 0
    while pages < max_pages:
        var = {"videoID": vod}
        if cursor:
            var["cursor"] = cursor
        else:
            var["contentOffsetSeconds"] = 0
        body = [{"operationName": "VideoCommentsByOffsetOrCursor", "variables": var,
                 "extensions": {"persistedQuery": {"version": 1, "sha256Hash": TW_HASH}}}]
        req = urllib.request.Request("https://gql.twitch.tv/gql", data=json.dumps(body).encode(), method="POST",
                                     headers={"Client-ID": TW_CLIENT, "Content-Type": "text/plain;charset=UTF-8",
                                              "User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            j = json.loads(r.read())
        if isinstance(j, list):
            j = j[0]
        if j.get("errors"):
            raise RuntimeError("Twitch refused the chat request: %s" % str(j["errors"])[:160])
        edges = ((((j.get("data") or {}).get("video") or {}).get("comments") or {}).get("edges")) or []
        for e in edges:
            n = e.get("node") or {}
            comments.append({"content_offset_seconds": n.get("contentOffsetSeconds"),
                             "message": {"body": "".join(f.get("text", "") for f in (n.get("message") or {}).get("fragments") or [])}})
        info = ((((j.get("data") or {}).get("video") or {}).get("comments") or {}).get("pageInfo")) or {}
        pages += 1
        if not edges or not info.get("hasNextPage"):
            break
        cursor = edges[-1].get("cursor")
        if not cursor:
            break
    if not comments:
        raise RuntimeError("Twitch returned no chat for this VOD")
    save_json(out, {"comments": comments}, indent=None)
    return out


def fetch(url, workdir, cfg=None):
    """Try to download the VOD's chat replay. Returns (path|None, note)."""
    os.makedirs(workdir, exist_ok=True)
    have = find(workdir)
    if have:
        return have, "chat file found"
    if not url or not url.startswith("http"):
        return None, "no chat file"
    try:
        if "youtu" in url:
            from .common import run
            from .fetch import _ytdlp_base
            cmd = _ytdlp_base(cfg or {}) + ["--skip-download", "--write-subs", "--sub-langs", "live_chat",
                                           "--no-playlist", "-o", os.path.join(workdir, "chat.%(ext)s"), url]
            run(cmd, timeout=1800, check=False)
            p = os.path.join(workdir, "chat.live_chat.json")
            if os.path.exists(p) and os.path.getsize(p) > 100:
                return p, "YouTube chat replay"
            return None, "this YouTube video has no chat replay"
        vod = _twitch_vod_id(url)
        if vod:
            return fetch_twitch(vod, os.path.join(workdir, "chat.twitch.json")), "Twitch chat replay"
        if "kick.com" in url:
            return None, "Kick chat replay can't be downloaded automatically - add a chat file to use it"
    except Exception as e:
        log("chat replay unavailable: %s" % str(e)[:160])
        return None, "chat replay unavailable (%s)" % str(e)[:100]
    return None, "no chat replay for this link"


def find(workdir):
    for f in ("chat.json", "chat.txt", "chat.csv", "chat.twitch.json", "chat.live_chat.json"):
        p = os.path.join(workdir, f)
        if os.path.exists(p) and os.path.getsize(p) > 0:
            return p
    return None


def load(workdir, url=None, cfg=None, section=None, dur=None):
    """Everything autoclip needs: (Activity|None, status dict). Never raises."""
    try:
        p, note = fetch(url, workdir, cfg)
        if not p:
            return None, {"used": False, "note": note}
        msgs = parse(p)
        if section:
            msgs = shift(msgs, section[0], (section[1] - section[0]) if section[1] else None)
        if len(msgs) < 30:
            return None, {"used": False, "note": "too little chat to use (%d messages)" % len(msgs)}
        a = Activity(msgs, dur)
        return a, dict(a.summary(), used=True, note=note)
    except Exception as e:
        return None, {"used": False, "note": str(e)[:200]}

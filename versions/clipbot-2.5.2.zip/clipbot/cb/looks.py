"""Faces: the reactions you SEE - the look to camera, the double take, the side-eye, a face that drops into shock,
disgust or a big laugh.

Expressions come from HSEmotion (EfficientNet-B0 trained on AffectNet, Apache 2.0; 8 classes). Our pipeline
reproduces the library's own test labels exactly (Happiness, Anger, Fear on its 3-face test photo). Where a face is
pointing comes from the 5 face landmarks YuNet already finds (eyes, nose, mouth corners): no extra model.

analyze(src, a, b, fps=3) -> {"beats": [{"t", "kind", "strength", "detail"}], "score": 0..3, "faces": n}
  kinds: "look_to_camera" (turned away >= 1 s, then straight into the lens), "double_take" (a sudden head snap),
         "side_look" (turns to the other person while staying quiet), "face" (a sharp change into surprise /
         disgust / contempt / fear / a big laugh, against that same face's own resting look in the window)
Expressions are judged against each face's own baseline, so a naturally intense face doesn't always "react".
"""
import os

import numpy as np

from .common import ROOT, YUNET, log

MODEL = os.path.join(ROOT, "assets", "models", "hsemotion_enet_b0_8.onnx")
NAMES = ["anger", "contempt", "disgust", "fear", "happiness", "neutral", "sadness", "surprise"]
REACT = {"surprise": 1.0, "disgust": 0.9, "contempt": 0.9, "fear": 0.7, "happiness": 0.6, "anger": 0.5}
RISE, MIN_P = 0.45, 0.6         # how far above the face's resting look, and how sure, an expression must be
MEAN = np.array([0.485, 0.456, 0.406], np.float32)
STD = np.array([0.229, 0.224, 0.225], np.float32)
_SESS = None


def available():
    if not os.path.exists(MODEL):
        return False
    try:
        import onnxruntime  # noqa: F401
        return True
    except Exception:
        return False


def _session():
    global _SESS
    if _SESS is None:
        import onnxruntime as ort
        so = ort.SessionOptions()
        so.intra_op_num_threads = max(1, min(4, (os.cpu_count() or 2) - 1))
        so.log_severity_level = 3
        _SESS = ort.InferenceSession(MODEL, so, providers=["CPUExecutionProvider"])
    return _SESS


def expressions(img_bgr, boxes):
    """Softmax over the 8 expressions for each (x, y, w, h) face box in a BGR frame."""
    import cv2
    if not boxes:
        return np.zeros((0, 8), np.float32)
    H, W = img_bgr.shape[:2]
    batch = []
    for x, y, w, h in boxes:
        x0, y0 = max(0, int(x)), max(0, int(y))
        crop = img_bgr[y0:min(H, int(y + h)), x0:min(W, int(x + w))]
        if crop.size == 0:
            crop = np.zeros((8, 8, 3), np.uint8)
        t = cv2.resize(cv2.cvtColor(crop, cv2.COLOR_BGR2RGB), (224, 224)).astype(np.float32) / 255.0
        batch.append(((t - MEAN) / STD).transpose(2, 0, 1))
    s = _session()
    logits = s.run(None, {s.get_inputs()[0].name: np.stack(batch).astype(np.float32)})[0]
    e = np.exp(logits - logits.max(1, keepdims=True))
    return e / e.sum(1, keepdims=True)


def head_turn(lm):
    """Signed yaw proxy from YuNet's 5 landmarks: ~0 facing the camera, about +-0.3 and beyond clearly turned.
    lm = [rx, ry, lx, ly, nx, ny, rmx, rmy, lmx, lmy] (right eye, left eye, nose, mouth corners)."""
    rx, ry, lx, ly, nx, ny = lm[:6]
    eye_d = max(1e-3, np.hypot(lx - rx, ly - ry))
    return float((nx - (rx + lx) / 2.0) / eye_d)


def _track(dets, prev, maxd):
    """Assign this frame's faces to running tracks by nearest centre."""
    out = {}
    used = set()
    for tid, (cx, cy) in prev.items():
        best, bi = maxd, None
        for i, d in enumerate(dets):
            if i in used:
                continue
            dd = np.hypot(d["cx"] - cx, d["cy"] - cy)
            if dd < best:
                best, bi = dd, i
        if bi is not None:
            used.add(bi)
            out[tid] = bi
    nxt = max(prev.keys(), default=-1) + 1
    for i in range(len(dets)):
        if i not in used:
            out[nxt] = i
            nxt += 1
    return out


def analyze(src, a, b, fps=3.0, max_faces=3, speech=None):
    """Visual reaction beats in [a, b] seconds of a video. speech: optional [(start, end)] when someone talks
    (a turn toward the other person only counts as a side look if this face's track is quiet then - optional)."""
    import cv2
    if not available():
        return {"beats": [], "score": 0.0, "faces": 0, "note": "face model missing"}
    cap = cv2.VideoCapture(src)
    if not cap.isOpened():
        return {"beats": [], "score": 0.0, "faces": 0, "note": "can't open video"}
    W0, H0 = cap.get(cv2.CAP_PROP_FRAME_WIDTH), cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
    aw = 640
    ah = int(round(aw * H0 / max(1.0, W0)))
    det = cv2.FaceDetectorYN.create(YUNET, "", (aw, ah), 0.7, 0.3, 5000)
    tracks = {}                                       # tid -> list of (t, yaw, probs, cx)
    prev = {}
    src_fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    cap.set(cv2.CAP_PROP_POS_MSEC, max(0.0, a) * 1000.0)     # one seek, then read straight through (seeking per
    i = 0                                                     # sample re-decodes from the keyframe every time)
    t0 = cap.get(cv2.CAP_PROP_POS_MSEC) / 1000.0 or a
    want = a
    while True:
        t = t0 + i / src_fps
        if t > b or not cap.grab():
            break
        i += 1
        if t + 1e-6 < want:
            continue
        want += 1.0 / fps
        ok, img = cap.retrieve()
        if not ok:
            break
        small = cv2.resize(img, (aw, ah))
        _, faces = det.detect(small)
        fs = sorted([f for f in (faces if faces is not None else []) if f[3] > 0.06 * ah], key=lambda f: -f[2] * f[3])
        fs = fs[:max_faces]
        dets = [{"cx": f[0] + f[2] / 2, "cy": f[1] + f[3] / 2, "box": f[:4], "lm": f[4:14]} for f in fs]
        probs = expressions(small, [d["box"] for d in dets]) if dets else []
        assign = _track(dets, prev, maxd=0.25 * aw)
        prev = {}
        for tid, k in assign.items():
            d = dets[k]
            tracks.setdefault(tid, []).append((round(t, 2), head_turn(d["lm"]), probs[k], float(d["cx"])))
            prev[tid] = (d["cx"], d["cy"])
    cap.release()
    beats = []
    for tid, rows in tracks.items():
        if len(rows) < 3:
            continue
        ts = np.array([r[0] for r in rows])
        yaw = np.array([r[1] for r in rows])
        P = np.stack([r[2] for r in rows])
        # expression change against this face's own resting look (its median over the window). Talking mouths read
        # as "surprise" to expression models, so a beat must HOLD for ~1 s, rise clearly above the resting look,
        # and the open-mouth kinds (surprise, fear) only count when the voice model hasn't heard this person talking.
        base = np.median(P, 0)
        hold = max(2, int(round(fps * 0.9)))
        for name, w in REACT.items():
            k = NAMES.index(name)
            rise = (P[:, k] - base[k]) * w
            on = (rise >= RISE) & (P[:, k] >= MIN_P)
            if name in ("surprise", "fear") and speech:
                on &= ~np.array([any(sa - 0.2 <= t_ <= se + 0.2 for sa, se in speech) for t_ in ts])
            j = 0
            while j < len(on):
                if on[j]:
                    e = j
                    while e + 1 < len(on) and on[e + 1]:
                        e += 1
                    if e - j + 1 >= hold:
                        beats.append({"t": float(ts[j]), "kind": "face", "detail": name,
                                      "strength": round(min(1.0, float(rise[j:e + 1].max()) / 0.7), 2)})
                    j = e + 1
                else:
                    j += 1
        # looks: where the head points over time
        step = max(1, int(round(fps * 0.5)))
        for j in range(len(rows)):
            if j >= step and abs(yaw[j] - yaw[j - step]) >= 0.35:
                beats.append({"t": float(ts[j]), "kind": "double_take", "strength": round(min(1.0, abs(yaw[j] - yaw[j - step]) / 0.6), 2),
                              "detail": "head snap"})
            k1 = int(round(fps * 1.0))
            if j >= k1 and abs(yaw[j]) <= 0.1 and np.all(np.abs(yaw[j - k1:j]) >= 0.22):
                beats.append({"t": float(ts[j]), "kind": "look_to_camera", "strength": 1.0, "detail": "looks into the lens"})
        if len(tracks) >= 2:                              # turning toward someone else in the shot
            others = [np.mean([r[3] for r in rr]) for k, rr in tracks.items() if k != tid and len(rr) >= 3]
            if others:
                me = np.mean([r[3] for r in rows])
                toward = 1.0 if np.mean(others) > me else -1.0   # +yaw = nose toward image right (a proxy)
                for j in range(1, len(rows)):
                    if yaw[j] * toward >= 0.3 and yaw[j - 1] * toward < 0.15:
                        beats.append({"t": float(ts[j]), "kind": "side_look", "strength": 0.6, "detail": "turns to the other person"})
    beats.sort(key=lambda x: x["t"])
    # de-duplicate beats of the same kind within 1 s
    out = []
    for x in beats:
        if out and out[-1]["kind"] == x["kind"] and x["t"] - out[-1]["t"] < 1.0:
            if x["strength"] > out[-1]["strength"]:
                out[-1] = x
            continue
        out.append(x)
    w = {"look_to_camera": 1.0, "double_take": 0.8, "face": 0.9, "side_look": 0.4}
    score = min(3.0, sum(w[x["kind"]] * x["strength"] for x in out))
    return {"beats": out, "score": round(score, 2), "faces": len(tracks)}


def rerank(cands, src, top=24, fps=3.0, words=None):
    """Add visual reaction beats to the best `top` candidates (only those: the rest of a long stream isn't scanned).
    A beat in the back half of a clip counts as part of its payoff. words: the transcript, so open-mouth
    expressions while someone is talking aren't mistaken for shock."""
    if not available() or not src or not os.path.exists(src):
        return cands
    speech = []
    for w in words or []:                       # merge words into talking stretches
        if speech and w[0] - speech[-1][1] < 0.5:
            speech[-1][1] = w[1]
        else:
            speech.append([w[0], w[1]])
    for c in cands[:top]:
        try:
            sp = [s for s in speech if s[1] >= c["start"] - 1 and s[0] <= c["end"] + 2]
            r = analyze(src, c["start"], c["end"] + 1.0, fps=fps, speech=sp)
        except Exception as e:
            log("faces skipped for a candidate (%s)" % str(e)[:80])
            continue
        mid = (c["start"] + c["end"]) / 2.0
        back = [x for x in r["beats"] if x["t"] >= mid]
        c["looks"] = {"beats": r["beats"][:8], "score": r["score"],
                      "back": round(min(3.0, sum(x["strength"] for x in back)), 2)}
    return cands

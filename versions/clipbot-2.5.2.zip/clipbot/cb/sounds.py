"""Hear the room: laughter, cheering, applause, screaming and shouting, second by second.

A small audio-tagging network (EfficientAT mn10, MIT licence; 4.9M parameters, AudioSet mAP 47.1) listens to the
stream and says when people laugh, cheer, clap or scream. That's the payoff signal that doesn't depend on chat - the
best signal for smaller streamers whose chat is a few messages a minute - and it catches the real reaction even when
nobody says "haha".

timeline(path_or_wav, hop=1.0) -> {"t": [...], "laugh": [...], "cheer": [...], "scream": [...], "shout": [...]}
   one value (0..1, the network's probability) per `hop` seconds, each from a 6 s window centred on that second.
reaction_at(tl, a, b) -> the strongest reaction inside [a, b] (0..1) and which kind.
Model: assets/models/efficientat_mn10.onnx (converted from the authors' AudioSet weights; outputs match PyTorch to
2e-6). Front end: assets/models/efficientat_mel.npy (the Kaldi mel filterbank the network was trained with).
"""
import os

import numpy as np

from .common import ROOT, log

MODEL = os.path.join(ROOT, "assets", "models", "efficientat_mn10.onnx")
MEL = os.path.join(ROOT, "assets", "models", "efficientat_mel.npy")
SR, N_FFT, WIN, HOP = 32000, 1024, 800, 320          # 100 mel frames per second
WINDOW_S = 6.0            # the network was trained on 10 s clips; under ~3.5 s its answers fall apart (measured)

# AudioSet class indices (metadata/class_labels_indices.csv)
CLASSES = {"laugh": [16, 18, 20, 21],                 # Laughter, Giggle, Belly laugh, Chuckle/chortle
           "cheer": [66, 67],                         # Cheering, Applause
           "scream": [14],                            # Screaming
           "shout": [8, 11]}                          # Shout, Yell
_SESS = None


def available():
    if not (os.path.exists(MODEL) and os.path.exists(MEL)):
        return False
    try:
        import onnxruntime  # noqa: F401
        return True
    except Exception:
        return False


def _session():
    global _SESS
    if _SESS is None:
        import onnxruntime as ort
        so = ort.SessionOptions()
        so.intra_op_num_threads = max(1, min(4, (os.cpu_count() or 2) - 1))
        so.log_severity_level = 3
        _SESS = ort.InferenceSession(MODEL, so, providers=["CPUExecutionProvider"])
    return _SESS


def kaldi_mel_banks(n_mels=128, n_fft=N_FFT, sr=SR, fmin=0.0, fmax=15000.0):
    """torchaudio.compliance.kaldi.get_mel_banks (no VTLN warp), padded with one zero column -> (n_mels, n_fft//2+1)"""
    mel = lambda f: 1127.0 * np.log(1.0 + np.asarray(f, np.float64) / 700.0)
    nb = n_fft // 2
    lo, hi = mel(fmin), mel(fmax)
    delta = (hi - lo) / (n_mels + 1)
    b = np.arange(n_mels)[:, None]
    left, center, right = lo + b * delta, lo + (b + 1) * delta, lo + (b + 2) * delta
    m = mel(sr / float(n_fft) * np.arange(nb))[None, :]
    up = (m - left) / (center - left)
    down = (right - m) / (right - center)
    bank = np.maximum(0.0, np.minimum(up, down))
    return np.pad(bank, ((0, 0), (0, 1))).astype(np.float32)


def melspec(x):
    """Waveform (32 kHz float) -> normalised log-mel (128, frames), the same as the authors' AugmentMelSTFT in eval."""
    x = np.asarray(x, np.float32)
    # dither: real recordings always have a noise floor; perfect digital silence (muted mic, padded files) is
    # something the network never heard and answers with nonsense. ~-80 dBFS, inaudible.
    x = x + np.random.default_rng(len(x)).standard_normal(len(x)).astype(np.float32) * 1e-4
    x = x[1:] - 0.97 * x[:-1]                                   # pre-emphasis (conv1d [-0.97, 1])
    pad = N_FFT // 2
    x = np.pad(x, pad, mode="reflect") if len(x) > pad else np.pad(x, pad)
    win = np.hanning(WIN)                                        # = torch.hann_window(800, periodic=False)
    w = np.zeros(N_FFT, np.float32)
    off = (N_FFT - WIN) // 2
    w[off:off + WIN] = win
    n = 1 + (len(x) - N_FFT) // HOP
    if n <= 0:
        return np.zeros((128, 0), np.float32)
    idx = np.arange(N_FFT)[None, :] + HOP * np.arange(n)[:, None]
    spec = np.abs(np.fft.rfft(x[idx] * w, N_FFT, axis=1)) ** 2   # (frames, 513)
    bank = np.load(MEL) if os.path.exists(MEL) else kaldi_mel_banks()
    mel = bank @ spec.T                                          # (128, frames)
    return ((np.log(mel + 1e-5) + 4.5) / 5.0).astype(np.float32)


def _load(path):
    import subprocess
    raw = subprocess.run(["ffmpeg", "-loglevel", "error", "-i", path, "-vn", "-ac", "1", "-ar", str(SR), "-f", "s16le",
                          "-"], capture_output=True, check=True).stdout
    return np.frombuffer(raw, np.int16).astype(np.float32) / 32768.0


def tag(x):
    """All 527 AudioSet probabilities for one waveform chunk (32 kHz)."""
    m = melspec(x)
    if m.shape[1] < 32:
        m = np.pad(m, ((0, 0), (0, 32 - m.shape[1])), constant_values=m.min() if m.size else 0)
    out = _session().run(None, {"mel": m[None, None]})[0]
    return np.asarray(out).reshape(-1, 527)[-1]


def timeline(src, hop=1.0, window=WINDOW_S, batch=16, max_seconds=6 * 3600):
    """Per-`hop` reaction probabilities over a whole file or waveform. ~0.05 s of CPU per second of audio."""
    x = _load(src) if isinstance(src, str) else np.asarray(src, np.float32)
    x = x[: int(max_seconds * SR)]
    dur = len(x) / float(SR)
    ts = np.arange(0.0, max(dur, 0.0), hop)
    out = {k: np.zeros(len(ts), np.float32) for k in CLASSES}
    n = int(window * SR)
    sess = _session()
    # windows are always real audio (never padded with digital silence, which the network hears as "crowd"):
    # near the ends the window slides inward instead of hanging off the edge
    starts = [int(min(max(0, t * SR - n / 2), max(0, len(x) - n))) for t in ts]
    mels = [melspec(x[a:a + n]) for a in starts]
    for i in range(0, len(mels), batch):
        group = mels[i:i + batch]
        if len({m.shape[1] for m in group}) == 1:
            p = np.asarray(sess.run(None, {"mel": np.stack(group)[:, None]})[0]).reshape(-1, 527)
        else:                                        # a file shorter than one window: run them one by one
            p = np.stack([np.asarray(sess.run(None, {"mel": m[None, None]})[0]).reshape(-1, 527)[-1] for m in group])
        for k, idx in CLASSES.items():
            out[k][i:i + len(p)] = p[:, idx].max(1)
    return {"t": ts.round(3).tolist(), "hop": hop, **{k: v.round(3).tolist() for k, v in out.items()}}


def reaction_at(tl, a, b):
    """(strength 0..1, kind) of the strongest laugh / cheer / scream inside [a, b] of a timeline."""
    if not tl or not tl.get("t"):
        return 0.0, None
    t = np.asarray(tl["t"])
    m = (t >= a) & (t <= b)
    if not m.any():
        return 0.0, None
    best, kind = 0.0, None
    for k in ("laugh", "cheer", "scream"):
        v = float(np.asarray(tl[k])[m].max())
        if v > best:
            best, kind = v, k
    return best, kind


def cached_timeline(src, workdir):
    """timeline(), saved next to the project as sounds.json so it runs once per stream."""
    from .common import load_store, save_json
    p = os.path.join(workdir, "sounds.json")
    tl = load_store(p, None, dict) if os.path.exists(p) else None
    if tl and tl.get("t") is not None:
        return tl
    if not available():
        return None
    try:
        tl = timeline(src)
        save_json(p, tl)
        return tl
    except Exception as e:
        log("reaction sounds skipped (%s)" % str(e)[:100])
        return None

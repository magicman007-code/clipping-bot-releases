"""Prompt clipping: "every time he talks about the $10M coin", "funny moments", "when chat goes crazy".

How a prompt is matched, per transcript sentence (0..1 relevance):
  meaning  - sentence-embedding similarity (semantic.py, offline MiniLM), so "losing money" finds
             "I watched $100,000 disappear" even with no shared words;
  keywords - the prompt's content words (light stemming, numbers/$ normalised), for names and exact phrases;
  intent   - category prompts ("funny", "hype", "drama", "donations"...) use the moment finder's own signals;
  lore     - the streamer's known names/nicknames (lore.py) resolve to how they're actually said.
Matches become normal candidates (moments.find_candidates with relevance), so every prompt clip is still
sentence-snapped, quality-scored and held to the same bar as auto-clips.
"""
import re

import numpy as np

from .moments import LEX, _rx
from .transcribe import sentences_from_words

STOP = set("""a an the and or but if of to in on at for with from by as is are was were be been being it its this that
these those he she they them his her their him i me my we us our you your about when where what which who whom how why
every each time times all any some moment moments part parts clip clips find show me talks talking talk says saying said
said mention mentions mentioning brings bringing up stream streamer video please just like really get got gets do does
did going goes go there here then than so very can could would should will""".split())

INTENTS = {
    "humor": r"funn\w*|laugh\w*|hilarious|joke\w*|comed\w*|lol|lmao|meme\w*",
    "shock": r"hype|crazy|insane|wild|shock\w*|unbelievable|reaction|react\w*|scream\w*|freak\w*|clutch|epic",
    "drama": r"drama|argu\w*|beef|fight\w*|rage|angry|mad|heated|tilt\w*|toxic|exposed|sad|emotional|cry\w*",
    "stakes": r"money|profit\w*|loss\w*|lost|won|win\w*|cash|dollar\w*|rich|broke|\$",
    "story": r"stor\w*|backstory|explain\w*|how (?:he|she|they) (?:got|started)",
    "events": r"donation\w*|donat\w*|subs?|gifted|raid\w*|bits|superchat|ban\w*|chat",
}
ALL_WORDS = re.compile(r"\b(?:every ?time|all (?:the )?(?:times|moments)|whenever|each time)\b", re.I)


def _stem(w):
    w = w.lower().strip("'")
    for suf in ("ing", "ed", "es", "s", "ly"):
        if len(w) > len(suf) + 2 and w.endswith(suf):
            return w[: -len(suf)]
    return w


def _norm_numbers(t):
    t = t.lower()
    t = re.sub(r"\$\s?(\d+(?:\.\d+)?)\s?(?:m|mil|million)\b", r"$\1 million", t)
    t = re.sub(r"\$\s?(\d+(?:\.\d+)?)\s?(?:k|thousand)\b", r"$\1 thousand", t)
    t = re.sub(r"(\d),(\d{3})", r"\1\2", t)
    return t


def keywords(prompt):
    toks = re.findall(r"\$?\d[\d.,]*\s?(?:k|m|million|thousand)?|[a-z][a-z']+", _norm_numbers(prompt))
    return [_stem(t) for t in toks if t not in STOP and len(t) > 1]


def plan(prompt):
    """What the prompt asks for: content keywords, intent categories, and whether it wants every match."""
    p = prompt or ""
    intents = [k for k, rx in INTENTS.items() if re.search(r"\b(?:%s)" % rx, p, re.I)]
    kws = keywords(p)
    intent_words = set()
    for k in intents:
        intent_words |= {_stem(w) for w in re.findall(r"[a-z]+", p.lower()) if re.fullmatch(INTENTS[k], w)}
    content = [w for w in kws if w not in intent_words]
    return {"prompt": p.strip(), "keywords": content, "intents": intents, "all": bool(ALL_WORDS.search(p))}


def relevance(prompt, sents, workdir, lore_aliases=None):
    """Per-sentence relevance 0..1 + how it was matched."""
    P = plan(prompt)
    n = len(sents)
    sem = np.zeros(n)
    method = []
    try:
        from . import semantic
        if semantic.available() and P["prompt"]:
            q = P["prompt"]
            for canon, alts in (lore_aliases or {}).items():      # "the goat" -> include the real name
                if canon.lower() in q.lower():
                    q += " " + " ".join(alts)
            sv = semantic.sentence_vectors(sents, workdir)
            # framing words ("when he talks about") dilute the meaning, so also search the core phrase
            core = " ".join(w for w in re.findall(r"\$?[\w$',.]+", q) if w.lower().strip(",.") not in STOP) or q
            qs = semantic.embed([q, core])
            sim = np.maximum(sv @ qs[0], sv @ qs[1])
            # neighbour context: a sentence that answers the prompt is often split across two
            ctx = np.maximum(sim, 0.6 * np.maximum(np.roll(sim, 1), np.roll(sim, -1)))
            sem = np.clip((ctx - 0.2) / 0.32, 0, 1)
            method.append("meaning")
    except Exception:
        sem = np.zeros(n)
    lex = np.zeros(n)
    if P["keywords"]:
        kw = set(P["keywords"])
        for i, s in enumerate(sents):
            toks = {_stem(t) for t in re.findall(r"\$?\d[\d.]*\s?(?:million|thousand)?|[a-z][a-z']+", _norm_numbers(s["text"]))}
            hit = len(kw & toks)
            lex[i] = min(1.0, hit / max(1.0, min(len(kw), 3.0)))
        method.append("keywords")
    inten = np.zeros(n)
    if P["intents"]:
        rx = [_rx(LEX[k]) for k in P["intents"] if k in LEX]
        for i, s in enumerate(sents):
            h = sum(len(r.findall(s["text"])) for r in rx)
            inten[i] = min(1.0, 0.6 * h)
        if P["keywords"]:          # "advice about taking profits": the specific words lead, the category only helps
            inten *= 0.5
        method.append("moment type (%s)" % ", ".join(P["intents"]))
    rel = np.maximum.reduce([sem, 0.9 * lex, inten]) if n else sem
    if P["keywords"] and sem.any():
        rel = np.maximum(rel, 0.55 * sem + 0.45 * lex)
    return rel, P, method


def find(prompt, words, src, workdir, n=6, min_len=12.0, max_len=50.0, lore=None, lore_aliases=None, energy=None,
         kind_w=None, chat=None, sounds=None):
    """Clip candidates for a prompt, best first (same format as moments.find_candidates + relevance/match)."""
    from .moments import find_candidates
    sents = sentences_from_words(words)
    if not sents:
        return [], {"prompt": prompt, "method": [], "matches": 0}
    rel, P, method = relevance(prompt, sents, workdir, lore_aliases)
    thr = 0.5
    strong = int((rel >= thr).sum())
    if strong == 0 and rel.max() >= 0.3:   # nothing clear-cut: take the best partial matches
        thr = float(max(0.3, np.sort(rel)[-min(3, len(rel))]))
    want = max(n, strong) if P["all"] else n
    from .moments import _overlap
    from .score import score_candidate
    allw = find_candidates(words, src, workdir, min_len=min_len, max_len=max_len, top_k=10 ** 6, energy=energy,
                           lore=lore, relevance=rel, rel_min=thr, sents=sents, rel_weight=30.0, pick=False,
                           kind_w=kind_w, chat=chat, sounds=sounds)
    # every window that contains a matched line competes; per line keep the best-QUALITY window that doesn't end
    # right on the match (so there's setup and payoff), falling back to the best-matching one
    groups = {}
    for c in allw:
        groups.setdefault(c["match_at"], []).append(c)
    best = []
    for k, grp in groups.items():
        top_rel = max(c["relevance"] for c in grp)
        pool = [c for c in grp if c["relevance"] >= top_rel - 1e-6]
        good = [c for c in pool if c.get("match_pos", 0) <= 0.85] or pool
        for c in good:
            c["quality"] = score_candidate(c)
        b = max(good, key=lambda c: (c["quality"]["score"], c["score"]))
        best.append(b)
    best.sort(key=lambda c: (-round(c["relevance"], 1), -c["quality"]["score"]))
    cands = []
    for c in best:                        # one clip per moment, no near-duplicates
        if any(_overlap(c, p) > 0.5 for p in cands):
            continue
        cands.append(c)
        if len(cands) >= want:
            break
    for r, c in enumerate(cands, 1):
        c["rank"] = r
    info = {"prompt": P["prompt"], "method": method, "keywords": P["keywords"], "intents": P["intents"],
            "every": P["all"], "matches": strong, "threshold": round(thr, 2)}
    return cands, info

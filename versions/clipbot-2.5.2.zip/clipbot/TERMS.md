# Clipbot Studio: terms of use and disclaimer

**Plain summary:** Clipbot is a tool. You choose what to clip, edit, generate and post, and you are responsible for that. The people who made Clipbot are not.

By installing, opening or using Clipbot Studio ("the software"), you agree to these terms. If you don't agree, don't use it.

## 1. You are responsible for your content and how you use it
- You are solely responsible for every video, clip, thumbnail, caption, image and post you make, change, download, upload or share with the software. That includes anything Clipbot suggests or generates automatically.
- You must have the rights to the footage you use. That means it is your own footage, or you have permission from the owner (for example, the streamer or creator you clip for), or your use is allowed under the law where you live. You alone decide whether your use is lawful.
- You must follow the terms, community guidelines and rules of every platform you download from or post to, including Twitch, Kick, YouTube, TikTok, Instagram, X, Google Drive, Dropbox and WeTransfer. Some platforms don't allow downloading or re-uploading.
- You are responsible for any campaign, brand-deal or clipping-program rules you agree to, including disclosure rules for paid or sponsored content.

## 2. People, faces, voices and likeness
- Don't use anyone's face, name, voice or likeness in a way they haven't agreed to. That includes thumbnails, AI-generated or AI-edited images, and edits that make someone appear to say or do something they didn't.
- Don't create content that is defamatory, harassing, sexual involving real people, misleading, or that impersonates someone.
- Get permission before putting real people into AI-generated images. The "people" options in Clipbot are switched off until you turn them on yourself.

## 3. AI features and outside services
- Some features send content (transcripts, images or prompts) to outside services that you choose to connect: your own AI provider, an image generator, YouTube, a phone-alert service, or a feedback sheet. Those services have their own terms, privacy rules and prices. You accept them yourself, and you pay any costs, including API bills.
- AI output can be wrong, inappropriate, or similar to someone else's work. Review everything before you publish it.
- The free image provider is a third-party service that can change or stop at any time. Don't send it anything private.

## 4. Your data
- Clipbot runs on your computer. Your videos and projects stay on your computer unless you choose to upload, post, share or send a report.
- **Sharing is your choice.** When you accept these terms you choose whether to send anonymous learning reports
  (which kinds of moments you keep or reject, scores, which features you use, how long runs take and what kind of
  error happened) to help improve Clipbot, and whether to include the transcript text of clips you rate. Reports
  never include your videos, links, file names or account details. It's off unless you turn it on, and you can
  change it any time in Settings -> Help improve Clipbot.
- **The free built-in AI** sends clip text to a free public service (Pollinations) when you use an AI feature. You
  can switch it off on the same screen or in Settings -> Your AI, or connect your own AI instead.
- Keep your own backups. Updates, crashes or mistakes can lose files.

## 5. No warranty
THE SOFTWARE IS PROVIDED "AS IS" AND "AS AVAILABLE", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED. THIS INCLUDES ANY WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE AND NON-INFRINGEMENT. Nobody promises that the software will be error-free, uninterrupted or secure, that it will get you views, money or approvals, or that any clip, score or suggestion is accurate. This is beta software.

## 6. Limitation of liability
TO THE FULLEST EXTENT ALLOWED BY LAW, THE DEVELOPERS, CONTRIBUTORS AND DISTRIBUTORS OF THE SOFTWARE ARE NOT LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY. THIS COVERS DIRECT, INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL AND PUNITIVE DAMAGES, AND LOSS OF DATA, PROFITS, REVENUE, ACCOUNTS OR CHANNELS. IT INCLUDES COPYRIGHT STRIKES, TAKEDOWNS, BANS, DEMONETISATION AND API CHARGES. IT APPLIES WHETHER THE CLAIM IS IN CONTRACT, TORT OR ANYTHING ELSE, AND WHETHER IT ARISES FROM USING THE SOFTWARE OR BEING UNABLE TO USE IT. Where the law doesn't allow some of this to be excluded, liability is limited to the smallest amount the law allows.

## 7. Indemnity
You agree to defend, indemnify and hold harmless the developers, contributors and distributors of the software against any claim, demand, loss, damage, cost or expense (including reasonable legal fees) arising from:
- your content
- your use of the software
- your breach of these terms
- your infringement of anyone's rights, including copyright, trademark, privacy and publicity rights
- your breach of any platform's terms.

## 8. Changes and ending
These terms may change with updates. If they change, Clipbot asks you to accept them again. You can stop using the software at any time by deleting it.

## 9. Third-party components
Clipbot includes open-source components, such as ffmpeg, yt-dlp, faster-whisper, hls.js and ONNX models. Each is covered by its own license. The speaker-detection model is Light-ASD by Junhua Liao et al. (CVPR 2023, MIT license; see
assets/models/LIGHT_ASD_LICENSE.txt). The sound-event model is EfficientAT by Florian Schmid et al. (MIT license;
assets/models/EFFICIENTAT_LICENSE.txt). The facial-expression model is HSEmotion by Andrey Savchenko (Apache 2.0;
assets/models/HSEMOTION_LICENSE.txt).

---
*This text is a general template, not legal advice. Have a lawyer review it before any commercial release.*

"""Connections: services a user plugs in themselves. Stored on their computer only
(<work_root>/_settings/connections.json, outside the app folder so updates keep it). Keys are never sent anywhere
except to the service they belong to.

  ai        {"provider": "anthropic"|"openai"|"custom"|"free"|"off", "key": "...", "model": "...", "base_url": "..."}
            no provider set (or a provider with no key) -> the free built-in AI (Pollinations, no key, slow:
            one request every ~30 s). "off" switches AI off completely.
            -> extra title/headline ideas (still fact-checked against what was said in the clip)
  cookies   {"browser": "chrome"|"firefox"|"edge"|"safari"|"brave"|"chromium"|"opera"|"vivaldi"}
            -> yt-dlp uses that browser's logins (subscriber-only / age-restricted VODs)
  webhook   {"url": "https://...", "events": ["clip_rendered", "autoclip_done"]}
            -> POST JSON when a clip finishes (Zapier, Make, n8n, a Discord webhook, your own server)
  feedback  {"enabled": bool, "url": "...", "include_text": bool}
            -> anonymous learning reports to the app's publisher (opt-in; see learn.py)
  scorer    {"url": "https://...", "weight": 0.3, "token": "..."}
            -> any outside tool scores auto-clip's candidates (your own model, an n8n/Make flow, a local server).
               Clipbot POSTs {"app": "clipbot", "candidates": [{"id", "start", "end", "text", "score", "tags"}]}
               and reads back [{"id": 0, "score": 0-10, "why": "..."}] (or {"scores": [...]}). See CONNECT.md.
"""
import json
import os
import re
import threading
import urllib.request

from .common import load_config, log

BROWSERS = ("chrome", "firefox", "edge", "safari", "brave", "chromium", "opera", "vivaldi")
_LOCK = threading.Lock()


def _path():
    d = os.path.join(load_config()["work_root"], "_settings")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "connections.json")


def get():
    try:
        c = json.load(open(_path()))
    except Exception:
        c = {}
    fb = c.setdefault("feedback", {})
    fb.setdefault("url", load_config().get("feedback_url") or "")      # baked in by the publisher
    fb.setdefault("enabled", False)
    fb.setdefault("include_text", False)
    return c


def save(patch):
    """Merge a partial update. Empty-string keys mean 'unchanged' for secrets, None means 'remove'."""
    with _LOCK:
        c = get()
        for sect, vals in (patch or {}).items():
            if sect not in ("ai", "cookies", "webhook", "feedback", "scorer", "youtube", "post_folder", "notify", "imagegen",
                            "tiktok", "twitch", "instagram"):
                continue
            if vals is None:
                c.pop(sect, None)
                continue
            cur = c.setdefault(sect, {})
            for k, v in vals.items():
                if k in ("key", "token", "client_secret", "refresh_token", "access_token") and v == "":
                    continue                    # keep the stored key when the field is left blank
                if v is None:
                    cur.pop(k, None)
                else:
                    cur[k] = v
        _validate(c)
        tmp = _path() + ".tmp"
        json.dump(c, open(tmp, "w"), indent=1)
        os.replace(tmp, _path())
        try:
            os.chmod(_path(), 0o600)
        except OSError:
            pass
        return redacted(c)


def _validate(c):
    ai = c.get("ai") or {}
    if ai.get("provider") and ai["provider"] not in ("anthropic", "openai", "custom", "free", "off"):
        raise ValueError("AI provider must be anthropic, openai, custom, free or off")
    if ai.get("provider") == "custom" and not str(ai.get("base_url", "")).startswith("http"):
        raise ValueError("a custom AI provider needs its base URL (https://...)")
    pf = (c.get("post_folder") or {}).get("path")
    if pf and not os.path.isdir(os.path.expanduser(pf)):
        raise ValueError("that posting folder doesn't exist: %s" % pf)
    ns = (c.get("notify") or {}).get("server")
    if ns and not str(ns).startswith(("https://", "http://127.0.0.1", "http://localhost")):
        raise ValueError("alert server must start with https://")
    nt = (c.get("notify") or {}).get("topic")
    if nt and not re.match(r"^[A-Za-z0-9_-]{6,64}$", nt):
        raise ValueError("the phone alert name can only use letters, numbers, - and _ (6 to 64 characters)")
    br = (c.get("cookies") or {}).get("browser")
    if br and br not in BROWSERS:
        raise ValueError("browser must be one of: " + ", ".join(BROWSERS))
    for sect in ("webhook", "feedback", "scorer"):
        u = (c.get(sect) or {}).get("url")
        if u and not str(u).startswith(("https://", "http://127.0.0.1", "http://localhost")):
            raise ValueError("%s URL must start with https://" % sect)


def redacted(c=None):
    """Safe to show in the UI: keys reduced to their last 4 characters."""
    c = json.loads(json.dumps(c or get()))
    for sect, field in (("ai", "key"), ("scorer", "token"), ("youtube", "client_secret"), ("imagegen", "key"),
                        ("tiktok", "client_secret"), ("instagram", "token")):
        k = (c.get(sect) or {}).get(field)
        if k:
            c[sect][field] = ""
            c[sect][field + "_hint"] = "…" + k[-4:]
    for sect in ("youtube", "tiktok", "twitch"):
        x = c.get(sect) or {}
        x.pop("access_token", None)
        if x.get("refresh_token"):
            x["refresh_token"] = ""
            x["connected"] = True
    return c


def cookies_browser():
    return (get().get("cookies") or {}).get("browser") or None


# ------------------------------------------------------------------ webhook
def fire(event, payload):
    """POST {event, ...payload} to the user's webhook in the background (and a phone alert). Never raises."""
    pl = payload or {}
    what = pl.get("title") or pl.get("name") or ""
    if event == "autoclip_done":
        n = pl.get("clips")
        notify("Clips ready", ("%d clips ready in %s" % (n, pl.get("project") or "your project")) if isinstance(n, int)
               else "Your clips are ready")
    elif event == "clip_rendered" and not pl.get("draft"):
        notify("Clip ready", "Rendered: %s" % what, group="rendered")
    elif event == "live_clip":
        notify("New live clip", what or "A new live clip is ready to check", group="live", tags="red_circle")
    elif event in ("posted", "scheduled"):
        notify("Posted" if event == "posted" else "Scheduled", "%s on %s" % (what, pl.get("platform") or ""),
               tags="white_check_mark", click=pl.get("url"))
    elif event == "edit_ready":
        notify("Video ready", "%s is ready (%s)" % (what or "Your edit", pl.get("length") or ""), tags="movie_camera")
    elif event in ("failed", "autoclip_failed", "post_failed", "edit_failed", "live_failed"):
        notify("Something failed", "%s: %s" % (what or event.replace("_", " "), str(pl.get("error") or "")[:300]),
               tags="warning", priority=4)
    wh = get().get("webhook") or {}
    url = wh.get("url")
    if not url or (wh.get("events") and event not in wh["events"]):
        return False
    body = dict(payload or {}, event=event, app="clipbot")
    if "discord.com/api/webhooks" in url:           # Discord wants {"content": "..."}
        body = {"content": "**Clipbot** - %s: %s" % (event.replace("_", " "),
                                                     payload.get("title") or payload.get("name") or "")[:1900]}

    def go():
        try:
            req = urllib.request.Request(url, data=json.dumps(body).encode(), method="POST",
                                         headers={"Content-Type": "application/json", "User-Agent": "clipbot"})
            urllib.request.urlopen(req, timeout=15).read()
        except Exception as e:
            log("webhook failed: %s" % str(e)[:120])
    threading.Thread(target=go, daemon=True).start()
    return True


# ------------------------------------------------------------------ phone alerts (ntfy: free app, no account)
_NT = {"lock": threading.Lock(), "pending": {}}
NOTIFY_GROUP_S = 45.0          # several of the same alert within this window arrive as one ("5 clips ready")


def notify(title, message, server=None, tags="clapper", click=None, group=None, priority=None, _send=None):
    """Push a phone notification via ntfy (https://ntfy.sh) to the user's own private topic. Never raises.
    group: alerts with the same group key inside NOTIFY_GROUP_S are merged into one ("Render all" sends one alert,
    not twenty). click: a link the phone opens when the alert is tapped (a posted video)."""
    nt = get().get("notify") or {}
    topic = nt.get("topic")
    if not topic:
        return False
    url = (server or nt.get("server") or "https://ntfy.sh").rstrip("/") + "/" + topic

    def send(t, m, tg, ck, pr):
        try:
            h = {"Title": str(t)[:120].encode("ascii", "ignore").decode() or "Clipbot", "Tags": tg or "clapper",
                 "User-Agent": "clipbot"}
            if ck and str(ck).startswith("https://"):
                h["Click"] = str(ck)[:500]
            if pr:
                h["Priority"] = str(pr)
            req = urllib.request.Request(url, data=str(m)[:1000].encode("utf-8"), method="POST", headers=h)
            urllib.request.urlopen(req, timeout=15).read()
        except Exception as e:
            log("phone alert failed: %s" % str(e)[:120])
    send = _send or send
    if not group:
        threading.Thread(target=send, args=(title, message, tags, click, priority), daemon=True).start()
        return True
    with _NT["lock"]:
        g = _NT["pending"].get(group)
        if g:                                          # one is already waiting: fold this one in
            g["n"] += 1
            g["last"] = message
            return True
        g = _NT["pending"][group] = {"n": 1, "first": message, "last": message}

    def later():
        import time as _t
        _t.sleep(NOTIFY_GROUP_S)
        with _NT["lock"]:
            gg = _NT["pending"].pop(group, g)
        m = gg["first"] if gg["n"] == 1 else "%d done. Latest: %s" % (gg["n"], gg["last"])
        send(title if gg["n"] == 1 else "%s (%d)" % (title, gg["n"]), m, tags, click if gg["n"] == 1 else None, priority)
    threading.Thread(target=later, daemon=True).start()
    return True


# ------------------------------------------------------------------ AI text (titles / headlines)
def _local(url):
    return str(url or "").startswith(("http://localhost", "http://127.0.0.1"))


FREE_TEXT = "https://text.pollinations.ai/"
FREE_GAP = 31.0                     # the free tier allows one anonymous request every 30 s
_FREE = {"lock": threading.Lock(), "last": 0.0}


def ai_cfg():
    """The AI Clipbot will use: the user's own (when it has a key / is local), else the free built-in one, else {}."""
    ai = get().get("ai") or {}
    prov = ai.get("provider")
    if prov == "off":
        return {}
    if prov in ("anthropic", "openai", "custom") and (ai.get("key") or (prov == "custom" and _local(ai.get("base_url")))):
        return ai
    return {"provider": "free", "rerank": ai.get("rerank", True)}


def ai_ready():
    return bool(ai_cfg())


def is_free():
    return ai_cfg().get("provider") == "free"


def _free_complete(prompt, system, timeout, wait):
    import time as _t
    url = load_config().get("free_text_url") or FREE_TEXT
    if not _FREE["lock"].acquire(timeout=max(0.0, wait)):
        raise RuntimeError("the free AI is busy - it answers one request every 30 seconds")
    try:
        gap = FREE_GAP - (_t.time() - _FREE["last"])
        if gap > 0:
            if gap > wait:
                raise RuntimeError("the free AI takes one request every 30 seconds - try again in %ds "
                                   "(or connect your own AI in Settings for speed)" % int(gap + 1))
            _t.sleep(gap)
        msgs = ([{"role": "system", "content": system}] if system else []) + [{"role": "user", "content": prompt}]
        body = json.dumps({"messages": msgs, "private": True}).encode()
        for attempt in (0, 1):
            _FREE["last"] = _t.time()
            try:
                req = urllib.request.Request(url, data=body, method="POST", headers={
                    "Content-Type": "application/json", "User-Agent": "clipbot"})
                with urllib.request.urlopen(req, timeout=timeout) as r:
                    raw = r.read().decode("utf-8", "replace")
                try:                                       # plain text normally; tolerate an OpenAI-style reply
                    j = json.loads(raw)
                    if isinstance(j, dict) and j.get("choices"):
                        return j["choices"][0]["message"]["content"] or ""
                except ValueError:
                    pass
                return raw
            except Exception as e:
                code = getattr(e, "code", None)
                if code in (402, 429) and attempt == 0:
                    try:
                        ra = float(e.headers.get("Retry-After") or FREE_GAP)
                    except Exception:
                        ra = FREE_GAP
                    if ra <= max(wait, 5):
                        _t.sleep(ra)
                        continue
                    raise RuntimeError("the free AI is rate-limited right now - try again in a minute")
                raise RuntimeError("the free AI didn't answer (%s) - try again, or connect your own AI in Settings"
                                   % (code or str(e)[:80]))
    finally:
        _FREE["lock"].release()


def ai_complete(prompt, system="", max_tokens=600, timeout=45, wait=40):
    """One text completion: the user's own AI, or the free built-in one. Raises RuntimeError with a readable reason.
    wait = how long a call may queue for the free AI's 30-second slot (0 = give up at once if it's busy)."""
    ai = ai_cfg()
    if not ai:
        raise RuntimeError("AI is switched off in Settings")
    if ai["provider"] == "free":
        return _free_complete(prompt, system, min(90, max(timeout, 45)), wait)
    prov = ai.get("provider", "anthropic")
    try:
        if prov == "anthropic":
            url = (ai.get("base_url") or "https://api.anthropic.com").rstrip("/") + "/v1/messages"
            body = {"model": ai.get("model") or "claude-haiku-5-5", "max_tokens": max_tokens,
                    "messages": [{"role": "user", "content": prompt}]}
            if system:
                body["system"] = system
            req = urllib.request.Request(url, data=json.dumps(body).encode(), method="POST", headers={
                "x-api-key": ai["key"], "anthropic-version": "2023-06-01", "content-type": "application/json"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                j = json.loads(r.read())
            return "".join(b.get("text", "") for b in j.get("content", []) if b.get("type") == "text")
        base = (ai.get("base_url") or "https://api.openai.com/v1").rstrip("/")
        if not ai.get("model"):
            raise RuntimeError("set the model name for this AI provider")
        msgs = ([{"role": "system", "content": system}] if system else []) + [{"role": "user", "content": prompt}]
        req = urllib.request.Request(base + "/chat/completions", method="POST",
                                     data=json.dumps({"model": ai["model"], "messages": msgs,
                                                      "max_tokens": max_tokens}).encode(),
                                     headers={"Authorization": "Bearer " + (ai.get("key") or "local"),
                                              "Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            j = json.loads(r.read())
        return j["choices"][0]["message"]["content"] or ""
    except RuntimeError:
        raise
    except Exception as e:
        code = getattr(e, "code", None)
        detail = ""
        try:
            detail = e.read().decode("utf-8", "replace")[:200] if hasattr(e, "read") else ""
        except Exception:
            pass
        if code in (401, 403):
            raise RuntimeError("the AI service rejected the key (check it in Settings)")
        if code == 429:
            raise RuntimeError("the AI service is rate-limiting this key - try again in a minute")
        raise RuntimeError("AI request failed: %s %s" % (code or str(e)[:100], detail))


def ai_titles(text, headline="", n=6, skill=None, wait=5):
    """Extra title ideas from the user's AI. Plain list of strings (the caller fact-checks them)."""
    system = ("You write titles for short vertical clips of livestreams. Every claim, number and name in a title "
              "must be stated in the transcript. No invented facts. Under 70 characters. Return only a JSON array "
              "of strings.")
    prompt = "Transcript of the clip:\n\"\"\"%s\"\"\"\n%sWrite %d different titles, from plain to curiosity-driven." % (
        text[:4000], ("Current headline: %s\n" % headline) if headline else "", n)
    if skill and skill.get("titles"):
        system += " The user's title style: %s" % str(skill["titles"])[:600]
    out = ai_complete(prompt, system=system, max_tokens=500, wait=wait)
    import re
    m = re.search(r"\[.*\]", out, re.S)
    try:
        arr = json.loads(m.group(0)) if m else []
    except Exception:
        arr = []
    if not arr:
        arr = [l.strip(" -*\"0123456789.") for l in out.splitlines() if l.strip()]
    return [str(t).strip()[:100] for t in arr if str(t).strip()][:n]


# ------------------------------------------------------------------ outside scorer (any software)
def scorer_ready():
    return bool((get().get("scorer") or {}).get("url"))


def score_external(cands, timeout=60):
    """POST candidates to the user's scorer. -> {index: {"score", "why"}}. Raises RuntimeError on failure."""
    sc = get().get("scorer") or {}
    body = {"app": "clipbot", "version": 1, "candidates": [
        {"id": i, "start": c["start"], "end": c["end"], "text": " ".join(t for _, t in c.get("sentences", []))[:2000],
         "score": (c.get("quality") or {}).get("score"), "tags": sorted((c.get("tags") or {}).keys()),
         "chat_z": c.get("chat_z")} for i, c in enumerate(cands)]}
    h = {"Content-Type": "application/json", "User-Agent": "clipbot"}
    if sc.get("token"):
        h["Authorization"] = "Bearer " + sc["token"]
    try:
        req = urllib.request.Request(sc["url"], data=json.dumps(body).encode(), method="POST", headers=h)
        with urllib.request.urlopen(req, timeout=timeout) as r:
            j = json.loads(r.read() or b"[]")
    except Exception as e:
        raise RuntimeError("your scorer didn't answer: %s" % str(e)[:120])
    arr = j.get("scores") if isinstance(j, dict) else j
    out = {}
    for x in arr or []:
        try:
            i, s_ = int(x["id"]), float(x["score"])
        except (KeyError, TypeError, ValueError):
            continue
        if 0 <= i < len(cands) and 0 <= s_ <= 10:
            out[i] = {"score": round(s_, 1), "why": str(x.get("why") or "")[:120]}
    return out


# ------------------------------------------------------------------ what's connected (for learning + reports)
HOSTS = (("openrouter.ai", "openrouter"), ("generativelanguage.googleapis.com", "gemini"), ("groq.com", "groq"),
         ("x.ai", "xai"), ("deepseek.com", "deepseek"), ("mistral.ai", "mistral"), (":11434", "ollama"),
         ("localhost", "local"), ("127.0.0.1", "local"), ("anthropic.com", "anthropic"), ("openai.com", "openai"))
HOOKS = (("discord.com", "discord"), ("zapier.com", "zapier"), ("make.com", "make"), ("integromat", "make"),
         ("n8n", "n8n"), ("pipedream", "pipedream"), ("slack.com", "slack"), ("localhost", "local"), ("127.0.0.1", "local"))


def _kind(url, table, default):
    u = str(url or "").lower()
    return next((k for h, k in table if h in u), default)


def ai_source():
    """'provider/model' of the connected AI, e.g. 'anthropic/claude-haiku-5-5', 'ollama/llama3'. No keys, no URLs."""
    ai = ai_cfg()
    if not ai:
        return None
    if ai["provider"] == "free":
        return "free/pollinations"
    prov = ai["provider"]
    if prov == "custom" or ai.get("base_url"):
        prov = _kind(ai.get("base_url"), HOSTS, "custom")
    return "%s/%s" % (prov, (ai.get("model") or ("claude-haiku-5-5" if prov == "anthropic" else "?"))[:60])


def profile():
    """Which connections are switched on - only kinds and model names, never keys, links or tokens."""
    c = get()
    ai = c.get("ai") or {}
    wh = (c.get("webhook") or {}).get("url")
    return {"ai": ai_source() if ai_ready() else None, "ai_rerank": bool(ai_ready() and ai.get("rerank", True)),
            "scorer": _kind((c.get("scorer") or {}).get("url"), HOOKS, "custom") if scorer_ready() else None,
            "webhook": _kind(wh, HOOKS, "custom") if wh else None,
            "cookies": (c.get("cookies") or {}).get("browser") or None,
            "reports": bool((c.get("feedback") or {}).get("enabled"))}


# ------------------------------------------------------------------ AI images (thumbnails)
IMG_RULES = ("Background plate for a YouTube thumbnail. Vivid colour, high contrast, dramatic light, depth. "
             "Leave the right side open for a person to be placed later. Absolutely no people, no faces, no hands, "
             "no text, no letters, no numbers, no logos, no watermarks.")
IMG_FREE = "https://image.pollinations.ai/prompt/"


def image_cfg():
    """{"provider": "openai"|"free", "key", "model", "base"}. Free (Pollinations, no key) unless the user set OpenAI."""
    ig = get().get("imagegen") or {}
    if ig.get("provider") == "off":
        return None
    if ig.get("key"):
        return {"provider": "openai", "key": ig["key"], "model": ig.get("model") or "gpt-image-1",
                "base": (ig.get("base_url") or "https://api.openai.com/v1").rstrip("/")}
    ai = get().get("ai") or {}
    if ai.get("provider") == "openai" and ai.get("key"):
        return {"provider": "openai", "key": ai["key"], "model": "gpt-image-1", "base": "https://api.openai.com/v1"}
    return {"provider": "free"}


def _img_err(e):
    code = getattr(e, "code", None)
    if code in (401, 403):
        return RuntimeError("the image service rejected the key (check it in Settings)")
    if code == 400:
        return RuntimeError("the image service refused that prompt - try describing it differently")
    if code == 429:
        return RuntimeError("the image service is busy - try again in a minute")
    return RuntimeError("AI image failed: %s" % (code or str(e)[:100]))


def ai_image(scene, size="1536x1024", timeout=180, base=None, people=False, cfg=None):
    """One image (bytes) for a thumbnail background. people=False keeps people, faces and text out of it."""
    import base64
    import urllib.parse
    c = cfg or image_cfg()
    if not c:
        raise RuntimeError("AI images are turned off in Settings")
    prompt = ("%s Scene: %s" % (IMG_RULES, str(scene)[:600])) if not people else \
        ("Eye-catching YouTube thumbnail image, vivid colour, high contrast, dramatic light: %s" % str(scene)[:700])
    w, h = (int(x) for x in size.split("x"))
    try:
        if c["provider"] == "free":
            url = (base or IMG_FREE) + urllib.parse.quote(prompt[:900]) + "?" + urllib.parse.urlencode(
                {"width": w, "height": h, "nologo": "true", "seed": abs(hash(scene)) % 100000})
            with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "clipbot"}), timeout=timeout) as r:
                data = r.read()
            if not data[:4] in (b"\x89PNG", b"\xff\xd8\xff\xe0", b"\xff\xd8\xff\xe1", b"\xff\xd8\xff\xdb") and data[:2] != b"\xff\xd8":
                raise RuntimeError("the free image service didn't send an image - try again, or add an OpenAI key")
            return data
        body = {"model": c["model"], "prompt": prompt, "size": size, "n": 1}
        req = urllib.request.Request((base or c["base"]) + "/images/generations", data=json.dumps(body).encode(), method="POST",
                                     headers={"Authorization": "Bearer " + c["key"], "Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            j = json.loads(r.read())
    except RuntimeError:
        raise
    except Exception as e:
        raise _img_err(e)
    d = (j.get("data") or [{}])[0]
    if d.get("b64_json"):
        return base64.b64decode(d["b64_json"])
    raise RuntimeError("the image service returned no image")


def ai_remix(png_bytes, instruction, size="1536x1024", timeout=240, base=None, cfg=None):
    """Whole-thumbnail remix of a real frame (OpenAI image edit). Only for people the user may show."""
    import base64
    import uuid as _uuid
    c = cfg or image_cfg()
    if not c or c["provider"] != "openai":
        raise RuntimeError("AI remix needs an OpenAI key (Settings -> AI images)")
    bnd = "----clipbot" + _uuid.uuid4().hex
    parts = []
    for k, v in (("model", c["model"]), ("prompt", instruction[:3000]), ("size", size), ("n", "1")):
        parts.append(("--%s\r\nContent-Disposition: form-data; name=\"%s\"\r\n\r\n%s\r\n" % (bnd, k, v)).encode())
    parts.append(("--%s\r\nContent-Disposition: form-data; name=\"image\"; filename=\"frame.png\"\r\n"
                  "Content-Type: image/png\r\n\r\n" % bnd).encode() + png_bytes + b"\r\n")
    parts.append(("--%s--\r\n" % bnd).encode())
    req = urllib.request.Request((base or c["base"]) + "/images/edits", data=b"".join(parts), method="POST",
                                 headers={"Authorization": "Bearer " + c["key"],
                                          "Content-Type": "multipart/form-data; boundary=" + bnd})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            j = json.loads(r.read())
    except Exception as e:
        raise _img_err(e)
    d = (j.get("data") or [{}])[0]
    if d.get("b64_json"):
        return base64.b64decode(d["b64_json"])
    raise RuntimeError("the image service returned no image")

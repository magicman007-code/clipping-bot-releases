"""Post schedule: spread clips over days and post them on time.

  plan(n, start, per_day, times)  -> the slot times for n posts (local time), never in the past
  add(items)                      -> queue entries; YouTube ones are uploaded straight away as *scheduled* videos
                                     (YouTube publishes them on time even if this computer is off)
  due() / run_due(poster)         -> everything else (TikTok draft or post, posting folder) is posted by Clipbot at
                                     the time, while it's open. If Clipbot was closed, it posts as soon as it opens
                                     and says it was late.
Queue: <work_root>/_settings/schedule.json
"""
import datetime as _dt
import json
import os
import threading
import time
import uuid

from .common import load_config, log

PLATFORMS = {"youtube": "YouTube (scheduled on YouTube)", "tiktok_draft": "TikTok draft", "folder": "Posting folder"}
# TikTok direct posts aren't scheduled: TikTok requires the creator to confirm privacy and disclosure at posting time,
# so a scheduled TikTok goes to the creator's inbox as a draft and they tap Post.
_LOCK = threading.Lock()
LATE_LIMIT = 3 * 86400        # missed by more than this (Clipbot closed for days) -> not posted, marked missed


def _path():
    d = os.path.join(load_config()["work_root"], "_settings")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "schedule.json")


def load():
    try:
        return json.load(open(_path()))
    except Exception:
        return []


def _save(q):
    tmp = _path() + ".tmp"
    json.dump(q, open(tmp, "w"), indent=1)
    os.replace(tmp, _path())


def plan(n, start=None, per_day=2, times=("12:00", "18:00"), now=None):
    """Slot times (unix) for n posts: per_day posts a day at the given local times, from `start` (unix, a day)."""
    now = now or time.time()
    per_day = max(1, min(6, int(per_day)))
    hm = []
    for t in list(times)[:per_day] or ["12:00"]:
        try:
            h, m = [int(x) for x in str(t).split(":")[:2]]
            if 0 <= h < 24 and 0 <= m < 60:
                hm.append((h, m))
        except ValueError:
            continue
    if not hm:
        raise ValueError("pick at least one posting time, like 12:00")
    hm.sort()
    day = _dt.date.fromtimestamp(start or now)
    out = []
    while len(out) < n:
        for h, m in hm:
            ts = _dt.datetime(day.year, day.month, day.day, h, m).timestamp()
            if ts > now + 120 and len(out) < n:          # never in the past (2 min buffer)
                out.append(int(ts))
        day += _dt.timedelta(days=1)
        if len(out) == 0 and (day - _dt.date.fromtimestamp(now)).days > 400:
            break
    return out


def add(items):
    """items: [{project, clip, platform, at, title?, privacy?}] -> stored entries."""
    new = []
    for it in items[:200]:
        if it.get("platform") not in PLATFORMS:
            raise ValueError("unknown platform")
        at = int(it["at"])
        if at < time.time() - 60:
            raise ValueError("that time has already passed")
        new.append({"id": uuid.uuid4().hex[:10], "project": it["project"], "clip": it["clip"], "platform": it["platform"],
                    "at": at, "title": str(it.get("title") or "")[:100], "privacy": it.get("privacy") or "SELF_ONLY",
                    "status": "waiting", "created": int(time.time())})
    with _LOCK:
        q = load()
        q.extend(new)
        _save(q)
    return new


def update(id_, **kw):
    with _LOCK:
        q = load()
        for e in q:
            if e["id"] == id_:
                e.update(kw)
        _save(q)


def cancel(id_):
    with _LOCK:
        q = load()
        keep = [e for e in q if not (e["id"] == id_ and e["status"] in ("waiting", "failed", "missed"))]
        _save(keep)
        return len(q) - len(keep)


def due(now=None):
    now = now or time.time()
    return [e for e in load() if e["status"] == "waiting" and e["platform"] != "youtube" and e["at"] <= now]


def run_due(poster, now=None):
    """poster(entry) -> result dict (raises on failure). Posts each due entry once."""
    now = now or time.time()
    done = []
    for e in due(now):
        late = now - e["at"]
        if late > LATE_LIMIT:
            update(e["id"], status="missed", error="Clipbot was closed at the posting time (%d days late)" % (late // 86400))
            continue
        update(e["id"], status="posting")
        try:
            r = poster(e) or {}
            update(e["id"], status="done", result=r, posted=int(now), late=int(late) if late > 300 else 0)
            done.append(e["id"])
        except Exception as ex:
            update(e["id"], status="failed", error=str(ex)[:300])
            log("scheduled post failed: %s" % ex)
    return done


class Runner:
    """Checks the queue every minute while the editor is open."""
    def __init__(self, poster):
        self.poster = poster
        self.stop = threading.Event()

    def run(self):
        for e in load():                       # a post interrupted by closing Clipbot goes back to waiting
            if e["status"] == "posting":
                update(e["id"], status="waiting")
        while not self.stop.wait(60):
            try:
                run_due(self.poster)
            except Exception as e:
                log("schedule: %s" % e)

"""Account tracking: follow the views of whole accounts, including ones you can't (or don't want to) connect.

  add(url)           a YouTube channel, TikTok profile, Twitch or Kick channel by link (public numbers, no login), or
                     "instagram" once Instagram is connected with your own token (Settings -> Posting -> Instagram)
  refresh(account)   lists its recent posts with view counts, keeps a history, and links posts to your clips when the
                     title matches a clip's headline/title (then that post shows up in Results and teaches Clipbot)

Public numbers come from the platforms' public pages (via yt-dlp), the same way a viewer sees them. If a site asks for a
login, turn on Settings -> "use my browser's logins" and Clipbot uses the browser where you're signed in.
Stored in <work_root>/_learning/accounts.json.
"""
import json
import os
import re
import threading
import time
import urllib.parse
import urllib.request

from .common import load_config, log

_LOCK = threading.Lock()
IG_API = "https://graph.instagram.com/v27.0"
RECENT = 30


def _path():
    d = os.path.join(load_config()["work_root"], "_learning")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "accounts.json")


def load():
    try:
        return json.load(open(_path()))
    except Exception:
        return []


def _save(a):
    tmp = _path() + ".tmp"
    json.dump(a, open(tmp, "w"), indent=1)
    os.replace(tmp, _path())


def normalize(url):
    """-> (platform, canonical url, handle). Raises ValueError with what to paste instead."""
    u = (url or "").strip()
    if u.lower() in ("instagram", "ig"):
        return "instagram", "instagram", "instagram"
    if not re.match(r"https?://", u):
        u = "https://" + u
    m = re.match(r"https?://(?:www\.|m\.)?youtube\.com/(@[\w.-]+|channel/[\w-]+|c/[\w.-]+)", u)
    if m:
        return "youtube", "https://www.youtube.com/%s" % m.group(1), m.group(1).lstrip("@")
    m = re.match(r"https?://(?:www\.|m\.)?tiktok\.com/@([\w.-]+)/?(?:$|\?)", u)
    if m:
        return "tiktok", "https://www.tiktok.com/@%s" % m.group(1), m.group(1)
    m = re.match(r"https?://(?:www\.|m\.)?twitch\.tv/([A-Za-z0-9_]{2,30})/?(?:videos.*)?$", u)
    if m:
        return "twitch", "https://www.twitch.tv/%s" % m.group(1).lower(), m.group(1)
    m = re.match(r"https?://(?:www\.)?kick\.com/([A-Za-z0-9_-]{2,40})/?$", u)
    if m:
        return "kick", "https://kick.com/%s" % m.group(1).lower(), m.group(1)
    if re.match(r"https?://(?:www\.)?instagram\.com/", u):
        raise ValueError("Instagram only shares views through its official API: connect Instagram in Settings → "
                         "Posting (your own token), then add 'instagram' here")
    if re.match(r"https?://(?:www\.)?(x|twitter)\.com/", u):
        raise ValueError("X accounts can't be tracked: X hides view counts from the public and its API is paid.")
    raise ValueError("paste a profile link like https://www.youtube.com/@name, https://www.tiktok.com/@name, "
                     "https://www.twitch.tv/name or https://kick.com/name")


# ------------------------------------------------------------------ listing posts
def _ytdlp(url, n=RECENT):
    from .common import run
    from .fetch import _ytdlp_base
    # A profile listing is one small request: retry little and give up fast, so a blocked site answers in about a
    # minute instead of retrying for many minutes (downloads keep their patient retries).
    base = _ytdlp_base(load_config())
    for flag, val in (("--retries", "2"), ("--extractor-retries", "1"), ("--socket-timeout", "15")):
        if flag in base:
            base[base.index(flag) + 1] = val
    try:
        r = run(base + ["--flat-playlist", "--playlist-end", str(n), "-J", url], timeout=100, check=False)
    except Exception as e:                      # timed out
        raise RuntimeError("timed out reading %s" % url) from e
    if r.returncode != 0:
        msg = ((r.stderr or "").strip().splitlines() or ["couldn't read the account"])[-1]
        raise RuntimeError(msg[:300])
    return json.loads(r.stdout or "{}")


def _entries_youtube(acct, lister):
    posts, followers = [], None
    for tab, kind in (("/shorts", "short"), ("/videos", "video")):
        try:
            j = lister(acct["url"] + tab)
        except RuntimeError:
            continue
        followers = followers or j.get("channel_follower_count")
        for e in j.get("entries") or []:
            if e.get("id"):
                posts.append({"id": e["id"], "title": e.get("title") or "", "views": e.get("view_count"),
                              "duration": e.get("duration"), "at": e.get("timestamp"),
                              "url": ("https://youtube.com/shorts/" if kind == "short" else "https://www.youtube.com/watch?v=") + e["id"]})
    if not posts:
        raise RuntimeError("couldn't read that channel's videos")
    return posts, followers


def _entries_flat(acct, lister):
    url = acct["url"] + ("/videos?filter=archives&sort=time" if acct["platform"] == "twitch" else "")
    j = lister(url)
    posts = []
    for e in j.get("entries") or []:
        if not e.get("id"):
            continue
        link = e.get("url") or e.get("webpage_url") or ""
        if acct["platform"] == "tiktok" and not link.startswith("http"):
            link = "https://www.tiktok.com/@%s/video/%s" % (acct["handle"], e["id"])
        if acct["platform"] == "twitch" and not link.startswith("http"):
            link = "https://www.twitch.tv/videos/%s" % str(e["id"]).lstrip("v")
        posts.append({"id": str(e["id"]), "title": e.get("title") or e.get("description") or "", "views": e.get("view_count"),
                      "duration": e.get("duration"), "at": e.get("timestamp"), "url": link})
    return posts, j.get("channel_follower_count")


def _entries_kick(acct, _lister=None):
    try:
        from curl_cffi import requests as creq            # Kick sits behind Cloudflare; a browser-like client helps
    except ImportError:
        raise RuntimeError("Kick tracking needs curl_cffi (run the installer again)")
    r = creq.get("https://kick.com/api/v2/channels/%s" % acct["handle"].lower(), impersonate="chrome", timeout=30)
    if r.status_code != 200:
        raise RuntimeError("Kick answered %s" % r.status_code)
    ch = r.json()
    posts = []
    for v in ch.get("previous_livestreams") or []:
        vid = (v.get("video") or {}).get("uuid") or v.get("slug") or v.get("id")
        posts.append({"id": str(vid), "title": v.get("session_title") or "", "views": v.get("views"),
                      "duration": (v.get("duration") or 0) / 1000.0 or None, "at": None,
                      "url": "https://kick.com/%s/videos/%s" % (acct["handle"], vid)})
    return posts, ch.get("followers_count") or ch.get("followersCount")


def _ig_get(path, params, token, api=None):
    q = dict(params, access_token=token)
    url = (api or IG_API) + path + "?" + urllib.parse.urlencode(q)
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "clipbot"}), timeout=40) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        try:
            err = json.loads(e.read()).get("error", {})
        except Exception:
            err = {}
        if e.code in (400, 401) and err.get("code") == 190:
            raise RuntimeError("your Instagram token expired - make a new one and paste it in Settings → Posting")
        raise RuntimeError("Instagram: %s" % (err.get("message") or e.code))


def ig_cfg():
    from .connect import get
    return get().get("instagram") or {}


def ig_check(token, api=None):
    """Validate a token and return the account it belongs to."""
    me = _ig_get("/me", {"fields": "user_id,username,followers_count,media_count"}, token, api)
    if not me.get("username"):
        raise RuntimeError("that token didn't return an Instagram account")
    return me


IG_REFRESH_EVERY = 7 * 86400     # Instagram tokens last 60 days; refreshing (allowed once a token is a day old) restarts that


def ig_refresh_if_due(now=None, api=None):
    """Keep the saved Instagram token alive: swap it for a fresh 60-day one about once a week."""
    now = now or time.time()
    c = ig_cfg()
    tok = c.get("token")
    if not tok or now - max(c.get("refreshed") or 0, c.get("saved") or 0) < IG_REFRESH_EVERY:
        return False
    j = _ig_get("/refresh_access_token", {"grant_type": "ig_refresh_token"}, tok,
                api=(api or IG_API).rsplit("/v", 1)[0])
    if j.get("access_token"):
        from . import connect
        connect.save({"instagram": dict(c, token=j["access_token"], refreshed=int(now))})
        return True
    return False


def _entries_instagram(acct, _lister=None, api=None):
    tok = ig_cfg().get("token")
    if not tok:
        raise RuntimeError("connect Instagram first (Settings → Posting → Instagram)")
    me = _ig_get("/me", {"fields": "username,followers_count"}, tok, api)
    media = _ig_get("/me/media", {"fields": "id,caption,media_product_type,media_type,permalink,timestamp",
                                  "limit": RECENT}, tok, api).get("data") or []
    posts = []
    for m in media:
        if m.get("media_type") != "VIDEO" and m.get("media_product_type") != "REELS":
            continue
        views = None
        try:
            ins = _ig_get("/%s/insights" % m["id"], {"metric": "views"}, tok, api).get("data") or []
            views = next((d["values"][0]["value"] for d in ins if d.get("name") == "views" and d.get("values")), None)
        except RuntimeError as e:
            if "expired" in str(e):
                raise
        ts = None
        try:
            ts = int(time.mktime(time.strptime(m.get("timestamp", "")[:19], "%Y-%m-%dT%H:%M:%S")))
        except Exception:
            pass
        posts.append({"id": m["id"], "title": (m.get("caption") or "").split("\n")[0][:120], "views": views,
                      "duration": None, "at": ts, "url": m.get("permalink") or ""})
    acct["handle"] = me.get("username") or acct.get("handle")
    return posts, me.get("followers_count")


READERS = {"youtube": _entries_youtube, "tiktok": _entries_flat, "twitch": _entries_flat, "kick": _entries_kick,
           "instagram": _entries_instagram}


# ------------------------------------------------------------------ matching posts to your clips
def _words(t):
    return set(w for w in re.findall(r"[a-z0-9$]+", (t or "").lower()) if len(w) > 2)


def _clip_index(root):
    out = []
    try:
        for d in os.listdir(root):
            sp = os.path.join(root, d, "specs.json")
            if os.path.isfile(sp):
                try:
                    for s in json.load(open(sp)):
                        txt = " ".join(x for x in (s.get("headline"), s.get("title")) if x)
                        if txt:
                            out.append({"project": os.path.join(root, d), "clip": s.get("name"), "words": _words(txt),
                                        "dur": float(s.get("end", 0)) - float(s.get("start", 0))})
                except Exception:
                    continue
    except OSError:
        pass
    return out


def match(post, index):
    """Best clip for a post: most shared title words (>= 60% of the clip's words), length within 4 s if both known."""
    pw = _words(post.get("title"))
    if len(pw) < 2:
        return None
    best, score = None, 0.0
    for c in index:
        if not c["words"]:
            continue
        sc = len(pw & c["words"]) / float(len(c["words"]))
        if post.get("duration") and c["dur"] and abs(float(post["duration"]) - c["dur"]) > 4:
            continue
        if sc > score:
            best, score = c, sc
    return best if score >= 0.6 else None


# ------------------------------------------------------------------ managing
NAMES = {"youtube": "YouTube", "tiktok": "TikTok", "twitch": "Twitch", "kick": "Kick", "instagram": "Instagram"}


def friendly_error(e, platform=None):
    """yt-dlp and site errors -> one plain sentence the person can act on."""
    raw = str(e)
    low = raw.lower()
    site = NAMES.get(platform, "The site")
    if isinstance(e, ValueError) and "\n" not in raw:
        return raw[:300]
    if any(k in low for k in ("does not exist", "404", "not found", "unable to find", "no such", "couldn't find")):
        return "%s couldn't find that account. Check the name in the link." % site
    if any(k in low for k in ("login", "sign in", "cookies", "private", "secondary user id", "403", "blocked", "captcha")):
        return ("%s didn't let Clipbot read that profile right now. Check the name, or pick your browser under Settings → \"Subscriber-only VODs\" "
                "(it uses your logins) and try again." % site)
    if any(k in low for k in ("timed out", "timeout", "connection", "network", "resolve", "unreachable")):
        return "Couldn't reach %s. Check your internet connection and try again." % site
    if "token expired" in low or "instagram" in low and "token" in low:
        return raw.splitlines()[0][:300]
    first = raw.strip().splitlines()[0] if raw.strip() else "unknown error"
    return ("%s: %s" % (site, first.replace("ERROR: ", "")))[:300]


def add(url, _reader=None):
    plat, canon, handle = normalize(url)
    with _LOCK:
        if any(a["url"] == canon for a in load()):
            raise ValueError("you're already tracking that account")
    acct = {"url": canon, "platform": plat, "handle": handle, "added": int(time.time()), "checked": 0,
            "followers": None, "posts": [], "history": [], "linked": 0, "error": None}
    refresh_one(acct, _reader=_reader)
    if acct["error"] and not acct["posts"]:
        raise RuntimeError(acct["error"])
    with _LOCK:
        a = load()
        a.append(acct)
        _save(a)
    return acct


def remove(url):
    with _LOCK:
        a = load()
        keep = [x for x in a if x["url"] != url]
        _save(keep)
        return len(a) - len(keep)


def refresh_one(acct, _reader=None, now=None, root=None):
    now = now or time.time()
    try:
        posts, followers = (_reader or READERS[acct["platform"]])(acct, _ytdlp)
        acct["error"] = None
    except Exception as e:
        acct["error"] = friendly_error(e, acct.get("platform"))
        acct["checked"] = int(now)
        return acct
    acct["checked"] = int(now)
    acct["followers"] = followers if followers is not None else acct.get("followers")
    old = {p["id"]: p for p in acct.get("posts") or []}
    for p in posts:
        if p["id"] in old and old[p["id"]].get("clip"):
            p["clip"], p["project"] = old[p["id"]]["clip"], old[p["id"]]["project"]
    acct["posts"] = posts[:60]
    total = sum(p["views"] or 0 for p in posts)
    acct["history"] = (acct.get("history") or [])[-60:] + [[int(now), total, acct["followers"]]]
    # link matching posts to clips: they then appear in Results and feed the learning loop
    from . import post as _post
    index = _clip_index(root or load_config()["work_root"])
    tracked = {(p["url"]) for p in _post.posts()}
    linked = 0
    for p in posts:
        if not p.get("url"):
            continue
        if not p.get("clip"):
            c = match(p, index)
            if c:
                p["clip"], p["project"] = c["clip"], c["project"]
        if p.get("clip") and p["url"] not in tracked:
            try:
                _post.track(p["url"], p["project"], p["clip"])
                tracked.add(p["url"])
            except Exception:
                continue
        if p.get("clip"):
            linked += 1
            if p.get("views") is not None:
                _post.set_views(p["url"], p["views"], now)
    acct["linked"] = linked
    return acct


def refresh_all(force=False, now=None):
    now = now or time.time()
    out = []
    try:
        ig_refresh_if_due(now)
    except Exception as e:
        log("instagram token refresh: %s" % e)
    for acct in load():
        if not force and now - acct.get("checked", 0) < 6 * 3600:
            continue
        refresh_one(acct, now=now)
        with _LOCK:
            a = load()
            for i, x in enumerate(a):
                if x["url"] == acct["url"]:
                    a[i] = acct
            _save(a)
        out.append(acct["url"])
    return out


def summary():
    rows = []
    for a in load():
        h = a.get("history") or []
        prev = next((x for x in reversed(h[:-1]) if h and h[-1][0] - x[0] >= 20 * 3600), None)
        rows.append({"url": a["url"], "platform": a["platform"], "handle": a["handle"], "followers": a.get("followers"),
                     "views_recent": h[-1][1] if h else None, "posts": len(a.get("posts") or []),
                     "growth": (h[-1][1] - prev[1]) if prev else None, "linked": a.get("linked", 0),
                     "checked": a.get("checked"), "error": a.get("error"),
                     "top": sorted((p for p in a.get("posts") or [] if p.get("views") is not None),
                                   key=lambda p: -p["views"])[:5]})
    return rows

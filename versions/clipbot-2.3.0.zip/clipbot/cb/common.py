"""Shared helpers: subprocess, probing, config + state files."""
import json
import os
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG_PATH = os.path.join(ROOT, "config.json")
STATE_PATH = os.path.join(ROOT, "state.json")
FONT_DIR = os.path.join(ROOT, "fonts")           # bundled OFL fonts (no admin rights needed)
YUNET = os.path.join(ROOT, "models", "yunet.onnx")
FPS = 30
VERSION = "0.9.0-beta (2026-11-03)"

# Homebrew's plain "ffmpeg" is a slim build without libass/freetype (no burned-in captions or text); the full
# build ("brew install ffmpeg-full") is keg-only, so put it first on PATH for us, yt-dlp and every subprocess.
for _d in ("/opt/homebrew/opt/ffmpeg-full/bin", "/usr/local/opt/ffmpeg-full/bin", os.path.join(ROOT, "bin")):
    if os.path.isfile(os.path.join(_d, "ffmpeg")) and _d not in os.environ.get("PATH", "").split(os.pathsep)[:1]:
        os.environ["PATH"] = _d + os.pathsep + os.environ.get("PATH", "")


class CmdError(RuntimeError):
    pass


def log(*a):
    print(*a, file=sys.stderr, flush=True)


def run(cmd, timeout=1800, check=True, quiet=True):
    """Run a command. Raises CmdError on non-zero exit (never fail silently)."""
    if not quiet:
        log("+ " + " ".join(str(c) for c in cmd))
    r = subprocess.run([str(c) for c in cmd], capture_output=True, text=True, timeout=timeout)
    if check and r.returncode != 0:
        raise CmdError("command failed (%d): %s\n%s" % (r.returncode, " ".join(str(c) for c in cmd[:8]),
                                                          (r.stderr or r.stdout)[-2000:]))
    return r


def ffmpeg(args, timeout=1800):
    return run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error"] + list(args), timeout=timeout)


def probe(path):
    """-> dict(width, height, duration, fps, has_audio)"""
    r = run(["ffprobe", "-v", "error", "-show_entries",
             "stream=codec_type,width,height,r_frame_rate:format=duration", "-of", "json", path])
    j = json.loads(r.stdout)
    v = next((s for s in j.get("streams", []) if s.get("codec_type") == "video"), {})
    a = any(s.get("codec_type") == "audio" for s in j.get("streams", []))
    num, _, den = (v.get("r_frame_rate") or "30/1").partition("/")
    fps = float(num) / float(den or 1) if float(den or 1) else 30.0
    return {"width": int(v.get("width") or 0), "height": int(v.get("height") or 0),
            "duration": float(j.get("format", {}).get("duration") or 0), "fps": fps, "has_audio": a}


def fpath(p):
    """Path as an ffmpeg filter option value (ass=filename=, drawtext=fontfile=, fontsdir=). Escaped for both
    levels ffmpeg parses (option value, then filtergraph), so Windows drives (C:), spaces, apostrophes
    (C:/Users/John's PC), commas and brackets all work. Use it UNQUOTED: filename=%s"""
    p = os.path.abspath(p).replace("\\", "/")
    p = "".join("\\" + c if c in "\\':" else c for c in p)          # level 1: option value
    return "".join("\\" + c if c in "\\'[],;" else c for c in p)    # level 2: filtergraph


def concat_path(p):
    """Path for an ffmpeg concat list: forward slashes, single-quoted, apostrophes escaped ('\\'')."""
    return "'%s'" % os.path.abspath(p).replace("\\", "/").replace("'", "'\\''")


def safe_remove(path):
    """Delete a temp file if the folder allows it (synced/mounted folders may refuse deletes)."""
    try:
        os.remove(path)
    except OSError:
        pass


def load_json(path, default):
    if not os.path.exists(path):
        return default
    with open(path) as f:
        txt = f.read().strip()
    return json.loads(txt) if txt else default


def save_json(path, obj):
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(obj, f, indent=1)
    os.replace(tmp, path)  # atomic: a crash mid-write never corrupts state


def load_config():
    cfg = load_json(CONFIG_PATH, {})
    cfg.setdefault("channels", [])
    cfg.setdefault("work_root", "~/Clipbot")
    wr = os.path.expanduser(os.environ.get("CLIPBOT_WORK_ROOT", cfg["work_root"]))
    parent = os.path.dirname(wr.rstrip("/")) or "/"
    if not (os.path.isdir(wr) and os.access(wr, os.W_OK)) and not os.access(parent, os.W_OK):
        wr = os.path.expanduser("~/Clipbot")       # e.g. the cloud default on a tester's laptop
    cfg["work_root"] = wr
    cfg.setdefault("whisper_model", "small")
    cfg.setdefault("max_height", 1080)
    cfg.setdefault("max_new_per_channel", 2)
    cfg.setdefault("max_download_attempts", 6)
    try:                                   # spellings the user taught by fixing words ("Fix it everywhere")
        learned = load_json(os.path.join(wr, "_settings", "vocab.json"), [])
        if learned:
            cfg["vocab"] = list(dict.fromkeys(list(cfg.get("vocab") or []) + [str(v) for v in learned][:300]))
    except Exception:
        pass
    return cfg


def load_state():
    st = load_json(STATE_PATH, {})
    st.setdefault("seen_video_ids", [])
    st.setdefault("pending", {})   # id -> {url, title, channel, attempts, last_error, first_seen}
    st.setdefault("failed", {})    # gave up after max attempts
    return st


def save_state(st):
    save_json(STATE_PATH, st)


def now_iso():
    return time.strftime("%Y-%m-%dT%H:%M:%S")

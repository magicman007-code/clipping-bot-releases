"""One-shot auto-clipping: link or file in -> scored, rendered, editable clips out.

  python3 clipbot.py autoclip <url | file> [--name x] [--clips 6] [--min-score 6] [--captions karaoke] [--draft]

Steps (progress in <project>/autoclip_status.json, which the editor polls):
  import -> transcribe -> find candidates -> score (cb/score.py) -> keep >= min_score (bar defaults to 6.0)
  -> draft headline + titles -> render -> re-score with render QA -> drop anything that fell below the bar
  -> write specs.json (open the project in the editor to tweak any clip) -> QC inbox.
Nothing below the bar is rendered as a deliverable; the rejects are listed with their scores and reasons.
"""
import json
import os
import re
import time
import traceback

from .common import ffmpeg, safe_remove, load_config, log, probe


def _status(d, **kw):
    p = os.path.join(d, "autoclip_status.json")
    st = json.load(open(p)) if os.path.exists(p) else {}
    st.update(kw, updated=time.strftime("%H:%M:%S"))
    tmp = p + ".tmp"
    json.dump(st, open(tmp, "w"), indent=1)
    os.replace(tmp, p)
    return st


def _project_dir(root, name):
    return os.path.join(root, re.sub(r"[^\w.-]+", "_", name)[:60] or "clip_project")


def draft_headline(c):
    """Starting headline from the strongest line (flagged for a human to rewrite)."""
    from .moments import LEX, _rx
    rx = [_rx(LEX[k]) for k in ("stakes", "shock", "drama", "humor")]
    sents = [re.sub(r"\s+", " ", s).strip() for _, s in c.get("sentences", [])]
    sents = [s for s in sents if s]
    if not sents:
        return ""
    whole = [s for s in sents if s[0].isupper() or s[0] in "$\"'0123456789"]   # skip sentences cut mid-way
    best = max(whole or sents, key=lambda s: sum(len(r.findall(s)) for r in rx) * 10 + min(len(s.split()), 12))
    w = best.split()
    out = " ".join(w[:11]).rstrip(",.") + ("..." if len(w) > 11 else "")
    out = re.sub(r"\bi\b", "I", out)
    return out[:1].upper() + out[1:]



def check_source(path, need_audio=True):
    """Readable reasons for files we can't use - instead of a raw ffmpeg error."""
    from .common import probe
    try:
        p = probe(path)
    except Exception:
        raise RuntimeError("Can't read this file as a video - it may be damaged, still downloading, or not a "
                           "video at all. Try re-downloading/re-exporting it (MP4 works best).")
    if not p["width"] or not p["height"]:
        raise RuntimeError("This file has no video picture in it (audio-only?). Use a video file.")
    if p["duration"] and p["duration"] < 3:
        raise RuntimeError("This video is only %.1fs long - too short to clip. Use a video of at least a few seconds."
                           % p["duration"])
    if need_audio and not p["has_audio"]:
        raise RuntimeError("This video has no sound, so auto-clip can't find the moments (it listens for them). "
                           "Choose \"I'll cut it myself\" to edit it by hand.")
    return p


def project_name(source):
    """Readable project name from a file path or link (Dropbox/Drive query strings stripped)."""
    if re.match(r"https?://", source):
        name = re.sub(r"\W+", "_", os.path.splitext(source.split("?")[0].rstrip("/").split("/")[-1])[0])[:40]
        if name.lower() in ("view", "edit", "open", "uc", "download", "preview", "share", ""):
            name = "drive_video"
        return name
    return os.path.splitext(os.path.basename(source))[0]


def auto_count(dur):
    """How many clips to aim for when the user leaves it on Auto: about one per 8 minutes, 6 to 40."""
    return int(min(40, max(6, round(dur / 480.0))))


def source_kind(source):
    s = (source or "").lower()
    for k, pat in (("twitch", "twitch.tv"), ("kick", "kick.com"), ("youtube", "youtu"), ("dropbox", "dropbox"),
                   ("drive", "drive.google"), ("wetransfer", "we.tl"), ("wetransfer", "wetransfer")):
        if pat in s:
            return k
    return "link" if s.startswith("http") else "file"


ERROR_KINDS = (("sub_only", r"subscriber|sub-only"), ("gone", r"deleted|no longer|removed"),
               ("blocked", r"block|403|bot|sign in"), ("no_speech", r"No speech"), ("too_short", r"too short"),
               ("bad_file", r"isn't a playable|not found|no audio|unsupported"), ("disk", r"No space|disk"),
               ("download", r"Download failed|download"), ("ffmpeg", r"ffmpeg"), ("transcribe", r"whisper|transcri"))


def _connectors():
    try:
        from .connect import profile
        return profile()
    except Exception:
        return None


def error_kind(msg):
    for k, rx in ERROR_KINDS:
        if re.search(rx, msg or "", re.I):
            return k
    return "other"


def run(*args, **kwargs):
    """Auto-clip (see _run), then log one anonymous 'run' event: which features were used, how it went, how long
    it took and what kind of error (never paths, links or text) - so the publisher can see what to improve."""
    import inspect
    t0 = time.time()
    st = _run(*args, **kwargs)
    ba = inspect.signature(_run).bind(*args, **kwargs)
    ba.apply_defaults()
    kw = ba.arguments
    source = kw["source"]
    try:
        from . import learn
        ch, ar = st.get("chat") or {}, st.get("ai_rank") or {}
        learn.record("run", None, None, run={
            "source": source_kind(source), "state": st.get("state"), "secs": round(time.time() - t0),
            "video_min": round((st.get("duration") or 0) / 60.0, 1), "section": bool(kw.get("section")),
            "manual": bool(kw.get("manual")), "prompt": bool(kw.get("prompt")), "streamer": bool(kw.get("streamer")),
            "aspect": kw.get("aspect", "9:16"), "extra_aspects": len(kw.get("also_aspects") or []),
            "captions": kw.get("captions") or "default", "asked": kw.get("clips", 6), "min_score": kw.get("min_score", 6.0),
            "candidates": st.get("candidates"), "passing": st.get("passing"),
            "made": len([c for c in st.get("clips") or [] if isinstance(c, dict) and c.get("file")]),
            "render_errors": len([c for c in st.get("clips") or [] if isinstance(c, dict) and c.get("error")]),
            "scores": [c.get("score") for c in st.get("clips") or [] if isinstance(c, dict) and c.get("score")],
            "chat": ch.get("messages") if ch.get("used") else 0, "ai": bool(ar.get("used")), "ai_moved": ar.get("moved"),
            "scorer": bool((st.get("scorer") or {}).get("used")), "learning": bool(st.get("learning")),
            "ai_src": ar.get("source"), "ai_skip": None if ar.get("used") or not ar else (ar.get("why") or "")[:60],
            "connectors": _connectors(),
            "error": error_kind(st.get("error")) if st.get("state") == "error" else None})
        learn.send_async()
    except Exception:
        pass
    return st


def _run(source, root=None, name=None, clips=6, min_score=6.0, captions=None, banner=None, draft=False,
         render=True, cfg=None, layout="auto", exclude=(), aspect="9:16", also_aspects=None, headline=True, manual=False, exclude_texts=(),
         prompt=None, streamer=None, section=None, chat_file=None, more=False, preset=None, campaign=None, skill=None):
    """exclude: [(a, b)] source-time windows already clipped (e.g. by the live detector) - not clipped again.
    banner=False -> no banner even if the link is a Kick/Twitch channel. headline=False -> no headline card.
    aspect: 9:16 | 4:5 | 1:1 | 16:9 ; also_aspects: extra ratios rendered alongside (name_1x1.mp4 ...).
    prompt: "every time he talks about X" / "funny moments" -> clips matching it (prompt_clip.py).
    streamer: a lore profile name (lore.py) -> names spelled right, callbacks to running jokes rank higher.
    manual=True: import + transcribe only, then open the editor with one starter clip to cut by hand
    (the AI picks are still listed as suggestions; nothing is auto-rendered)."""
    cfg = cfg or load_config()
    root = root or cfg["work_root"]
    is_url = bool(re.match(r"https?://", source))
    name = name or project_name(source)
    d = _project_dir(root, name)
    os.makedirs(d, exist_ok=True)
    _status(d, state="importing", source=source, step=1, steps=6, clips=[], rejected=[], error=None, manual=False, note=None, detail=None,
            started=time.time(), tpart=0, tparts=0, rk=0, rn=0, more=bool(more),
            opts={"min_score": min_score, "captions": captions, "aspect": aspect, "also_aspects": also_aspects,
                  "headline": headline, "prompt": prompt, "streamer": streamer, "layout": layout,
                  "preset": preset, "campaign": campaign, "skill": skill})
    try:
        # 1 import
        src = os.path.join(d, "source.mp4")
        if not os.path.exists(src):
            if is_url:
                from .fetch import download
                from .fetch import FRIENDLY
                path, kind, info = download(source, d, cfg, section=section)
                if not path and kind == "bad_link":
                    raise RuntimeError(info)
                if not path:
                    raise RuntimeError(FRIENDLY.get(kind) or (
                        "Download failed. The site may be blocking this network - download the video yourself and drop "
                        "the file in instead.\n%s" % info[-300:]))
                src = path
            else:
                if not os.path.exists(source):
                    raise RuntimeError("file not found: %s" % source)
                check_source(source, need_audio=False)
                try:    # lossless remux when the codecs allow it, else a fast re-encode
                    ffmpeg(["-i", source, "-map", "0:v:0", "-map", "0:a:0?", "-c", "copy", "-movflags", "+faststart", src])
                except Exception:
                    ffmpeg(["-i", source, "-map", "0:v:0", "-map", "0:a:0?", "-vf", "fps=30", "-c:v", "libx264",
                            "-preset", "veryfast", "-crf", "18", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart",
                            src], timeout=7200)
        from . import lore as _lore
        prof = _lore.load(streamer)
        vocab = list(cfg.get("vocab") or []) + _lore.vocab(prof)
        if streamer:
            _status(d, streamer=streamer, lore_loaded=bool(prof))
        if section:          # only part of a long video: cut it out once (downloads may already be cut)
            a_, b_ = section
            full = probe(src)["duration"]
            if b_ and full > (b_ - a_) + 5:
                part = os.path.join(d, "source_part.mp4")
                ffmpeg(["-ss", "%.2f" % a_, "-to", "%.2f" % min(b_, full), "-i", src, "-map", "0:v:0", "-map", "0:a:0?",
                        "-c", "copy", "-avoid_negative_ts", "make_zero", "-movflags", "+faststart", part])
                os.replace(part, os.path.join(d, "source.mp4"))
                src = os.path.join(d, "source.mp4")
                for f in ("words.json", "transcript.txt", "sentences.json", "voiceband.wav", "candidates.json"):
                    safe_remove(os.path.join(d, f))
            _status(d, section=[a_, b_])
        pr = check_source(src, need_audio=not manual)
        dur = pr["duration"]
        if not clips:          # "Auto": longer videos get more clips (still only the ones that pass the bar)
            clips = auto_count(dur)
        _status(d, target=clips)
        # 2 transcribe
        _status(d, state="transcribing", step=2, duration=round(dur, 1))
        from .transcribe import transcribe_video
        if not is_url and not os.path.exists(os.path.join(d, "words.json")):
            prev = os.path.join(os.path.dirname(os.path.abspath(source)), "words.json")
            if os.path.exists(prev) and abs(probe(source)["duration"] - dur) < 1.0:
                import shutil
                shutil.copyfile(prev, os.path.join(d, "words.json"))   # already transcribed: reuse, don't redo
        try:
            words = transcribe_video(src, d, cfg["whisper_model"], vocab,
                                     progress=lambda i, n: _status(d, detail="part %d of %d (10 min each)" % (min(i + 1, n), n),
                                                                   tpart=i, tparts=n, tpart_at=time.time()))
        except Exception:
            if not manual:
                raise
            words = []          # hand editing still works without a transcript (no auto captions)
        if manual:
            if words:
                try:
                    from .moments import find_candidates, write_candidates
                    write_candidates(find_candidates(words, src, d, top_k=12), d)
                except Exception:
                    pass
            spath = os.path.join(d, "specs.json")
            old = json.load(open(spath)) if os.path.exists(spath) else []
            if not old:
                old = [{"name": "01_my_clip", "source": src, "start": 0.0, "end": round(min(30.0, dur), 2),
                        "segments": [[0.0, round(min(30.0, dur), 2)]], "headline": "", "layout": layout,
                        "captions": captions or cfg.get("caption_style", "karaoke") if words else "none",
                        "banner": None if banner is False else banner, "aspect": aspect,
                        "also_aspects": also_aspects or None}]
                json.dump(old, open(spath, "w"), indent=1)
            return _status(d, state="done", step=6, clips=[], manual=True,
                           note=None if words else "no speech found / speech model unavailable - captions are off")
        if not words:
            raise RuntimeError("No speech found, so auto-clip has nothing to go on (music-only or silent video?). "
                               "Choose \"I'll cut it myself\" to edit it by hand.")
        # 3 candidates + 4 score
        _status(d, state="finding moments", step=3, detail=("matching: " + prompt[:80]) if prompt else None,
                prompt=prompt or None)
        from .moments import find_candidates, write_candidates
        from .score import score_candidate
        niche = tuple(cfg.get("niche") or ())
        prompt_info = None
        from . import style as _style
        sty = (prof or {}).get("style")
        lr = _style.length_range(sty)
        kw = _style.kind_weights(sty)
        lens = {"min_len": lr[0], "max_len": lr[1]} if lr else {}
        from . import learn as _learn                 # what this user keeps/deletes/rates (learn.py)
        adj = _learn.adjustments()
        for k_, w_ in (adj.get("kind_w") or {}).items():
            kw[k_] = round(kw.get(k_, 1.0) * w_, 2)
        if adj.get("hook_boost", 1.0) != 1.0:
            kw["_hook"] = adj["hook_boost"]
        if adj.get("len_shift"):
            lo_, hi_ = lens.get("min_len", 15.0), lens.get("max_len", 58.0)
            sh = adj["len_shift"]
            lens = {"min_len": max(8.0, lo_ + sh / 2), "max_len": min(120.0, max(lo_ + sh / 2 + 8, hi_ + sh))}
        from . import chat as _chat                # chat replay: where the audience exploded (chat.py)
        if chat_file and os.path.exists(chat_file):
            import shutil
            ext = os.path.splitext(chat_file)[1].lower()
            shutil.copyfile(chat_file, os.path.join(d, "chat" + (ext if ext in (".json", ".txt", ".csv") else ".json")))
        _status(d, detail="looking for the chat replay")
        chat_act, chat_info = _chat.load(d, source if is_url else None, cfg, section=section, dur=dur)
        _status(d, chat=chat_info, detail=None)
        if adj:
            _status(d, learning="applied: %s" % ", ".join(sorted(adj.get("kind_w") or {})) if adj.get("kind_w") else "applied")
        if sty:
            _status(d, style=_style.describe(sty))
        if prompt and prompt.strip():
            from .prompt_clip import find as prompt_find
            cands, prompt_info = prompt_find(prompt, words, src, d, n=max(12, clips * 3), lore=_lore.terms(prof),
                                             lore_aliases=_lore.aliases(prof), kind_w=kw, chat=chat_act, **lens)
            _status(d, prompt_info=prompt_info)
            if not cands:
                return _status(d, state="done", step=6, clips=[],
                               note="Nothing in this video matches \"%s\". Try other words, or leave the prompt "
                                    "empty to let the AI pick." % prompt.strip()[:80])
        else:
            cands = find_candidates(words, src, d, niche=niche, top_k=max(12, clips * 3), lore=_lore.terms(prof),
                                    kind_w=kw, chat=chat_act, **lens)
        _style.similarity(sty, cands)      # "resembles their best clips" -> part of the quality score
        for c in cands:
            c["quality"] = score_candidate(c)
        write_candidates(cands, d)          # with scores: the editor lists the ones under the bar to use by hand
        def _overlap(c):
            return any(min(c["end"], b) - max(c["start"], a) > 0.5 * (c["end"] - c["start"]) for a, b in exclude)
        dup_live = [c for c in cands if _overlap(c)]
        cands = [c for c in cands if not _overlap(c)]
        keep = [c for c in cands if c["quality"]["score"] >= min_score]
        rejected = [{"start": c["start"], "end": c["end"], "score": c["quality"]["score"],
                     "why": c["quality"]["why"]} for c in cands if c["quality"]["score"] < min_score] + \
            [{"start": c["start"], "end": c["end"], "score": c["quality"]["score"],
              "why": ["already clipped live"]} for c in dup_live]
        if prompt_info:   # prompt clips: best match first, quality breaks ties
            keep.sort(key=lambda c: (-round(c.get("relevance", 0), 1), -c["quality"]["score"]))
        else:
            keep.sort(key=lambda c: -c["quality"]["score"])

        def toks(c):
            return set(re.findall(r"[a-z']{3,}", " ".join(x[1] for x in c["sentences"]).lower()))
        uniq, heads = [], set()
        prior = [set(t) for t in exclude_texts or ()]      # e.g. moments already clipped live
        for c in keep:          # duplicate suppression: the same story told twice is one clip
            tc = toks(c)
            hk = re.sub(r"\W+", " ", draft_headline(c).lower()).strip()
            if all(len(tc & toks(u)) / float(max(1, len(tc | toks(u)))) < 0.6 for u in uniq) and \
                    all(len(tc & p_) / float(max(1, len(tc | p_))) < 0.5 for p_ in prior) and \
                    (not hk or hk not in heads):
                uniq.append(c)
                heads.add(hk)
            else:
                rejected.append({"start": c["start"], "end": c["end"], "score": c["quality"]["score"],
                                 "why": ["duplicate of a higher-scoring clip (same story)"]})
        from . import ai_rank as _ai               # optional second opinion from the user's own AI key
        if _ai.enabled() and uniq:
            _status(d, detail="asking your AI for a second opinion")
            from .presets import load_skill
            ai_info = _ai.rerank(uniq, streamer=streamer, prof=prof, prompt=prompt if prompt_info else None,
                                 skill=load_skill(skill) if skill else None)
            _status(d, ai_rank=ai_info, detail=None)
        from .connect import scorer_ready
        if scorer_ready() and uniq:
            _status(d, detail="asking your scorer")
            _status(d, scorer=_ai.external(uniq), detail=None)
        spath = os.path.join(d, "specs.json")
        old = json.load(open(spath)) if os.path.exists(spath) else []
        if more and old:       # "More clips": skip moments that overlap clips this project already has
            taken = [(float(s_["start"]), float(s_["end"])) for s_ in old]
            fresh = []
            for c in uniq:
                if any(min(c["end"], b2) - max(c["start"], a2) > 0.3 * (c["end"] - c["start"]) for a2, b2 in taken):
                    rejected.append({"start": c["start"], "end": c["end"], "score": c["quality"]["score"],
                                     "why": ["already a clip in this project"]})
                else:
                    fresh.append(c)
            uniq = fresh
        backups = uniq[clips:clips + 3]        # rendered only if a clip drops below the bar after render QA
        keep = uniq[:clips]
        _status(d, state="scored", step=4, candidates=len(cands), passing=len(keep), rejected=rejected[:20])
        # 5 specs
        from .banner import from_url
        bnr = None if banner is False else (banner or (from_url(source, "socials") if is_url else None) or cfg.get("banner"))
        _status(d, banner_used=bnr)
        def mkspec(i, c):
            return ({"name": "%02d_clip" % i, "source": src, "start": c["start"], "end": c["end"],
                          "segments": [[c["start"], c["end"]]], "headline": (draft_headline({"sentences": [(0, c["match"])]}) if prompt_info and c.get("match")
                                       else draft_headline(c)) if headline else "",
                          "headline_draft": bool(headline), "aspect": aspect, "also_aspects": also_aspects or None,
                          "captions": captions or cfg.get("caption_style", "karaoke"), "layout": layout,
                          "banner": bnr, "quality": c["quality"],
                          "candidate": dict({k: c[k] for k in ("score", "tags", "payoff_mag", "novelty", "dur")},
                                            chat_z=c.get("chat_z"), chat_mood=c.get("chat_mood"),
                                            style_sim=c.get("style_sim"),
                                            ai_score=(c.get("ai") or {}).get("score"),
                                            ai_why=(c.get("ai") or {}).get("why"),
                                            ai_src=(c.get("ai") or {}).get("src"),
                                            ext_score=(c.get("ext") or {}).get("score"),
                                            ext_why=(c.get("ext") or {}).get("why")),
                          "match": {"prompt": prompt, "line": c.get("match"), "relevance": c.get("relevance")}
                          if prompt_info else None,
                          "orig": [c["start"], c["end"]], "origin": "prompt" if prompt_info else "auto"})
        first = 1
        if more:               # continue the numbering after the clips already there
            nums = [int(m.group(1)) for m in (re.match(r"(\d+)_", s_["name"]) for s_ in old) if m]
            first = max(nums) + 1 if nums else len(old) + 1
        from . import presets as _presets          # the campaign's look / the chosen preset, on every clip
        camp = _presets.load_campaign(campaign) if campaign else None
        pr = _presets.load_preset(preset or (camp or {}).get("preset"))
        _mk = mkspec

        def mkspec(i, c):                           # noqa: F811
            s_ = _mk(i, c)
            if pr:
                s_ = _presets.apply(s_, pr)
            if camp:
                s_["campaign"] = camp["name"]
            return s_
        specs = [mkspec(i, c) for i, c in enumerate(keep, first)]
        if more:
            keep_old = list(old)                                             # keep every clip already made
        else:
            keep_old = [s for s in old if not s["name"].endswith("_clip")]   # never clobber hand-made clips

        def save_specs(lst):
            json.dump(keep_old + lst, open(spath, "w"), indent=1)
        save_specs(specs)
        if not render or not specs:
            return _status(d, state="done", step=6, clips=[s["name"] for s in specs],
                           note=None if specs else ("This video is only %ds - too short for auto-clip. Choose \"I'll cut it myself\" instead." % dur
                                                     if dur < 20 else ("%d moment(s) matched \"%s\" but scored under %.1f/10 - they're listed in AI picks, so you "
                                                     "can still make them into clips." % (len(cands), prompt.strip()[:60], min_score)
                                                     if prompt_info else "No moment reached the %.1f bar - see the rejected list." % min_score)))
        # 6 render
        from .render import make_clip
        from .review import ledger_append, write_gallery
        from .score import adjust_after_render
        out = os.path.join(d, "renders")
        done, results, passed = [], [], []
        queue = list(specs)
        nxt_i = first + len(specs)
        k = 0
        while queue and len(passed) < clips:
            s = queue.pop(0)
            k += 1
            _status(d, state="rendering %d/%d" % (k, k + len(queue)), step=5, clips=done, rk=k - 1, rn=k + len(queue),
                    rk_at=time.time(), rk_dur=round(float(s["end"]) - float(s["start"]), 1))
            sp = dict(s)
            if draft:
                sp["_draft"] = True
            try:
                res = make_clip(sp, out, os.path.join(d, "_work"), cfg)
            except Exception as e:
                done.append({"name": s["name"], "error": str(e)[-400:]})
                continue
            q = adjust_after_render(s["quality"], res)
            res["quality"] = q
            json.dump(res, open(os.path.join(out, res["name"] + ".json"), "w"), indent=1)
            ledger_append(res, sp)
            if q["score"] < min_score:
                # dropped below the bar after render QA: park the files, try a backup moment instead
                bdir = os.path.join(out, "_below_bar")
                os.makedirs(bdir, exist_ok=True)
                import glob as _g
                import shutil as _sh
                for f in _g.glob(os.path.join(out, res["name"] + "*")):
                    if os.path.isfile(f):
                        _sh.move(f, os.path.join(bdir, os.path.basename(f)))
                rejected.append({"start": s["start"], "end": s["end"], "score": q["score"],
                                 "why": ["below the bar after render QA"] + q["why"][-3:]})
                if backups:
                    queue.append(mkspec(nxt_i, backups.pop(0)))
                    nxt_i += 1
                _status(d, rejected=rejected[:20])
                continue
            results.append(res)
            passed.append(s)
            s["headline_orig"] = s.get("headline", "")
            _learn.record("auto_clip", s, d)
            done.append({"name": res["name"], "file": res["out"], "score": q["score"], "dur": res["dur"],
                         "start": s["start"], "end": s["end"], "passes": True, "headline": s["headline"],
                         "warnings": res["qa"]["warnings"]})
        save_specs(passed + [x for x in specs if x not in passed and any(x["name"] == e.get("name") and e.get("error")
                                                                        for e in done)])
        if results:
            write_gallery(results, out)
        try:
            from .connect import fire
            fire("autoclip_done", {"project": os.path.basename(d), "clips": len(passed),
                                   "files": [r["out"] for r in results], "titles": [x.get("headline") for x in passed]})
            _learn.send_async()
        except Exception:
            pass
        return _status(d, state="done", step=6, clips=done, project=d, passing=len(passed),
                       note=None if passed else "every rendered clip fell below the %.1f bar - see rejected" % min_score)
    except Exception as e:
        log(traceback.format_exc())
        try:
            from .connect import fire
            fire("autoclip_failed", {"name": os.path.basename(d), "error": str(e).splitlines()[0][:200] if str(e) else ""})
        except Exception:
            pass
        return _status(d, state="error", error=str(e)[-800:])

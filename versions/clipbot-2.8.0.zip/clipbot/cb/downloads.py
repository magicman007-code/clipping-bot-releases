"""Getting finished videos out of Clipbot, the easy way.

save(paths, project)  copies finished files straight into the computer's Downloads folder (Downloads/Clipbot), with
                      readable names. No browser save dialog, works the same on Mac and PC, never overwrites a file.
everything(dir)       every finished video of a project (vertical + other shapes, not quick previews) + its caption files
reveal(path)          opens the folder with the file selected (Finder / Explorer / the Linux file manager)
nice_name(path, project) the readable file name used for both of the above and for browser downloads
"""
import os
import re
import shutil
import subprocess
import sys

KEEP = (".mp4", ".mov", ".srt", ".vtt", ".png", ".jpg", ".jpeg")


def downloads_dir():
    home = os.path.expanduser("~")
    for d in (os.environ.get("CLIPBOT_DOWNLOADS"), os.path.join(home, "Downloads"),
              os.path.join(os.environ.get("USERPROFILE") or home, "Downloads")):
        if d and os.path.isdir(d):
            return os.path.join(d, "Clipbot")
    return os.path.join(home, "Downloads", "Clipbot")       # created below


def nice_name(path, project=""):
    base = os.path.basename(path)
    proj = re.sub(r"[^\w.-]+", "_", os.path.basename(str(project or "").rstrip("/\\"))).strip("_")[:40]
    name = re.sub(r"[^\w.-]+", "_", base).strip("_") or "clip.mp4"
    return (proj + "-" + name) if proj and not name.startswith(proj) else name


def _unique(dst):
    if not os.path.exists(dst):
        return dst
    stem, ext = os.path.splitext(dst)
    n = 2
    while os.path.exists("%s (%d)%s" % (stem, n, ext)):
        n += 1
    return "%s (%d)%s" % (stem, n, ext)


def _same(a, b):
    try:
        return os.path.getsize(a) == os.path.getsize(b) and int(os.path.getmtime(a)) == int(os.path.getmtime(b))
    except OSError:
        return False


def save(paths, project=""):
    """-> {"folder", "files": [saved paths], "skipped": [[path, why]]}"""
    out = downloads_dir()
    os.makedirs(out, exist_ok=True)
    saved, skipped = [], []
    for p in paths:
        if not os.path.isfile(p):
            skipped.append([p, "not rendered yet"])
            continue
        dst = os.path.join(out, nice_name(p, project))
        if os.path.exists(dst) and _same(p, dst):       # already there (pressed twice): don't make "(2)" copies
            saved.append(dst)
            continue
        dst = _unique(dst)
        shutil.copy2(p, dst + ".part")
        os.replace(dst + ".part", dst)                  # never leaves half a video with the real name
        saved.append(dst)
    return {"folder": out, "files": saved, "skipped": skipped}


def everything(d):
    rd = os.path.join(d, "renders")
    if not os.path.isdir(rd):
        return []
    files = []
    for f in sorted(os.listdir(rd)):
        p = os.path.join(rd, f)
        if not os.path.isfile(p) or not f.lower().endswith(KEEP) or f.startswith("."):
            continue
        if "_draft" in f or f.endswith(".part") or "_qc" in f or "sheet" in f:
            continue
        if f.lower().endswith((".png", ".jpg", ".jpeg")):  # contact sheets and frames aren't exports
            continue
        files.append(p)
    return files


def reveal(path):
    """Open the file's folder with the file selected. Returns the folder."""
    path = os.path.abspath(path)
    folder = path if os.path.isdir(path) else os.path.dirname(path)
    try:
        if sys.platform == "darwin":
            subprocess.Popen(["open", "-R", path] if os.path.isfile(path) else ["open", folder])
        elif os.name == "nt":
            subprocess.Popen(["explorer", "/select,", path] if os.path.isfile(path) else ["explorer", folder])
        else:
            subprocess.Popen(["xdg-open", folder], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass                                             # the folder path is still shown to the person
    return folder

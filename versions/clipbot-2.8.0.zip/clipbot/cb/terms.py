"""Terms of use: the text lives in TERMS.md; acceptance is stored per install in <work_root>/_settings/terms.json.

The version is a hash of the text, so if the terms ever change, Clipbot asks again."""
import hashlib
import json
import os
import time

from .common import ROOT, load_config, save_json

PATH = os.path.join(ROOT, "TERMS.md")


def text():
    try:
        return open(PATH, encoding="utf-8").read()
    except OSError:
        return ""


def version():
    return hashlib.sha256(text().encode("utf-8")).hexdigest()[:12]


def _file():
    d = os.path.join(load_config()["work_root"], "_settings")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "terms.json")


def accepted():
    try:
        return json.load(open(_file())).get("version") == version()
    except Exception:
        return False


def accept():
    v = version()
    save_json(_file(), {"version": v, "at": int(time.time())})
    return {"version": v, "accepted": True}


def status():
    from .connect import get
    c = get()
    fb, ai = c.get("feedback") or {}, c.get("ai") or {}
    return {"text": text(), "version": version(), "accepted": accepted(),
            "choices": {"share": bool(fb.get("enabled")), "share_text": bool(fb.get("include_text")),
                        "free_ai": ai.get("provider") != "off"}}

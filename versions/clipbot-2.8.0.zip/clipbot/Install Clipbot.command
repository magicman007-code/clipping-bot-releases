#!/bin/bash
# Double-click me (Mac). Installs Clipbot the first time, adds Clipbot to your Applications folder and opens it.
cd "$(dirname "$0")" || exit 1
chmod +x install.sh start.sh clipbot 2>/dev/null
xattr -dr com.apple.quarantine . 2>/dev/null
if [ ! -f .clipbot_python ]; then
  echo "Setting up Clipbot (the first time takes a few minutes)..."
  ./install.sh || { echo; echo "Setup didn't finish - see the messages above."; read -r -p "Press Return to close."; exit 1; }
fi
PYBIN="$(cat .clipbot_python)"
"$PYBIN" clipbot.py app
for A in /Applications/Clipbot.app "$HOME/Applications/Clipbot.app"; do
  if [ -d "$A" ]; then
    open "$A"
    echo
    echo "Done. From now on open Clipbot from Applications, Launchpad or Spotlight (Cmd+Space, type Clipbot)."
    echo "You can close this window."
    exit 0
  fi
done
echo "Couldn't add the app - starting Clipbot here instead (keep this window open)."
exec ./start.sh

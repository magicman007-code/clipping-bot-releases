"""Long-form: a stream (or any long talking footage) -> a finished YouTube video.

  build(project_dir, minutes=10, ...) -> <project>/edits/<name>.mp4 + <name>_chapters.txt + <name>_plan.json

How it decides, in order:
  1. stories   the transcript is scanned for self-contained stretches (40 s - 3 min) with the same moment finder
               auto-clip uses, scored the same way; overlapping stretches are merged into the best one
  2. selection the best stories are kept until the target length is reached, then put back in the order they
               happened (the video still makes sense as a story)
  3. cold open the most gripping 6-12 s line from the chosen stories plays first, as a hook, then a title card
  4. chapters  each story gets a short title card (and a YouTube chapter timestamp in the description file)
  5. tighten   every story is rendered with dead air and um/uh removed, loudness levelled, captions optional
Everything is rendered with the normal clip renderer, so framing, captions, banners and looks all apply.
"""
import json
import os
import re
import time

from .common import FONT_DIR, ffmpeg, load_config, log, probe, safe_remove

ASPECTS = {"16:9": (1920, 1080), "9:16": (1080, 1920), "1:1": (1080, 1080)}


def _hms(t):
    t = int(round(t))
    return ("%d:%02d:%02d" % (t // 3600, t % 3600 // 60, t % 60)) if t >= 3600 else ("%d:%02d" % (t // 60, t % 60))


def _secs(line):
    v = 0
    for x in line.split(" ", 1)[0].split(":"):
        v = v * 60 + int(x)
    return v


def stories(words, src, workdir, min_len=40.0, max_len=180.0, top_k=80):
    from .moments import find_candidates
    from .score import score_candidate
    cs = find_candidates(words, src, workdir, min_len=min_len, max_len=max_len, top_k=top_k)
    for c in cs:
        c["quality"] = score_candidate(c)
    cs.sort(key=lambda c: -c["quality"]["score"])
    keep = []
    for c in cs:                      # overlapping windows are the same story: keep the best-scoring one
        if all(min(c["end"], k["end"]) - max(c["start"], k["start"]) <= 3.0 for k in keep):
            keep.append(c)
    return keep


def select(cands, target_s, min_score=4.0):
    chosen, total = [], 0.0
    for c in cands:
        if c["quality"]["score"] < min_score and chosen:
            break
        if total >= target_s:
            break
        chosen.append(c)
        total += c["end"] - c["start"]
    return sorted(chosen, key=lambda c: c["start"])


def cold_open(chosen, words):
    """The most gripping short line inside the chosen stories: [a, b] or None."""
    from .transcribe import sentences_from_words
    from .moments import LEX, _rx
    rx = [_rx(LEX[k]) for k in ("stakes", "shock", "drama", "humor") if k in LEX]
    best = None
    for c in chosen:
        ws = [w for w in words if w[0] >= c["start"] and w[1] <= c["end"]]
        for s in sentences_from_words(ws, max_gap=0.6, max_len=12):
            dur = s["end"] - s["start"]
            if not 4.0 <= dur <= 12.0:
                continue
            txt = s["text"] if isinstance(s, dict) and "text" in s else " ".join(w[2] for w in ws if s["start"] <= w[0] <= s["end"])
            hits = sum(len(r.findall(txt)) for r in rx)
            sc = hits * 2 + c["quality"]["score"] / 10.0 + ("!" in txt) * 0.3 + ("?" in txt) * 0.2
            if hits and (best is None or sc > best[0]):
                best = (sc, s["start"] - 0.25, s["end"] + 0.35)
    return [round(best[1], 2), round(best[2], 2)] if best else None


def card(text, out, W, H, secs=1.6, sub=None, big=False):
    """A title card: big white words on black, fading in and out (silent audio track so pieces concat)."""
    from PIL import Image, ImageDraw, ImageFont
    img = Image.new("RGB", (W, H), (0, 0, 0))
    d = ImageDraw.Draw(img)
    fp = os.path.join(FONT_DIR, "Anton-Regular.ttf")
    size = int(H * (0.11 if W > H else 0.065) * (1.45 if big else 1.0))
    words, lines, cur = text.upper().split(), [], ""
    f = ImageFont.truetype(fp, size)
    for w in words:
        t = (cur + " " + w).strip()
        if d.textlength(t, font=f) <= W * 0.82 or not cur:
            cur = t
        else:
            lines.append(cur)
            cur = w
    lines.append(cur)
    lh = int(size * 1.1)
    y = (H - lh * len(lines)) / 2 - (lh * 0.3 if sub else 0)
    for l in lines[:4]:
        d.text(((W - d.textlength(l, font=f)) / 2, y), l, font=f, fill=(255, 255, 255))
        y += lh
    if sub:
        fs = ImageFont.truetype(os.path.join(FONT_DIR, "Montserrat-Black.ttf"), int(size * 0.32))
        d.text(((W - d.textlength(sub.upper(), font=fs)) / 2, y + lh * 0.2), sub.upper(), font=fs, fill=(255, 77, 61))
    png = out + ".png"
    img.save(png)
    ffmpeg(["-loop", "1", "-t", "%.2f" % secs, "-i", png, "-f", "lavfi", "-t", "%.2f" % secs, "-i",
            "anullsrc=channel_layout=stereo:sample_rate=48000",
            "-vf", "fps=30,format=yuv420p,fade=t=in:st=0:d=0.25,fade=t=out:st=%.2f:d=0.3" % (secs - 0.3),
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "18", "-c:a", "aac", "-b:a", "192k", "-ar", "48000",
            "-shortest", out])
    safe_remove(png)
    return out


def build(project, minutes=10.0, aspect="16:9", name=None, title=None, captions="none", cold=True, chapters=True,
          min_score=4.0, preset=None, progress=None, draft=False, parts=None, cold_range=None):
    """Render the long-form video. progress(done, total, what) is called as pieces finish."""
    from .render import make_clip
    from .autoclip import draft_headline
    src = os.path.join(project, "source.mp4")
    wj = os.path.join(project, "words.json")
    if not os.path.exists(src) or not os.path.exists(wj):
        raise ValueError("this project hasn't been transcribed yet - auto-clip or import it first")
    words = json.load(open(wj))
    dur = probe(src)["duration"]
    if dur < 120:
        raise ValueError("this video is only %ds - long-form needs at least a few minutes of footage" % dur)
    target = max(60.0, min(float(minutes) * 60, dur * 0.9))
    if aspect not in ASPECTS:
        aspect = "16:9"
    W, H = ASPECTS[aspect]
    name = re.sub(r"[^\w-]+", "_", name or "youtube_%s" % time.strftime("%m%d_%H%M"))[:60]
    out_dir = os.path.join(project, "edits")
    work = os.path.join(out_dir, "_" + name)
    os.makedirs(work, exist_ok=True)
    if parts:                                    # edited by hand: exactly these parts, in this order
        chosen = []
        for p in parts[:60]:
            try:
                a_, b_ = max(0.0, float(p["start"])), min(dur, float(p["end"]))
            except (KeyError, TypeError, ValueError):
                raise ValueError("each part needs a start and an end")
            if b_ - a_ < 2:
                raise ValueError("a part is shorter than 2 seconds - check its start and end")
            chosen.append({"start": a_, "end": b_, "quality": {"score": float(p.get("score") or 0)},
                           "title": str(p.get("title") or "").strip()[:80], "sentences": []})
        if not chosen:
            raise ValueError("keep at least one part")
    else:
        if progress:
            progress(0, 1, "finding the best stories")
        cands = stories(words, src, project, max_len=min(180.0, max(60.0, target / 3)))
        chosen = select(cands, target, min_score)
        if not chosen:
            raise ValueError("couldn't find stories that score well enough in this video")
    pr = None
    if preset:
        from .presets import load_preset
        pr = load_preset(preset)
    if cold_range and cold:
        co = [max(0.0, float(cold_range[0])), min(dur, float(cold_range[1]))]
        if co[1] - co[0] < 1:
            co = None
    else:
        co = cold_open(chosen, words) if cold and not parts else (cold_open(chosen, words) if cold else None)
    base = {"source": src, "aspect": aspect, "captions": captions or "none", "headline": "", "tighten": True,
            "banner": None, "layout": "auto"}
    if pr:
        from .presets import apply as _apply
        base = _apply(base, pr)
        base.update(aspect=aspect, headline="")
    plan, pieces = [], []
    steps = len(chosen) + (2 if co else 0) + (len(chosen) if chapters else 0) + 1
    k = 0

    def tick(what):
        nonlocal k
        k += 1
        if progress:
            progress(k, steps, what)
    if co:
        sp = dict(base, name="00_cold_open", start=co[0], end=co[1], segments=[co], tighten=False)
        if draft:
            sp["_draft"] = True
        r = make_clip(sp, work, os.path.join(work, "_r"), load_config(), all_words=words)
        pieces.append(r["out"])
        tick("cold open")
        pieces.append(card(title or chosen[0].get("title") or draft_headline(chosen[0]) or "WATCH THIS", os.path.join(work, "01_title.mp4"),
                           W, H, 2.0, big=True))
        tick("title card")
    marks = {}                                   # piece index -> chapter part number
    for i, c in enumerate(chosen, 1):
        head = c.get("title") or draft_headline(c) or "Part %d" % i
        if chapters:
            marks[len(pieces)] = i
            pieces.append(card(head, os.path.join(work, "%02d_card.mp4" % (i * 2)), W, H, 1.4, sub="part %d" % i))
            tick("chapter card %d" % i)
        else:
            marks[len(pieces)] = i
        sp = dict(base, name="%02d_story" % (i * 2 + 1), start=c["start"], end=c["end"], segments=[[c["start"], c["end"]]])
        if draft:
            sp["_draft"] = True
        r = make_clip(sp, work, os.path.join(work, "_r"), load_config(), all_words=words)
        plan.append({"part": i, "title": head, "start": round(c["start"], 2), "end": round(c["end"], 2),
                     "score": c["quality"]["score"]})
        pieces.append(r["out"])
        tick("story %d of %d" % (i, len(chosen)))
    at, cum = {}, 0.0
    for j, pth in enumerate(pieces):
        if j in marks:
            at[marks[j]] = cum
        cum += probe(pth)["duration"]
    for p in plan:
        p["at"] = round(at.get(p["part"], 0.0), 2)
    # ---- join (re-encode once, so every piece's timing and format line up exactly)
    lst = os.path.join(work, "concat.txt")
    open(lst, "w").write("".join("file '%s'\n" % p.replace("'", "'\\''") for p in pieces))
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, name + ".mp4")
    ffmpeg(["-f", "concat", "-safe", "0", "-i", lst, "-vf", "scale=%d:%d:force_original_aspect_ratio=decrease,"
            "pad=%d:%d:(ow-iw)/2:(oh-ih)/2,fps=30,format=yuv420p" % (W, H, W, H), "-c:v", "libx264",
            "-preset", "veryfast" if draft else "medium", "-crf", "20", "-c:a", "aac", "-b:a", "192k", "-ar", "48000",
            "-movflags", "+faststart", out], timeout=4 * 3600)
    tick("joining")
    total = probe(out)["duration"]
    lines = ["0:00 Intro"] if co else []
    for p in plan:                               # YouTube chapters: first at 0:00, each at least 10 s long
        if lines and p["at"] - _secs(lines[-1]) < 10:
            if len(lines) == 1:                  # part 1 starts right after the intro: it takes the 0:00 slot
                lines[0] = "0:00 " + p["title"]
            continue
        lines.append("%s %s" % ("0:00" if not lines else _hms(p["at"]), p["title"]))
    open(os.path.join(out_dir, name + "_chapters.txt"), "w").write("\n".join(lines) + "\n")
    json.dump({"source": src, "minutes": minutes, "aspect": aspect, "cold_open": co, "parts": plan, "title": title,
               "captions": captions, "chapter_cards": chapters, "name": name,
               "length": round(total, 1)}, open(os.path.join(out_dir, name + "_plan.json"), "w"), indent=1)
    return {"file": out, "length": round(total, 1), "parts": len(plan), "chapters": "\n".join(lines),
            "chapters_file": os.path.join(out_dir, name + "_chapters.txt")}

"""Getting a long-form edit out the door: a YouTube title, description (with chapters) and tags.

package(project, name) -> {"title", "description", "tags", "ai"}   (saved to edits/<name>_package.json)
Uses the connected AI (or the free built-in one) on what the chosen parts actually say; without AI it builds a plain
package from the part titles and the most-said words. Chapters are always the real ones from <name>_chapters.txt.
"""
import collections
import json
import os
import re

STOP = set("""a an the and or but if so to of in on at for with from by as is are was were be been it its this that
these those i you he she we they me him her us them my your his our their what which who when where why how not no
yes just like really very gonna wanna got get go going know think yeah okay ok oh um uh mean right all out up down
then there here now one two do did does dont can cant will would could should have has had about into over more some
any thing things kind sort lot little bit gotta lets let im youre hes thats whats time back still even much
zero one two three four five six seven eight nine ten eleven twelve twenty thirty forty fifty hundred thousand
million okay well because guys literally actually basically""".split())


def _paths(project, name):
    ed = os.path.join(project, "edits")
    if not re.match(r"^[\w-]{1,80}$", name or "") or not os.path.isfile(os.path.join(ed, name + ".mp4")):
        raise ValueError("that edit doesn't exist")
    return ed, os.path.join(ed, name + ".mp4")


def _text_of(project, parts, limit=6000):
    try:
        words = json.load(open(os.path.join(project, "words.json")))
    except Exception:
        return ""
    out = []
    for p in parts:
        out.append(" ".join(w[2] for w in words if p["start"] <= w[0] <= p["end"]))
    t = "\n".join(out)
    return t[:limit]


def keywords(text, n=12):
    c = collections.Counter(w for w in re.findall(r"[a-z][a-z']{3,}", text.lower()) if w.replace("'", "") not in STOP)
    return [w for w, k in c.most_common(n) if k >= 2]


def package(project, name, complete=None, use_ai=True):
    ed, _vid = _paths(project, name)
    try:
        plan = json.load(open(os.path.join(ed, name + "_plan.json")))
    except Exception:
        plan = {"parts": []}
    parts = plan.get("parts") or []
    chapters = ""
    cp = os.path.join(ed, name + "_chapters.txt")
    if os.path.exists(cp):
        chapters = open(cp).read().strip()
    text = _text_of(project, parts)
    kws = keywords(text)
    title = (plan.get("title") or (parts[0]["title"] if parts else name.replace("_", " "))).strip()
    summary = ""
    tags = kws[:10]
    ai = False
    if use_ai and text:
        try:
            if complete is None:
                from .connect import ai_complete, ai_ready
                if not ai_ready():
                    raise RuntimeError("off")
                complete = ai_complete
            system = ("You package a YouTube video made from a livestream. Using ONLY what is in the transcript (never "
                      "invent events, numbers or names), return JSON: {\"title\": under 70 characters, curiosity without "
                      "lying, no clickbait the video doesn't deliver; \"summary\": 2-3 short sentences for the "
                      "description; \"tags\": 8-12 search tags}.")
            parts_txt = "\n".join("- %s" % p["title"] for p in parts)
            out = complete("Chapter titles:\n%s\n\nTranscript of the video:\n%s" % (parts_txt, text), system=system,
                           max_tokens=500)
            m = re.search(r"\{.*\}", out or "", re.S)
            j = json.loads(m.group(0)) if m else {}
            if j.get("title"):
                title, ai = str(j["title"]).strip()[:100], True
            summary = str(j.get("summary") or "").strip()[:1200]
            t2 = [re.sub(r"[^\w\s'-]", "", str(t)).strip()[:30] for t in (j.get("tags") or []) if str(t).strip()]
            if t2:
                tags = t2[:12]
        except Exception:
            pass
    if not summary:
        summary = "In this video: " + "; ".join(p["title"] for p in parts[:6]) + "." if parts else ""
    desc = "\n\n".join(x for x in (summary, ("Chapters:\n" + chapters) if chapters else "",
                                   " ".join("#" + re.sub(r"\W", "", t) for t in tags[:3] if re.sub(r"\W", "", t))) if x)
    res = {"title": title[:100], "description": desc[:4900], "tags": tags, "ai": ai}
    json.dump(res, open(os.path.join(ed, name + "_package.json"), "w"), indent=1)
    return res


def saved(project, name):
    try:
        return json.load(open(os.path.join(project, "edits", name + "_package.json")))
    except Exception:
        return None

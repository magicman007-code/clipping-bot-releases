# Clipbot beta - tester guide

Thanks for testing! Everything runs on your own computer: no account, no uploads to anyone's server,
no watermark, no subscription.

## 1. Install (once, ~5 minutes)

**Mac**
1. Install Homebrew if you don't have it: https://brew.sh (paste the one line it shows into Terminal).
2. Unzip `clipbot-beta.zip`, open Terminal, then:
   ```
   cd ~/Downloads/clipbot      # wherever you unzipped it
   ./install.sh
   ```
   (If macOS says the file can't be opened: right-click `install.sh` -> Open, or run `chmod +x install.sh start.sh`.)

**Windows**
1. Install **Python 3.12** from https://www.python.org/downloads/ - tick **"Add python.exe to PATH"** on the
   first screen. (3.10-3.13 all work; the newest 3.14 may not have every package yet.)
2. Unzip `clipbot-beta.zip` somewhere simple like `C:\clipbot` (not inside OneDrive), right-click
   `install.ps1` -> **Run with PowerShell**. It installs ffmpeg with winget if you don't have it.
   If Windows says scripts are disabled, open PowerShell in the folder and run:
   `powershell -ExecutionPolicy Bypass -File install.ps1`

The installer ends with a `doctor` report. `"ready": true` means you're good. Warnings about network
or disk space are OK to ignore for a first try.

## 2. Start

- Mac: `./start.sh`   ·   Windows: double-click `start.bat`

Your browser opens **Clipbot Studio** at **http://127.0.0.1:8765** (if that port is busy it uses 8766, 8767… and
says so in the window). The first time, you land on the **Home** screen with three choices: **Auto-clip a video**,
**Edit it myself**, or **Clip a live stream**. Press **Take the 1-minute tour** there (or **Tour** in the top bar any
time) for a guided walk-through of every part of the screen. A **demo project** is included, so you can try everything
before using your own footage. Projects live in `~/Clipbot` (Windows: `C:\Users\<you>\Clipbot`).

The **first time you clip real footage**, the speech model downloads automatically (~500 MB for the
default "small" model). Leave it running; later runs start straight away.

**The screen:** the left rail has Home, New, Clips, AI picks, Transcript, Live and Jobs. The middle is the live
preview (drag captions, headline, text and the picture itself). The right side has the clip's settings in tabs:
Clip, Captions, Text, Stickers, Audio, Look, Export. The timeline at the bottom trims the clip. **Render clip**
(top right) makes the final MP4; **Quick preview** makes a fast half-size check first.

**Progress:** while auto-clip runs, a bar in the top bar shows how far along it is and roughly how long is left.
Long videos are fine (tested with 25-minute files); they just take longer. Reloading the page picks the bar back up.

## 3. Clip anything (Home -> Auto-clip / Edit it myself, or the New tab in the left rail)

Pick a mode first:
- **Auto-clip**: the AI finds the best moments, scores them and renders the ones that pass.
- **I'll cut it myself**: it only imports (and transcribes, for captions) and opens the editor with a
  30-second starter clip. Drag the clip edges on the timeline, click/shift-click sentences in **Transcript**, or
  press **New clip at playhead** to make as many clips as you want. The AI picks are still listed under
  **AI picks** as suggestions you can ignore. (No speech / no speech model? It still imports, with captions off.)

- **A video file:** drag it onto "drop a video here" (or the Home screen), or press "Choose a video file…".
  MP4, MOV, MKV, WebM, phone videos (rotated), 4K/60fps, vertical or square all work. Multi-hour VODs work.
- **A link:** paste a Kick VOD, Twitch VOD, YouTube video, or Kick/Twitch clip link and press **Auto-clip it**.
  Kick VODs: copy the link from the streamer's **Videos** page (kick.com/name/videos/...). Twitch: twitch.tv/videos/...
  **Long VOD?** Fill in "Only part of a long VOD" (e.g. from 1:00:00 to 2:30:00) and only that stretch is downloaded.
  **Subscriber-only VODs:** Settings → "Subscriber-only VODs" → pick the browser you're logged in with.
  If YouTube or Twitch changes something and a download fails, Clipbot updates its downloader by itself and retries.
  (Some sites block downloads now and then. If a link fails, download the video yourself and drop the file in.)
- **Dropbox / Google Drive / WeTransfer:** paste the share link of the **video file** (Share -> Copy link, or the
  we.tl link). It downloads the file directly; a WeTransfer with several files arrives as a zip and Clipbot takes the
  video out of it. Folder links don't work (it tells you), Drive files must be shared "Anyone with the link", and
  WeTransfer links expire after 7 days on the free plan.
- Choose how many clips, the minimum score (default **6/10**: nothing below the bar gets rendered),
  caption style (or none), the streamer banner (auto from a Kick/Twitch link, a handle you type, or **no banner**),
  headline card on/off, and the **output ratio**: 9:16 (TikTok/Reels/Shorts), 4:5 (Instagram feed), 1:1 (square)
  or 16:9 (YouTube/X). Tick "also export" to get the same clip in extra ratios (files end in `_1x1`, `_16x9`...).

It transcribes, finds the moments, scores them, renders the ones that pass, and opens the project.
Rejected moments are listed in **Jobs** with the reason (e.g. "weak opening line", "duplicate").
Every clip is checked again after it renders (sound level, faces, captions). If one drops below the bar it is set
aside in `renders/_below_bar` and the next-best moment is rendered instead, so what you get is all 6/10 or better.

## 3b. Find any moment by describing it (left rail -> Find)

Type what you want: "every time he talks about the coin", "funniest moments", "when chat goes crazy",
"donations and subs", "the part where he explains his strategy". It searches **by meaning**, so "losing money" finds
"I watched $100,000 disappear" even with no shared words. Each result shows the line it matched, how well it matches
(the yellow bar) and its quality score. **Preview** jumps to it, **Make clip** turns it into a clip with a draft
headline, **Make all** does every result. You can also type the prompt in **What should it clip?** before an
auto-clip run, so it only clips what you asked for.

The meaning model downloads once (~90 MB) the first time you search. Without internet it still works by keywords.

## 3c. Streamer lore (left rail -> Lore)

Teach Clipbot what the community knows: the streamer's friends and rivals, nicknames ("Orangie = orange, the
orange guy"), catchphrases and running jokes. Then pick the streamer under **Streamer** when you start a project.
It spells those names right in captions and headlines, ranks callbacks to running jokes higher (that's what
regular viewers share), and lets prompts use nicknames.

**Study their best clips:** in the same panel, press **Add clips…** and pick clips of theirs that did well (from
their channel, or a clipper's TikTok you downloaded). Press **Study these clips**. Clipbot transcribes each one and
learns how long their hits are, how fast they talk, what kind of moments they are (reactions, rage, awkward,
stories, money...) and how they open. From then on, clipping that streamer favours moments that resemble those
hits, at that length. The more clips (10+ is ideal), the stronger the effect; with a few it only nudges. **Suggest from these projects** reads their past streams and
suggests names and phrases that keep coming back; click the real ones to add them, then **Save lore**.

**What Clipbot looks for** (from research on the most-shared stream clips): genuine reactions and "chat, clip
that" moments, rage, awkward or embarrassing moments, stories with a payoff, stakes and money, stream events
(subs, raids, donations), callbacks to running jokes, and a voice that suddenly jumps (a scream or a laugh). It marks
down intros, sponsor reads and "hit follow" talk, and openings that only make sense if you watched the stream
("and then he...").

## 4. Live clipping (Home -> Clip a live stream, or Live in the left rail)

1. Paste the stream link (kick.com/name or twitch.tv/name). Optional chat for better detection:
   `twitch:channelname` or `kick:channelname`.
2. Tick "I own this channel or have permission to clip it" (only clip streams you're allowed to).
3. **Start live clipping.** It records the whole stream, clips good moments as they happen (each one
   renders while the stream continues), and when the stream ends it builds a **highlight reel** and a
   **recap.md**. Set "Wait for it to go live" to start it before the streamer goes live.
4. **Clip last 30s / 60s** buttons make an instant clip of what just happened.
5. After the stream it also sweeps the **whole recording** for anything the live pass missed (it skips
   moments already clipped), so leave it running until it says *finished*.

Command-line version (same thing, handy for an all-night stream):
```
./clipbot live-watch https://kick.com/NAME --authorized --wait-hours 6
```
(Windows: `clipbot live-watch ...` from a Command Prompt in the folder.) Ctrl+C stops it cleanly and still builds the recap.

### Watch channels: every new VOD gets clipped automatically

Live tab -> **Watch channels**. Paste `twitch.tv/name`, `kick.com/name` or `youtube.com/@handle`, pick the streamer's
lore and how many clips, then **Watch**. While the editor is open, Clipbot checks every 30 minutes. When a new VOD
has finished (its length stops changing), it auto-clips it in the background and the clips show up in Jobs and the
project list. VODs that already existed are skipped; tick **Also clip their most recent VOD now** to start with
the latest one. Command line: `./clipbot watch add twitch.tv/name --streamer Name`, then `./clipbot watch run`.

### Chat explosions

When chat floods right after something happens (KEKW, LUL, W, "???", 💀), that moment ranks higher, and the clip
card says *💬 chat exploded (laughing)*. YouTube and Twitch VOD chat is fetched automatically (Twitch sometimes
refuses; then export the chat with TwitchDownloader). For Kick, or any other source, drop a chat file in the
**Chat replay** box on the New screen.

## 5. Edit any clip

Click a clip in **Clips**. Everything previews live:

| Panel | What you can do |
|---|---|
| Timeline (bottom) | drag the clip edges, **S** = split, **Del** = cut a segment (jump cut), drag to scrub, double-click a word to fix it |
| Clip | **output ratio** (9:16 / 4:5 / 1:1 / 16:9, preview switches shape) + "also export" other ratios, headline (+ its own font, text colour, box colour), **Remove headline**, **Remove all overlays** (headline, text, stickers, banner, watermark; Ctrl+Z undoes), layout (follow speaker / split / webcam+screen / full frame / gameplay below), drag the picture to reframe, speed, auto-remove pauses, payoff teaser, zooms |
| Captions | 4 styles or **None** (clean version), 25 bundled fonts + **Upload font…** (.ttf/.otf/.woff), bold / italic / shadow, text colour, highlight colour (presets or any colour), outline colour + width, letter spacing, size, drag them on the preview, ALL CAPS, censor, edit every word + timing, **Export .srt / Import .srt** |
| Text / Stickers | add text layers (any font, bold/italic, spacing, colour, stroke, box, animation) and emoji/image stickers, drag + scroll to resize, set when they show |
| Audio | voice volume, **replace the audio** with another track, mix a track under it, mute all of it or **mute just a section** (a swear, a bad mic moment), background music that ducks under speech |
| Look | colour looks, brightness/contrast/saturation/warmth, vignette, progress bar, watermark, **streamer banner** (Kick K + name, Twitch, uploaded campaign banners, end card) |
| Export | suggested titles (each checked against what's actually said), thumbnails (16:9 + 9:16), quick preview render, final render, **Approve / Reject** |

Every final render also writes a **.srt subtitle file** next to the .mp4 (same lines and timing as the burned-in
captions) for YouTube/TikTok uploads. Want a clean copy without burned captions? Set captions to **None** and render.
Fonts you upload are kept in `Clipbot/_fonts` and show up in every font menu (or: `clipbot font add MyFont.ttf`).

**Quick preview** renders the real thing at half size in ~20s. **Render final** makes the 1080x1920 file,
checks it (loudness, clipping, black/frozen frames, letterboxing) and puts it in the review queue.

Everything is optional: clear the headline, set captions to None, set the banner to **off** (Look tab), delete text
layers/stickers (select + Delete key). Add them back any time.

**Ratios:** 9:16 has the special layouts (stacked split for two people, webcam-over-gameplay, gameplay below).
4:5 / 1:1 / 16:9 follow the speaker with a moving crop, or show the whole picture on a blurred fill when the shapes
are too different (e.g. a vertical video into 16:9). Text and stickers are moved/scaled to fit when you switch.

Keyboard: Space play · ←/→ frame · S split · Del delete · I/O in/out · T text · Ctrl+Z undo · Ctrl+S save · ? help

## 6. Sick edits / trailers (command line for now)

```
./clipbot montage-build brief.json out.mp4 --aspect 9:16 --aspect 16:9
```
Profiles: `hype`, `velocity` (fast-in/slow-out ramps), `glam` (slow-mo, soft glow), `cinematic`, `trailer`
(cold open, title cards, booms), `comedic`, `emotional`. Use music you have the rights to. The demo project
has a ready `montage_brief.json`.

## 6b. Teach it what you like (it learns)

Every clip card has **👍** and **👎**. Click one and pick what's good or wrong ("slow start", "ends too early",
"wrong moment"...). Clipbot also notices which clips you render, which AI clips you delete, how you trim them,
and (Export tab → "How did it do?") how many views they got. After about 8 rated clips it starts adjusting its own
picks: favouring the moment types you keep, matching how you trim, preferring stronger openings if you keep saying
"slow start". **Settings → What Clipbot has learned** shows it in plain words.

**Settings** also has your own connections:
- **Other AIs:** OpenRouter, Gemini, Groq, xAI, DeepSeek, Mistral, or **Ollama** (free, runs on your computer, no key)
  are presets in Settings -> Your AI. Any other OpenAI-compatible server works with "Other".
- **Your own scorer:** any software (your own model, an n8n/Make/Zapier flow, a local script) can score the top
  moments; Clipbot blends its scores in and learns how much to trust it. Format in CONNECT.md.
- **Your AI:** your own Anthropic or OpenAI key adds AI title ideas (still fact-checked against the clip) and a second opinion on which moments to clip. It reads the top ~15 moments' transcripts plus what Clipbot has learned about your taste (your 👍/👎 clips and reasons, the streamer's lore, their studied clips). It only reorders moments that already passed the quality bar, and Clipbot tracks whether the AI's favourites are the ones you keep, then gives its opinion more or less weight. Each clip shows the AI's score and reason. Costs about 1-3¢ per video with Claude Haiku. Turn it off in Settings → Your AI.
- **Subscriber-only VODs:** use your browser's logins for downloads.
- **Webhook:** send each finished clip to Zapier, Make, n8n, a Discord channel or your own server.
- **Help improve Clipbot:** share what it learns (numbers only, never your videos) with the developer.

## 7. Updates

When there's a new version, a green **Update to x.y** button appears in the top bar. Click it, then close and
restart Clipbot. Your projects, settings, uploaded fonts and banners are kept, and the previous version is saved so
`clipbot update --rollback` can undo it. Command line: `clipbot update`.

## 8. What to send back

- What you clipped (link or type of video), how long it took, and your score for each clip /10.
- Anything that looked wrong: a screenshot plus the clip name.
- Run `./clipbot bug-report` (Mac) or `clipbot bug-report` (Windows) and
  send the zip it prints. It contains settings and logs only, no video.

## Known limits (beta)
- CPU only. A 10-minute video takes a few minutes to transcribe; each clip renders in roughly 30-90s.
  (Measured here: a 10-minute talking video went from file to 4 finished clips in about 13 minutes.)
- Scores are a transparent rule of thumb, not a guarantee. Your ratings are what we'll tune them with.
- Auto-headlines are drafts (flagged), so rewrite them before posting.
- YouTube sometimes asks downloaders to "confirm you're not a bot". Fix: export a `cookies.txt` from a logged-in
  browser and set `"cookies_file"` in `config.json`, or just download the video and drop the file in.
- Fonts, emoji stickers and platform icons are bundled, so they work offline. Typing a custom emoji outside the
  built-in set uses your computer's emoji font.
- The Windows installer/launcher haven't been run on a real Windows PC yet - you may be the first. If anything
  fails, send a screenshot of the PowerShell window.
- Only clip content you're allowed to use. Live clipping refuses to start without the permission tick.

## If something goes wrong
| Problem | Fix |
|---|---|
| `doctor` says ffmpeg missing | Mac: `brew install ffmpeg` · Windows: `winget install Gyan.FFmpeg`, then reopen the window |
| Browser didn't open | open http://127.0.0.1:8765 yourself (the window prints the exact address if it used another port) |
| "Operation not permitted" / venv errors on Mac | move the folder out of iCloud/Desktop sync (e.g. to `~/clipbot`) and run `./install.sh` again |
| First transcription seems stuck | it's downloading the speech model once (~500 MB); leave it |
| A link won't download | download the video yourself and drag the file in |
| Dropbox/Drive link says "web page, not a video" | share the single file (not the folder) as "Anyone with the link", copy that link again |
| A font won't upload | it must contain normal A-Z letters; .ttf/.otf work best (some .woff2 icon fonts are rejected on purpose) |
| "This video has no sound" / "No speech found" | auto-clip listens for moments; choose **Edit it myself** to cut it by hand |
| "Can't read this file as a video" | the file is damaged or still downloading; re-download or re-export it as MP4 |
| Clip looks wrong | fix it in the editor and press Render final, or send `bug-report` + a screenshot |

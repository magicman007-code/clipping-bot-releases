# Clipbot beta - tester guide

Thanks for testing! Everything runs on your own computer: no account, no uploads to anyone's server,
no watermark, no subscription.


## Editing on the video
- **Add** (top right of the video) puts **Text**, an **Emoji** or a **Blur** box on the clip.
- Click anything on the video to select it:
  - drag it to move it, or drag the white corner to resize it
  - use the arrow keys to nudge it (Shift moves further)
  - **Ctrl/Cmd+D** or **Duplicate** copies it
  - **Delete** or **Remove** takes it off
  - **Ctrl/Cmd+Z** undoes
- **Blur** hides a face, a username, chat or anything else. In the Text tab, under Blur and hide, pick **Blur**,
  **Pixelate** or **Black box**, set the strength, and choose when it starts and ends. It's in the final video exactly
  where you put it.
- **Long YouTube videos:** in Edits -> Change parts, press **Edit** on any part to open it in the full editor. There
  you can trim, add text, blur, stickers and captions, or change the framing. Go back and press **Rebuild video**: that
  part uses everything you did.

## Simple and Pro
Clipbot opens in **Simple** mode, which shows only what you need: New, Clips, Live, Edits and Settings on the left;
Clip, Captions, Text and Export on the right. The steps above the video (**1 Pick a clip -> 2 Make it yours ->
3 Render -> 4 Post**) take you to each stage. Switch to **Pro** (top right) for everything else: Find, Transcript,
Lore, Jobs, Stickers, Audio, Look, presets, campaigns, skills and advanced settings. Nothing is lost when you switch.

**Make a YouTube video** on Home (or **YouTube** on the New screen) takes a long stream, transcribes it and opens
Edits, ready for you to pick a length and press **Make the edit**.

## 1. Install (once, ~5 minutes)

**Mac**
1. Install Homebrew if you don't have it: https://brew.sh (paste the one line it shows into Terminal).
2. Unzip `clipbot-beta.zip`, open Terminal, then:
   ```
   cd ~/Downloads/clipbot      # wherever you unzipped it
   ./install.sh
   ```
   (If macOS says the file can't be opened: right-click `install.sh` -> Open, or run `chmod +x install.sh start.sh`.)
   The Mac's built-in Python (3.9) is too old; the installer installs Python 3.12 with Homebrew by itself.

**Windows**
1. Install **Python 3.12** from https://www.python.org/downloads/ - tick **"Add python.exe to PATH"** on the
   first screen. (3.10-3.13 all work; the newest 3.14 may not have every package yet.)
2. Unzip `clipbot-beta.zip` somewhere simple like `C:\clipbot` (not inside OneDrive), right-click
   `install.ps1` -> **Run with PowerShell**. It installs ffmpeg with winget if you don't have it.
   If Windows says scripts are disabled, open PowerShell in the folder and run:
   `powershell -ExecutionPolicy Bypass -File install.ps1`

The installer ends with a `doctor` report. `"ready": true` means you're good. Warnings about network
or disk space are OK to ignore for a first try.

## 2. Start

- Mac: `./start.sh`   ·   Windows: double-click `start.bat`

Your browser opens **Clipbot Studio** at **http://127.0.0.1:8765** (if that port is busy it uses 8766, 8767… and
says so in the window). The first time, you land on the **Home** screen with three choices: **Auto-clip a video**,
**Edit it myself**, or **Clip a live stream**. Press **Take the 1-minute tour** there (or **Tour** in the top bar any
time) for a guided walk-through of every part of the screen. A **demo project** is included, so you can try everything
before using your own footage. Projects live in `~/Clipbot` (Windows: `C:\Users\<you>\Clipbot`).

The **first time you clip real footage**, the speech model downloads automatically (~500 MB for the
default "small" model). Leave it running; later runs start straight away.

**The screen:** the left rail has Home, New, Clips, AI picks, Transcript, Live and Jobs. The middle is the live
preview (drag captions, headline, text and the picture itself). The right side has the clip's settings in tabs:
Clip, Captions, Text, Stickers, Audio, Look, Export. The timeline at the bottom trims the clip. **Render clip**
(top right) makes the final MP4; **Quick preview** makes a fast half-size check first.

**Progress:** while auto-clip runs, a bar in the top bar shows how far along it is and roughly how long is left.
Long videos are fine (tested with 25-minute files); they just take longer. Reloading the page picks the bar back up.

## 3. Clip anything (Home -> Auto-clip / Edit it myself, or the New tab in the left rail)

Pick a mode first:
- **Auto-clip**: the AI finds the best moments, scores them and renders the ones that pass.
- **I'll cut it myself**: it only imports (and transcribes, for captions) and opens the editor with a
  30-second starter clip. Drag the clip edges on the timeline, click/shift-click sentences in **Transcript**, or
  press **New clip at playhead** to make as many clips as you want. The AI picks are still listed under
  **AI picks** as suggestions you can ignore. (No speech / no speech model? It still imports, with captions off.)

- **A video file:** drag it onto "drop a video here" (or the Home screen), or press "Choose a video file…".
  MP4, MOV, MKV, WebM, phone videos (rotated), 4K/60fps, vertical or square all work. Multi-hour VODs work.
- **A link:** paste a Kick VOD, Twitch VOD, YouTube video, or Kick/Twitch clip link and press **Auto-clip it**.
  Kick VODs: copy the link from the streamer's **Videos** page (kick.com/name/videos/...). Twitch: twitch.tv/videos/...
  **Long VOD?** Fill in "Only part of a long VOD" (e.g. from 1:00:00 to 2:30:00) and only that stretch is downloaded.
  **Subscriber-only VODs:** Settings → "Subscriber-only VODs" → pick the browser you're logged in with.
  If YouTube or Twitch changes something and a download fails, Clipbot updates its downloader by itself and retries.
  (Some sites block downloads now and then. If a link fails, download the video yourself and drop the file in.)
- **Dropbox / Google Drive / WeTransfer:** paste the share link of the **video file** (Share -> Copy link, or the
  we.tl link). It downloads the file directly; a WeTransfer with several files arrives as a zip and Clipbot takes the
  video out of it. Folder links don't work (it tells you), Drive files must be shared "Anyone with the link", and
  WeTransfer links expire after 7 days on the free plan.
- Choose how many clips, the minimum score (default **6/10**: nothing below the bar gets rendered),
  caption style (or none), the streamer banner (auto from a Kick/Twitch link, a handle you type, or **no banner**),
  headline card on/off, and the **output ratio**: 9:16 (TikTok/Reels/Shorts), 4:5 (Instagram feed), 1:1 (square)
  or 16:9 (YouTube/X). Tick "also export" to get the same clip in extra ratios (files end in `_1x1`, `_16x9`...).

It transcribes, finds the moments, scores them, renders the ones that pass, and opens the project.
Rejected moments are listed in **Jobs** with the reason (e.g. "weak opening line", "duplicate").
Every clip is checked again after it renders (sound level, faces, captions). If one drops below the bar it is set
aside in `renders/_below_bar` and the next-best moment is rendered instead, so what you get is all 6/10 or better.

## 3b. Find any moment by describing it (left rail -> Find)

Type what you want: "every time he talks about the coin", "funniest moments", "when chat goes crazy",
"donations and subs", "the part where he explains his strategy". It searches **by meaning**, so "losing money" finds
"I watched $100,000 disappear" even with no shared words. Each result shows the line it matched, how well it matches
(the yellow bar) and its quality score. **Preview** jumps to it, **Make clip** turns it into a clip with a draft
headline, **Make all** does every result. You can also type the prompt in **What should it clip?** before an
auto-clip run, so it only clips what you asked for.

The meaning model downloads once (~90 MB) the first time you search. Without internet it still works by keywords.

## 3c. Streamer lore (left rail -> Lore)

Teach Clipbot what the community knows: the streamer's friends and rivals, nicknames ("Orangie = orange, the
orange guy"), catchphrases and running jokes. Then pick the streamer under **Streamer** when you start a project.
It spells those names right in captions and headlines, ranks callbacks to running jokes higher (that's what
regular viewers share), and lets prompts use nicknames.

**Study their best clips:** in the same panel, press **Add clips…** and pick clips of theirs that did well (from
their channel, or a clipper's TikTok you downloaded). Press **Study these clips**. Clipbot transcribes each one and
learns how long their hits are, how fast they talk, what kind of moments they are (reactions, rage, awkward,
stories, money...) and how they open. From then on, clipping that streamer favours moments that resemble those
hits, at that length. The more clips (10+ is ideal), the stronger the effect; with a few it only nudges. **Suggest from these projects** reads their past streams and
suggests names and phrases that keep coming back; click the real ones to add them, then **Save lore**.

**What Clipbot looks for** (from research on the most-shared stream clips): genuine reactions and "chat, clip
that" moments, rage, awkward or embarrassing moments, stories with a payoff, stakes and money, stream events
(subs, raids, donations), callbacks to running jokes, and a voice that suddenly jumps (a scream or a laugh). It marks
down intros, sponsor reads and "hit follow" talk, and openings that only make sense if you watched the stream
("and then he...").

## 4. Live clipping (Home -> Clip a live stream, or Live in the left rail)

1. Paste the stream link (kick.com/name or twitch.tv/name). Optional chat for better detection:
   `twitch:channelname` or `kick:channelname`.
2. Tick "I own this channel or have permission to clip it" (only clip streams you're allowed to).
3. **Start live clipping.** It records the whole stream, clips good moments as they happen (each one
   renders while the stream continues), and when the stream ends it builds a **highlight reel** and a
   **recap.md**. Set "Wait for it to go live" to start it before the streamer goes live.
4. **Clip last 30s / 60s** buttons make an instant clip of what just happened.
   **Watch it here and clip by hand:** opens the stream inside Clipbot. Scrub back to any moment, press **Mark in**
   (or the I key) where it starts and **Mark out** (O) where it ends, then **Clip it**. It renders in the background
   and shows up in the Live tab. **Jump to live** returns to the newest part (about a minute behind the real stream).
   **Clip pace:** *Steady* (default) makes a good clip at least every ~8 minutes even when nothing huge happens,
   *Fast* every ~4, *Fastest* every ~2, *Standouts only* waits for big moments. Nothing under the minimum score is ever clipped.
   **Always on:** tick it to clip every stream that channel does. After a stream ends it waits for the next one
   (each stream gets its own folder) until you press Stop. Leave the editor open.
5. After the stream it also sweeps the **whole recording** for anything the live pass missed (it skips
   moments already clipped), so leave it running until it says *finished*.

Command-line version (same thing, handy for an all-night stream):
```
./clipbot live-watch https://kick.com/NAME --authorized --wait-hours 6
```
(Windows: `clipbot live-watch ...` from a Command Prompt in the folder.) Ctrl+C stops it cleanly and still builds the recap.

### Watch channels: every new VOD gets clipped automatically

Live tab -> **Watch channels**. Paste `twitch.tv/name`, `kick.com/name` or `youtube.com/@handle`, pick the streamer's
lore and how many clips, then **Watch**. While the editor is open, Clipbot checks every 30 minutes. When a new VOD
has finished (its length stops changing), it auto-clips it in the background and the clips show up in Jobs and the
project list. VODs that already existed are skipped; tick **Also clip their most recent VOD now** to start with
the latest one. Command line: `./clipbot watch add twitch.tv/name --streamer Name`, then `./clipbot watch run`.

### Chat explosions

When chat floods right after something happens (KEKW, LUL, W, "???", 💀), that moment ranks higher, and the clip
card says *💬 chat exploded (laughing)*. YouTube and Twitch VOD chat is fetched automatically (Twitch sometimes
refuses; then export the chat with TwitchDownloader). For Kick, or any other source, drop a chat file in the
**Chat replay** box on the New screen.

## 5. Edit any clip

Click a clip in **Clips**. Everything previews live.

**The basics (no menus needed):**
- **Remove anything:** click it on the video (captions, headline, a text box, sticker or banner). A bar appears saying
  what you picked; press **Delete** or **Remove**. **Ctrl+Z** brings it back.
- **Move anything:** click and drag it on the video. Scroll over a text box or sticker to resize it.
- **Someone cut off?** In the Clip tab, open **Framing** and change **Layout**. For a stream with separate video
  windows (a reaction video plus the webcam), pick **Stream panels**: each window is stacked full width. If it picks
  the wrong windows, press **Edit windows** and drag a box over each window yourself. **Full frame + blur** never
  crops anything.
- **Simple first:** each tab opens with just the essentials. Click any heading to open more options, or press
  **Show all options**.
- **Almost made it:** under your clips, moments that scored just under the bar are listed with what held them back.
  **Make it a clip** adds one so you can fix the start, end or headline yourself.
- **Other moments it found:** under your clips, Clipbot lists the moments it didn't pick (even ones under your
  minimum score) with their score and what held them back. **Make a clip** turns one into a clip you can fix up.
- **More clips:** in Clips, press **More clips from this video**. It finds the next-best moments (never the same
  ones) without downloading or transcribing again.

| Panel | What you can do |
|---|---|
| Timeline (bottom) | drag the clip edges, **S** = split, **Del** = cut a segment (jump cut), drag to scrub, double-click a word to fix it |
| Clip | **output ratio** (9:16 / 4:5 / 1:1 / 16:9, preview switches shape) + "also export" other ratios, headline (+ its own font, text colour, box colour), **Remove headline**, **Remove all overlays** (headline, text, stickers, banner, watermark; Ctrl+Z undoes), layout (follow speaker / split / webcam+screen / full frame / gameplay below), drag the picture to reframe, speed, auto-remove pauses, payoff teaser, zooms |
| Captions | 4 styles or **None** (clean version), 25 bundled fonts + **Upload font…** (.ttf/.otf/.woff), bold / italic / shadow, text colour, highlight colour (presets or any colour), outline colour + width, letter spacing, size, drag them on the preview, ALL CAPS, censor, edit every word + timing, **Export .srt / Import .srt** |
| Text / Stickers | add text layers (any font, bold/italic, spacing, colour, stroke, box, animation) and emoji/image stickers, drag + scroll to resize, set when they show |
| Audio | voice volume, **replace the audio** with another track, mix a track under it, mute all of it or **mute just a section** (a swear, a bad mic moment), background music that ducks under speech |
| Look | colour looks, brightness/contrast/saturation/warmth, vignette, progress bar, watermark, **streamer banner** (Kick K + name, Twitch, uploaded campaign banners, end card) |
| Export | suggested titles (each checked against what's actually said), thumbnails (16:9 + 9:16), quick preview render, final render, **Approve / Reject** |

Every final render also writes a **.srt subtitle file** next to the .mp4 (same lines and timing as the burned-in
captions) for YouTube/TikTok uploads. Want a clean copy without burned captions? Set captions to **None** and render.
Fonts you upload are kept in `Clipbot/_fonts` and show up in every font menu (or: `clipbot font add MyFont.ttf`).

**Quick preview** renders the real thing at half size in ~20s. **Render final** makes the 1080x1920 file,
checks it (loudness, clipping, black/frozen frames, letterboxing) and puts it in the review queue.

Everything is optional: clear the headline, set captions to None, set the banner to **off** (Look tab), delete text
layers/stickers (select + Delete key). Add them back any time.

**How many clips:** on **Auto** (the default) Clipbot aims for about one clip per 8 minutes of video, 6 to 40, and
only keeps the ones that pass the minimum score. Pick a number (up to 100) under Options on the New screen to ask for
more. Live clipping clips standout moments as they happen and, on **Steady** pace, at least one good moment every
~8 minutes.

**Ratios:** 9:16 has the special layouts (stacked split for two people, webcam-over-gameplay, gameplay below).
4:5 / 1:1 / 16:9 follow the speaker with a moving crop, or show the whole picture on a blurred fill when the shapes
are too different (e.g. a vertical video into 16:9). Text and stickers are moved/scaled to fit when you switch.

Keyboard: Space play · ←/→ frame · S split · Del delete · I/O in/out · T text · Ctrl+Z undo · Ctrl+S save · ? help

## 6. Long videos, YouTube edits and trailers (left rail -> Edits)

Open a project that has been auto-clipped or imported (so it has a transcript), then open **Edits**.

**YouTube video** turns a long stream or video into a watchable YouTube video:
1. Pick a length (for example 10 or 20 minutes), the shape (16:9 for YouTube), captions and a title.
2. Press **Make the edit**. Clipbot finds the strongest self-contained stories, keeps them in the order they
   happened, adds a short cold open (the most gripping line) and a title card, and puts a chapter card before each part.
   Dead air and um/uh are cut out and loudness is levelled.
3. Tick **Fast draft** to check it quickly at half size first.
4. When it's ready it shows up under **Your edits**, with YouTube chapters you can copy into the description.

**Change parts** (under each YouTube edit) is the long-form editor:
- Untick a part to drop it. Change its chapter title, or its start and end (m:ss).
- Move parts up or down. ▶ jumps the player to that part.
- **Find a moment in what was said**: type words from the stream, press ▶ to check a match, then **Add** to make it
  a part (about 45 seconds, starting just before the line).
- **Add the open clip as a part**: open any clip in the editor, trim it, then add it.
- Turn the cold open on or off, or set its times.
- **Rebuild video** remakes the same edit (same name) with your changes, and the chapters update.

**End screen** (on by default for 16:9) adds 20 seconds at the end, made from the last frame blurred, with faint
guides showing where YouTube's subscribe and video cards go. Add the real clickable cards in YouTube Studio -> Editor ->
End screen. Use a template there; it lines up with the guides.

**Make Shorts from this** (under each edit) finds the best 15-58 second moment in each part and adds them to
your clips as 9:16 Shorts with headlines. Render them like any clip. One stream gives you a long video and a set of Shorts.

**Publish to YouTube** (under each edit) handles getting the video out:
- **Write it with AI** fills in the title, description and tags from what was actually said. The real chapters are
  included in the description. Edit anything.
- **Find the best frames**, pick one, type 2-3 words and press **Make** for big-creator thumbnails. Click the one you want.
- Choose Public, Unlisted, Private or Schedule, then **Upload to YouTube**. The thumbnail is set too if the channel
  is phone-verified. Views are tracked automatically.

**Trailer / hype** cuts a fast edit from the project's best clips or moments, with profiles `hype`, `velocity`,
`glam`, `cinematic`, `trailer`, `comedic` and `emotional`. Cards between shots can be typed one per line. Use music
you have the rights to.

The command line still works too: `./clipbot montage-build brief.json out.mp4 --aspect 9:16 --aspect 16:9`.

### Thumbnails (Clip tab -> Thumbnail)
1. **Find the best frames**, then click the face you want.
2. Write 2-3 punchy words, and add an emoji, arrow or circle if you want.
3. Pick styles: Pop, Studio, Hype and Clean use the real frame and cut out the person. **AI scene** paints a new
   background behind them (free, no key). **AI remix** redraws the whole frame and needs an OpenAI key.
4. **Help me write this** next to AI scene turns a rough idea into a scene prompt that works, with tips.
5. You get every style in 16:9 (YouTube) and 9:16 (Shorts). Only use people who agreed to be shown.

### Skills and prompt help (Settings -> Skills)
A **skill** is your taste written down for the AI: what makes a great clip for this streamer, what to skip, and how
titles should sound. Make one in Settings -> Skills (type a rough idea and press **Write it for me** to get a
draft), then pick it under Options on the New screen. It changes which moments the AI rates highly and the title ideas it
writes. Skills can be shared in a share file like presets.

**Help me write this** sits next to "What should it clip?" and the thumbnail AI scene. It rewrites your rough
idea and shows tips for writing that kind of prompt.

### Built-in AI (no setup)
AI features work straight away with a free built-in AI: no key needed. It's slower (one request about every 30
seconds) and sends clip text to a free public service, Pollinations. For speed and privacy, connect your own AI in
Settings -> Your AI, or use Ollama on your computer. Choose **Off** there to switch AI off completely.

### Posting to TikTok and making Twitch clips
Set it up once (CONNECT.md, about 5 minutes per platform). Then in a clip's **Export -> Post it**:
- **Send as draft** puts the clip in the TikTok app's inbox.
- **Post to TikTok…** posts directly, with the privacy, interaction and disclosure choices TikTok requires.

In the live viewer, **Twitch clip** makes a real Twitch clip of the last 30 seconds. Once TikTok is connected (with
`video.list`), the views of TikTok posts you track come straight from TikTok.

### Terms
The first time Clipbot opens, it shows the terms of use: you're responsible for the footage, people and
content you use and post, not the developers. It's in TERMS.md, and on Home under "Terms of use and disclaimer".

## 6b. Teach it what you like (it learns)

Every clip card has **👍** and **👎**. Click one and pick what's good or wrong ("slow start", "ends too early",
"wrong moment"...). Clipbot also notices which clips you render, which AI clips you delete, how you trim them,
and (Export tab → "How did it do?") how many views they got. After about 8 rated clips it starts adjusting its own
picks: favouring the moment types you keep, matching how you trim, preferring stronger openings if you keep saying
"slow start". **Settings → What Clipbot has learned** shows it in plain words.

**Settings** also has your own connections:
- **Other AIs:** OpenRouter, Gemini, Groq, xAI, DeepSeek, Mistral, or **Ollama** (free, runs on your computer, no key)
  are presets in Settings -> Your AI. Any other OpenAI-compatible server works with "Other".
- **Your own scorer:** any software (your own model, an n8n/Make/Zapier flow, a local script) can score the top
  moments; Clipbot blends its scores in and learns how much to trust it. Format in CONNECT.md.
- **Your AI:** your own Anthropic or OpenAI key adds AI title ideas (still fact-checked against the clip) and a second opinion on which moments to clip. It reads the top ~15 moments' transcripts plus what Clipbot has learned about your taste (your 👍/👎 clips and reasons, the streamer's lore, their studied clips). It only reorders moments that already passed the quality bar, and Clipbot tracks whether the AI's favourites are the ones you keep, then gives its opinion more or less weight. Each clip shows the AI's score and reason. Costs about 1-3¢ per video with Claude Haiku. Turn it off in Settings → Your AI.
- **Subscriber-only VODs:** use your browser's logins for downloads.
- **Webhook:** send each finished clip to Zapier, Make, n8n, a Discord channel or your own server.
- **Help improve Clipbot:** share what it learns (numbers only, never your videos) with the developer.

## 6c. Post it, and let it learn from the views

In the **Export** tab (render the clip first):
- **Send to my phone:** a QR code appears. Scan it with your phone's camera (phone and computer on the same
  Wi-Fi), tap **Save video**, then **Copy caption** and post from the TikTok, Instagram or YouTube app. The link
  works for 30 minutes and only opens that one clip.
- **Save to posting folder:** copies the clip and a caption file to the folder set in Settings, Posting. Make it a
  Google Drive or Dropbox folder and Buffer, Later, Metricool, Make or Zapier can post it on a schedule for you.
- **YouTube Upload:** posts (or schedules) straight to your channel. One-time setup in Settings, Posting
  (CONNECT.md has the steps).
- **How did it do?** Paste the post's link. Clipbot reads its public view count every few hours for two weeks and
  learns from it, with no numbers to type. YouTube uploads made from Clipbot are tracked automatically.
- **Subtitles in another language** (Captions tab): your AI translates the clip's .srt, keeping the timing.
- **Add hook opener** (Clip tab, Headline): a big punchy line for the first 1.6 seconds. It's a normal text layer,
  so edit it or click it and press Delete.

**Presets:** style one clip, then **Save this clip's look as a preset** (Clip tab). Apply it to other clips, or pick
it under Options on the New screen, on the Live tab or for a watched channel, so every clip comes out that way.
**Campaigns** (Settings): save a clipping campaign's rules (length, shape, banner handle, hashtags, title words).
**Export, Campaign check** lists what a clip breaks and how to fix it. **Share selected** puts presets, campaigns
and streamer lore in one file for a teammate; they press **Import a share file**.

**Lots of videos:** paste several links into the New box (one per line or separated by spaces). They're clipped one
after another; a bad link is skipped and the rest keep going. **Phone alerts** (Settings, Posting): install the free
ntfy app and your phone buzzes when clips are ready.

## 7. Updates

**Your work is never touched.** Projects, clips, renders, settings, connections, fonts and banners live in your
projects folder (`~/Clipbot`, Windows `C:\Users\<you>\Clipbot`), not in the app folder. Updates only replace the app.
The **Update** button waits while a clip is rendering, auto-clip is running or live clipping is on, then restarts
Clipbot by itself.

**Keeping your own changes to the app:**
- Your own look or tweaks: put a `custom.css` (and/or `custom.js`) in `~/Clipbot/_custom/`. Every version loads them,
  and updates never touch that folder.
- A whole editor page of your own: save it as `~/Clipbot/_custom/index.html` and Clipbot uses it instead of the
  built-in one (new features then only appear once you merge them into your page).
- If you edited files inside the app folder anyway, the update copies them to `~/Clipbot/_my_changes/<version>/`
  before replacing them, so nothing is lost. Older versions put the previous app in the app's `_previous` folder.


When there's a new version, a green **Update to x.y** button appears in the top bar. Click it, then close and
restart Clipbot. Your projects, settings, uploaded fonts and banners are kept, and the previous version is saved so
`clipbot update --rollback` can undo it. Command line: `clipbot update`.

## 8. What to send back

- What you clipped (link or type of video), how long it took, and your score for each clip /10.
- Anything that looked wrong: a screenshot plus the clip name.
- Run `./clipbot bug-report` (Mac) or `clipbot bug-report` (Windows) and
  send the zip it prints. It contains settings and logs only, no video.

## Known limits (beta)
- CPU only. A 10-minute video takes a few minutes to transcribe; each clip renders in roughly 30-90s.
  (Measured here: a 10-minute talking video went from file to 4 finished clips in about 13 minutes.)
- Scores are a transparent rule of thumb, not a guarantee. Your ratings are what we'll tune them with.
- Auto-headlines are drafts (flagged), so rewrite them before posting.
- YouTube sometimes asks downloaders to "confirm you're not a bot". Fix: export a `cookies.txt` from a logged-in
  browser and set `"cookies_file"` in `config.json`, or just download the video and drop the file in.
- Fonts, emoji stickers and platform icons are bundled, so they work offline. Typing a custom emoji outside the
  built-in set uses your computer's emoji font.
- The Windows installer/launcher haven't been run on a real Windows PC yet - you may be the first. If anything
  fails, send a screenshot of the PowerShell window.
- Only clip content you're allowed to use. Live clipping refuses to start without the permission tick.

## If something goes wrong
| Problem | Fix |
|---|---|
| `doctor` says ffmpeg missing | Mac: `brew install ffmpeg` · Windows: `winget install Gyan.FFmpeg`, then reopen the window |
| Browser didn't open | open http://127.0.0.1:8765 yourself (the window prints the exact address if it used another port) |
| "Operation not permitted" / venv errors on Mac | move the folder out of iCloud/Desktop sync (e.g. to `~/clipbot`) and run `./install.sh` again |
| First transcription seems stuck | it's downloading the speech model once (~500 MB); leave it |
| A link won't download | download the video yourself and drag the file in |
| Dropbox/Drive link says "web page, not a video" | share the single file (not the folder) as "Anyone with the link", copy that link again |
| A font won't upload | it must contain normal A-Z letters; .ttf/.otf work best (some .woff2 icon fonts are rejected on purpose) |
| "This video has no sound" / "No speech found" | auto-clip listens for moments; choose **Edit it myself** to cut it by hand |
| "Can't read this file as a video" | the file is damaged or still downloading; re-download or re-export it as MP4 |
| Clip looks wrong | fix it in the editor and press Render final, or send `bug-report` + a screenshot |

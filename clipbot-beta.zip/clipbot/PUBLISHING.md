# Sending updates to your testers

Testers get a green **Update** button in Clipbot whenever you publish a new version. Pick one host.

## Option A (recommended): GitHub Releases

Every version gets its own page with release notes, the "latest" link never changes, and publishing is one command.

One-time setup on your computer:
1. Install GitHub's tool: Mac `brew install gh`, Windows `winget install GitHub.cli`. Then run `gh auth login`.
2. Make a **public** repo just for the downloads (your code can stay in a private repo):
   `gh repo create yourname/clipbot-releases --public`
3. Publish the first version:
   ```
   ./clipbot publish 1.7.0 --repo yourname/clipbot-releases --notes "First beta"
   ```
4. Send testers the download link it prints (or the release page). Their copy now checks
   `https://github.com/yourname/clipbot-releases/releases/latest/download/latest.json` for updates.

Every update after that:
```
./clipbot publish 1.7.1 --repo yourname/clipbot-releases --notes "What changed, one line"
```
Use a higher version number each time. Testers see **Update to 1.7.1** within a few hours, or as soon as they
restart Clipbot.

## Option B: a Dropbox folder

Good if you'd rather not use GitHub. Replacing a file in Dropbox keeps its share link.
1. `./clipbot release 1.7.0 --out "~/Dropbox/Clipbot updates"` writes `clipbot-beta.zip` and `latest.json` there.
2. Copy the share link of **clipbot-beta.zip** and paste it as the `"zip"` value inside `latest.json`.
3. Copy the share link of **latest.json** and build once more with it baked in:
   `./clipbot release 1.7.0 --out "~/Dropbox/Clipbot updates" --url "<link to latest.json>"`
4. Send testers that zip. Each update after: `./clipbot release 1.7.1 --out "~/Dropbox/Clipbot updates" --notes "..."`

## Safety

The updater checks the download's checksum (a broken or tampered zip is refused), keeps the tester's projects,
settings, fonts and banners, and saves the previous version. If an update goes wrong, testers run
`clipbot update --rollback` (`clipbot.bat update --rollback` on Windows) and restart.

# Sending updates to your testers

Your setup: **`magicman007-code/clipping-bot`** (private) holds the code, and **`magicman007-code/clipping-bot-releases`**
(public) holds the download. Testers download from
https://github.com/magicman007-code/clipping-bot-releases
and their copy checks `latest.json` in that repo, showing a green **Update** button when there's a newer version.

## Publish an update (one command)

From the Clipbot folder on your computer:
```
./clipbot publish 1.8.1 --repo magicman007-code/clipping-bot-releases --notes "What changed, one line"
```
(Windows: `clipbot.bat publish ...`). Use a higher version number each time. It builds the zip, writes `latest.json`
with its checksum, and pushes both to the releases repo. Testers see the update within a few hours, or as soon as they
restart Clipbot.

One-time: git needs access to your GitHub. Install GitHub's tool (`brew install gh` on Mac, `winget install GitHub.cli`
on Windows), then run `gh auth login` and `gh auth setup-git`.

Or ask Claude to publish it for you. That's how 1.7.0 and 1.8.0 went out.

## See what Clipbot learns on testers' computers

Set up a free Google Sheet as your report link (FEEDBACK.md, about 5 minutes), then add it to the next publish:
```
./clipbot publish 1.8.1 --repo magicman007-code/clipping-bot-releases --feedback-url "https://script.google.com/macros/s/.../exec"
```
Testers are asked once whether to share reports (numbers only, never their videos), and can change it in Settings.

## Without GitHub (Dropbox)

`./clipbot release 1.8.1 --out "~/Dropbox/Clipbot updates" --url "<share link of latest.json>"` writes the zip and
`latest.json` there. Put the zip's share link in `latest.json` as `"zip"`. Replacing files in Dropbox keeps the links.
Note: testers' copies follow whichever link was built into them, so stick to one host.

## Safety

The updater checks the download's checksum (a broken or tampered zip is refused), keeps testers' projects, settings,
fonts, banners and connections, and saves the previous version. If an update goes wrong, testers run
`clipbot update --rollback` (`clipbot.bat update --rollback` on Windows) and restart.

# Seeing what Clipbot learns on your testers' computers

Each copy of Clipbot learns from what its user does: clips they rate 👍 / 👎 (and why), render, delete, or enter
views for. If they opt in (Settings → "Help improve Clipbot", or the card on the Home screen), Clipbot sends that to
**your** report link a few times a day. It sends numbers and moment types only (length, score, tags like
"reaction" / "rage", rating, reasons, views). It never sends video, file names or paths, and sends transcript text
only if they also tick that box.

## Set up your report link (free, about 5 minutes)

1. Create a new Google Sheet (sheets.new) and name it "Clipbot reports".
2. **Extensions → Apps Script**. Delete what's there and paste in `backend/feedback_sheet.gs` from this folder. Save.
3. **Deploy → New deployment** → type **Web app**. Execute as **Me**. Who has access: **Anyone**. Deploy and allow access.
4. Copy the **Web app URL** (it ends in `/exec`). That's your report link.
5. Build it into the app you send out:
   ```
   ./clipbot publish 1.8.0 --repo you/clipbot-releases --feedback-url "https://script.google.com/macros/s/.../exec"
   ```
   (or the same `--feedback-url` with `clipbot release`). Testers who already have Clipbot get it with the update.

Reports arrive as rows in two tabs: **events** (one row per clip event) and **summaries** (one row per report:
each tester's keep rate, the moment types they keep most, how they trim, their most common complaint).

## Using it to improve the code

- The `summaries` tab shows what the scoring gets wrong. A moment type with lift well above 1 is underweighted in
  `cb/moments.py` (`WEIGHTS`); one well below 1 is overweighted.
- Sort `events` by `reasons`: lots of "slow start" points at the hook rules in `cb/moments.py` / `cb/score.py`;
  "ends too early" at the window ends.
- `score` vs `views` (once testers enter views) shows whether the 0–10 score predicts anything. Recalibrate if not.
- Each tester's own copy already adjusts itself after 8 labelled clips; the sheet is how you improve the
  defaults for everyone.

Optional: set `SECRET` in the script and add `?k=yoursecret` to the end of the report link, so the sheet ignores
anything that isn't from Clipbot.

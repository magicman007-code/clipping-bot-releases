# Clipping Bot v4

Monitors creator channels (YouTube/Kick), finds the moments worth clipping, and renders
finished 9:16 shorts: auto layout (webcam+screen / follow-crop / stacked split / blur-fit /
vertical), honest headline card, word-by-word captions, subtle punch-zoom, -14 LUFS audio,
and an automatic QA sheet for every clip. Also does one-off "best of" for ANY creator and
montages.

Everything runs through ONE command: `python3 clipbot.py <subcommand>` (in this directory).
**Read `title_and_style_playbook.md` before picking moments or writing any headline.**

## 0. Setup (every run, one call)
```
python3 clipbot.py setup
```
Installs/verifies ffmpeg, yt-dlp (upgraded every run: YouTube breaks old versions), faster-whisper,
OpenCV, and the Anton + Montserrat fonts (GitHub first, npm fallback). Prints a status JSON;
fix anything `false` before continuing.

## Mode A - scheduled/on-demand monitoring of `config.json` channels
1. `python3 clipbot.py prep` - lists every channel, queues unseen videos in `state.json`
   (`pending` with attempt counts), downloads up to `max_new_per_channel` each (1080p, retries,
   4 YouTube player-client fallbacks, cookies if configured), transcribes each ONCE with
   name hotwords from `vocab`, and writes per video:
   - `transcript.txt` - `[mm:ss.s] sentence` lines
   - `candidates.md` - top 12 sentence-snapped windows with tags/energy/hook/payoff
   - `words.json` - word timestamps reused for captions (no re-transcription)
   Output JSON lists `ready_to_pick` (paths) and `downloads` (failures with reason).
2. **Pick moments (judgment - this is what makes clips good).** For each ready video read
   `candidates.md`, then skim `transcript.txt` around and between them. Keep only moments that
   pass ~3 of the 5 traits (resolves / standalone / provokes / legible in frame 1 / rewatchable).
   Tighten start/end to exact word times from `words.json`; cold-open on the event. 15-40s target.
   Use `"segments": [[a,b],[c,d]]` to jump-cut a long story down to its beats. Fewer, better
   clips beat a quota. Exclude sexually explicit/not-general-audience segments and say so.
3. **Headlines**: name + concrete thing that happened + honest gap the clip answers.
   Only names you can confirm (on screen or clearly said). Ban list in the playbook.
   Emoji are stripped from the burned-in card; put them in the post title instead.
4. Write `specs.json` and render:
   ```
   python3 clipbot.py render specs.json <outdir>
   ```
   ```json
   [{"name": "01_donkey_coin", "source": "/home/user/clips/Orangie/<id>/source.mp4",
     "start": 74.2, "end": 109.8, "headline": "He bought a coin about a shot donkey and almost 10x'd it"}]
   ```
   Optional keys (all also editable in the browser editor):
   - cutting: `segments` [[a,b],...] jump cuts · `tighten` (default true: drops pauses > 0.42s and um/uh)
     · `teaser` "auto" | [a,b] (payoff line first, flash + whoosh, then the story) · `speed` 0.75-1.5
   - framing: `layout` auto | tall | split | facecam_screen | blur_fit | gameplay (+ `background`
     video, Crayo-style) · `crop_x` 0-1 manual crop · `facecam` [x,y,w,h] · `open_punch` · `punch`
   - captions: `captions` pro | karaoke | box | minimal · `accent` yellow|green|pink|cyan ·
     `caption_size` · `caption_y` · `caption_font` · `uppercase` · `censor` · `words` (edited
     [[s,e,word]] in source time) · `headline_y` · `progress` · `watermark`
   - layers: `texts` [{text,start,end,x,y,size,color,stroke_color,font,box,box_color,anim,rotate}] ·
     `stickers` [{emoji|path,start,end,x,y,w}] (times are OUTPUT seconds)
   - sound/look: `volume_db` · `music` {path, volume, duck} · `audio_replace` {path, mode: replace|mix,
     volume, offset} · `mute_original` · `sfx` · `grade` {look: punchy|film|bw,
     brightness, contrast, saturation, warmth, sharpen, vignette}
   - posting: `title`, `description`, `hashtags` -> written to posts.md
   - credit: `banner` {"preset": "socials"|"kick_campaign"|"kick_moving"|"twitch_tag", "platform", "handle",
     "outro": true} or {"library": "<uploaded campaign banner>"}. ALWAYS credit the streamer; if a clipping
     campaign supplies its own banner, use exactly that (campaigns reject clips with the wrong credit).
   Auto layout is speaker-aware: with two people too far apart for one crop it cuts to whoever is
   talking (mouth motion synced to the audio) and goes to a stacked split when both talk.
   `render --jobs 2` renders in parallel and writes `review.html` (all clips + QA) and `posts.md`.
   Use `teaser: "auto"` when the payoff is a loud/visual beat; skip it for slow-burn stories.
   Pick `captions: karaoke` or `box` for fast talkers, `pro` for clip-page reactions, `minimal` for
   educational/screen content.
5. **QA - required.** QA also flags weak hooks (speech starting after 0.8s, <4 words in the first
   3s, no face in frame 1) - viewers decide in ~1.5-3s, so fix these first.
   Each clip writes `<name>.json` (`qa.ok`, `qa.warnings`, layout log, LUFS) and
   `<name>_sheet.jpg` (8 frames). Open every sheet and look: face cut off? caption on a face?
   headline readable? wrong layout? Fix (spec tweak + `render --force`) before delivering.
   Never report a clip you haven't looked at.
6. `python3 clipbot.py done <video_id> ...` - only after its clips are delivered. Videos that
   failed to download stay `pending` and are retried next run automatically; after
   `max_download_attempts` they move to `failed` (visible in `clipbot.py status`).
7. Append the run to `report.md` (newest first): channel, title, URL, each clip's times + headline
   + one line on why it was picked. Then notify: channels checked, new videos, clips made with 1-2
   top picks, anything blocked.

## Editor (when the user wants to tweak clips themselves)
`python3 clipbot.py editor --root <dir>` serves a browser editor on http://127.0.0.1:8765 (run it on
the user's machine, or the linked computer). It reads/writes each project's `specs.json`, so agent picks
and hand edits share one file. Render from the editor or with `clipbot.py render`.

## Mode B - one-off "best of" for any creator (no config change needed)
`clipbot.py list <url> [--platform kick] -n 20` -> `download <url> <dir>` ->
`transcribe <dir>/source.mp4 --vocab "Name1,Name2"` -> `candidates <dir>/source.mp4 --niche gaming`
-> read + pick as in A2-A5. For long VODs, transcription resumes from `words.partial.json` if a
call times out - just run it again.

## Mode C - montage
Render the individual clips first (A4-A5), order them editorially (strongest first, vary tone,
second-strongest last), then:
```
python3 clipbot.py montage montage.json <out.mp4> [--intro x.mp4] [--outro y.mp4] [--no-labels]
```
`montage.json`: `[{"file": "clips/01.mp4", "label": "VOD 2 · Cop finds a gun"}, ...]`. Any mix
of sizes/rates is normalised in one pass; final audio is two-pass normalised to -14 LUFS.
Only mix creators if the user asked.

## Live
`clipbot.py live <url> <dir> --seconds 300` records the live edge with ffmpeg (playable even if
cut short), then transcribes + writes candidates. Only when explicitly asked.

## When YouTube blocks downloads ("confirm you're not a bot")
The cloud sandbox IP gets flagged regularly (this blocked 3 of 4 runs in Oct 2026). In order:
1. The downloader already falls through 4 player clients; the video stays queued for next run.
2. Set `cookies_file` in config.json to a Netscape cookies.txt exported from a logged-in
   browser - the most reliable fix.
3. If the session is linked to the user's computer, run the yt-dlp download there (home IP)
   and stage the file into the work dir.
Report blocks briefly; don't burn the whole run retrying.

## Layout notes
- `auto` is right almost always. Orangie's videos = webcam inset over fomo screenshare ->
  auto-detected `facecam_screen` (cam on top, full uncropped screen below). The detector looks for
  a small, stable face off-centre and finds the inset's border lines; check the sheet.
- Punch-zoom never fires on screen/blur segments (charts must stay readable).
- Captions sit on the seam in split/facecam layouts and below the face otherwise.

## Reuse
These are clips of other people's content at the user's request - remind them once (not every
run) to check the creator's clip/reuse rules before posting.

# Title & Style Playbook (research-backed, Sept 2026)

Read this before writing headlines or styling clips. Distilled from clip-titling
guides and real top-performing clip channels (Kai Cenat clips, IShowSpeed clips,
StableRonaldo). Full sourced writeup with citations: ask to see
`clip_playbook.html` (also saved to the user's relevant Drive folder if one exists).

## Moment selection: the 5-trait filter (apply BEFORE scoring/cutting)
A clip needs ~3 of these 5, not all 5. Use this as real judgment, not just the
audio/keyword scorer — the scorer is a cheap first pass, not the final say:
1. **Resolves** — setup + payoff inside the clip itself. No "it just stops."
2. **Standalone** — a stranger with zero context on the creator still gets it.
3. **Provokes a reaction** — a debatable claim or quotable line.
4. **Emotionally legible in frame 1** — a visible reaction/face, works muted.
5. **Rewatchable** — a detail/line that lands differently on a 2nd viewing.

Length sweet spot: 15-30s (highest completion + algo boost). Only exceed 40s if
a multi-beat story genuinely needs the runway. Cold-open on the peak moment —
never show the setup-before-the-setup.

## When doing a "best of" / deep-dive request (any creator, any platform)
Don't trust keyword+loudness scoring alone to pick the final list — it reliably
over-ranks mundane filler that happens to contain hype words, and under-ranks
real stories buried in noisy auto-transcripts. Process:
1. Use the scorer to narrow down (it's fine as a first-pass filter across hours
   of footage).
2. Then actually READ the full bucketed transcript text yourself (dump to a
   plain `[timestamp] text` file) and re-select using the 5-trait filter above.
   Real narrative stories with a punchline beat loud-but-empty reactions every time.
3. **Content-appropriateness check**: if the source drifts into sexually explicit
   or otherwise inappropriate-for-general-audience territory, exclude those
   segments from a "best/viral clips" deliverable by default and tell the user —
   don't silently include or silently drop; flag the judgment call.
4. Quality over a fixed quota — delivering 10 genuinely good clips beats forcing
   20 where several are filler.

## Titling: the 4-part build
1. **Name the subject** — the real name, not "he"/"streamer."
2. **State the specific event** — a concrete noun/action, not a category
   ("Loses a 4v1 he already won," not "crazy moment").
3. **Leave a small, honest gap** — curiosity, not a lie. The clip MUST answer
   the gap it opens, in-clip. Never let the payoff live only in the caption text.
4. **Fit the platform** — front-load subject + hook within ~60-100 characters
   total; nothing load-bearing after that (truncation).

Format: `[Name] + [concrete specific thing that happened] + 1-2 emoji max`
Real examples that hit millions of views: "A Streamer University Nominee Gifts
Kai Cenat A Snake 😭", "Speed Entered the Shoe 👠" (5.7M views).

**Ban list** (vague hype with zero information — do not use): "insane," "you
won't believe," "the most X ever," "crazy moment," bare reaction words with no
noun attached, unresolved questions the clip doesn't answer.

## Caption spec (the clean, "pro clip page" look)
- Font: Montserrat Black, Anton, or Bebas Neue (heavy condensed sans), ALL CAPS.
- Fill: white, with an 8-12px black stroke (on a 1080x1920 canvas) for contrast.
- One emphasized keyword per phrase in yellow (`#FFD93D`) — not every word.
- Size 80-120px (~10-15% of frame height). Position: lower-middle, ~60-70% down
  — never dead-center over faces.
- 1-3 words revealed per beat, tightly synced to speech (200-500ms/word).
- Minimal/no bounce or zoom animation on the caption itself — snap-in timing
  does the work; over-animated captions read as cheap.

## Other cheap, tasteful upgrades
- Subtle punch-zoom on the peak line only (105-110% scale, snap not ease).
- Sparing motivated SFX (a soft whoosh on a hard cut) — NOT chaotic meme/
  "brainrot" overlays; that style clashes with real-conversation content.
- Small quiet corner watermark (channel/handle) for consistent branding.
- Light contrast grade (lifted blacks, warm skin tones) rather than a heavy LUT.

## Known limitation / next build: reaction-cut multi-cam style
Not yet implemented in `pipeline.py` — flag this to the user as a separate
build step when they ask for "crop to whoever's talking, cut between people":
- **Active speaker detection**: combine which audio channel/mic is loudest with
  face detection to know who's talking each moment (audio-visual triangulation,
  not video alone).
- **Single speaker talking** → tall 9:16 crop centered on that person.
- **Wide two-shot / overlapping talk / laughing together** → do NOT force a
  single-person crop (cuts people out); use a stacked top/bottom split-screen
  instead, one person per half.
- **Cut on the speaker switch**, not on a timer, so cuts feel conversation-driven.
- Reference implementation to study: github.com/usernameazevedo/vertical-podcast-clips

---
## Round 2 research (Oct 2026): ~2,900 popular Shorts/videos sampled across 20+ clip channels
Sources: Kai Cenat / IShowSpeed official + fan pages, N3on/Adin/Sketch/Plaqueboymax clip pages, xQc/Ludwig/Mizkif/Asmongold clip channels,
podcast clip pages (Flagrant, Impaulsive, Schulz, Theo Von, DOAC, Hormozi, PBD), Stable Ronaldo, House of Highlights, Jynxzi/Valkyrae/Emiru/Pokimane/
Hasan/Dr Disrespect/Full Send clips. Full reports + raw rows: `research_round2/*.md|json`. Counts are observational, not controlled tests.

**Title facts (measured):** median 35-44 chars / 6-7 words. 80% of N3on/Adin/Sketch titles and 80% of Kai/Speed titles name the person. ~45-87% use emoji on Shorts
(0% on xQc/Asmongold long clips). Best titles = [named subject] + [specific action] + [concrete object/stakes]. Generic ones ("this is hilarious") only survive when a
huge audience + strong visual carry them. Questions/curiosity gaps are fine only if the clip itself resolves them.
**Edit facts:** cold-open on the event (no intro card/logo, no black first second); 15-40s default (6-60s observed); captions = heavy condensed sans, white + thick
black stroke, 1-3 words at a time, ONE accent keyword (yellow); headline card separate from captions (Plugclipping = white card, black italic text);
stacked layout (reaction on top, source below) when two things matter; minimal motivated zoom/SFX, no meme clutter; small watermark OK.
**Rules the bot now enforces (edit.py):** face-aware 9:16 reframe that pans to follow the person (never a blind centre crop), stacked split when two people are far apart,
headline card in its own band (never covers a face), word-by-word Anton captions with yellow keyword, voice clean-up + loudnorm, jump-cuts to tighten long stories.
**Selection rule that matters most:** the moment must be a self-contained story/joke. Read the transcript, write the headline from what is actually said, and drop weak moments rather than pad.

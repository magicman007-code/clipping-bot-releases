# v3.5.3 — a heads-up before you post something a campaign won't take

- **Clips now show a small amber "⚠ Check before posting" note when the transcript
  has strong language, sexual/adult wording, or a slur.** It's advisory only — it
  never changes the clip's score, hides it, or stops you. It just flags what a brand
  campaign or a monetised page might reject, so you can bleep it or pick another clip.
- Hover the note for what it caught and why. Computed from the words already on your
  machine — nothing is uploaded.

---

# v3.5.2 — a calmer first run

- **The very first time you open Clipbot (before you have any projects), the Home
  screen is now one clear path:** the headline, the link box, and a quiet "More
  tools" link — nothing else competing for attention. Press "More tools" and the
  full set (Watch channels, Find moments, Trailer, Streamer lore, Results…) appears.
- Once you've made a project, Home looks exactly like before — everything's there.
  This only simplifies the empty, brand-new state.

---

# v3.5.1 — the Home screen leads with what makes Clipbot different

- **New headline and intro** that lead with Clipbot's edge: it catches moments
  **live, while you stream**, and with Always-on it clips every stream you do,
  hands off — plus the usual "paste any link" path. (Most clip tools only work on
  a finished VOD; Clipbot does it live.)
- **A line right under the link box** now says the quiet part out loud: it runs on
  your computer, your footage never leaves it, and there's no per-minute cloud bill.
- Nothing about clipping or rendering changed — this is wording on the Home screen.

---

# v3.5.0 — one cleaner, more consistent look

- **The app now speaks one accent colour instead of four.** "This is active / selected" used to show up as green in some places, yellow in others, and blue focus rings — all at once. Now every active tab, selected clip, checkbox, focus ring and the "Tell Clipbot" box uses the same coral you already see on Live and Render, so the whole thing reads as one deliberate look. Green is kept only where it means success or a job running.
- Nothing about your clips changed: captions, fonts, colours and renders are exactly the same. This is purely the look of the app's own buttons and panels.

---

# v3.4.17 — "Always on" now clearly waits for the next stream

- **When you clip a channel with "Always on" checked and their stream ends, the Live panel now says "⟳ Always on — waiting for <channel> to go live again…" and keeps watching**, instead of saying "stream finished" and looking like it stopped. Nothing changed under the hood — Clipbot already re-armed for the next stream — but now you can see it's still on duty. Press "Stop live clipping" whenever you want to end the watch.

---

# v3.4.16 — clear "reconnect" when a sign-in expires

- **If your Twitch sign-in expires, Settings now says so clearly** ("Twitch sign-in expired — press Connect Twitch to reconnect") instead of still showing "Connected" while clips silently fail. Normal token refresh is automatic as before; this only kicks in when the connection truly needs re-doing.

---

# v3.4.15 — search and filter in All clips

- **The All-clips gallery now has search and a project filter.** Type to find a clip by name, or pick a project to see just its clips. A count shows how many match. Handy once you have clips piling up from a lot of streams.

---

# v3.4.14 — the start panel makes sense in-project

- **The left "New project" panel now reads "Start another project" when you already have one open**, so it no longer looks like you lost your project. It still says "New project" on a fresh start.

---

# v3.4.13 — framing is clearer and easy to change

- **The Framing control now explains itself.** It is labelled "Framing — how the clip is cropped to fit," with a hint telling you to change it if people look too small or off-centre, and what Auto vs Full frame + blur do. Same 7 options; now obvious what they are and when to switch.

---

# v3.4.12 — Schedule messages show up again

- **Fixed a hidden-message bug in Schedule posts.** The Schedule panel shared an element id with the Settings scorer box, so its status and error messages ("Render some clips first", connection prompts, errors) were being written to a hidden element and never shown. Each now has its own id, so you see the right message.
- Added a test that fails the build on any duplicate element id, so this class of silent bug can't come back.

---

# v3.4.11 — "Watch" previews the moment you clicked

- **Fixed: clicking "Watch" on a different moment kept showing the same clip.** The preview was locked to the clip you had open, so watching another moment snapped straight back. Now "Watch" plays that exact moment from the source (looping it), and picking a clip returns to normal editing. Works for the "other moments" list and the candidates list.

---

# v3.4.10 — new auto-clips show progress, not old clips

- **Starting an auto-clip now shows a clean "building…" state** instead of leaving the previous project's clips on screen. The progress runs start to finish and your new clips appear the moment it is done. Manual clipping still opens the editor as before.

---

# v3.4.9 — Category Watch: confirm once, not every time

- **One-time clip-rights acknowledgement.** The first time you start Category Watch or live-clip a channel, you confirm you have the right to clip it. After that, Clipbot remembers — no more confirming on every single start. The live-clipper checkbox pre-checks itself once you have acknowledged.

---

# v3.4.8 — tidier Clips panel

- **Cleaned up the Clips panel.** "Find more moments" and its count sit together on one row, and "Open clips folder" + "Schedule posts…" are now full-width buttons underneath — so "Open clips folder" no longer wraps awkwardly onto three lines. Same actions, cleaner layout.

---

# v3.4.7 — a clear Home welcome

- **New Home hero.** Home now opens with a clear headline — "Turn any stream into clips" — and a one-line explainer, so anyone opening Clipbot for the first time instantly gets what it does and what to do (paste a link). Nothing else moved; it is orientation and polish on top of your existing layout.

---

# v3.4.6 — All clips in the sidebar

- **"All clips" is now in the left rail**, so every clip from every project is one click away from any screen — not just from Home. (Still on Home too.)
- Added a tour navigation audit to the tests: every feature the tour points at must stay reachable, so navigation can't silently break.

---

# v3.4.5 — All clips gallery

- **New "All clips" gallery.** The "Find all my clips" button on Home now opens an in-app gallery showing every finished clip from every project, newest first — each one plays right there, with a one-click download and an "Open clips folder" button. No more digging through project folders to find a clip.

---

# v3.4.4 — find all your clips in one click

- **New "Find all my clips" button on Home.** Opens the folder that holds every project, so all your finished clips are one click away instead of buried per-project. (Each project keeps its clips in its renders folder inside.)

---

# v3.4.3 — clearer Export tab

- **Renamed the confusing "Post" section to "Title & caption"** — it is where you write the title, description and hashtags, so it no longer looks like a near-duplicate of the "Post it" section right below it (which is where you actually post).
- **Export opens tidier** — it now expands "Make the video" and "Post it" by default instead of three sections; the rest open with one click.

---

# v3.4.2 — tidier Settings + one-click Twitch connect

- **Settings opens cleaner.** The "What Clipbot has learned" section (empty until you rate clips) now starts collapsed, so Settings opens as a tidy list with only "Your AI" expanded. Every section still opens with one click and remembers your choice.
- **Connecting Twitch is one click now.** The Client ID box has a clear hint showing what to paste, and **Connect Twitch** saves it for you — no more separate Save step. Paste your Client ID, press Connect, authorize in the tab that opens.

---

# v3.4.1 — more Home cleanup

- **Removed the duplicate "Open editor"** from the Home tab row — the one in the top bar is always there, so the second was just noise.
- **Removed the duplicate "AI live clipper" shortcut** — live clipping already has its own "Live clipper" tab up top, so the extra shortcut was redundant. The Home shortcut row is now all distinct tools.
- UI test updated to lock in the deduped Home controls.

---

# v3.4.0 — cleanup pass: plainer words, less clutter

- **Plain-language messages.** Rewrote the confusing error texts into clear sentences that tell you what to do next (e.g. the live-stream and "permission to clip" messages).
- **Less clutter on Home.** Removed the duplicate "YouTube video" shortcut (it is already a tab up top), so the shortcut row is cleaner.
- **Clearer Settings label** on hover.
- **New automated UI test** that opens every screen and fails the build if any of them throws an error — so a change in one place cannot quietly break another.

---

# v3.3.1 — live sessions end cleanly (no more stuck "live clipping")

- **Fixed: a stream that goes offline now ends the session properly.** Before, when a streamer stopped broadcasting, the live session could keep showing "live clipping" forever — and that stale state even blocked updates. Now an ended stream winds the session down to "finished" on its own.
- **Fixed: stopped sessions no longer linger.** The Live list now prunes sessions that have finished, errored, or been stopped, and reports their state honestly instead of showing them as still live.
- **Updates are no longer falsely blocked** by a session that has really already ended.
- **Batch jobs always finish in a clear state.** Hardened the multi-link batch runner so an unexpected error can never leave a batch stuck on "running" — it now always ends as done or error.
- Ran a wider "stuck-state" audit (Category Watch, always-on respawn, job error paths) — all confirmed to end cleanly. Regression tests added (tests/test_live_lifecycle.py).
- Groundwork logged in BUG-SWEEP.md for the de-clunk/redesign pass.

---

# v3.3.0 — Category Watch + walk-away notifications

- **Category Watch** — the launch-day feature. Open **Find**, type a game (GTA 6 is the default), and hit **“Clip all top streams at once.”** Clipbot finds the top live streams across Twitch/Kick/YouTube and starts live-clipping them **all in parallel**, dropping clips into your QC inbox. No cloud tool can do this — it only works because Clipbot clips locally and live.
- **Finish notifications** — when a background job finishes and Clipbot isn't your front window, the tab title badges (✅ with the result) and a soft chime plays, so you can walk away and know the moment clips are ready.
- **One-click Re-render** — a clip that comes back “needs a look” now has a Re-render button right on its status chip.

---

# v3.2.4 — runs start to finish, clearer progress

- **Submit and relax.** Paste a link or drop a file and Clipbot runs the whole way through on its own. You stay on a progress view the entire time, and your finished clips open automatically only when the job is **completely done** — no more being dropped into an empty Clips list mid-run. (Editing by hand and live clipping keep their own flows.)
- **Plain-language progress** — the bar now reads "Rendering clips · 45% · about 2m left" instead of "rendering 2/6".
- **Tutorial** updated to explain the run-to-finish behavior; it already walks through every feature and Pro mode.
- **Cropping verified** — added a safety net of tests proving the vertical reframe always fits the source and matches the target shape (no black bars, no off-edge crops).

---

# v3.2.3 — clearer, calmer, and a Help that works

**Fixes & clarity.** A pass to make Clipbot easier to use and less jumbled:

- **Help works again** — the Help button and the `?` shortcut did nothing before (a bug); they now open the shortcuts panel (Esc or click-away to close).
- **Plainer words** throughout: *More clips from this video* → **Find more moments** (one click, no typing — it just rescans), *New clip at playhead* → **New clip here**, *Output ratio* → **Size**, *Headline card* → **Title on the video**, *Delete segment* → **Delete part**, *Fit clip* → **Fit**.
- **Open clips folder** — a new button that opens the folder with all your finished clips, so they're easy to find after the fact.
- **Live clips are checked twice** — every live clip now gets an independent second verification pass before it lands in the QC inbox, with a pass / auto-fixable / needs-a-look verdict.
- Subtle **premium UI polish** (depth, hairlines, softer shadows) on the existing theme.

More coming (see the roadmap): calmer default layout, clearer progress, a beginner-first layout audit, and a better first-run demo.

---

# v3.2.2 — smarter quality gate + clearer status

**The quality gate now speaks reason codes and fixes what it can.** Every automatic check turns its
plain-English warnings into a small, stable set of codes (`LOUDNESS_OFF`, `TRUE_PEAK_HOT`,
`NOT_FASTSTART`, `BLACK_FRAMES`, `CAPTION_WER_HIGH`, …) with a severity, folded into one verdict:

- **pass** — nothing wrong,
- **repair** — only mechanically fixable issues (loudness, true peak, fast start, container),
- **block** — something a re-mux can't fix (wrong size, black/frozen video, captions reading wrong, black bars).

**Auto-repair:** when the verdict is *repair*, Clipbot re-finishes the clip for just those codes and
re-verifies — the picture and the cut are never touched, block-level issues are left for a re-render.
So loudness/true-peak/fast-start/container problems get fixed before they ever reach you.

**Status at a glance:** each rendered clip now shows one coloured chip — green *Passed all checks*
(noting anything auto-fixed), amber *Auto-fixable*, or red *Needs a look* with the reasons in plain
words — instead of a wall of warnings. The verifier still re-transcribes the delivered audio with a
second speech model to check the burned captions.

**Also:** the stream finder is clearer (searches Twitch/Kick/YouTube by game or category, with one-tap
examples and a note on where keys are needed) and the tutorial now covers the finder, posting and GIFs.

14 new offline tests. No change to how a clip is rendered.

---

# v3.2.1 — installer fix + today's feature wave

**Fix (the one a tester hit):** "Make Clipbot a real app" no longer crashes with
`[Errno 20] Not a directory` when a previous install was interrupted. The app is now
built in a fresh temp folder each time, a missing icon never aborts the install, and any
leftover `Clipbot.app.new` is cleared before the move.

**Shipped in 3.2.0 → 3.2.1 (all behind the new dashboard UI):**
- **Home / Projects / Processes dashboard** — redesigned dark UI.
- **GIPHY** — add GIFs, stickers and emoji as frames.
- **Learn my style** — point Clipbot at a creator's own videos and match their colour look,
  captions and motion (ported style engine + offline caption OCR).
- **Brand kit** — captions, colours and corner logo applied to every clip.
- **Stream finder** — who's live on Twitch, Kick and YouTube right now for a game
  (built for the GTA 6 launch wave, Nov 19).
- **Posting** — one-click post to X, Discord and Telegram, plus a "Post everywhere" button.
  TikTok / YouTube / Instagram / Reddit are **not** wired up yet (pending each platform's review).
- **Music-safety check** — flags clips whose audio looks like copyrighted music, so you know
  before you post.
- **Auto-update to Applications/Dock** on Mac; updates relaunch the app.
- Proprietary `LICENSE.txt` and updated `TERMS.md`.

Everything above is covered by the test suite (`tests/test_*.py`, all passing). Your projects,
settings, fonts, banners and connections are kept across the update; `clipbot update --rollback`
still reverts if anything goes wrong.

---

# v2 -> v3: what was wrong and what changed

## Problems found in v2
| Area | Problem | Effect |
|---|---|---|
| Scoring | Keywords matched as substrings: "cap" hits "market cap", "yo" hits "you", "bro" hits "brought", "lied" hits "applied", "rug" hits "drug" | On a crypto channel, filler like "you know, the market cap..." scored as jokes; picks were mundane (the 10/08 "these suck" run) |
| Scoring | Fixed 15s buckets, clip start = peak - 1/3 length | Clips started and ended mid-sentence; setup or payoff got cut |
| Scoring | Bucket scores were sums, so more speech = higher score; audio z-scored against the whole video | Rambling sections won; long streams that got louder skewed every pick late |
| Workflow | Two overlapping scripts (pipeline.py scorer/styler + edit.py renderer) with different styles, and the scorer was mostly bypassed | Drift; the agent re-did the work by hand every run |
| Transcription | Whole video transcribed, then every clip re-transcribed with a freshly loaded model | Slow; caption words didn't always match the transcript used to pick; names mangled ("Brez" -> "breast gales") |
| Layout | Facecam position had to be found by hand per video (memory has coordinates for two videos) | Manual step every run; wrong box = face cut off |
| Layout | Every source padded to 1920x1080 | Vertical IRL footage (N3on-style) got pillarboxed and then re-cropped |
| Layout | Captions at a fixed height | In split-screen they landed on the lower person's face |
| Render | 3-4 lossy encodes per clip; segments joined with stream copy | Softer image; risk of audio drift |
| Render | pipeline.py's run() ignored exit codes | The silent no-headline failure from 10/08 |
| Audio | Single-pass loudnorm | Clips landed anywhere from -12 to -17 LUFS |
| Downloads | One format string, no fallback, no cookies; state only had "seen" | 3 of 4 October runs blocked; retries depended on the agent remembering |
| State | state.json written by hand, non-atomic | Easy to mark a video seen that never got clipped |

## What v3 does
- **One CLI** (`clipbot.py`) and modules in `cb/`; `prep` runs the whole mechanical half and stops where judgment starts.
- **Transcribe once** per video with name hotwords; `words.json` feeds candidates and captions alike. Long VODs resume after a timeout.
- **Candidate finder**: windows that start and end on sentence boundaries, whole-word lexicons plus niche ones (crypto/gaming/podcast), spelled-out money as stakes, rolling-baseline voice energy, payoff-in-back-half bonus, hook check, dead-air and filler penalties. Never opens or closes on filler. Writes a readable `candidates.md`.
- **Renderer**: one final encode; frame-exact cuts; native aspect (vertical passes through); auto layout per shot including **auto facecam-inset detection** (stable small face + temporal-median edge search, within a few px in testing); captions placed by layout (seam / under the face); headline sized by measuring the real font (big 1-2 line cards instead of tiny 3-line ones); headline placed around the face on vertical video; punch-zoom (109%, snap) on loud, meaningful words but never on charts; two-pass loudnorm to -14 LUFS; optional watermark and caption censoring.
- **QA**: every clip gets checks for resolution, duration, audio, loudness, headline actually drawn, captions over a face (YuNet run on the output), black frames, plus an 8-frame contact sheet.
- **Downloads**: 1080p, retries, 4 YouTube player-client fallbacks, cookies support, error classified (bot_check / unavailable / error). The queue in state.json tracks attempts and moves a video to `failed` after the limit. Atomic writes.
- **Montage**: any mix of sources normalised in one graph, labels, two-pass loudness.
- **Setup**: fonts fall back to npm when GitHub raw is blocked.

## Not done yet (next candidates)
- ~~Active-speaker detection~~ (done in v4).
- Chat-replay spikes as a signal (Twitch/YouTube live chat; Kick has no replay API).
- Posting/scheduling to TikTok/Shorts.

---
# v3 -> v4 (research-driven upgrade + editor)

## What the research said (directional - most public numbers come from tool vendors)
- Viewers decide to stay or swipe within ~1.5-3s; YouTube's own guidance for "viewed vs swiped away"
  is: show the subject in the first frame, no greetings/setup, open with a result or conflict, make the
  opening match the title, captions readable on a phone. Replays have counted as Shorts views since
  March 2025, so rewatchable/loopable clips matter more.
- Word-synced captions with a single highlighted word outperform block captions; highlight should land
  ~50-100ms before the word is spoken. Emoji: at most one per line, only when it reinforces.
- Top tools (OpusClip, Vizard) sell: active-speaker framing that cuts between speakers, animated caption
  presets, filler/silence removal, a virality score, brand kits. Crayo sells: gameplay-below split
  screens, AI voiceover and text-story formats.

## New in v4
- **Active speaker detection** (`cb/speaker.py`): face tracks + mouth-vs-eye motion compared with the
  audio envelope; switches back-dated to the real turn. In the two-speaker test, cuts landed within
  ~0.6s of each true turn; overlaps go to a stacked split.
- **Auto-tighten**: pauses > 0.42s and um/uh removed using word timestamps, micro-fades on every cut.
- **Payoff teaser**: optional cold open on the loudest meaningful line, white flash + synthesized
  whoosh, then the story.
- **Frame-1 push-in** and snap punch-zooms (never on charts).
- **Caption presets**: pro / karaoke (active word lights up) / box (active word in a colour box) /
  minimal; accent colours, fonts, size, position, case, censoring; early highlight timing.
- **Gameplay layout** (Crayo-style), **text layers**, **emoji + image stickers**, **music with
  sidechain ducking**, **speed**, **colour looks**, **progress bar**.
- **Hook QA**: late first word, slow first 3s, no face in frame 1.
- **Browser editor** (`clipbot.py editor`): see README.
- Parallel rendering (`--jobs`), `review.html` gallery, `posts.md`, `ledger.jsonl` (one row per clip
  with its features - add real views/retention later to learn what works for this channel).
- Kick VOD listing falls back to Kick's own API; long VODs use faster-whisper's batched pipeline.

## Honest comparison
| | OpusClip | Crayo | Clipbot v4 |
|---|---|---|---|
| Moment finding | proprietary "virality score" | n/a (you bring content) | transparent feature score + reading the transcript |
| Active speaker framing | yes | no | yes (audio-visual sync, no model download) |
| Webcam-over-screen layout | partial | no | auto-detected inset |
| Gameplay split | no | yes | yes |
| Caption presets | many | many | 4 + full custom |
| Silence/filler removal | yes | n/a | yes |
| Full editor | yes (cloud) | basic | yes (local, browser) |
| AI B-roll / AI voiceover / text-story videos | B-roll yes | voiceover yes | **no** |
| Auto emoji, translation, auto-posting | yes | some | **no** (manual stickers; whisper can transcribe other languages) |
| Cost / watermark / your files leave your machine | subscription | subscription | free, none, no |
Not built: keyframe curves, masks, transitions library, multi-track video compositing beyond
stickers, 1:1/16:9 export, AI voice. These would be the next layer.

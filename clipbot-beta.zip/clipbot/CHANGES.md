# v2 -> v3: what was wrong and what changed

## Problems found in v2
| Area | Problem | Effect |
|---|---|---|
| Scoring | Keywords matched as substrings: "cap" hits "market cap", "yo" hits "you", "bro" hits "brought", "lied" hits "applied", "rug" hits "drug" | On a crypto channel, filler like "you know, the market cap..." scored as jokes; picks were mundane (the 10/08 "these suck" run) |
| Scoring | Fixed 15s buckets, clip start = peak - 1/3 length | Clips started and ended mid-sentence; setup or payoff got cut |
| Scoring | Bucket scores were sums, so more speech = higher score; audio z-scored against the whole video | Rambling sections won; long streams that got louder skewed every pick late |
| Workflow | Two overlapping scripts (pipeline.py scorer/styler + edit.py renderer) with different styles, and the scorer was mostly bypassed | Drift; the agent re-did the work by hand every run |
| Transcription | Whole video transcribed, then every clip re-transcribed with a freshly loaded model | Slow; caption words didn't always match the transcript used to pick; names mangled ("Brez" -> "breast gales") |
| Layout | Facecam position had to be found by hand per video (memory has coordinates for two videos) | Manual step every run; wrong box = face cut off |
| Layout | Every source padded to 1920x1080 | Vertical IRL footage (N3on-style) got pillarboxed and then re-cropped |
| Layout | Captions at a fixed height | In split-screen they landed on the lower person's face |
| Render | 3-4 lossy encodes per clip; segments joined with stream copy | Softer image; risk of audio drift |
| Render | pipeline.py's run() ignored exit codes | The silent no-headline failure from 10/08 |
| Audio | Single-pass loudnorm | Clips landed anywhere from -12 to -17 LUFS |
| Downloads | One format string, no fallback, no cookies; state only had "seen" | 3 of 4 October runs blocked; retries depended on the agent remembering |
| State | state.json written by hand, non-atomic | Easy to mark a video seen that never got clipped |

## What v3 does
- **One CLI** (`clipbot.py`) and modules in `cb/`; `prep` runs the whole mechanical half and stops where judgment starts.
- **Transcribe once** per video with name hotwords; `words.json` feeds candidates and captions alike. Long VODs resume after a timeout.
- **Candidate finder**: windows that start and end on sentence boundaries, whole-word lexicons plus niche ones (crypto/gaming/podcast), spelled-out money as stakes, rolling-baseline voice energy, payoff-in-back-half bonus, hook check, dead-air and filler penalties. Never opens or closes on filler. Writes a readable `candidates.md`.
- **Renderer**: one final encode; frame-exact cuts; native aspect (vertical passes through); auto layout per shot including **auto facecam-inset detection** (stable small face + temporal-median edge search, within a few px in testing); captions placed by layout (seam / under the face); headline sized by measuring the real font (big 1-2 line cards instead of tiny 3-line ones); headline placed around the face on vertical video; punch-zoom (109%, snap) on loud, meaningful words but never on charts; two-pass loudnorm to -14 LUFS; optional watermark and caption censoring.
- **QA**: every clip gets checks for resolution, duration, audio, loudness, headline actually drawn, captions over a face (YuNet run on the output), black frames, plus an 8-frame contact sheet.
- **Downloads**: 1080p, retries, 4 YouTube player-client fallbacks, cookies support, error classified (bot_check / unavailable / error). The queue in state.json tracks attempts and moves a video to `failed` after the limit. Atomic writes.
- **Montage**: any mix of sources normalised in one graph, labels, two-pass loudness.
- **Setup**: fonts fall back to npm when GitHub raw is blocked.

## Not done yet (next candidates)
- ~~Active-speaker detection~~ (done in v4).
- Chat-replay spikes as a signal (Twitch/YouTube live chat; Kick has no replay API).
- Posting/scheduling to TikTok/Shorts.

---
# v3 -> v4 (research-driven upgrade + editor)

## What the research said (directional - most public numbers come from tool vendors)
- Viewers decide to stay or swipe within ~1.5-3s; YouTube's own guidance for "viewed vs swiped away"
  is: show the subject in the first frame, no greetings/setup, open with a result or conflict, make the
  opening match the title, captions readable on a phone. Replays have counted as Shorts views since
  March 2025, so rewatchable/loopable clips matter more.
- Word-synced captions with a single highlighted word outperform block captions; highlight should land
  ~50-100ms before the word is spoken. Emoji: at most one per line, only when it reinforces.
- Top tools (OpusClip, Vizard) sell: active-speaker framing that cuts between speakers, animated caption
  presets, filler/silence removal, a virality score, brand kits. Crayo sells: gameplay-below split
  screens, AI voiceover and text-story formats.

## New in v4
- **Active speaker detection** (`cb/speaker.py`): face tracks + mouth-vs-eye motion compared with the
  audio envelope; switches back-dated to the real turn. In the two-speaker test, cuts landed within
  ~0.6s of each true turn; overlaps go to a stacked split.
- **Auto-tighten**: pauses > 0.42s and um/uh removed using word timestamps, micro-fades on every cut.
- **Payoff teaser**: optional cold open on the loudest meaningful line, white flash + synthesized
  whoosh, then the story.
- **Frame-1 push-in** and snap punch-zooms (never on charts).
- **Caption presets**: pro / karaoke (active word lights up) / box (active word in a colour box) /
  minimal; accent colours, fonts, size, position, case, censoring; early highlight timing.
- **Gameplay layout** (Crayo-style), **text layers**, **emoji + image stickers**, **music with
  sidechain ducking**, **speed**, **colour looks**, **progress bar**.
- **Hook QA**: late first word, slow first 3s, no face in frame 1.
- **Browser editor** (`clipbot.py editor`): see README.
- Parallel rendering (`--jobs`), `review.html` gallery, `posts.md`, `ledger.jsonl` (one row per clip
  with its features - add real views/retention later to learn what works for this channel).
- Kick VOD listing falls back to Kick's own API; long VODs use faster-whisper's batched pipeline.

## Honest comparison
| | OpusClip | Crayo | Clipbot v4 |
|---|---|---|---|
| Moment finding | proprietary "virality score" | n/a (you bring content) | transparent feature score + reading the transcript |
| Active speaker framing | yes | no | yes (audio-visual sync, no model download) |
| Webcam-over-screen layout | partial | no | auto-detected inset |
| Gameplay split | no | yes | yes |
| Caption presets | many | many | 4 + full custom |
| Silence/filler removal | yes | n/a | yes |
| Full editor | yes (cloud) | basic | yes (local, browser) |
| AI B-roll / AI voiceover / text-story videos | B-roll yes | voiceover yes | **no** |
| Auto emoji, translation, auto-posting | yes | some | **no** (manual stickers; whisper can transcribe other languages) |
| Cost / watermark / your files leave your machine | subscription | subscription | free, none, no |
Not built: keyframe curves, masks, transitions library, multi-track video compositing beyond
stickers, 1:1/16:9 export, AI voice. These would be the next layer.

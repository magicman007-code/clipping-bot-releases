#!/usr/bin/env python3
"""Clipping bot v3 - one CLI for the whole workflow.

  autoclip <link | file> [--clips 6] [--min-score 6] [--aspect 9:16|4:5|1:1|16:9] [--also 16:9] [--no-banner] [--no-headline]
                                                        ONE STEP: import -> transcribe -> score -> render clips
  thumbnail <clip.mp4> [--text ..] [--emoji ..]        YouTube 16:9 + 9:16 cover thumbnails
  titles <clip.json>                                    title options, each checked against what's said
  setup                                  install/verify ffmpeg, python deps, fonts
  doctor                                 check this machine is ready (beta testers: run this first)
  demo [dir]                             create a demo project (works offline, no footage needed)
  import <video> [...]                   bring local files into the projects folder (+ transcribe)
  bug-report                             zip logs/specs/QC (no media) to send to the team
  font add <file.ttf|.otf> | font list    add your own fonts (show up in every font menu)
  banner add <campaign.png> [--name x] | list | preview --preset kick_campaign --handle orangie
  scan                                   list configured channels, queue unseen videos
  fetch                                  download queued videos (retries + fallbacks)
  prep                                   scan + fetch + transcribe + candidates (stops where judgment starts)
  status                                 show queue (pending / failed / seen)
  done <video_id>                        mark a video processed (only after clips are delivered)

  list <url> [--platform youtube|kick] [-n 5]
  download <url> <workdir>
  live <url> <workdir> [--seconds 300]   record live edge, then transcribe + candidates
  transcribe <source.mp4> [--model small] [--vocab "Orangie,Brez"]
  candidates <source.mp4> [--niche crypto] [--top 12]
  clip <source.mp4> <start> <end> <out.mp4> "<HEADLINE>" [--layout auto]
  render <specs.json> <outdir>           batch render (see SKILL.md for spec keys)
  montage <specs.json> <out.mp4> [--intro x.mp4] [--outro y.mp4] [--no-labels]
  editor [--root DIR] [--port 8765]      browser editor: trim/split, captions, text, stickers, layouts, render
  verify <clip.mp4> [...]                independent re-measurement of finished files
  qc inbox|approve|reject <outdir> [name] [--watched] [--note ..]   human QC gate (nothing ships unapproved)
  montage-build <brief.json> <out.mp4> [--aspect 9:16 --aspect 16:9] [--from-plan]   sick edits / trailers
  live-watch <url> [--name N] [--minutes M] [--chat twitch:<channel>]   continuous live clipping
"""
import argparse
import json
import os
import shutil
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from cb import fetch                                  # noqa: E402
from cb.common import FONT_DIR, load_config, load_state, log  # noqa: E402


def out(obj):
    print(json.dumps(obj, indent=1, default=str), flush=True)


def channel_cfg(cfg, name):
    return next((c for c in cfg["channels"] if c["name"] == name), {})


def cmd_setup(_):
    status = {}
    if not shutil.which("ffmpeg"):
        if sys.platform.startswith("linux") and shutil.which("apt-get") and hasattr(os, "geteuid") and os.geteuid() == 0:
            subprocess.run("apt-get update -qq && DEBIAN_FRONTEND=noninteractive apt-get install -y -qq ffmpeg", shell=True)
    status["ffmpeg"] = bool(shutil.which("ffmpeg"))
    pip = [sys.executable, "-m", "pip", "install", "-q", "--break-system-packages"]
    for pkgs in (["yt-dlp", "numpy", "opencv-python-headless"],
                 ["ctranslate2", "onnxruntime", "tokenizers", "huggingface_hub", "av"]):
        subprocess.run(pip + pkgs, capture_output=True)
    try:
        __import__("faster_whisper")
    except ImportError:
        subprocess.run(pip + ["--no-deps", "faster-whisper"], capture_output=True)
    subprocess.run(pip + ["-U", "yt-dlp"], capture_output=True)  # YouTube breaks old versions often
    for m in ("yt_dlp", "faster_whisper", "cv2", "numpy"):
        try:
            __import__(m)
            status[m] = True
        except ImportError:
            status[m] = False
    status["fonts"] = install_fonts()
    out(status)


def install_fonts():
    os.makedirs(FONT_DIR, exist_ok=True)
    want = {"Anton-Regular.ttf": ("https://github.com/google/fonts/raw/main/ofl/anton/Anton-Regular.ttf",
                                  "@fontsource/anton", "anton-latin-400-normal.woff2"),
            "Montserrat-Black.ttf": ("https://github.com/google/fonts/raw/main/ofl/montserrat/Montserrat%5Bwght%5D.ttf",
                                     "@fontsource/montserrat", "montserrat-latin-900-normal.woff2")}
    got = {}
    for fn, (url, npm_pkg, woff) in want.items():
        dst = os.path.join(FONT_DIR, fn)
        if not os.path.exists(dst):
            if shutil.which("curl") and "Montserrat%5B" not in url:     # (that file is a variable font: wrong weight)
                subprocess.run(["curl", "-sSfL", "-o", dst, url], capture_output=True)
            if not os.path.exists(dst) or os.path.getsize(dst) < 10000:
                if os.path.exists(dst):
                    os.remove(dst)
                _font_from_npm(npm_pkg, woff, dst)   # fallback when GitHub raw is blocked
        got[fn] = os.path.exists(dst)
    if shutil.which("fc-cache"):
        subprocess.run(["fc-cache", "-f"], capture_output=True)
    return got


def _font_from_npm(pkg, woff, dst):
    import glob
    import tempfile
    tmp = tempfile.mkdtemp()
    if not (shutil.which("npm") and shutil.which("tar")):
        return
    subprocess.run(["npm", "pack", pkg], cwd=tmp, capture_output=True)
    tgz = glob.glob(os.path.join(tmp, "*.tgz"))
    if not tgz:
        return
    subprocess.run(["tar", "xzf", tgz[0], "-C", tmp], capture_output=True)
    src = glob.glob(os.path.join(tmp, "package", "files", woff))
    if not src:
        return
    subprocess.run([sys.executable, "-m", "pip", "install", "-q", "--break-system-packages", "fonttools", "brotli"],
                   capture_output=True)
    from fontTools.ttLib import TTFont
    f = TTFont(src[0])
    f.flavor = None
    f.save(dst)


def cmd_list(a):
    out(fetch.list_videos(a.url, a.platform, a.n))


def cmd_download(a):
    p, kind, info = fetch.download(a.url, a.workdir)
    out({"source": p, "error": kind, "log": info[-1500:]})


def cmd_scan(_):
    new, rep = fetch.scan()
    out({"new": new, "channels": rep})


def cmd_fetch(_):
    out(fetch.fetch_pending())


def cmd_status(_):
    st = load_state()
    out({"pending": st["pending"], "failed": st["failed"], "seen": len(st["seen_video_ids"])})


def cmd_done(a):
    for v in a.ids:
        fetch.mark_done(v)
    out({"marked_seen": a.ids})


def _transcribe(src, model=None, vocab=None):
    from cb.transcribe import transcribe_video
    cfg = load_config()
    return transcribe_video(src, os.path.dirname(os.path.abspath(src)), model or cfg["whisper_model"], vocab)


def _candidates(src, niche=(), top=12, title=""):
    from cb.moments import find_candidates, write_candidates
    wd = os.path.dirname(os.path.abspath(src))
    words = json.load(open(os.path.join(wd, "words.json")))
    c = find_candidates(words, src, wd, niche=niche, top_k=top)
    return write_candidates(c, wd, title), c


def _vocab(cfg, ch):
    return list(dict.fromkeys((cfg.get("vocab") or []) + (ch.get("vocab") or []) + [ch.get("name", "")])) or None


def cmd_transcribe(a):
    cfg = load_config()
    vocab = [v.strip() for v in a.vocab.split(",")] if a.vocab else cfg.get("vocab")
    w = _transcribe(a.source, a.model, vocab)
    out({"words": len(w), "transcript": os.path.join(os.path.dirname(os.path.abspath(a.source)), "transcript.txt")})


def cmd_candidates(a):
    p, c = _candidates(a.source, tuple(a.niche or ()), a.top)
    out({"candidates_md": p, "top": [{k: x[k] for k in ("rank", "start", "end", "dur", "score", "tags")} for x in c[:5]]})


def cmd_prep(_):
    cfg = load_config()
    new, rep = fetch.scan(cfg)
    dl = fetch.fetch_pending(cfg)
    st = load_state()
    ready = []
    for r in dl:
        if not r["ok"]:
            continue
        p = st["pending"].get(r["id"], {})
        ch = channel_cfg(cfg, p.get("channel"))
        try:
            _transcribe(r["source"], vocab=_vocab(cfg, ch))
            md, c = _candidates(r["source"], tuple(ch.get("niche") or cfg.get("niche") or ()), 12, r["title"] or "")
            ready.append({"id": r["id"], "title": r["title"], "channel": p.get("channel"), "source": r["source"],
                          "transcript": os.path.join(os.path.dirname(r["source"]), "transcript.txt"),
                          "candidates": md, "n_candidates": len(c)})
        except Exception as e:
            ready.append({"id": r["id"], "error": str(e)[-600:]})
    out({"channels": rep, "new_queued": new, "downloads": [{k: v for k, v in d.items() if k != "detail"} for d in dl],
         "ready_to_pick": ready, "still_pending": list(load_state()["pending"].keys())})


def cmd_live(a):
    src = fetch.capture_live(a.url, a.workdir, a.seconds)
    _transcribe(src)
    p, c = _candidates(src, tuple(a.niche or ()), 6)
    out({"source": src, "candidates_md": p})


def cmd_clip(a):
    from cb.render import make_clip
    spec = {"name": os.path.splitext(os.path.basename(a.out))[0], "source": a.source, "start": a.start,
            "end": a.end, "headline": a.headline, "layout": a.layout}
    out(make_clip(spec, os.path.dirname(os.path.abspath(a.out)), a.workdir, load_config()))


def _render_one(args):
    from cb.render import make_clip
    from cb.review import ledger_append
    s, outdir, workdir, cfg = args
    try:
        r = make_clip(s, outdir, workdir, cfg)
        ledger_append(r, s)
        log("%s: %s %s" % (s["name"], "OK" if r["qa"]["ok"] else "CHECK", "; ".join(r["qa"]["warnings"])))
        return r
    except Exception as e:
        log("%s FAILED: %s" % (s["name"], e))
        return {"name": s["name"], "error": str(e)[-1500:]}


def cmd_render(a):
    from concurrent.futures import ProcessPoolExecutor
    from cb.review import write_gallery, write_posts
    cfg = load_config()
    specs = json.load(open(a.specs))
    todo = [s for s in specs if a.force or not os.path.exists(os.path.join(a.outdir, s["name"] + ".mp4"))]
    for s in specs:
        if s not in todo:
            log("skip existing " + s["name"])
    jobs = [(s, a.outdir, a.workdir, cfg) for s in todo]
    if a.jobs > 1 and len(jobs) > 1:
        with ProcessPoolExecutor(a.jobs) as ex:
            results = list(ex.map(_render_one, jobs))
    else:
        results = [_render_one(j) for j in jobs]
    if results:
        os.makedirs(a.outdir, exist_ok=True)
        log("review page: " + write_gallery(results, a.outdir))
        log("posting copy: " + write_posts(results, a.outdir))
    out([{k: r.get(k) for k in ("name", "out", "dur", "layout", "qa", "error") if k in r} for r in results])


def cmd_verify(a):
    from cb.verify import verify_file
    res = []
    for f in a.files:
        meta = os.path.splitext(f)[0] + ".json"
        words = None
        if os.path.exists(meta):
            words = (json.load(open(meta)).get("text") or "").split() or None
        res.append(verify_file(f, words, check_wer=not a.no_wer))
    out(res)


def cmd_qc(a):
    from cb.verify import qc_load, qc_set
    if a.action == "inbox":
        import glob as _g
        res = {}
        for qf in sorted(_g.glob(os.path.join(a.outdir, "**", "qc.json"), recursive=True)):
            d = os.path.dirname(qf)
            for k, v in qc_load(d).items():
                if a.all or v["status"] == "pending":
                    res["%s :: %s" % (d, k)] = {"status": v["status"], "file": v["file"], "note": v.get("note"),
                                                "defects": (v.get("verify") or {}).get("defects")}
        out(res)
        return
    if not a.name:
        sys.exit("name required")
    status = "approved" if a.action == "approve" else "rejected"
    d = a.outdir
    if not os.path.exists(os.path.join(d, "qc.json")):
        import glob as _g
        hits = [os.path.dirname(f) for f in _g.glob(os.path.join(d, "**", "qc.json"), recursive=True)
                if a.name in qc_load(os.path.dirname(f))]
        if len(hits) != 1:
            sys.exit("clip %r found in %d QC folders under %s; pass the exact folder" % (a.name, len(hits), d))
        d = hits[0]
    out(qc_set(d, a.name, status, a.note or "", a.watched))


def cmd_live_watch(a):
    from cb.live import LiveSession
    cfg = load_config()
    allowed = [u.lower().rstrip("/") for u in cfg.get("live", {}).get("authorized_channels", [])]
    local = a.url.startswith(("http://127.", "http://localhost", "rtmp://127.", "srt://127.")) or os.path.exists(a.url)
    if not (a.authorized or local or a.url.lower().rstrip("/") in allowed):
        sys.exit("Live capture records the stream. Only record channels you own or have permission to clip.\n"
                 "Confirm with --authorized, or add the URL to config.json live.authorized_channels.")
    LiveSession(a.url, name=a.name, minutes=a.minutes, chat=a.chat, render=not a.no_render,
                transcriber=a.transcriber, outroot=a.outroot, wait_hours=a.wait_hours, min_quality=a.min_score).run()


def cmd_montage_build(a):
    from cb.montage_engine import build
    brief = json.load(open(a.brief))
    res = []
    for asp in (a.aspect or [brief.get("aspect", "9:16")]):
        o = a.out if len(a.aspect or []) <= 1 else "%s_%s%s" % (os.path.splitext(a.out)[0], asp.replace(":", "x"),
                                                               os.path.splitext(a.out)[1])
        res.append(build(brief, o, asp, a.from_plan))
    out(res)


def cmd_update(a):
    from cb import updater
    if a.rollback:
        return out(updater.rollback())
    info = updater.check(a.url)
    if a.check or not info.get("available"):
        return out(info)
    out(updater.apply(info))


def cmd_release(a):
    from cb import updater
    out(updater.release(a.out, a.version, url=a.url, notes=a.notes or ""))


def cmd_publish(a):
    from cb import updater
    try:
        out(updater.publish_github(a.version, a.repo, notes=a.notes or ""))
    except (RuntimeError, ValueError) as e:
        print("\n%s\n" % e, file=sys.stderr)
        sys.exit(1)


def cmd_find(a):
    from cb import lore
    from cb.prompt_clip import find
    from cb.score import score_candidate
    words = json.load(open(os.path.join(a.project, "words.json")))
    prof = lore.load(a.streamer)
    c, info = find(a.prompt, words, os.path.join(a.project, "source.mp4"), a.project, n=a.n,
                   lore=lore.terms(prof), lore_aliases=lore.aliases(prof))
    out({"info": info, "moments": [{"start": x["start"], "end": x["end"], "match": x.get("match"),
                                    "relevance": x.get("relevance"), "score": score_candidate(x)["score"]} for x in c]})


def cmd_lore(a):
    from cb import lore
    if a.action == "list":
        return out(lore.list_profiles())
    if a.action == "show":
        name = a.name or (a.projects[0] if a.projects else None)
        return out(lore.load(name) or {"error": "no lore for %s" % name})
    if a.action == "learn":
        r = lore.learn(a.projects or [])
        if a.name and a.save:
            p = lore.load(a.name) or {"streamer": a.name}
            p["names"] = list(p.get("names", [])) + [n["text"] for n in r["names"]]
            p["phrases"] = list(p.get("phrases", [])) + [x["text"] for x in r["phrases"]]
            p["projects"] = list(p.get("projects", [])) + list(a.projects or [])
            r["saved"] = lore.save(p)
        return out(r)


def cmd_doctor(_):
    from cb.tools import doctor
    sys.exit(0 if doctor() else 1)


def cmd_demo(a):
    from cb.tools import demo
    demo(a.dest or os.path.join(load_config()["work_root"], "demo"))


def cmd_import(a):
    from cb.tools import import_media
    for f in a.files:
        import_media(f, a.root or load_config()["work_root"], transcribe=not a.no_transcribe)


def cmd_bugreport(a):
    from cb.tools import bug_report
    bug_report(a.root or load_config()["work_root"])


def cmd_banner(a):
    import shutil as _sh
    from cb.banner import PRESETS, library, library_dir, render_png, resolve
    if a.action == "add":
        for f in a.files:
            dst = os.path.join(library_dir(), (a.name or os.path.splitext(os.path.basename(f))[0]) + os.path.splitext(f)[1].lower())
            _sh.copyfile(f, dst)
            print("added", dst)
    elif a.action == "list":
        out({"library": library(), "presets": PRESETS})
    else:
        b = resolve({"preset": a.preset} if a.preset else {"platform": a.platform})
        b.update({k: v for k, v in (("handle", a.handle), ("style", a.style), ("format", a.format)) if v})
        if a.files:
            b = {"image": a.files[0]}
        print(render_png(b)[0])


def cmd_autoclip(a):
    from cb.autoclip import run
    out(run(a.source, a.root, a.name, a.clips, a.min_score, a.captions, False if a.no_banner else None, a.draft,
            aspect=a.aspect, also_aspects=a.also or None, headline=not a.no_headline, prompt=a.prompt,
            streamer=a.streamer))


def cmd_titles(a):
    from cb.packaging import titles
    meta = json.load(open(a.clip_json))
    out(titles(meta.get("text", ""), (), meta.get("headline", "")))


def cmd_thumbnail(a):
    from cb.packaging import thumbnail
    out(thumbnail(a.video, os.path.splitext(a.video)[0] + "_thumb", a.text or "", emoji=a.emoji, arrow=a.arrow,
                  circle=a.circle))


def cmd_font(a):
    from cb.fonts import add, list_fonts
    if a.action == "add":
        for f in a.files:
            print("added:", add(f)["family"])
    else:
        for f in list_fonts():
            print(("[yours] " if f["user"] else "        ") + f["family"])


def cmd_editor(a):
    from cb.editor_server import serve
    root = a.root or load_config()["work_root"]
    os.makedirs(root, exist_ok=True)
    serve(root, a.port, a.host, open_browser=a.open)


def cmd_montage(a):
    from cb.montage import build_montage
    out(build_montage(json.load(open(a.specs)), a.out, a.workdir, a.intro, a.outro, not a.no_labels))


def main():
    from cb.common import VERSION
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--version", action="version", version="clipbot " + VERSION)
    sp = ap.add_subparsers(dest="cmd", required=True)
    for n, f in (("setup", cmd_setup), ("scan", cmd_scan), ("fetch", cmd_fetch), ("prep", cmd_prep),
                 ("status", cmd_status)):
        sp.add_parser(n).set_defaults(f=f)
    p = sp.add_parser("done"); p.add_argument("ids", nargs="+"); p.set_defaults(f=cmd_done)
    p = sp.add_parser("list"); p.add_argument("url"); p.add_argument("--platform", default="youtube")
    p.add_argument("-n", type=int, default=5); p.set_defaults(f=cmd_list)
    p = sp.add_parser("download"); p.add_argument("url"); p.add_argument("workdir"); p.set_defaults(f=cmd_download)
    p = sp.add_parser("live"); p.add_argument("url"); p.add_argument("workdir")
    p.add_argument("--seconds", type=int, default=300); p.add_argument("--niche", nargs="*"); p.set_defaults(f=cmd_live)
    p = sp.add_parser("transcribe"); p.add_argument("source"); p.add_argument("--model")
    p.add_argument("--vocab"); p.set_defaults(f=cmd_transcribe)
    p = sp.add_parser("candidates"); p.add_argument("source"); p.add_argument("--niche", nargs="*")
    p.add_argument("--top", type=int, default=12); p.set_defaults(f=cmd_candidates)
    p = sp.add_parser("clip"); p.add_argument("source"); p.add_argument("start", type=float)
    p.add_argument("end", type=float); p.add_argument("out"); p.add_argument("headline")
    p.add_argument("--layout", default="auto"); p.add_argument("--workdir", default="/tmp/clipbot_work")
    p.set_defaults(f=cmd_clip)
    p = sp.add_parser("render"); p.add_argument("specs"); p.add_argument("outdir")
    p.add_argument("--workdir", default="/tmp/clipbot_work"); p.add_argument("--force", action="store_true")
    p.add_argument("--jobs", type=int, default=2); p.set_defaults(f=cmd_render)
    p = sp.add_parser("verify"); p.add_argument("files", nargs="+"); p.add_argument("--no-wer", action="store_true")
    p.set_defaults(f=cmd_verify)
    p = sp.add_parser("qc"); p.add_argument("action", choices=["inbox", "approve", "reject"]); p.add_argument("outdir")
    p.add_argument("name", nargs="?"); p.add_argument("--watched", action="store_true"); p.add_argument("--note")
    p.add_argument("--all", action="store_true"); p.set_defaults(f=cmd_qc)
    p = sp.add_parser("live-watch"); p.add_argument("url"); p.add_argument("--name"); p.add_argument("--minutes", type=float)
    p.add_argument("--chat"); p.add_argument("--no-render", action="store_true"); p.add_argument("--outroot")
    p.add_argument("--transcriber", default="whisper"); p.add_argument("--authorized", action="store_true")
    p.add_argument("--wait-hours", type=float, help="start before the stream: wait up to N hours for it to go live")
    p.add_argument("--min-score", type=float, help="quality bar for auto clips (default 6)")
    p.set_defaults(f=cmd_live_watch)
    p = sp.add_parser("montage-build"); p.add_argument("brief"); p.add_argument("out")
    p.add_argument("--aspect", action="append"); p.add_argument("--from-plan", action="store_true")
    p.set_defaults(f=cmd_montage_build)
    sp.add_parser("doctor").set_defaults(f=cmd_doctor)
    p = sp.add_parser("demo"); p.add_argument("dest", nargs="?"); p.set_defaults(f=cmd_demo)
    p = sp.add_parser("update", help="get the latest version (from config update_url)")
    p.add_argument("--check", action="store_true"); p.add_argument("--rollback", action="store_true"); p.add_argument("--url")
    p.set_defaults(f=cmd_update)
    p = sp.add_parser("release", help="build clipbot-beta.zip + latest.json to share an update")
    p.add_argument("version"); p.add_argument("--out", default="release"); p.add_argument("--url", help="link to latest.json")
    p.add_argument("--notes"); p.set_defaults(f=cmd_release)
    p = sp.add_parser("publish", help="publish an update to GitHub Releases (needs the gh tool)")
    p.add_argument("version"); p.add_argument("--repo", required=True, help="yourname/clipbot-releases")
    p.add_argument("--notes"); p.set_defaults(f=cmd_publish)
    p = sp.add_parser("find", help="find moments in a project by describing them")
    p.add_argument("project"); p.add_argument("prompt"); p.add_argument("--n", type=int, default=8); p.add_argument("--streamer")
    p.set_defaults(f=cmd_find)
    p = sp.add_parser("lore", help="streamer lore: list | show NAME | learn --name NAME PROJECT...")
    p.add_argument("action", choices=["list", "show", "learn"]); p.add_argument("projects", nargs="*")
    p.add_argument("--name"); p.add_argument("--save", action="store_true"); p.set_defaults(f=cmd_lore)
    p = sp.add_parser("import"); p.add_argument("files", nargs="+"); p.add_argument("--root")
    p.add_argument("--no-transcribe", action="store_true"); p.set_defaults(f=cmd_import)
    p = sp.add_parser("bug-report"); p.add_argument("--root"); p.set_defaults(f=cmd_bugreport)
    p = sp.add_parser("banner"); p.add_argument("action", choices=["add", "list", "preview"])
    p.add_argument("files", nargs="*"); p.add_argument("--name"); p.add_argument("--preset"); p.add_argument("--platform", default="kick")
    p.add_argument("--handle"); p.add_argument("--style"); p.add_argument("--format"); p.set_defaults(f=cmd_banner)
    p = sp.add_parser("autoclip"); p.add_argument("source"); p.add_argument("--root"); p.add_argument("--name")
    p.add_argument("--clips", type=int, default=6); p.add_argument("--min-score", type=float, default=6.0)
    p.add_argument("--captions"); p.add_argument("--draft", action="store_true")
    p.add_argument("--aspect", default="9:16", choices=["9:16", "4:5", "1:1", "16:9"])
    p.add_argument("--also", action="append", choices=["9:16", "4:5", "1:1", "16:9"], help="extra ratio(s) to render too")
    p.add_argument("--no-banner", action="store_true"); p.add_argument("--no-headline", action="store_true")
    p.add_argument("--prompt", help='what to clip, e.g. "every time he talks about the coin"')
    p.add_argument("--streamer", help="lore profile to use")
    p.set_defaults(f=cmd_autoclip)
    p = sp.add_parser("titles"); p.add_argument("clip_json"); p.set_defaults(f=cmd_titles)
    p = sp.add_parser("thumbnail"); p.add_argument("video"); p.add_argument("--text"); p.add_argument("--emoji")
    p.add_argument("--arrow", action="store_true"); p.add_argument("--circle", action="store_true"); p.set_defaults(f=cmd_thumbnail)
    p = sp.add_parser("font"); p.add_argument("action", choices=["add", "list"]); p.add_argument("files", nargs="*")
    p.set_defaults(f=cmd_font)
    p = sp.add_parser("editor"); p.add_argument("--root"); p.add_argument("--port", type=int, default=8765)
    p.add_argument("--open", action="store_true", help="open the editor in your browser")
    p.add_argument("--host", default="127.0.0.1"); p.set_defaults(f=cmd_editor)
    p = sp.add_parser("montage"); p.add_argument("specs"); p.add_argument("out")
    p.add_argument("--workdir", default="/tmp/clipbot_work/montage"); p.add_argument("--intro")
    p.add_argument("--outro"); p.add_argument("--no-labels", action="store_true"); p.set_defaults(f=cmd_montage)
    a = ap.parse_args()
    a.f(a)


if __name__ == "__main__":
    main()

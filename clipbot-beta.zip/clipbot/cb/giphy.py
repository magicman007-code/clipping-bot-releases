"""GIPHY search for animated stickers and GIFs.

The key lives in connections.json under "giphy" (Settings -> Connections). Search results are shown straight from
GIPHY's CDN in the editor; the GIF the user picks is downloaded into <project>/assets/ so renders work offline and
the project keeps working if the GIF is later removed from GIPHY.
"""
import json
import os
import re
import urllib.error
import urllib.parse
import urllib.request

API = "https://api.giphy.com"
MAX_BYTES = 15 * 1024 * 1024          # GIPHY originals can be huge; we pick a smaller rendition when one exists
_ID = re.compile(r"^[A-Za-z0-9]{4,40}$")
_HOSTS = (".giphy.com",)


def key():
    from . import connect
    return ((connect.get().get("giphy") or {}).get("key") or "").strip()


def ready():
    return bool(key())


def _get(path, params, timeout=15):
    k = key()
    if not k:
        raise RuntimeError("add your GIPHY API key in Settings > Connections first (free at developers.giphy.com)")
    qs = urllib.parse.urlencode(dict(params, api_key=k))
    req = urllib.request.Request("%s/%s?%s" % (API, path if path.startswith("v2/") else "v1/" + path, qs), headers={"User-Agent": "Clipbot"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):
            raise RuntimeError("GIPHY didn't accept that API key - check it in Settings > Connections")
        if e.code == 429:
            raise RuntimeError("GIPHY's limit for this key was reached - wait a bit and try again")
        raise RuntimeError("GIPHY search failed (HTTP %d)" % e.code)
    except (urllib.error.URLError, TimeoutError, OSError):
        raise RuntimeError("couldn't reach GIPHY - check your internet connection")


def _item(g):
    im = g.get("images") or {}
    prev = im.get("fixed_width") or im.get("fixed_width_downsampled") or im.get("downsized") or {}
    still = im.get("fixed_width_still") or {}
    orig = im.get("original") or {}
    return {"id": g.get("id"), "title": (g.get("title") or "").strip()[:120],
            "preview": prev.get("webp") or prev.get("url"), "still": still.get("url"),
            "w": int(orig.get("width") or prev.get("width") or 0), "h": int(orig.get("height") or prev.get("height") or 0)}


def search(q="", kind="gifs", offset=0, limit=24, rating="pg-13"):
    """kind: gifs (full-frame GIFs), stickers (transparent background) or emoji (GIPHY's animated emoji).
    Empty q -> trending (or the emoji library)."""
    kind = kind if kind in ("stickers", "emoji") else "gifs"
    limit = max(1, min(int(limit or 24), 50))
    offset = max(0, min(int(offset or 0), 4999))
    q = (q or "").strip()[:50]
    params = {"limit": limit, "offset": offset, "rating": rating if rating in ("g", "pg", "pg-13", "r") else "pg-13"}
    if kind == "emoji":                       # the emoji library has no search: search stickers for "<q> emoji"
        j = _get("stickers/search", dict(params, q=q + " emoji", lang="en")) if q else _get("v2/emoji", params)
    elif q:
        j = _get("%s/search" % kind, dict(params, q=q, lang="en"))
    else:
        j = _get("%s/trending" % kind, params)
    items = [_item(g) for g in j.get("data") or [] if g.get("id")]
    pg = j.get("pagination") or {}
    return {"items": [i for i in items if i["preview"]], "offset": offset + len(items),
            "total": int(pg.get("total_count") or len(items)), "kind": kind, "q": q}


def _pick_rendition(images):
    """Biggest rendition that is still a reasonable size for a sticker on a 1080-wide clip."""
    for name in ("downsized_large", "original", "downsized_medium", "downsized", "fixed_width"):
        r = images.get(name) or {}
        url, size = r.get("url"), int(r.get("size") or 0)
        if url and (not size or size <= MAX_BYTES):
            return url
    return None


def fetch(gif_id, project_dir):
    """Download one GIF into <project>/assets/giphy_<id>.gif and return its path and size."""
    if not _ID.match(str(gif_id or "")):
        raise ValueError("not a GIPHY id")
    out_dir = os.path.join(project_dir, "assets")
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, "giphy_%s.gif" % gif_id)
    j = _get("gifs/%s" % gif_id, {})
    g = j.get("data") or {}
    im = g.get("images") or {}
    if os.path.exists(out) and os.path.getsize(out) > 0:
        return {"path": out, "w": int((im.get("original") or {}).get("width") or 0),
                "h": int((im.get("original") or {}).get("height") or 0), "title": g.get("title") or ""}
    url = _pick_rendition(im)
    if not url:
        raise RuntimeError("GIPHY has no downloadable version of that GIF")
    host = urllib.parse.urlparse(url).hostname or ""
    if urllib.parse.urlparse(url).scheme != "https" or not host.endswith(_HOSTS):
        raise RuntimeError("unexpected GIF address from GIPHY")
    req = urllib.request.Request(url, headers={"User-Agent": "Clipbot"})
    tmp = out + ".part"
    n = 0
    try:
        with urllib.request.urlopen(req, timeout=60) as r, open(tmp, "wb") as f:
            while True:
                b = r.read(65536)
                if not b:
                    break
                n += len(b)
                if n > MAX_BYTES * 2:
                    raise RuntimeError("that GIF is too big to use as a sticker - pick another")
                f.write(b)
        with open(tmp, "rb") as f:
            if f.read(6) not in (b"GIF87a", b"GIF89a"):
                raise RuntimeError("GIPHY sent something that isn't a GIF")
        os.replace(tmp, out)
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)
    orig = im.get("original") or {}
    return {"path": out, "w": int(orig.get("width") or 0), "h": int(orig.get("height") or 0), "title": g.get("title") or ""}

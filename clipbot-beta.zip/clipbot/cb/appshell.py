"""Clipbot as a normal app on the computer.

install()  puts a "Clipbot" app where people expect it, pointing at this folder:
             Mac      Clipbot.app in /Applications (or ~/Applications), with the Clipbot icon. It stays in the Dock
                      while Clipbot runs; Quit (Dock or Cmd+Q) stops it; clicking the Dock icon reopens the window.
             Windows  Clipbot in the Start menu and on the desktop. No black console window.
             Linux    Clipbot in the applications menu (~/.local/share/applications).
           The app is built on the computer itself (not downloaded), so the Mac doesn't ask about an
           "unidentified developer". The Clipbot folder, its updates and the projects folder don't change.
launch()   what the app runs: if Clipbot is already open, bring its window up; otherwise make the demo project the first
           time, start the editor and open it - in an app window (no tabs or address bar) when Chrome, Edge, Brave or
           Chromium is installed, else in the normal browser.
"""
import json
import os
import shutil
import subprocess
import urllib.parse
import sys
import urllib.request

from .common import ROOT, log

PORT = 8765
NAME = "Clipbot"
BUNDLE_ID = "studio.clipbot.app"
ICON_DIR = os.path.join(ROOT, "assets", "app")


def projects_root():
    return os.environ.get("CLIPBOT_PROJECTS") or os.path.join(os.path.expanduser("~"), "Clipbot")


def running(port=PORT):
    """The URL of a Clipbot editor already running on this computer, or None."""
    for p in range(port, port + 11):
        try:
            with urllib.request.urlopen("http://127.0.0.1:%d/api/ping" % p, timeout=0.6) as r:
                if json.loads(r.read().decode() or "{}").get("app") == "clipbot":
                    return "http://127.0.0.1:%d" % p
        except Exception:
            continue
    return None


# ------------------------------------------------------------------------------------------- the window
def _chromium_browsers():
    if sys.platform == "darwin":
        apps = ["Google Chrome", "Microsoft Edge", "Brave Browser", "Chromium", "Arc"]
        out = []
        for a in apps:
            for base in ("/Applications", os.path.expanduser("~/Applications")):
                exe = os.path.join(base, a + ".app", "Contents", "MacOS", a)
                if os.path.exists(exe):
                    out.append(exe)
        return out
    if os.name == "nt":
        pf = [os.environ.get(k) for k in ("PROGRAMFILES(X86)", "PROGRAMFILES", "LOCALAPPDATA")]
        rel = [r"Microsoft\Edge\Application\msedge.exe", r"Google\Chrome\Application\chrome.exe",
               r"BraveSoftware\Brave-Browser\Application\brave.exe"]
        return [os.path.join(b, r) for r in rel for b in pf if b and os.path.exists(os.path.join(b, r))]
    return [p for p in (shutil.which(n) for n in ("google-chrome", "google-chrome-stable", "chromium",
                                                  "chromium-browser", "microsoft-edge", "brave-browser")) if p]


def open_window(url):
    """Open the editor in an app window (its own window, no tabs or address bar) when a Chromium browser is
    installed; the normal browser otherwise. Set CLIPBOT_BROWSER=default to always use the normal browser."""
    if os.environ.get("CLIPBOT_BROWSER", "").lower() != "default":
        for exe in _chromium_browsers():
            if exe.endswith("/Arc"):
                continue                                   # Arc ignores --app
            try:
                kw = {"stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL}
                if os.name == "nt":
                    kw["creationflags"] = 0x00000008       # DETACHED_PROCESS
                else:
                    kw["start_new_session"] = True
                subprocess.Popen([exe, "--app=" + url, "--window-size=1440,900"], **kw)
                return exe
            except Exception:
                continue
    import webbrowser
    webbrowser.open(url)
    return "browser"


# ------------------------------------------------------------------------------------------- launching
def _quiet_windows():
    """Started without a console (pythonw): ffmpeg, yt-dlp and friends must not each flash a black window."""
    if os.name != "nt":
        return
    base = subprocess.Popen

    class NoWindow(base):
        def __init__(self, *a, **k):
            k.setdefault("creationflags", 0x08000000)          # CREATE_NO_WINDOW
            super().__init__(*a, **k)
    subprocess.Popen = NoWindow


def launch():
    if sys.stdout is None or sys.stderr is None:                # no console: keep a log instead
        root = projects_root()
        os.makedirs(root, exist_ok=True)
        f = open(os.path.join(root, "clipbot.log"), "a", buffering=1, encoding="utf-8", errors="replace")
        sys.stdout = sys.stdout or f
        sys.stderr = sys.stderr or f
    _quiet_windows()
    url = running()
    if url:
        open_window(url)
        return 0
    root = projects_root()
    os.makedirs(root, exist_ok=True)
    if not os.path.exists(os.path.join(root, "demo", "source.mp4")):
        try:
            subprocess.run([sys.executable, os.path.join(ROOT, "clipbot.py"), "demo", os.path.join(root, "demo")],
                           cwd=ROOT, timeout=600, check=False)
        except Exception as e:
            log("demo project skipped (%s)" % e)
    from . import editor_server
    editor_server.serve(root, port=PORT, open_browser=True, opener=open_window)
    return 0


# ------------------------------------------------------------------------------------------- installing
def _python():
    """The Python Clipbot was installed with (the venv), as the app should run it."""
    exe = sys.executable
    if os.name == "nt":
        w = os.path.join(os.path.dirname(exe), "pythonw.exe")   # no console window
        return w if os.path.exists(w) else exe
    return exe


def _mac_app_dir():
    for d in ("/Applications", os.path.expanduser("~/Applications")):
        try:
            os.makedirs(d, exist_ok=True)
            if os.access(d, os.W_OK):
                return d
        except OSError:
            continue
    return os.path.expanduser("~/Applications")


def _q(s):
    return "'" + str(s).replace("'", "'\\''") + "'"


def launcher_script():
    """The shell script the Mac / Linux app runs. Finder starts apps with a bare PATH, so the PATH Clipbot was
    installed with (Homebrew's ffmpeg) is written in."""
    path = os.pathsep.join(dict.fromkeys(
        ["/opt/homebrew/opt/ffmpeg-full/bin", "/usr/local/opt/ffmpeg-full/bin", "/opt/homebrew/bin", "/usr/local/bin"] +
        os.environ.get("PATH", "/usr/bin:/bin").split(os.pathsep)))
    log_file = os.path.join(projects_root(), "clipbot.log")
    return """#!/bin/bash
# Starts Clipbot (written by `clipbot.py app` - run it again if you move the Clipbot folder)
DIR=%s
export PATH=%s
if [ ! -f "$DIR/clipbot.py" ]; then
  osascript -e 'display alert "Clipbot can'"'"'t find its folder" message "It was moved or deleted: '"$DIR"'. Open the Clipbot folder and double-click Install Clipbot.command again."' 2>/dev/null
  exit 1
fi
cd "$DIR" || exit 1
mkdir -p %s
exec %s "$DIR/clipbot.py" launch >> %s 2>&1
""" % (_q(ROOT), _q(path), _q(projects_root()), _q(_python()), _q(log_file))


APPLESCRIPT = '''on run
	do shell script "nohup " & quoted form of "%(launch)s" & " >/dev/null 2>&1 &"
end run
on reopen
	do shell script "nohup " & quoted form of "%(launch)s" & " >/dev/null 2>&1 &"
end reopen
on quit
	try
		do shell script "curl -s -m 5 -X POST -H 'X-Clipbot: 1' -H 'Content-Type: application/json' -d '{}' http://127.0.0.1:%(port)d/api/quit"
	end try
	continue quit
end quit
'''


def install_mac():
    app = os.path.join(_mac_app_dir(), NAME + ".app")
    launch_sh = os.path.join(ROOT, ".clipbot_launch.sh")
    with open(launch_sh, "w") as f:
        f.write(launcher_script())
    os.chmod(launch_sh, 0o755)
    src = os.path.join(ROOT, ".clipbot_app.applescript")
    with open(src, "w") as f:
        f.write(APPLESCRIPT % {"launch": launch_sh.replace("\\", "\\\\").replace('"', '\\"'), "port": PORT})
    # Build in a FRESH temp dir every time. A leftover "Clipbot.app.new" from a previously interrupted install could
    # leave Contents/Resources in a broken state (ENOTDIR when copying the icon in); a clean dir avoids that entirely.
    import tempfile
    work = tempfile.mkdtemp(prefix=".clipbot-app-", dir=os.path.dirname(app))
    try:
        tmp = os.path.join(work, NAME + ".app")
        # a stay-open AppleScript applet: a real Mac app (Dock icon while open, Cmd+Q / Dock Quit, click to reopen)
        subprocess.run(["osacompile", "-s", "-o", tmp, src], check=True, capture_output=True, timeout=120)
        res = os.path.join(tmp, "Contents", "Resources")
        try:                                   # the icon is cosmetic - never let it abort the whole install
            if os.path.exists(res) and not os.path.isdir(res):
                os.remove(res)
            os.makedirs(res, exist_ok=True)
            shutil.copy(os.path.join(ICON_DIR, "clipbot.icns"), os.path.join(res, "applet.icns"))
        except OSError as e:
            log("clipbot app: custom icon skipped (%s)" % e)
        return _finish_mac_app(tmp, app)
    finally:
        shutil.rmtree(work, ignore_errors=True)


def _finish_mac_app(tmp, app):
    plist = os.path.join(tmp, "Contents", "Info.plist")
    for k, v in (("CFBundleName", NAME), ("CFBundleDisplayName", NAME), ("CFBundleIdentifier", BUNDLE_ID),
                 ("CFBundleShortVersionString", _version()), ("NSHighResolutionCapable", "true")):
        subprocess.run(["plutil", "-replace", k, "-bool" if v == "true" else "-string", v, plist],
                       capture_output=True, timeout=30)
    subprocess.run(["codesign", "--force", "--deep", "--sign", "-", tmp], capture_output=True, timeout=120)
    subprocess.run(["xattr", "-cr", tmp], capture_output=True, timeout=60)
    if os.path.islink(app) or os.path.isfile(app):     # a stale non-directory in the way
        try:
            os.remove(app)
        except OSError:
            pass
    elif os.path.isdir(app):
        shutil.rmtree(app, ignore_errors=True)
    os.replace(tmp, app)
    subprocess.run(["touch", app], capture_output=True)            # Finder / Dock pick up the new icon
    return app


DOCK_MARK = os.path.expanduser("~/.clipbot_dock_added")


def add_to_dock(app):
    """Pin Clipbot.app to the Mac Dock once. If the person later drags it out of the Dock, we never put it back."""
    if sys.platform != "darwin" or os.path.exists(DOCK_MARK):
        return False
    try:
        cur = subprocess.run(["defaults", "read", "com.apple.dock", "persistent-apps"], capture_output=True, text=True,
                             timeout=20).stdout
        if NAME + ".app" not in cur:
            url = "file://" + urllib.parse.quote(app.rstrip("/") + "/")
            tile = ("<dict><key>tile-data</key><dict><key>file-data</key><dict><key>_CFURLString</key><string>%s</string>"
                    "<key>_CFURLStringType</key><integer>15</integer></dict></dict></dict>" % url)
            subprocess.run(["defaults", "write", "com.apple.dock", "persistent-apps", "-array-add", tile],
                           capture_output=True, timeout=20, check=True)
            subprocess.run(["killall", "Dock"], capture_output=True, timeout=20)     # the Dock reloads with Clipbot in it
        open(DOCK_MARK, "w").write(_version())
        return True
    except Exception:
        return False


def install_windows():
    py = _python()
    ico = os.path.join(ICON_DIR, "clipbot.ico")
    target_args = '"%s" launch' % os.path.join(ROOT, "clipbot.py")
    places = [os.path.join(os.environ.get("APPDATA", ""), r"Microsoft\Windows\Start Menu\Programs", NAME + ".lnk")]
    desktop = os.path.join(os.path.expanduser("~"), "Desktop")
    if os.path.isdir(desktop):
        places.append(os.path.join(desktop, NAME + ".lnk"))
    made = []
    for lnk in places:
        ps = ("$s=(New-Object -ComObject WScript.Shell).CreateShortcut('{lnk}');$s.TargetPath='{py}';"
              "$s.Arguments='{args}';$s.WorkingDirectory='{root}';$s.IconLocation='{ico}';"
              "$s.Description='Clipbot Studio';$s.Save()").format(
            lnk=lnk.replace("'", "''"), py=py.replace("'", "''"), args=target_args.replace("'", "''"),
            root=ROOT.replace("'", "''"), ico=ico.replace("'", "''"))
        r = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps],
                           capture_output=True, text=True, timeout=60)
        if r.returncode == 0 and os.path.exists(lnk):
            made.append(lnk)
    return made


def install_linux():
    d = os.path.join(os.path.expanduser("~"), ".local", "share", "applications")
    os.makedirs(d, exist_ok=True)
    launch_sh = os.path.join(ROOT, ".clipbot_launch.sh")
    with open(launch_sh, "w") as f:
        f.write(launcher_script().replace("osascript", "true"))
    os.chmod(launch_sh, 0o755)
    p = os.path.join(d, "clipbot.desktop")
    with open(p, "w") as f:
        f.write("[Desktop Entry]\nType=Application\nName=Clipbot\nComment=Clipbot Studio\nExec=%s\nIcon=%s\n"
                "Terminal=false\nCategories=AudioVideo;Video;\nStartupNotify=true\n"
                % (launch_sh, os.path.join(ICON_DIR, "clipbot.png")))
    os.chmod(p, 0o755)
    return p


def _version():
    try:
        return open(os.path.join(ROOT, "VERSION")).read().strip()
    except Exception:
        return "1.0"


def install():
    """-> {"ok", "where", "how"} - never raises: the app shortcut is a convenience, Clipbot still runs without it."""
    try:
        if sys.platform == "darwin":
            app = install_mac()
            docked = add_to_dock(app)
            return {"ok": True, "where": app, "dock": docked,
                    "how": "Clipbot is in your %s folder%s. Open it from there, Launchpad or Spotlight (Cmd+Space, "
                           "type Clipbot)." % (os.path.basename(os.path.dirname(app)), " and in your Dock" if docked else "")}
        if os.name == "nt":
            made = install_windows()
            return {"ok": bool(made), "where": made,
                    "how": "Clipbot is in the Start menu and on your desktop." if made else "couldn't make the shortcuts"}
        p = install_linux()
        return {"ok": True, "where": p, "how": "Clipbot is in your applications menu."}
    except Exception as e:
        return {"ok": False, "error": str(e)[:300], "how": "Start Clipbot with start.sh / start.bat instead."}


def installed():
    if sys.platform == "darwin":
        return any(os.path.exists(os.path.join(d, NAME + ".app")) for d in ("/Applications", os.path.expanduser("~/Applications")))
    if os.name == "nt":
        return os.path.exists(os.path.join(os.environ.get("APPDATA", ""), r"Microsoft\Windows\Start Menu\Programs", NAME + ".lnk"))
    return os.path.exists(os.path.join(os.path.expanduser("~"), ".local", "share", "applications", "clipbot.desktop"))

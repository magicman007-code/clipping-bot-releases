"""Beta helpers: doctor (environment check), demo project, import, bug report."""
import glob
import json
import os
import platform
import shutil
import socket
import subprocess
import sys
import time
import zipfile

import numpy as np

from .common import safe_remove, FONT_DIR, ROOT, ffmpeg, load_config, probe

DEMO_LINES = [
    (2, "so um yeah you know we are just looking at the chart here okay."),
    (8, "okay so basically the market cap here is fine you know."),
    (14, "So one time I aped into this coin at a hundred K market cap."),
    (19, "I put twelve thousand dollars in, half my wallet."),
    (23.5, "But the dev sold everything and it got rugged."),
    (28, "Then my friend texts me, bro, I bought the top for you."),
    (32.5, "No way. I'm dead. That was hilarious."),
    (38, "okay so um yeah let's scroll down you know basically."),
    (44, "Wait, did that just hit ten million? Oh my god."),
    (48.5, "I bought this at two hundred K, that's a 50x."),
    (53, "Turns out the whale was buying the whole time."),
    (57, "Let's go! We actually won, we did it!"),
]


def doctor():
    rep, ok = {}, True

    def chk(name, cond, detail="", fix=""):
        nonlocal ok
        rep[name] = {"ok": bool(cond), "detail": detail}
        if fix and not cond:
            rep[name]["fix"] = fix
        ok = ok and bool(cond)
    chk("python", sys.version_info >= (3, 9), platform.python_version(), "install Python 3.9+")
    ff = shutil.which("ffmpeg")
    ver = subprocess.run(["ffmpeg", "-version"], capture_output=True, text=True).stdout.split("\n")[0] if ff else ""
    chk("ffmpeg", bool(ff), ver, "macOS: brew install ffmpeg · Windows: winget install Gyan.FFmpeg · Linux: apt install ffmpeg")
    if ff:
        filt = subprocess.run(["ffmpeg", "-hide_banner", "-filters"], capture_output=True, text=True).stdout
        need = ["ass", "loudnorm", "xfade", "rgbashift", "sidechaincompress", "drawtext", "zoompan"]
        missing = [f for f in need if (" %s " % f) not in filt]
        chk("ffmpeg filters", not missing, "missing: %s" % missing if missing else "all present",
            "install a full ffmpeg build (with libass + freetype)")
    for mod, pkg in (("numpy", "numpy"), ("cv2", "opencv-python-headless"), ("faster_whisper", "faster-whisper"),
                     ("yt_dlp", "yt-dlp"), ("PIL", "pillow")):
        try:
            __import__(mod)
            chk(pkg, True, "ok")
        except Exception as e:
            chk(pkg, False, str(e)[:80], "pip install %s" % pkg)
    fonts = [f for f in ("Anton-Regular.ttf", "Montserrat-Black.ttf") if os.path.exists(os.path.join(FONT_DIR, f))]
    chk("fonts", len(fonts) == 2, "%s in %s" % (fonts, FONT_DIR), "python clipbot.py setup")
    chk("face model", os.path.exists(os.path.join(ROOT, "models", "yunet.onnx")), "models/yunet.onnx")
    cache = os.path.expanduser("~/.cache/huggingface/hub")
    models = [os.path.basename(p) for p in glob.glob(os.path.join(cache, "models--Systran--faster-whisper-*"))]
    rep["whisper models cached"] = {"ok": True, "detail": models or "none yet - downloads automatically on first transcribe (~150-500MB)"}
    for host in ("huggingface.co", "www.youtube.com"):
        try:
            socket.create_connection((host, 443), timeout=5).close()
            rep["network " + host] = {"ok": True, "detail": "reachable"}
        except Exception as e:
            rep["network " + host] = {"ok": True, "warning": True, "detail": "not reachable: " + str(e)[:60],
                                      "fix": "needed for model download / YouTube links; local files still work"}
    cfg = load_config()
    root = cfg["work_root"] if os.access(os.path.dirname(cfg["work_root"]) or "/", os.W_OK) else os.path.expanduser("~/Clipbot")
    try:
        free = shutil.disk_usage(os.path.expanduser("~")).free / 1e9
        rep["disk space"] = {"ok": free > 2, "warning": free <= 20, "detail": "%.0f GB free" % free,
                             "fix": "renders + long VODs need room (20GB+ recommended)"}
        ok = ok and free > 2
    except Exception:
        pass
    rep["work_root"] = {"ok": True, "detail": root}
    print(json.dumps({"ready": ok, "checks": rep}, indent=1))
    return ok


def _speechy_audio(path, dur, lines, workdir):
    """Pitched syllable bursts timed to the script words, louder on the payoff lines."""
    sr = 24000
    t = np.arange(int(dur * sr)) / sr
    y = 0.01 * np.random.RandomState(0).randn(len(t))
    for start, text in lines:
        loud = 2.2 if any(k in text.lower() for k in ("no way", "dead", "50x", "won", "oh my god")) else 1.0
        for i, w in enumerate(text.split()):
            a = start + i * 0.38
            n = int(0.3 * sr)
            i0 = int(a * sr)
            tt = np.arange(n) / sr
            f0 = 140 + 30 * np.sin(i)
            syl = (np.sin(2 * np.pi * f0 * tt) + 0.5 * np.sin(2 * np.pi * 2 * f0 * tt) + 0.25 * np.sin(2 * np.pi * 3 * f0 * tt))
            syl *= np.sin(np.pi * tt / 0.3) ** 2 * 0.12 * loud
            y[i0:i0 + n] += syl[: max(0, len(y) - i0)]
    y = np.clip(y, -1, 1)
    import wave
    w = wave.open(path, "wb")
    w.setnchannels(1)
    w.setsampwidth(2)
    w.setframerate(sr)
    w.writeframes((y * 32767).astype(np.int16).tobytes())
    w.close()


def demo(dest):
    """A 64s demo 'stream' with a real face photo, a script with filler and two stories, a matching
    transcript, candidate moments, two starter clips and a montage brief - try every feature offline."""
    os.makedirs(dest, exist_ok=True)
    face = os.path.join(ROOT, "assets", "demo", "face.png")
    words, script = [], DEMO_LINES
    for start, text in script:
        for i, w in enumerate(text.split()):
            words.append([round(start + i * 0.38, 2), round(start + i * 0.38 + 0.3, 2), w, 0.95])
    wav = os.path.join(dest, "_voice.wav")
    _speechy_audio(wav, 64, script, dest)
    src = os.path.join(dest, "source.mp4")
    # slow drift so the face-follow crop has something to do
    ffmpeg(["-loop", "1", "-framerate", "30", "-i", face, "-i", wav, "-f", "lavfi", "-i",
            "color=c=0x2a2f3a:s=1920x1080:r=30", "-filter_complex",
            "[0:v]scale=900:900[f];[2:v][f]overlay=x='510+300*sin(t/6)':y=90:shortest=1,format=yuv420p[v]",
            "-map", "[v]", "-map", "1:a", "-t", "64", "-c:v", "libx264", "-preset", "veryfast", "-crf", "22",
            "-c:a", "aac", "-shortest", src])
    safe_remove(wav)
    json.dump(words, open(os.path.join(dest, "words.json"), "w"))
    from .moments import find_candidates, write_candidates
    from .transcribe import write_readables
    write_readables(words, dest)
    c = find_candidates(words, src, dest, niche=("crypto",), top_k=6)
    write_candidates(c, dest, "demo")
    specs = [{"name": "01_rugged", "source": src, "start": 14.0, "end": 35.5, "segments": [[14.0, 35.5]],
              "headline": "He aped $12K into a coin and the dev rugged it", "captions": "karaoke", "layout": "auto"},
             {"name": "02_the_50x", "source": src, "start": 44.0, "end": 60.5, "segments": [[44.0, 60.5]],
              "headline": "He bought at $200K and it hit $10M", "captions": "box", "accent": "green", "teaser": "auto"}]
    json.dump(specs, open(os.path.join(dest, "specs.json"), "w"), indent=1)
    music = os.path.join(ROOT, "assets", "demo", "demo_beat_128bpm.m4a")
    json.dump({"name": "demo_edit", "profile": "hype", "duration": 20, "music": music, "intensity": 0.8,
               "title": "THE 50X", "subtitle": "demo edit",
               "moments": [{"source": src, "start": 14, "end": 36, "label": "rugged", "score": 7},
                           {"source": src, "start": 44, "end": 61, "label": "the 50x", "score": 9}]},
              open(os.path.join(dest, "montage_brief.json"), "w"), indent=1)
    print(json.dumps({"demo": dest, "source": src, "clips": [s["name"] for s in specs],
                      "candidates": len(c), "montage_brief": os.path.join(dest, "montage_brief.json")}, indent=1))
    return dest


def import_media(path, root, name=None, transcribe=True):
    """Bring a local file into the projects folder (non-destructive: the original is never touched)."""
    name = name or os.path.splitext(os.path.basename(path))[0]
    d = os.path.join(root, "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in name))
    os.makedirs(d, exist_ok=True)
    out = os.path.join(d, "source.mp4")
    pr = probe(path)
    if not pr["has_audio"]:
        print("warning: no audio track - captions/moment finding will be limited", file=sys.stderr)
    try:   # remux when possible (fast, lossless); re-encode only if the codecs need it
        ffmpeg(["-i", path, "-map", "0:v:0", "-map", "0:a:0?", "-c", "copy", "-movflags", "+faststart", out])
    except Exception:
        ffmpeg(["-i", path, "-map", "0:v:0", "-map", "0:a:0?", "-vf", "fps=30", "-c:v", "libx264", "-preset", "veryfast",
                "-crf", "18", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", out], timeout=7200)
    res = {"project": d, "source": out, "duration": round(probe(out)["duration"], 1)}
    if transcribe:
        from .transcribe import transcribe_video
        words = transcribe_video(out, d, load_config()["whisper_model"], load_config().get("vocab"))
        from .moments import find_candidates, write_candidates
        write_candidates(find_candidates(words, out, d, top_k=12), d)
        res["words"] = len(words)
    print(json.dumps(res, indent=1))
    return res


def bug_report(root, out=None):
    """Zip logs/specs/QC/results (no media) for a tester to send."""
    out = out or os.path.join(os.path.expanduser("~"), "clipbot_bugreport_%s.zip" % time.strftime("%Y%m%d_%H%M%S"))
    keep = ("specs.json", "qc.json", "events.jsonl", "live_status.json", "candidates.md", ".result.json", ".plan.json")
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("environment.txt", "%s\n%s\npython %s\n" % (platform.platform(), sys.executable, platform.python_version()))
        for p in glob.glob(os.path.join(root, "**", "*"), recursive=True):
            if os.path.isfile(p) and (p.endswith(keep) or (p.endswith(".json") and "/renders/" in p)) \
                    and os.path.getsize(p) < 5e6:
                z.write(p, os.path.relpath(p, root))
    print(out)
    return out

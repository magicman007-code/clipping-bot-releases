"""Category Watch: clip the best moments across all the top live streams of a game at once.

`plan()` discovers the top live streams for a game (via cb/discover), de-duplicates them and caps the
count. The editor server then starts one live clipper per stream. This is the thing cloud clip tools
can't do: during a big launch (GTA 6), point it at the category and it clips every top stream live,
in parallel, into the QC inbox. Pure orchestration here so it's testable without the network."""
from . import discover


def plan(game=discover.DEFAULT_GAME, platforms=("twitch", "kick"), limit=5, find=None):
    """Pick the top `limit` distinct live streams for a game. Returns {game, streams, errors}.
    `find` is injectable for tests; defaults to discover.find_streams."""
    find = find or discover.find_streams
    limit = max(1, min(int(limit), 20))
    r = find(game, platforms=tuple(platforms), limit=max(limit * 3, limit)) or {}
    seen, picks = set(), []
    for s in (r.get("streams") or []):
        url = s.get("url")
        if not url or url in seen:
            continue
        seen.add(url)
        picks.append(s)
        if len(picks) >= limit:
            break
    return {"game": r.get("game", game), "streams": picks, "errors": r.get("errors") or {}}

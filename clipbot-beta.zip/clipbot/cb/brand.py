"""Brand kit: set your colours, caption look and logo once, and every clip comes out branded.

Stored in config under "brand" (Settings -> Brand kit). When "enabled" is on, these values become the default for every
render; anything set on an individual clip still wins over them. The logo is any PNG/JPG the user uploads; it's composited
as a persistent overlay in a corner, on top of captions and banner. Nothing here changes a clip the user has hand-styled.
"""
import os

CORNERS = {"tl", "tr", "bl", "br"}
# brand look keys -> the keys build_ass()'s `look` dict understands
LOOK_KEYS = ("color", "outline_color", "outline", "shadow", "bold", "italic", "spacing",
             "headline_font", "headline_color", "headline_bg")


def active(cfg):
    """The brand dict if the kit is turned on, else {} (so nothing is applied)."""
    b = (cfg or {}).get("brand") or {}
    return b if b.get("enabled") else {}


def look_defaults(brand):
    """Brand values for build_ass()'s `look`, so a clip that doesn't set its own inherits the brand's."""
    return {k: brand[k] for k in LOOK_KEYS if brand.get(k) not in (None, "")}


def logo_path(brand):
    p = (brand or {}).get("logo")
    return p if p and os.path.exists(p) else None


def logo_overlay(brand, input_index, OW, OH):
    """ffmpeg pieces to put the brand logo in a corner. Returns (input_args, prep_filter, overlay_expr) or None.

    input_index is the ffmpeg input number the logo will be; prep scales it and sets its opacity; overlay_expr places it
    with a margin from the chosen corner (default bottom-right, the least intrusive spot for a watermark)."""
    path = logo_path(brand)
    if not path:
        return None
    try:
        size = float(brand.get("logo_size", 14)) / 100.0        # % of the video width
    except (TypeError, ValueError):
        size = 0.14
    size = max(0.04, min(size, 0.5))
    try:
        op = float(brand.get("logo_opacity", 90)) / 100.0
    except (TypeError, ValueError):
        op = 0.9
    op = max(0.1, min(op, 1.0))
    corner = brand.get("logo_pos") if brand.get("logo_pos") in CORNERS else "br"
    m = max(12, int(OW * 0.03))                                 # margin from the edge
    lw = int(OW * size) // 2 * 2
    x = ("%d" % m) if corner in ("tl", "bl") else "W-w-%d" % m
    y = ("%d" % m) if corner in ("tl", "tr") else "H-h-%d" % m
    args = ["-loop", "1", "-i", path]
    prep = ("[%d:v]scale=%d:-1:force_original_aspect_ratio=decrease,format=rgba,"
            "colorchannelmixer=aa=%.2f[logo]" % (input_index, lw, op))
    return args, prep, "overlay=%s:%s:format=auto" % (x, y)

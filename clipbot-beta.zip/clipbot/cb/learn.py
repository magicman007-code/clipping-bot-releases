"""Learning from what people do with clips.

Every clip Clipbot suggests carries its features (moment types, length, score parts...). We then watch what
happens to it - all locally, in <work_root>/_learning/events.jsonl:
  auto_clip    Clipbot made it                                      (baseline)
  rendered     the user rendered a final version in the editor      (kept; how much they trimmed/changed it)
  rated        thumbs up/down + reasons ("slow start", "cut too early", ...)
  deleted      the user deleted an AI clip                          (rejected)
  performance  views they typed in after posting                    (the real outcome)
From these, learned() works out which moment types this user keeps vs throws away, whether they keep extending
or trimming the ends, and what they complain about - and turns that into gentle scoring adjustments
(only after enough labelled clips, capped so it can't run away).

Reports (opt-in, Connections -> "Help improve Clipbot"): the summary plus anonymised events - numbers and
moment types only; no video, file names, paths or transcript text unless the user also ticks "include clip text".
They go to the feedback URL the publisher set (e.g. a Google Sheet - see FEEDBACK.md).
"""
import hashlib
import json
import os
import threading
import time
import uuid

import numpy as np

from .common import load_config, log

TAGS = ("humor", "drama", "shock", "story", "stakes", "niche", "events", "lore", "reaction", "rage", "awkward", "burst", "chat")
REASONS = {
    "slow_start": "slow start",
    "cut_early": "ends too early",
    "too_long": "too long",
    "wrong_moment": "wrong moment",
    "not_funny": "not funny / boring",
    "bad_framing": "bad framing",
    "caption_errors": "caption mistakes",
    "great_hook": "great hook",
    "great_payoff": "great payoff",
}
MIN_LABELLED = 8
_LOCK = threading.Lock()


def _dir():
    d = os.path.join(load_config()["work_root"], "_learning")
    os.makedirs(d, exist_ok=True)
    return d


def install_id():
    p = os.path.join(_dir(), "install.json")
    try:
        return json.load(open(p))["id"]
    except Exception:
        i = uuid.uuid4().hex[:16]
        json.dump({"id": i, "created": time.strftime("%Y-%m-%d")}, open(p, "w"))
        return i


def clip_key(project_dir, name):
    return hashlib.sha1(("%s|%s" % (os.path.basename(os.path.normpath(project_dir or "")), name)).encode()).hexdigest()[:12]


def features(spec):
    """What we know about a clip, without any personal content."""
    c = spec.get("candidate") or {}
    tags = c.get("tags") or {}
    q = spec.get("quality") or {}
    f = {"tags": sorted(k for k in TAGS if tags.get(k)), "dur": round(float(spec.get("end", 0)) - float(spec.get("start", 0)), 1),
         "aspect": spec.get("aspect") or "9:16", "layout": spec.get("layout") or "auto",
         "captions": spec.get("captions") or "pro", "headline": bool(spec.get("headline")),
         "origin": spec.get("origin") or ("auto" if c else "manual"), "prompt": bool((spec.get("match") or {}).get("prompt")),
         "score": q.get("score") if isinstance(q, dict) else spec.get("quality_score"),
         "parts": (q.get("parts") if isinstance(q, dict) else None), "style_sim": c.get("style_sim"),
         "payoff_mag": c.get("payoff_mag"), "novelty": c.get("novelty")}
    for k_ in ("ai_score", "ext_score", "chat_z"):
        if c.get(k_) is not None:
            f[k_] = c[k_]
    o = spec.get("orig")
    if o and len(o) == 2:
        f["start_delta"] = round(float(spec.get("start", 0)) - float(o[0]), 2)
        f["end_delta"] = round(float(spec.get("end", 0)) - float(o[1]), 2)
    if spec.get("headline_orig") is not None:
        f["headline_edited"] = (spec.get("headline") or "") != spec["headline_orig"]
    return f


def record(kind, spec=None, project_dir=None, **extra):
    """Append one learning event. Never raises (learning must never break clipping)."""
    try:
        ev = {"t": round(time.time()), "kind": kind, "v": _version()}
        if spec is not None:
            ev["clip"] = clip_key(project_dir, spec.get("name", ""))
            ev["f"] = features(spec)
            ev["_text"] = " ".join(t for _, t in (spec.get("candidate") or {}).get("sentences", []))[:600] or None
        ev.update({k: v for k, v in extra.items() if v is not None})
        with _LOCK, open(os.path.join(_dir(), "events.jsonl"), "a") as fh:
            fh.write(json.dumps(ev) + "\n")
        return ev
    except Exception as e:
        log("learning event skipped: %s" % e)
        return None


def events():
    p = os.path.join(_dir(), "events.jsonl")
    out = []
    if os.path.exists(p):
        for line in open(p):
            try:
                out.append(json.loads(line))
            except ValueError:
                continue
    return out


def _version():
    try:
        from .updater import current_version
        return current_version()
    except Exception:
        return "?"


# ------------------------------------------------------------------ learn
def learned(evs=None):
    """Summary + adjustments. Labels per clip (latest wins): good = thumbs up, posted views above this user's
    median, or rendered in the editor (weaker); bad = thumbs down or deleted."""
    evs = evs if evs is not None else events()
    clips, views = {}, []
    for e in evs:
        k = e.get("clip")
        if not k:
            continue
        c = clips.setdefault(k, {"f": e.get("f") or {}, "label": None, "w": 0.0, "reasons": []})
        if e.get("f"):
            c["f"] = e["f"]
        if e["kind"] == "rated":
            c["label"], c["w"] = (1 if e.get("rating", 0) > 0 else 0), 1.0
            c["reasons"] = e.get("reasons") or []
        elif e["kind"] == "deleted" and c["w"] < 1.0:
            c["label"], c["w"] = 0, 0.8
        elif e["kind"] == "rendered" and c["w"] < 0.6:
            c["label"], c["w"] = 1, 0.5
        elif e["kind"] == "performance" and e.get("views") is not None:
            c["views"] = float(e["views"])
            views.append(float(e["views"]))
    if views:
        med = float(np.median(views))
        for c in clips.values():
            if "views" in c:
                c["label"], c["w"] = (1 if c["views"] >= med else 0), 1.2
    lab = [c for c in clips.values() if c["label"] is not None]
    n = len(lab)
    good = sum(c["w"] * c["label"] for c in lab)
    tot = sum(c["w"] for c in lab) or 1.0
    base = (good + 1) / (tot + 2)
    tag_stats, weights = {}, {}
    for t in TAGS:
        with_t = [c for c in lab if t in (c["f"].get("tags") or [])]
        if not with_t:
            continue
        g = sum(c["w"] * c["label"] for c in with_t)
        w = sum(c["w"] for c in with_t)
        rate = (g + base * 2) / (w + 2)                      # smoothed toward the overall keep rate
        lift = rate / base
        tag_stats[t] = {"clips": len(with_t), "keep_rate": round(rate, 2), "lift": round(lift, 2)}
        if n >= MIN_LABELLED and len(with_t) >= 3:
            weights[t] = round(float(np.clip(lift ** 0.7, 0.8, 1.35)), 2)
    rend = [e["f"] for e in evs if e["kind"] == "rendered" and e.get("f") and "end_delta" in e["f"]]
    ends = [f["end_delta"] for f in rend if abs(f["end_delta"]) < 20]
    starts = [f["start_delta"] for f in rend if abs(f["start_delta"]) < 20]
    trim = {"end": round(float(np.median(ends)), 1) if len(ends) >= 5 else 0.0,
            "start": round(float(np.median(starts)), 1) if len(starts) >= 5 else 0.0, "samples": len(ends)}
    reasons = {}
    for c in lab:
        for r in c["reasons"]:
            reasons[r] = reasons.get(r, 0) + 1
    adj = {"kind_w": weights, "len_shift": 0.0, "hook_boost": 1.0}
    if abs(trim["end"] - trim["start"]) >= 1.5:
        adj["len_shift"] = round(float(np.clip(trim["end"] - trim["start"], -10, 10)), 1)
    if reasons.get("cut_early", 0) >= 3:
        adj["len_shift"] = max(adj["len_shift"], 3.0)
    if reasons.get("too_long", 0) >= 3:
        adj["len_shift"] = min(adj["len_shift"], -4.0)
    if reasons.get("slow_start", 0) >= 3:
        adj["hook_boost"] = 1.3
    return {"labelled": n, "clips_seen": len(clips), "keep_rate": round(base, 2), "tags": tag_stats, "trim": trim,
            "reasons": dict(sorted(reasons.items(), key=lambda kv: -kv[1])), "adjust": adj,
            "active": n >= MIN_LABELLED, "needs": max(0, MIN_LABELLED - n), "ai": _ai_stats(lab, base),
            "scorer": _ai_stats(lab, base, "ext_score")}


AI_HIGH = 7.0
AI_MIN = 8          # labelled clips with an AI score before its weight moves


def _ai_stats(lab, base, field="ai_score"):
    """Does the AI's (or outside scorer's) opinion match what this user keeps? -> how much it counts (ai_rank.py)."""
    from .ai_rank import DEFAULT_W
    sc = [c for c in lab if (c["f"] or {}).get(field) is not None]
    out = {"clips": len(sc), "weight": DEFAULT_W}
    if not sc:
        return out
    hi = [c for c in sc if c["f"][field] >= AI_HIGH]
    lo = [c for c in sc if c["f"][field] < AI_HIGH]

    def rate(g):
        return (sum(c["w"] * c["label"] for c in g) + base * 2) / (sum(c["w"] for c in g) + 2)
    out["keep_high"], out["keep_low"] = round(rate(hi), 2), round(rate(lo), 2)
    out["high"], out["low"] = len(hi), len(lo)
    if len(sc) >= AI_MIN and hi and lo:
        edge = out["keep_high"] - out["keep_low"]           # >0: the AI's favourites really are kept more
        out["weight"] = round(float(np.clip(DEFAULT_W + edge, 0.15, 0.7)), 2)
    return out


def insights(L=None):
    """Plain-English lines for the editor's 'What Clipbot has learned' panel."""
    L = L or learned()
    out = []
    if not L["labelled"]:
        return ["Nothing yet. Rate clips with 👍 / 👎 (or render, delete, or enter views) and Clipbot learns what you keep."]
    out.append("Learned from %d clip%s you kept, rated or deleted (you keep about %d%%)."
               % (L["labelled"], "" if L["labelled"] == 1 else "s", round(100 * L["keep_rate"])))
    names = {"reaction": "big reactions", "rage": "rage", "awkward": "awkward moments", "humor": "jokes", "drama": "drama",
             "shock": "shock moments", "story": "stories", "stakes": "money/stakes", "events": "subs & donations",
             "lore": "lore callbacks", "burst": "loud outbursts", "niche": "niche talk", "chat": "chat explosions"}
    ranked = sorted(((t, s) for t, s in L["tags"].items() if s["clips"] >= 3), key=lambda kv: -kv[1]["lift"])
    if ranked and ranked[0][1]["lift"] >= 1.15:
        out.append("You keep %s more than average (%.1f×)." % (names.get(ranked[0][0], ranked[0][0]), ranked[0][1]["lift"]))
    if ranked and ranked[-1][1]["lift"] <= 0.85:
        out.append("You often drop %s (%.1f×)." % (names.get(ranked[-1][0], ranked[-1][0]), ranked[-1][1]["lift"]))
    if L["trim"]["samples"] >= 5 and abs(L["trim"]["end"]) >= 1:
        out.append("You usually %s the ending by %.1f s." % ("extend" if L["trim"]["end"] > 0 else "cut", abs(L["trim"]["end"])))
    bad = [(k, v) for k, v in L["reasons"].items() if not k.startswith("great_")]
    good = [(k, v) for k, v in L["reasons"].items() if k.startswith("great_")]
    if bad:
        out.append("Most common complaint: \"%s\" (%d×)." % (REASONS.get(bad[0][0], bad[0][0]), bad[0][1]))
    if good:
        out.append("Most common praise: \"%s\" (%d×)." % (REASONS.get(good[0][0], good[0][0]), good[0][1]))
    ai = L.get("ai") or {}
    if ai.get("high") and ai.get("low") and ai.get("clips", 0) >= AI_MIN:
        out.append("Clips your AI rated highly: you keep %d%% (vs %d%% of the rest), so its opinion counts %d%% in ranking."
                   % (round(100 * ai["keep_high"]), round(100 * ai["keep_low"]), round(100 * ai["weight"])))
    a = L["adjust"]
    if L["active"]:
        bits = []
        if a["kind_w"]:
            bits.append("re-weighting moment types")
        if a["len_shift"]:
            bits.append("making clips %.0f s %s" % (abs(a["len_shift"]), "longer" if a["len_shift"] > 0 else "shorter"))
        if a["hook_boost"] > 1:
            bits.append("favouring stronger openings")
        out.append("Now applied to new clips: %s." % (", ".join(bits) if bits else "no changes needed yet"))
    else:
        out.append("Starts adjusting after %d more labelled clip%s." % (L["needs"], "" if L["needs"] == 1 else "s"))
    return out


def adjustments():
    """For autoclip: {'kind_w': {...}, 'len_shift': s, 'hook_boost': x} once there's enough data, else {}."""
    try:
        L = learned()
        return L["adjust"] if L["active"] else {}
    except Exception:
        return {}


# ------------------------------------------------------------------ reports to the publisher (opt-in)
def build_report(include_text=False, since=0):
    evs = [e for e in events() if e.get("t", 0) > since]
    clean = []
    for e in evs:
        e = dict(e)
        if not include_text:
            e.pop("_text", None)
        clean.append(e)
    return {"app": "clipbot", "version": _version(), "install": install_id(), "sent": int(time.time()),
            "summary": learned(), "events": clean[-500:]}


def send_report(force=False):
    """POST the report to the feedback URL if the user opted in. Returns a status dict."""
    from .connect import get
    fb = get().get("feedback") or {}
    if not fb.get("enabled") or not fb.get("url"):
        return {"sent": False, "why": "reporting is off"}
    st_p = os.path.join(_dir(), "sent.json")
    try:
        st = json.load(open(st_p))
    except Exception:
        st = {"last": 0}
    if not force and time.time() - st.get("last", 0) < 6 * 3600:
        return {"sent": False, "why": "sent recently"}
    rep = build_report(include_text=bool(fb.get("include_text")), since=st.get("last_event", 0))
    if not rep["events"] and not force:
        return {"sent": False, "why": "nothing new"}
    import urllib.request
    try:
        req = urllib.request.Request(fb["url"], data=json.dumps(rep).encode(), method="POST",
                                     headers={"Content-Type": "application/json", "User-Agent": "clipbot"})
        urllib.request.urlopen(req, timeout=20).read(2000)
    except Exception as e:
        return {"sent": False, "why": "couldn't reach the feedback link: %s" % str(e)[:120]}
    st = {"last": time.time(), "last_event": max([e.get("t", 0) for e in rep["events"]] or [st.get("last_event", 0)])}
    json.dump(st, open(st_p, "w"))
    return {"sent": True, "events": len(rep["events"])}


def send_async():
    threading.Thread(target=send_report, daemon=True).start()

"""Written posts from a stream: everything a creator types after streaming, drafted from what was actually said.

make(d, kinds=None, use_ai=True, handle="", url="") -> {"items": [{"kind", "title", "text"}], "source", "dropped"}
  recap     stream recap / show notes: summary, timestamps of the best moments, best quotes
  youtube   a YouTube description with chapters (timestamps YouTube turns into chapters) and hashtags
  thread    an X / Threads thread: hook, one post per moment (each under 280 characters), follow
  linkedin  a LinkedIn post: hook, three takeaways in the streamer's words, a question
  blog      a blog / newsletter draft: intro, one section per moment with its quote
Without an AI everything is built from the moments and real quotes. With an AI connected, it writes the summary and
the intros; every AI sentence is checked against the transcript (numbers, outcomes, names) and dropped if it isn't
supported - the drops are counted in "dropped".
"""
import json
import os
import re

from .common import load_store, log, save_json

KINDS = ("recap", "youtube", "thread", "linkedin", "blog")
NAMES = {"recap": "Stream recap / show notes", "youtube": "YouTube description", "thread": "X / Threads thread",
         "linkedin": "LinkedIn post", "blog": "Blog / newsletter draft"}


def ts(t):
    t = int(max(0, t))
    return "%d:%02d:%02d" % (t // 3600, t % 3600 // 60, t % 60) if t >= 3600 else "%d:%02d" % (t // 60, t % 60)


def _moments(d, n=8):
    from .carousel import _moments as cm, _best_quote
    sents = load_store(os.path.join(d, "sentences.json"), [], list)
    if not sents:
        raise RuntimeError("This project has no transcript yet. Auto-clip it first.")
    out = []
    for m in cm(d, n):
        q = _best_quote(sents, m["a"], m["b"])
        if not q:
            continue
        head = m["heading"] or _short(q[0])
        out.append({"t": m["a"], "heading": head, "quote": q[0]})
    out.sort(key=lambda x: x["t"])
    return out, sents


def _short(q, n=14):
    """A heading from a quote: its first sentence if short, else up to a comma, else the first words."""
    first = re.split(r"(?<=[.!?])\s+", q.strip())[0].rstrip(".!?")
    w = first.split()
    if len(w) <= n:
        return first
    cut = " ".join(w[:n])
    if "," in cut and len(cut.rsplit(",", 1)[0].split()) >= 4:
        return cut.rsplit(",", 1)[0]
    return cut + "…"


def _names_ok(sentence, text):
    """Capitalised words (names, places, brands) that aren't at the start of the sentence must be in the transcript."""
    low = text.lower()
    for w in re.findall(r"(?<!^)(?<![.!?]\s)\b([A-Z][a-zA-Z0-9']{2,})\b", sentence.strip()):
        if w.lower() not in low and w not in ("I'm", "I've", "I'll", "YouTube", "Twitch", "Kick", "TikTok", "Instagram", "LinkedIn"):
            return False
    return True


def checked(text, full):
    """Keep only the sentences of an AI text that the transcript supports. -> (kept text, n dropped)"""
    from .packaging import _supported
    keep, drop = [], 0
    for s in re.split(r"(?<=[.!?])\s+", (text or "").strip()):
        if not s:
            continue
        if _supported(s, full)[0] and _names_ok(s, full):
            keep.append(s)
        else:
            drop += 1
    return " ".join(keep), drop


def _hashtags(full, extra=()):
    base = ["#stream", "#streamer", "#clips"]
    words = re.findall(r"\b([a-z]{5,})\b", full.lower())
    topics = [w for w in ("crypto", "gaming", "casino", "slots", "podcast", "trading", "football", "basketball",
                          "music", "comedy") if w in words]
    return " ".join(["#" + t for t in topics[:3]] + base + list(extra))


def make(d, kinds=None, use_ai=True, handle="", url=""):
    kinds = [k for k in (kinds or KINDS) if k in KINDS] or list(KINDS)
    ms, sents = _moments(d)
    if not ms:
        raise RuntimeError("Couldn't find moments to write about in this stream.")
    full = " ".join(s["text"] for s in sents)
    specs = load_store(os.path.join(d, "specs.json"), [], list)
    title = (specs[0].get("headline") if specs else "") or ms[0]["heading"]
    summary = "Best moments from the stream: " + "; ".join(m["heading"].rstrip(".…!?") for m in ms[:3]) + "."
    intro = ""
    source, dropped = "transcript", 0
    if use_ai:
        try:
            from .connect import ai_ready, ai_complete, ai_source
            if ai_ready():
                system = ("You write posts about a livestream using ONLY what was said. No invented facts, numbers, names "
                          "or outcomes. Plain, lively English. Return JSON: {\"summary\": \"2-3 sentences\", "
                          "\"intro\": \"2 sentences to open a blog post\"}.")
                prompt = "Moments (time - what happened - quote):\n" + "\n".join(
                    "%s - %s - \"%s\"" % (ts(m["t"]), m["heading"], m["quote"]) for m in ms) + \
                    "\n\nTranscript excerpt:\n" + full[:3500]
                out = ai_complete(prompt, system=system, max_tokens=500, wait=5)
                j = json.loads(re.search(r"\{.*\}", out, re.S).group(0))
                s1, n1 = checked(j.get("summary", ""), full)
                s2, n2 = checked(j.get("intro", ""), full)
                dropped = n1 + n2
                if len(s1.split()) >= 8:
                    summary = s1
                if len(s2.split()) >= 8:
                    intro = s2
                source = ai_source() or "ai"
        except Exception as e:
            log("write-ups AI skipped (%s)" % str(e)[:100])
    tags = _hashtags(full)
    who = handle or "the channel"
    link = ("\n\nFull stream: %s" % url) if url else ""
    items = []
    for k in kinds:
        if k == "recap":
            text = "%s\n\n%s\n\nTimestamps\n%s\n\nBest lines\n%s%s" % (
                title, summary, "\n".join("%s  %s" % (ts(m["t"]), m["heading"]) for m in ms),
                "\n".join("“%s”" % m["quote"] for m in ms[:4]), link)
        elif k == "youtube":
            chap = ([] if ms[0]["t"] < 1 else ["0:00  Start"]) + ["%s  %s" % (ts(m["t"]), m["heading"][:60]) for m in ms]
            text = "%s%s\n\nChapters\n%s\n\n%s" % (summary, link, "\n".join(chap), tags)
        elif k == "thread":
            posts = ["%s. Here's how the stream went 🧵" % title.rstrip(".!")]
            for m in ms[:6]:
                p = ("“%s”" % m["quote"]) if m["heading"] == title else "%s\n\n“%s”" % (m["heading"], m["quote"])
                posts.append(p if len(p) <= 270 else p[:267].rsplit(" ", 1)[0] + "…”")
            posts.append("Follow %s for more%s" % (who, (": " + url) if url else "."))
            text = "\n\n---\n\n".join("%d/%d %s" % (i + 1, len(posts), p) for i, p in enumerate(posts))
        elif k == "linkedin":
            text = "%s\n\n%s\n\n%s\n\nWhich moment was the best?%s\n\n%s" % (
                title, summary, "\n".join("→ “%s”" % m["quote"] for m in ms[:3]), link, tags)
        else:
            body = "\n\n".join("## %s\n\n> %s" % (m["heading"], m["quote"]) for m in ms)
            text = "# %s\n\n%s\n\n%s%s" % (title, intro or summary, body, link)
        items.append({"kind": k, "title": NAMES[k], "text": text})
    return {"items": items, "source": source, "dropped": dropped}


def save(d, items):
    """Write each piece to renders/writeups/<kind>.md -> list of files."""
    out = os.path.join(d, "renders", "writeups")
    os.makedirs(out, exist_ok=True)
    files = []
    for it in items:
        k = it.get("kind") if it.get("kind") in KINDS else "post"
        p = os.path.join(out, "%s.md" % k)
        with open(p, "w", encoding="utf-8") as f:
            f.write(str(it.get("text") or "")[:20000])
        files.append(p)
    return files

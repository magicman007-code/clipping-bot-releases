"""Study a streamer's best clips and find more like them.

Feed it clips that did well for this streamer (downloaded from their channel, their clipper's TikTok, etc).
For each one it measures:
  * length and talking pace
  * what kind of moment it is (reaction, rage, awkward, story, stakes, humor... - the moment finder's signals)
  * how it opens (straight into the reaction? a question? stakes?)
  * what it's about (a meaning vector, offline - semantic.py)
The result is stored in the streamer's lore profile as "style" and used when clipping their streams:
  * clip length range follows their hits (not a generic 15-60 s)
  * moment types their audience shares count more
  * candidates get a "resembles their best clips" score (cosine to the hits' centroid)
Nothing leaves the computer. Plain heuristics + a small sentence model; it is not a trained virality predictor.
"""
import hashlib
import os
import re
import shutil
import threading

import numpy as np

from .common import load_config, log, probe

KINDS = ("reaction", "rage", "awkward", "humor", "drama", "shock", "story", "stakes", "events", "burst")
_RUNNING = {}


def examples_dir(streamer):
    from .lore import lore_dir, slug
    d = os.path.join(lore_dir(), slug(streamer) + "_clips")
    os.makedirs(d, exist_ok=True)
    return d


def _clip_features(path, cache):
    """Transcribe one example clip (cached) and measure it."""
    from .moments import CHROME, LEX, _rx, voice_energy
    from .transcribe import sentences_from_words, transcribe_video
    os.makedirs(cache, exist_ok=True)
    cfg = load_config()
    words = transcribe_video(path, cache, cfg["whisper_model"], cfg.get("vocab"))
    dur = float(probe(path)["duration"])
    sents = sentences_from_words(words) if words else []
    text = " ".join(s["text"] for s in sents)
    kinds = {k: len(_rx(LEX[k]).findall(text)) for k in KINDS if k in LEX}
    try:
        z, hop = voice_energy(path, cache)
        look = max(2, int(6.0 / hop))
        jumps = [z[i] - np.median(z[i - look:i]) for i in range(look, len(z))]
        kinds["burst"] = int(sum(1 for j in jumps if j >= 3.0) > 0)
    except Exception:
        kinds["burst"] = 0
    first = sents[0]["text"] if sents else ""
    fk = [k for k in ("reaction", "rage", "awkward", "shock", "stakes", "humor", "drama") if k in LEX
          and _rx(LEX[k]).search(first)]
    opener = fk[0] if fk else ("question" if first.rstrip().endswith("?") else ("story" if _rx(LEX["story"]).search(first)
                                                                              else "plain"))
    return {"file": os.path.basename(path), "dur": round(dur, 1), "words": len(words),
            "wps": round(len(words) / max(1.0, dur), 2), "kinds": kinds, "opener": opener,
            "first_line": first[:140], "text": text[:2000], "chrome": len(_rx(CHROME).findall(text))}


def study(streamer, paths=None, progress=None):
    """Analyse the example clips for a streamer and save the learned style into their lore profile."""
    from . import lore
    prof = lore.load(streamer) or {"streamer": streamer}
    d = examples_dir(streamer)
    paths = paths or sorted(os.path.join(d, f) for f in os.listdir(d)
                            if f.lower().endswith((".mp4", ".mov", ".mkv", ".webm", ".m4v")))
    feats = []
    for k, p in enumerate(paths, 1):
        if progress:
            progress(k - 1, len(paths), os.path.basename(p))
        h = hashlib.md5(("%s|%s" % (os.path.basename(p), os.path.getsize(p))).encode()).hexdigest()[:10]
        try:
            f = _clip_features(p, os.path.join(d, "_cache", h))
            if f["words"] >= 5:
                feats.append(f)
        except Exception as e:
            log("study: skipped %s (%s)" % (os.path.basename(p), str(e)[:100]))
    if progress:
        progress(len(paths), len(paths), "")
    if not feats:
        raise RuntimeError("none of the clips had speech Clipbot could learn from")
    durs = np.array([f["dur"] for f in feats])
    share = {k: round(sum(1 for f in feats if f["kinds"].get(k)) / len(feats), 2) for k in KINDS}
    openers = {}
    for f in feats:
        openers[f["opener"]] = openers.get(f["opener"], 0) + 1
    style = {"clips": len(feats), "dur": [round(float(np.percentile(durs, q)), 1) for q in (25, 50, 75)],
             "wps": round(float(np.median([f["wps"] for f in feats])), 2), "share": share,
             "openers": dict(sorted(openers.items(), key=lambda kv: -kv[1])),
             "examples": [f["first_line"] for f in feats[:12]], "files": [f["file"] for f in feats]}
    try:
        from . import semantic
        if semantic.available():
            v = semantic.embed([f["text"] for f in feats])
            c = v.mean(0)
            style["centroid"] = [round(float(x), 5) for x in c / max(1e-9, np.linalg.norm(c))]
            style["spread"] = round(float(np.median(v @ np.array(style["centroid"]))), 3)
    except Exception as e:
        log("study: meaning vectors skipped (%s)" % str(e)[:100])
    prof["style"] = style
    lore.save(prof)
    return style


def study_async(streamer):
    """Run study() in the background; status readable via status(streamer)."""
    key = streamer.lower()
    if _RUNNING.get(key, {}).get("state") == "running":
        return _RUNNING[key]
    st = _RUNNING[key] = {"state": "running", "done": 0, "total": 0, "file": ""}

    def prog(i, n, f):
        st.update(done=i, total=n, file=f)

    def go():
        try:
            st["style"] = study(streamer, progress=prog)
            st["state"] = "done"
        except Exception as e:
            st.update(state="error", error=str(e)[:300])
    threading.Thread(target=go, daemon=True).start()
    return st


def status(streamer):
    return _RUNNING.get((streamer or "").lower(), {"state": "idle"})


def add_example(streamer, src_path, name):
    name = re.sub(r"[^\w.\- ]+", "_", os.path.basename(name))[:80] or "clip.mp4"
    dst = os.path.join(examples_dir(streamer), name)
    shutil.move(src_path, dst)
    return dst


# ------------------------------------------------------------------ apply
def length_range(style, lo=10.0, hi=90.0):
    """Clip length range that matches the streamer's hits (with some slack)."""
    if not style or not style.get("dur"):
        return None
    p25, _, p75 = style["dur"]
    if style.get("clips", 0) < 3:
        return None
    return max(lo, round(p25 * 0.8, 1)), min(hi, max(round(p75 * 1.25, 1), p25 * 0.8 + 12))


def kind_weights(style):
    """Moment types this audience shares get more weight (0.75x-1.6x), types they never share a bit less."""
    if not style or not style.get("share"):
        return {}
    base = 0.25
    conf = min(1.0, style.get("clips", 0) / 10.0)          # 10+ example clips = full confidence
    return {k: round(1.0 + (float(np.clip((v + 0.05) / base, 0.75, 1.6)) - 1.0) * conf, 2)
            for k, v in style["share"].items()}


def similarity(style, cands):
    """Cosine similarity of each candidate's text to the hits' centroid (style_sim), in place."""
    if not style or not style.get("centroid") or not cands:
        return cands
    try:
        from . import semantic
        if not semantic.available():
            return cands
        v = semantic.embed([" ".join(t for _, t in c.get("sentences", [])) for c in cands])
        sims = v @ np.array(style["centroid"], dtype=np.float32)
        for c, s in zip(cands, sims):
            c["style_sim"] = round(float(s), 3)
    except Exception as e:
        log("style similarity skipped: %s" % str(e)[:100])
    return cands


def describe(style):
    """One readable summary line for the editor."""
    if not style:
        return ""
    names = {"reaction": "big reactions", "rage": "rage", "awkward": "awkward moments", "humor": "jokes",
             "drama": "drama", "shock": "shock moments", "story": "stories", "stakes": "money/stakes",
             "events": "subs & donations", "burst": "loud outbursts"}
    top = [names[k] for k, v in sorted(style["share"].items(), key=lambda kv: -kv[1]) if v >= 0.3][:3]
    op = next(iter(style.get("openers", {})), "plain")
    opn = {"plain": "a normal line", "question": "a question", "story": "a story setup"}.get(op, names.get(op, op))
    p25, med, p75 = style["dur"]
    return ("Learned from %d clips: usually %.0f-%.0f s (median %.0f s), %.1f words/s%s; most open with %s."
            % (style["clips"], p25, p75, med, style["wps"], ("; mostly " + ", ".join(top)) if top else "", opn))

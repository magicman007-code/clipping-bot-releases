"""Terms of use: the text lives in TERMS.md; acceptance is stored per install in <work_root>/_settings/terms.json.

The version is a hash of the text, so if the terms ever change, Clipbot asks again."""
import hashlib
import json
import os
import time

from .common import ROOT, load_config

PATH = os.path.join(ROOT, "TERMS.md")


def text():
    try:
        return open(PATH, encoding="utf-8").read()
    except OSError:
        return ""


def version():
    return hashlib.sha256(text().encode("utf-8")).hexdigest()[:12]


def _file():
    d = os.path.join(load_config()["work_root"], "_settings")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "terms.json")


def accepted():
    try:
        return json.load(open(_file())).get("version") == version()
    except Exception:
        return False


def accept():
    v = version()
    tmp = _file() + ".tmp"
    json.dump({"version": v, "at": int(time.time())}, open(tmp, "w"))
    os.replace(tmp, _file())
    return {"version": v, "accepted": True}


def status():
    return {"text": text(), "version": version(), "accepted": accepted()}

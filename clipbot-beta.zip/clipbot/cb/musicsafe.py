"""Music / copyright safety: flag stretches of a clip where background MUSIC is playing, so a creator knows a post
might get claimed or muted before it goes out.

This is a heads-up, not a blocker and not a fingerprint match: it can't name a song or say for certain it's
copyrighted. It listens for the acoustic signature of music under or instead of speech -- sustained tonal/harmonic
energy, steady level with few of the pauses speech has, and weak speech-rate (3-7 Hz) amplitude modulation -- and
reports the time ranges that look musical for more than a few seconds. Music the creator ADDED through Clipbot (a
licensed track or their own bed) is never scanned; only the original stream audio is.

    scan_wav(samples, sr)      -> {"music": [(start, end), ...], "music_frac": 0..1, "note": str|None}
    scan_file(path, ffmpeg)    -> same, decoding the file's audio first
"""
import os
import subprocess
import wave

import numpy as np

SR = 16000
WIN = 2048
HOP = 1024
BLOCK = 1.0          # seconds per decision
MIN_RUN = 3.0        # only report music that lasts at least this long
MUSIC_TH = 0.55      # 0..1 musicality score above which a block is called "music"


def _frames(x):
    n = 1 + max(0, (len(x) - WIN) // HOP)
    idx = np.arange(WIN)[None, :] + HOP * np.arange(n)[:, None]
    fr = x[idx] * np.hanning(WIN)
    return np.abs(np.fft.rfft(fr, axis=1)) + 1e-9


def _block_scores(mag, energy, fps):
    """Per ~1s block: (tonality, continuity, speech_mod_weakness), each 0..1."""
    per = max(1, int(round(BLOCK * fps)))
    out = []
    for i in range(0, len(mag), per):
        m = mag[i:i + per]
        e = energy[i:i + per]
        if len(m) < max(4, per // 2):
            break
        # tonality: low spectral flatness = tonal/harmonic (music); high = noisy/breathy (speech, room)
        gm = np.exp(np.mean(np.log(m), axis=1))
        am = np.mean(m, axis=1)
        flat = np.median(gm / am)
        tonality = float(np.clip(1.0 - flat * 2.2, 0, 1))
        # continuity: fraction of frames with real energy (music sustains; speech has gaps between words)
        thr = 0.15 * (np.median(e) + e.max() * 0.3)
        continuity = float(np.mean(e > thr))
        # speech modulation: speech envelope beats at the syllable rate (~2-8 Hz). Weak modulation + energy = music.
        # The denominator ignores the very slow (<1.5 Hz) swell of phrases and word gaps, which would otherwise swamp
        # the syllable-rate energy and make real speech look un-modulated (i.e. music-like).
        env = e - e.mean()
        if np.allclose(env, 0):
            mod = 0.0
        else:
            sp = np.abs(np.fft.rfft(env * np.hanning(len(env))))
            f = np.fft.rfftfreq(len(env), 1.0 / fps)
            den = sp[f >= 1.5].sum() + 1e-9
            band = (f >= 2) & (f <= 8)
            mod = float(sp[band].sum() / den) if band.any() else 0.0
        speech_weak = float(np.clip(1.0 - mod * 2.2, 0, 1))
        out.append((tonality, continuity, speech_weak))
    return out


def scan_wav(samples, sr):
    x = np.asarray(samples, dtype=np.float32)
    if x.ndim > 1:
        x = x.mean(axis=1)
    if not len(x):
        return {"music": [], "music_frac": 0.0, "note": None}
    peak = float(np.max(np.abs(x)))
    if peak < 1e-3:                         # the whole clip is silent: nothing to flag
        return {"music": [], "music_frac": 0.0, "note": None}
    # absolute loudness per 1-second block, from the un-normalised audio: a near-silent block is never "music"
    # (silence looks perfectly tonal and steady once you normalise it, so spectral features alone can't rule it out)
    spb = int(BLOCK * sr)
    floor = max(2e-3, 0.06 * peak)
    active = [float(np.sqrt(np.mean(x[i:i + spb] ** 2))) > floor for i in range(0, len(x), spb)]
    x = x / peak
    mag = _frames(x)
    energy = mag.sum(axis=1)
    fps = sr / float(HOP)
    blocks = _block_scores(mag, energy, fps)
    if not blocks:
        return {"music": [], "music_frac": 0.0, "note": None}
    # a block is "music" when it has real sound AND is tonal AND sustained AND not strongly speech-modulated
    flags = []
    for k, (ton, cont, sw) in enumerate(blocks):
        score = 0.45 * ton + 0.30 * cont + 0.25 * sw
        flags.append(score >= MUSIC_TH and cont > 0.6 and (k >= len(active) or active[k]))
    # merge runs, keep those at least MIN_RUN long (bridge a single non-music block so one dip doesn't split a song)
    runs = []
    i = 0
    while i < len(flags):
        if flags[i]:
            j = i
            while j + 1 < len(flags) and (flags[j + 1] or (j + 2 < len(flags) and flags[j + 2])):
                j += 1
            runs.append((i * BLOCK, min((j + 1) * BLOCK, len(blocks) * BLOCK)))
            i = j + 1
        else:
            i += 1
    music = [(round(a, 1), round(b, 1)) for a, b in runs if b - a >= MIN_RUN]
    total = len(blocks) * BLOCK
    frac = sum(b - a for a, b in music) / total if total else 0.0
    note = None
    if music:
        where = ", ".join("%.0f-%.0fs" % (a, b) for a, b in music[:4])
        note = ("music detected (%s%s) - may be claimed or muted on some platforms; mute those parts or post anyway"
                % (where, ", ..." if len(music) > 4 else ""))
    return {"music": music, "music_frac": round(frac, 3), "note": note}


def scan_file(path, ffmpeg_run=None):
    """Decode a media file's audio to mono 16k and scan it."""
    wav = path + ".musicsafe.wav"
    cmd = ["ffmpeg", "-nostdin", "-y", "-loglevel", "error", "-i", path, "-vn", "-ac", "1", "-ar", str(SR), wav]
    try:
        (ffmpeg_run or (lambda a: subprocess.run(a, check=True, timeout=120)))(cmd)
        with wave.open(wav, "rb") as wf:
            x = np.frombuffer(wf.readframes(wf.getnframes()), dtype=np.int16).astype(np.float32) / 32768.0
        return scan_wav(x, SR)
    except Exception:
        return {"music": [], "music_frac": 0.0, "note": None}
    finally:
        if os.path.exists(wav):
            os.remove(wav)

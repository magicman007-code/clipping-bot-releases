"""Prompt help: turn a rough idea into a prompt that works for the part of Clipbot it's for.

improve(kind, text) -> {"prompt": "...", "tips": [...]}       (kind "skill" -> {"skill": {pick, avoid, titles}, "tips"})
Uses the connected AI (or the free built-in one). Tips are fixed, written guidance and always come back,
so the help still works when the AI is switched off.
"""
import json
import re

KINDS = {
    "clip": {
        "what": "a request telling a clipping tool which moments of a long livestream to find",
        "rules": "Name concrete things that are SAID or HAPPEN (topics, names, reactions, phrases), not vibes. "
                 "One sentence, under 25 words. Example: 'every time he talks about his ex or reacts to a donation "
                 "over $100'.",
        "tips": ["Say what is said or happens, e.g. 'when he reads a donation out loud', not 'good moments'.",
                 "Use names and words that come up in the stream: Clipbot matches against the transcript.",
                 "One idea per run works better than five at once.",
                 "Leave it empty to let Clipbot pick the best moments on its own."]},
    "scene": {
        "what": "a background scene for a YouTube thumbnail, made by an image generator",
        "rules": "Describe ONE bold setting with a clear light source, colour palette and mood, in under 30 words. "
                 "No people, no text, no logos. Leave the right side emptier (a person is placed there later). "
                 "Example: 'a neon-lit underground casino, red and gold light, smoke, chips flying, shallow depth "
                 "of field'.",
        "tips": ["One place, one mood: 'stormy rooftop at night, purple lightning' beats a list of ten things.",
                 "Name the light and colours: 'golden hour', 'red neon', 'blue rim light'.",
                 "Don't ask for text or faces in the background. Clipbot adds your real face and words on top, "
                 "which looks sharper and avoids made-up faces.",
                 "Keep the right side simple; that's where you go."]},
    "remix": {
        "what": "an instruction to an image editor that restyles a real thumbnail frame",
        "rules": "Say what to change and what to KEEP (the person's face and expression stay the same). "
                 "Under 30 words.",
        "tips": ["Say what stays: 'keep his face and expression exactly the same'.",
                 "Change one or two things: the background, the lighting, the colours.",
                 "Only remix people who agreed to it. The person's likeness is your responsibility."]},
    "skill": {
        "what": "a reusable skill: plain-language instructions an AI editor follows when it picks and titles clips",
        "rules": "Return JSON {\"pick\": ..., \"avoid\": ..., \"titles\": ...}. pick = 2-5 short, concrete rules for "
                 "what makes a great clip for this creator. avoid = 1-3 things to skip. titles = how titles "
                 "should sound (length, tone, words to use or never use). Concrete and checkable, no fluff.",
        "tips": ["Write rules you could check by watching the clip, e.g. 'the payoff lands within 20 seconds'.",
                 "Add what to skip: 'no clips that need the earlier part of the stream to make sense'.",
                 "Give title style examples: 'lowercase, under 50 characters, name the person'.",
                 "Rate clips with thumbs up or down too. Skills and ratings work together."]},
}


def improve(kind, text, complete=None):
    if kind not in KINDS:
        raise ValueError("unknown prompt type")
    text = str(text or "").strip()[:1500]
    k = KINDS[kind]
    if not text:
        return {"prompt": "", "tips": k["tips"], "ai": False}
    if complete is None:
        from .connect import ai_complete, ai_ready
        if not ai_ready():
            return {"prompt": text, "tips": k["tips"], "ai": False, "note": "AI is switched off in Settings, so here are the tips."}
        complete = ai_complete
    system = ("You rewrite a user's rough idea into %s. %s Keep the user's intent and any names exactly. "
              "Return only the result, with no preamble." % (k["what"], k["rules"]))
    out = (complete("Rough idea: %s" % text, system=system, max_tokens=400) or "").strip()
    if kind == "skill":
        m = re.search(r"\{.*\}", out, re.S)
        try:
            j = json.loads(m.group(0)) if m else {}
        except ValueError:
            j = {}
        sk = {x: str(j.get(x) or "").strip()[:1200] for x in ("pick", "avoid", "titles")}
        if not any(sk.values()):
            raise RuntimeError("the AI's answer didn't come back as a skill - try again")
        return {"skill": sk, "tips": k["tips"], "ai": True}
    out = out.strip().strip('"').strip()
    if kind in ("scene", "remix", "clip"):
        out = out.splitlines()[0].strip() if out else ""
    if not out:
        raise RuntimeError("the AI didn't answer - try again")
    return {"prompt": out[:600], "tips": k["tips"], "ai": True}

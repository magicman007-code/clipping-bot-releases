"""Learn my style: measure the look of a creator's OWN posted videos and fill the Brand kit from it.

Point it at a few of your own clips and it measures, from the pixels (not from a name or a trend):
  look        brightness, contrast, saturation, warmth, faded/deep blacks, vignette
  framing     fills the screen / wide footage on a blurred background / letterbox bars
  zooms       punch-ins and slow push-ins
  cuts        straight cuts, white flashes, dips to black
  pacing      how often it cuts, how much silence is left in
It turns that into a colour grade + framing/zoom defaults for your clips, plus a plain-English style card.

This is for YOUR OWN videos - learning your style for your footage, not cloning someone else's channel.
Reading the exact caption look (colour, box, font) needs an on-screen text reader and is added separately; for now
the Brand kit's caption controls stay yours to set, and this fills in the grade and motion.

Measurement is adapted from the Mango editor's style engine (style_fx). numpy + OpenCV + ffmpeg only.
"""
import math
import subprocess

import numpy as np

from .common import probe

LOOK_FPS = 2
LOOK_W = 180
MOTION_FPS = 15
MOTION_W = 270
MAX_S = 180            # measure up to the first 3 minutes of each video


def _decode(path, fps, width, max_s=MAX_S, gray=False):
    """Yield frames (RGB or gray) `width` wide at `fps`, via ffmpeg."""
    info = probe(path)
    w, h = info.get("width") or 16, info.get("height") or 9
    hh = max(2, int(round(h * width / w / 2)) * 2)
    fmt, ch = ("gray", 1) if gray else ("rgb24", 3)
    cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-i", path, "-t", str(max_s),
           "-vf", "fps=%s,scale=%d:%d" % (fps, width, hh), "-f", "rawvideo", "-pix_fmt", fmt, "-"]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    size = width * hh * ch
    try:
        while True:
            buf = proc.stdout.read(size)
            if len(buf) < size:
                break
            a = np.frombuffer(buf, np.uint8)
            yield a.reshape(hh, width) if gray else a.reshape(hh, width, 3)
    finally:
        proc.stdout.close()
        proc.wait()


def _luma(f):
    f = f.astype(np.float32)
    return f[..., 0] * 0.299 + f[..., 1] * 0.587 + f[..., 2] * 0.114


def detect_framing(frames):
    """fill / blur / bars, and the rows (0..1) where the real picture is."""
    import cv2
    if not frames:
        return "fill", (0.0, 1.0)
    H, W = frames[0].shape[:2]
    if W >= H:
        return "fill", (0.0, 1.0)
    bars, blur_t, blur_b, valid = 0, 0, 0, 0
    black_rows = np.zeros(H)
    for f in frames:
        L = _luma(f)
        black = (L.mean(axis=1) < 18) & (L.std(axis=1) < 8)
        black_rows += black
        if black[: int(H * 0.15)].mean() > 0.9 and black[int(H * 0.85):].mean() > 0.9:
            bars += 1
        lap = np.abs(cv2.Laplacian(L, cv2.CV_32F))
        mid = lap[int(H * 0.4):int(H * 0.6)].mean()
        if mid < 2.0:
            continue
        valid += 1
        blur_t += (lap[int(H * 0.04):int(H * 0.18)].mean() / mid) < 0.15 and L[int(H * 0.04):int(H * 0.18)].mean() > 12
        blur_b += (lap[int(H * 0.88):int(H * 0.97)].mean() / mid) < 0.15 and L[int(H * 0.88):int(H * 0.97)].mean() > 12
    n = len(frames)
    if bars >= 0.7 * n:
        rows = np.where(black_rows / n < 0.5)[0]
        return ("bars", (float(rows[0] / H), float((rows[-1] + 1) / H))) if rows.size else ("bars", (0.25, 0.75))
    if valid >= 3 and blur_t >= 0.6 * valid and blur_b >= 0.35 * valid:
        frac = W * 9 / 16 / H
        return "blur", (0.5 - frac / 2, 0.5 + frac / 2)
    return "fill", (0.0, 1.0)


def look_stats(frames, band=(0.0, 1.0)):
    if not frames:
        return None
    H = frames[0].shape[0]
    y0, y1 = int(band[0] * H), max(int(band[0] * H) + 2, int(band[1] * H))
    px = np.concatenate([f[y0:y1].reshape(-1, 3) for f in frames]).astype(np.float32)
    if px.shape[0] > 400000:
        px = px[:: px.shape[0] // 400000 + 1]
    L = px @ np.array([0.299, 0.587, 0.114], np.float32)
    sat = px.max(axis=1) - px.min(axis=1)
    cs, cc = [], []
    for f in frames:
        g = _luma(f[y0:y1])
        h, w = g.shape
        chh, cw = max(1, int(h * 0.15)), max(1, int(w * 0.18))
        corners = np.concatenate([g[:chh, :cw].ravel(), g[:chh, -cw:].ravel(),
                                  g[-chh:, :cw].ravel(), g[-chh:, -cw:].ravel()])
        cs.append(corners.mean())
        cc.append(g[int(h * 0.35):int(h * 0.65), int(w * 0.35):int(w * 0.65)].mean())
    return {"brightness": round(float(L.mean()), 2), "contrast": round(float(L.std()), 2),
            "black": round(float(np.percentile(L, 2)), 2), "white": round(float(np.percentile(L, 98)), 2),
            "saturation": round(float(sat.mean()), 2),
            "warmth": round(float(px[:, 0].mean() - px[:, 2].mean()), 2),
            "vignette": round(float(np.mean(cs) / max(1.0, np.mean(cc))), 3)}


def _punch_scale(a, b):
    import cv2
    best = None
    H, W = a.shape
    for s in (1.1, 1.15, 1.2, 1.3, 1.4, 1.5, 1.65, 1.8, 2.0):
        cw, chh = int(W / s), int(H / s)
        x0, y0 = (W - cw) // 2, (H - chh) // 2
        z = cv2.resize(a[y0:y0 + chh, x0:x0 + cw], (W, H), interpolation=cv2.INTER_LINEAR)
        err = float(np.abs(z.astype(np.int16) - b).mean())
        if best is None or err < best[0]:
            best = (err, s)
    base = float(np.abs(a.astype(np.int16) - b).mean())
    return best[1] if best and base > 6 and best[0] < base * 0.45 else None


def _similarity(a, b):
    import cv2
    pts = cv2.goodFeaturesToTrack(a, maxCorners=200, qualityLevel=0.01, minDistance=6)
    if pts is None or len(pts) < 12:
        return None
    nxt, ok, _ = cv2.calcOpticalFlowPyrLK(a, b, pts, None, winSize=(21, 21), maxLevel=3)
    back, ok2, _ = cv2.calcOpticalFlowPyrLK(b, a, nxt, None, winSize=(21, 21), maxLevel=3)
    good = (ok.ravel() == 1) & (ok2.ravel() == 1) & (np.abs(back - pts).reshape(-1, 2).max(1) < 1.0)
    if good.sum() < 12:
        return None
    m, inl = cv2.estimateAffinePartial2D(pts[good], nxt[good], method=cv2.RANSAC, ransacReprojThreshold=1.5)
    if m is None or inl is None or inl.sum() < 12 or inl.mean() < 0.6:
        return None
    return float(math.hypot(m[0, 0], m[1, 0]))


def motion(path, band=(0.0, 1.0), max_s=MAX_S):
    ys, push_pairs, punches, cuts = [], [], 0, 0
    prev, hist, last_cut = None, [], -99
    step = int(MOTION_FPS * 0.5)
    for i, f in enumerate(_decode(path, MOTION_FPS, MOTION_W, max_s=max_s, gray=True)):
        H = f.shape[0]
        g = f[int(band[0] * H):max(int(band[0] * H) + 2, int(band[1] * H))]
        ys.append(float(g.mean()))
        if prev is not None:
            diff = float(np.abs(g.astype(np.int16) - prev).mean())
            if not (14 <= ys[-1] <= 225) or not (14 <= float(prev.mean()) <= 225):
                last_cut = i
                hist = []
            elif diff > 18:
                p = _punch_scale(prev, g) or _punch_scale(g, prev)
                if p:
                    punches += 1
                elif i - last_cut > 4:
                    cuts += 1
                    last_cut = i
                hist = []
        hist.append(g)
        if len(hist) > step:
            s = _similarity(hist[-1 - step], g)
            if s is not None:
                push_pairs.append(s)
        prev = g
    n = len(ys)
    ya = np.array(ys) if ys else np.zeros(1)
    med = float(np.median(ya))

    def runs(mask):
        out, on = 0, False
        for m in mask:
            if m and not on:
                out += 1
            on = bool(m)
        return out
    black = runs((ya < 14) & (med > 40)) if med > 40 else 0
    flash = runs((ya > 225) & (med < 190)) if med < 190 else 0
    pp = np.array(push_pairs) if push_pairs else np.ones(1)
    return {"seconds": round(n / MOTION_FPS if n else 0.0, 1), "cuts": cuts, "punches": punches,
            "push_share": round(float((pp > 1.006).mean()), 3) if push_pairs else 0.0,
            "push_rate": round(float(np.median(pp) - 1) * 2, 4) if push_pairs else 0.0,
            "black_dips": black, "flashes": flash}


def sound(path, max_s=MAX_S):
    out = subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-i", path, "-t", str(max_s),
                          "-vn", "-ac", "1", "-ar", "16000", "-f", "s16le", "-"], capture_output=True)
    a = np.frombuffer(out.stdout, np.int16).astype(np.float32) / 32768
    if a.size < 16000:
        return None
    win = 800
    n = a.size // win
    db = 20 * np.log10(np.sqrt((a[: n * win].reshape(n, win) ** 2).mean(axis=1) + 1e-10) + 1e-9)
    if db.max() < -60:
        return {"silent": True, "bed": False, "silence_share": 1.0}
    p10, p50 = float(np.percentile(db, 10)), float(np.percentile(db, 50))
    quiet = float((db < p50 - 12).mean())
    return {"silent": False, "bed": bool(p10 > -45 and (p50 - p10) < 14), "silence_share": round(quiet, 3)}


def analyse_one(path):
    info = probe(path)
    dur = float(info.get("duration") or 0)
    frames = list(_decode(path, LOOK_FPS if dur <= 90 else max(0.5, 90 * LOOK_FPS / dur), LOOK_W,
                          max_s=MAX_S if dur > MAX_S else dur + 1))
    framing, band = detect_framing(frames)
    look = look_stats(frames, band)
    mot = motion(path, band)
    snd = sound(path) if info.get("has_audio", True) else None
    return {"w": info.get("width") or 0, "h": info.get("height") or 0, "duration": dur,
            "framing": framing, "look": look, "motion": mot, "sound": snd}


def _median(vals):
    vals = [v for v in vals if v is not None]
    return float(np.median(vals)) if vals else None


def summarise(videos):
    from collections import Counter
    videos = [v for v in videos if v]
    if not videos:
        return {}
    ratios = [v["w"] / v["h"] for v in videos if v["h"]]
    r = _median(ratios) or 0.56
    looks = [v["look"] for v in videos if v.get("look")]
    look = {k: round(_median([lk[k] for lk in looks]), 2) for k in
            ("brightness", "contrast", "black", "white", "saturation", "warmth", "vignette")} if looks else {}
    mins = sum(v["motion"]["seconds"] for v in videos) / 60 or 1
    punches = sum(v["motion"]["punches"] for v in videos)
    cuts = sum(v["motion"]["cuts"] for v in videos)
    push_share = _median([v["motion"]["push_share"] for v in videos]) or 0.0
    push_rate = _median([v["motion"]["push_rate"] for v in videos]) or 0.0
    zoom = "punch" if punches >= 2 and punches / mins >= 3 else "push" if push_share >= 0.5 and push_rate >= 0.01 else "none"
    dips, flashes = sum(v["motion"]["black_dips"] for v in videos), sum(v["motion"]["flashes"] for v in videos)
    joins = max(1, cuts + punches)
    trans = "flash" if flashes >= 2 and flashes >= 0.35 * joins else "black" if dips >= 2 and dips >= 0.35 * joins else "cut"
    snd = [v["sound"] for v in videos if v.get("sound") and not v["sound"].get("silent")]
    sil = _median([s["silence_share"] for s in snd]) if snd else None
    return {"format": {"shape": "vertical" if r < 0.8 else "square" if r < 1.2 else "wide",
                       "typical_length_s": round(_median([v["duration"] for v in videos]) or 0, 1)},
            "look": look, "framing": Counter(v["framing"] for v in videos).most_common(1)[0][0],
            "zoom": {"kind": zoom, "push_rate": round(push_rate, 4),
                     "per_min": round(punches / mins, 1)},
            "transition": trans,
            "pacing": {"cuts_per_min": round(_median([60 * v["motion"]["cuts"] / max(1, v["motion"]["seconds"])
                                                      for v in videos]) or 0, 1),
                       "silence_left_in": round(sil, 3) if sil is not None else None},
            "sound_bed": bool(snd and sum(s["bed"] for s in snd) >= max(1, len(snd) / 2))}


# ------------------------------------------------------------------ map to the Brand kit
# neutral reference for a "normal" vertical clip, used to turn absolute measurements into relative grade deltas
_NEUTRAL = {"brightness": 128.0, "contrast": 55.0, "saturation": 60.0, "warmth": 0.0, "vignette": 1.0, "black": 8.0}


def to_grade(look):
    """Map measured colour numbers to Clipbot's grade dict (relative to a neutral clip)."""
    if not look:
        return {}
    g = {}
    b = (look.get("brightness", 128) - _NEUTRAL["brightness"]) / 255.0
    if abs(b) > 0.02:
        g["brightness"] = round(max(-0.3, min(0.3, b * 1.3)), 3)
    c = look.get("contrast", 55) / _NEUTRAL["contrast"]
    if abs(c - 1) > 0.05:
        g["contrast"] = round(max(0.8, min(1.4, c)), 3)
    s = look.get("saturation", 60) / _NEUTRAL["saturation"]
    if abs(s - 1) > 0.05:
        g["saturation"] = round(max(0.4, min(1.9, s)), 3)
    w = look.get("warmth", 0) / 40.0
    if abs(w) > 0.05:
        g["warmth"] = round(max(-0.6, min(0.6, w)), 3)
    if look.get("vignette", 1) < 0.72:
        g["vignette"] = True
    if look.get("contrast", 55) > 72 and look.get("saturation", 60) > 95:
        g["look"] = "punchy"
    elif look.get("black", 8) > 22 and look.get("saturation", 60) < 45:
        g["look"] = "film"
    elif look.get("saturation", 60) < 12:
        g["look"] = "bw"
    return g


def to_brand(summary):
    """A patch for config: a grade and render defaults learned from the videos. Caption look stays the user's."""
    if not summary:
        return {}
    grade = to_grade(summary.get("look") or {})
    fx = {}
    if summary.get("framing") in ("blur", "bars"):
        fx["framing"] = summary["framing"]
    z = summary.get("zoom") or {}
    if z.get("kind") == "punch":
        fx["zoom"] = "punch"
    elif z.get("kind") == "push":
        fx["zoom"] = "push"
    return {"grade": grade, "fx": fx}


def describe(summary):
    """Plain-English style card lines for the UI."""
    if not summary:
        return []
    lk = summary.get("look") or {}
    out = []
    if lk:
        bits = []
        b = lk.get("brightness", 120)
        bits.append("bright" if b > 145 else "dark" if b < 85 else "normal brightness")
        c = lk.get("contrast", 55)
        bits.append("punchy contrast" if c > 72 else "soft contrast" if c < 40 else "normal contrast")
        s = lk.get("saturation", 60)
        bits.append("vivid colour" if s > 110 else "muted colour" if s < 35 else "natural colour")
        wv = lk.get("warmth", 0)
        bits.append("warm" if wv > 18 else "cool" if wv < -18 else "neutral white balance")
        if lk.get("black", 0) > 22:
            bits.append("faded blacks")
        if lk.get("vignette", 1) < 0.68:
            bits.append("darker corners")
        out.append("Look: " + ", ".join(bits))
    out.append("Framing: " + {"fill": "fills the screen", "blur": "wide shots on a blurred background",
                              "bars": "wide shots with black bars"}[summary.get("framing", "fill")])
    z = summary.get("zoom") or {}
    out.append("Zooms: " + ("punch-ins (~%g a minute)" % z["per_min"] if z.get("kind") == "punch"
                            else "slow push-ins" if z.get("kind") == "push" else "none"))
    out.append("Cuts: " + {"cut": "straight cuts", "flash": "white flashes between shots",
                           "black": "dips to black between shots"}[summary.get("transition", "cut")])
    p = summary.get("pacing") or {}
    if p.get("cuts_per_min"):
        out.append("Pacing: ~%g cuts a minute" % p["cuts_per_min"])
    if summary.get("sound_bed"):
        out.append("Sound: music/background under the talking (noticed only)")
    return out


def learn(paths, read_caps=True):
    """Measure each video and return {card, summary, brand, captions} for the Brand kit."""
    vids = []
    for p in paths:
        try:
            vids.append(analyse_one(p))
        except Exception:
            continue
    summary = summarise(vids)
    brand = to_brand(summary)
    card = describe(summary)
    caps = {}
    if read_caps:
        reader = Reader()
        allcap = []
        for p in paths:
            try:
                c = read_captions(p, reader)
                if c.get("present"):
                    allcap.append(c)
            except Exception:
                continue
        if not reader.ok:
            caps = {"available": False}
            card.append("Captions: couldn't read (the on-screen text reader isn't installed) — set captions in the Brand kit")
        elif allcap:
            caps = allcap[0] if len(allcap) == 1 else _merge_captions(allcap)
            brand.update(captions_to_brand(caps))
            bits = [caps.get("fill_name", "")]
            if caps.get("kind"):
                bits.append({"boxed": "boxed", "outline": "outlined", "plain": "plain", "shadow": "with a shadow"}.get(caps["kind"], caps["kind"]))
            if caps.get("all_caps"):
                bits.append("ALL CAPS")
            if caps.get("highlight_name"):
                bits.append("%s highlight" % caps["highlight_name"])
            card.append("Captions: " + ", ".join(b for b in bits if b) + " (%s)" % caps.get("position", "bottom"))
        else:
            caps = {"available": True, "present": False}
            card.append("Captions: none found")
    return {"summary": summary, "card": card, "brand": brand, "captions": caps, "videos": len(vids)}


def _merge_captions(cs):
    from collections import Counter
    out = dict(cs[0])
    out["kind"] = Counter(c["kind"] for c in cs).most_common(1)[0][0]
    out["position"] = Counter(c["position"] for c in cs).most_common(1)[0][0]
    out["all_caps"] = sum(c["all_caps"] for c in cs) >= len(cs) / 2
    return out


# ====================================================================== captions (OCR)
# Reading the exact caption look needs an offline on-screen-text reader (rapidocr-onnxruntime). When it isn't
# installed, everything above still works and the caption fields are simply left for the user to set.
SAMPLE_FPS = 3
WORK_LONG = 960
MIN_SCORE = 0.6
MIN_CAPTION_H = 0.016      # share of screen height; tiny footage text (clocks, scores) is never the caption
CAP_SECONDS = 60


def _hexcol(rgb):
    return "#%02X%02X%02X" % tuple(int(max(0, min(255, round(c)))) for c in rgb)


def _colour_name(rgb):
    r, g, b = [c / 255 for c in rgb]
    mx, mn = max(r, g, b), min(r, g, b)
    light, chroma = (mx + mn) / 2, mx - mn
    if chroma < 0.14:
        return "white" if light > 0.8 else "light grey" if light > 0.55 else "grey" if light > 0.3 else "black"
    if mx == r:
        h = ((g - b) / chroma) % 6
    elif mx == g:
        h = (b - r) / chroma + 2
    else:
        h = (r - g) / chroma + 4
    h *= 60
    for limit, name in ((15, "red"), (40, "orange"), (65, "yellow"), (160, "green"), (200, "cyan"),
                        (255, "blue"), (290, "purple"), (335, "pink"), (361, "red")):
        if h < limit:
            return name
    return "red"


def _luma_img(img):
    return img[..., 0] * 0.299 + img[..., 1] * 0.587 + img[..., 2] * 0.114


def _otsu(values):
    hist, edges = np.histogram(values, bins=64, range=(0, 255))
    total, best, best_t, w0, s0 = values.size, -1, 128, 0, 0.0
    s_all = (hist * edges[:-1]).sum()
    for i in range(64):
        w0 += hist[i]
        if w0 == 0 or w0 == total:
            continue
        s0 += hist[i] * edges[i]
        between = w0 * (total - w0) * (s0 / w0 - (s_all - s0) / (total - w0)) ** 2
        if between > best:
            best, best_t = between, edges[i + 1]
    return best_t


def _text_mask(L):
    import cv2
    dark = L < 70
    if dark.mean() > 0.05:
        n, lab = cv2.connectedComponents((~dark).astype(np.uint8), connectivity=4)
        edge = set(np.unique(np.concatenate([lab[0], lab[-1], lab[:, 0], lab[:, -1]])).tolist())
        inner = (lab > 0) & ~np.isin(lab, list(edge))
        if inner.mean() > 0.06:
            return inner
    t = _otsu(L.ravel())
    light = L > t
    bg_light = np.concatenate([light[0], light[-1], light[:, 0], light[:, -1]]).mean() > 0.5
    mask = ~light if bg_light else light
    core = mask & ((L < t - 20) if bg_light else (L > t + 20))
    return core if core.sum() >= 6 else mask


def _two_colours(px):
    px = px.astype(np.float32)
    main = np.median(px, axis=0)
    if px.shape[0] < 40:
        return main, None, 0.0
    far = np.linalg.norm(px - main, axis=1) > 90
    share = float(far.mean())
    if 0.12 <= share <= 0.6:
        other = np.median(px[far], axis=0)
        if float(np.ptp(other)) > 70 or abs(float(_luma_img(other[None])[0] - _luma_img(main[None])[0])) > 90:
            return np.median(px[~far], axis=0), other, share
    return main, None, 0.0


def _text_look(frame_bgr, box):
    """Fill colour, kind (boxed/outline/plain) and any highlight colour of one OCR'd line. frame is BGR."""
    H, W = frame_bgr.shape[:2]
    xs = [p[0] for p in box]
    ys = [p[1] for p in box]
    x0, x1 = max(0, int(min(xs))), min(W, int(math.ceil(max(xs))))
    y0, y1 = max(0, int(min(ys))), min(H, int(math.ceil(max(ys))))
    if x1 - x0 < 4 or y1 - y0 < 4:
        return None
    rgb = frame_bgr[..., ::-1].astype(np.float32)
    th = y1 - y0
    m = max(2, int(th * 0.12))
    X0, X1, Y0, Y1 = max(0, x0 - m), min(W, x1 + m), max(0, y0 - m), min(H, y1 + m)
    crop = rgb[Y0:Y1, X0:X1]
    L = _luma_img(crop)
    mask = _text_mask(L)
    if mask.sum() < 6:
        return None
    px = crop[mask]
    pl = _luma_img(px)
    fill_light = float(pl.mean()) > float(L[~mask].mean() if (~mask).any() else 0)
    if fill_light and px.shape[0] >= 12:
        px = px[pl >= np.percentile(pl, 35)]
    fill, accent, accent_share = _two_colours(px)
    fl = float(_luma_img(fill[None])[0])
    pad = max(3, int(th * 0.2))
    BX0, BX1, BY0, BY1 = max(0, x0 - pad), min(W, x1 + pad), max(0, y0 - pad), min(H, y1 + pad)
    sides = [rgb[y0:y1, BX0:x0], rgb[y0:y1, x1:BX1], rgb[BY0:y0, x0:x1], rgb[y1:BY1, x0:x1]]
    flat = []
    for sd in sides:
        if sd.size < 9:
            continue
        sdl = _luma_img(sd)
        if float(sdl.std()) < 22 and abs(float(sdl.mean()) - fl) > 60:
            flat.append(sd.reshape(-1, 3).mean(axis=0))
    box_col = None
    if len(flat) >= 3:
        fm = np.array(flat)
        if float(np.ptp(_luma_img(fm))) < 35:
            box_col = np.median(fm, axis=0)
    kind = "boxed" if box_col is not None else "plain"
    if box_col is None:
        # outline vs plain: darker on both diagonal sides of the letters = outline
        P = max(6, int(th * 0.6))
        GX0, GX1, GY0, GY1 = max(0, x0 - P), min(W, x1 + P), max(0, y0 - P), min(H, y1 + P)
        LB = _luma_img(rgb[GY0:GY1, GX0:GX1])
        reg = rgb[GY0:GY1, GX0:GX1]
        big = (np.abs(LB - fl) < 22) & (np.linalg.norm(reg - fill, axis=2) < 45)
        inside = np.zeros(LB.shape, bool)
        inside[y0 - GY0:y1 - GY0, x0 - GX0:x1 - GX0] = True
        big &= inside
        d = max(2, int(round(th * 0.07)))

        def drop(sx, sy):
            ring = np.roll(np.roll(big, sy * d, 0), sx * d, 1) & ~big
            ref_L = np.roll(np.roll(LB, -sy * 2 * d, 0), -sx * 2 * d, 1)
            ref_txt = np.roll(np.roll(big, -sy * 2 * d, 0), -sx * 2 * d, 1)
            ok = ring & ~ref_txt & (ref_L > 80)
            ok[:3 * d + 1] = ok[-3 * d - 1:] = False
            ok[:, :3 * d + 1] = ok[:, -3 * d - 1:] = False
            return float((ref_L[ok] - LB[ok]).mean()) if ok.sum() >= 20 else None
        br, tl = drop(1, 1), drop(-1, -1)
        if br is not None and tl is not None and br > 30 and tl > 30 and tl > 0.5 * br:
            kind = "outline"
    return {"fill": [float(c) for c in fill], "kind": kind,
            "box": [float(c) for c in box_col] if box_col is not None else None,
            "accent": [float(c) for c in accent] if accent is not None else None}


class Reader:
    """Offline on-screen text reader, loaded once."""
    def __init__(self):
        try:
            from rapidocr_onnxruntime import RapidOCR
            self.engine, self.ok, self.why = RapidOCR(), True, None
        except Exception as e:
            self.engine, self.ok, self.why = None, False, str(e)

    def read(self, frame_bgr):
        res, _ = self.engine(frame_bgr)
        return [(box, text.strip()) for box, text, score in (res or [])
                if float(score) >= MIN_SCORE and text.strip()]


def _work_size(w, h):
    if h >= w:
        hh = WORK_LONG
        ww = int(round(w * hh / h / 2)) * 2
    else:
        ww = WORK_LONG
        hh = int(round(h * ww / w / 2)) * 2
    return ww, hh


def _cap_frames(path, w, h, length):
    ww, hh = _work_size(w, h)
    cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-i", path, "-t", "%.3f" % length,
           "-vf", "fps=%d,scale=%d:%d" % (SAMPLE_FPS, ww, hh), "-f", "rawvideo", "-pix_fmt", "bgr24", "-"]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE)
    size = ww * hh * 3
    i = 0
    try:
        while True:
            buf = proc.stdout.read(size)
            if len(buf) < size:
                break
            yield i / SAMPLE_FPS, np.frombuffer(buf, np.uint8).reshape(hh, ww, 3)
            i += 1
    finally:
        proc.stdout.close()
        proc.wait()


def read_captions(path, reader=None):
    """Sample frames, read on-screen text, and return the dominant caption look, or {} if the reader is unavailable."""
    reader = reader or Reader()
    if not reader.ok:
        return {"available": False, "why": reader.why}
    info = probe(path)
    w, h, dur = info.get("width") or 0, info.get("height") or 0, float(info.get("duration") or 0)
    if not (w and h):
        return {"available": True}
    lines, prev, prev_got = [], None, []
    for t, f in _cap_frames(path, w, h, min(dur, CAP_SECONDS) or 1):
        if prev is not None and np.abs(f.astype(np.int16) - prev).mean() < 1.0:
            got = prev_got
        else:
            got = []
            for box, text in reader.read(f):
                look = _text_look(f, box)
                if not look:
                    continue
                ys = [p[1] for p in box]
                got.append({"text": text, "y": (min(ys) + max(ys)) / 2 / f.shape[0],
                            "height": (max(ys) - min(ys)) / f.shape[0], **look})
        prev, prev_got = f.astype(np.int16), got
        for g in got:
            lines.append({"t": round(t, 2), **g})
    return caption_summary(lines, dur)


def caption_summary(lines, dur=0):
    """Dominant caption look from OCR'd lines. Static footage text (watermarks) and tiny text are dropped."""
    from collections import Counter
    caps = [l for l in lines if l["height"] >= MIN_CAPTION_H and any(ch.isalpha() for ch in l["text"])]
    if not caps:
        return {"available": True, "present": False}
    # drop near-static text (a watermark/handle on screen the whole time): texts seen across most of the span
    span = max(1.0, dur)
    seen = Counter(l["text"].upper() for l in caps)
    tspan = {}
    for l in caps:
        tspan.setdefault(l["text"].upper(), [l["t"], l["t"]])
        tspan[l["text"].upper()][0] = min(tspan[l["text"].upper()][0], l["t"])
        tspan[l["text"].upper()][1] = max(tspan[l["text"].upper()][1], l["t"])
    static = {t for t, (a, b) in tspan.items() if (b - a) > 0.7 * min(span, CAP_SECONDS) and seen[t] >= 4}
    caps = [l for l in caps if l["text"].upper() not in static] or caps
    kinds = Counter(l["kind"] for l in caps if l["kind"] != "unclear") or Counter(["plain"])
    zones = Counter(("top" if l["y"] < 0.4 else "bottom" if l["y"] > 0.6 else "middle") for l in caps)
    letters = "".join(ch for l in caps for ch in l["text"] if ch.isalpha())
    upper = sum(ch.isupper() for ch in letters) / max(1, len(letters))
    fill = np.median(np.array([l["fill"] for l in caps]), axis=0)
    out = {"available": True, "present": True, "kind": kinds.most_common(1)[0][0],
           "position": zones.most_common(1)[0][0], "all_caps": upper > 0.9, "upper_share": round(upper, 2),
           "fill": _hexcol(fill), "fill_name": _colour_name(fill),
           "words_per_caption": round(float(np.median([len(l["text"].split()) for l in caps])), 1),
           "examples": list(dict.fromkeys(l["text"] for l in caps))[:6]}
    boxes = [l["box"] for l in caps if l.get("box") is not None]
    if out["kind"] == "boxed" and boxes:
        out["box"] = _hexcol(np.median(np.array(boxes), axis=0))
    acc = [l["accent"] for l in caps if l.get("accent") is not None]
    if acc:
        names = Counter(_colour_name(a) for a in acc)
        nm, k = names.most_common(1)[0]
        if k >= 0.3 * len(caps) and nm != out["fill_name"]:
            out["highlight"] = _hexcol(np.median(np.array([a for a in acc if _colour_name(a) == nm]), axis=0))
            out["highlight_name"] = nm
    return out


# map a caption summary onto the Brand kit's caption fields
_KIND_TO_STYLE = {"boxed": "box", "outline": "pro", "plain": "minimal", "shadow": "pro"}


def captions_to_brand(cap):
    if not cap or not cap.get("present"):
        return {}
    b = {"caption_style": _KIND_TO_STYLE.get(cap.get("kind"), "pro"),
         "color": cap.get("fill", "#FFFFFF"), "uppercase": bool(cap.get("all_caps"))}
    if cap.get("highlight"):
        b["accent"] = cap["highlight"]
    return b

"""Listing channels, robust downloads, live capture, and the seen/pending queue."""
import glob
import json
import os
import re
import subprocess
import sys
import time

from .common import (CmdError, ffmpeg, load_config, load_state, log, now_iso, probe, run,
                     save_state)

BOT_RE = re.compile(r"confirm you.?re not a bot|Sign in to confirm|HTTP Error 429|rate.?limit", re.I)
UNAVAIL_RE = re.compile(r"Video unavailable|Private video|members-only|This live event", re.I)
SUBONLY_RE = re.compile(r"subscriber|sub-only|only available to (?:subscribers|members)|requires? (?:a )?subscription", re.I)
GONE_RE = re.compile(r"does not exist|has been (?:deleted|removed)|HTTP Error 404|not found|expired|no longer available", re.I)
BLOCK_RE = re.compile(r"cloudflare|HTTP Error 403|impersonat|Forbidden|Just a moment", re.I)
FRIENDLY = {
    "sub_only": "This VOD is for subscribers only. Download it yourself while logged in, then drop the file in "
                "(or add your browser cookies - see BETA_TESTING.md).",
    "gone": "That VOD is gone - it was deleted or expired (Twitch keeps VODs 7-60 days; Kick deletes old ones too).",
    "blocked": "The site blocked the download. Update Clipbot (it includes browser impersonation for Kick), try again "
               "later, or download the VOD yourself and drop the file in.",
    "bot_check": "The site asked for a bot check. Try again in a few minutes, or download the video yourself and drop "
                 "the file in.",
}


def vod_url(url):
    """Tidy Kick/Twitch VOD links so yt-dlp recognises them. Returns (url, note)."""
    from urllib.parse import parse_qs, urlparse
    u = url.strip()
    p = urlparse(u if "://" in u else "https://" + u)
    host = re.sub(r"^(?:www\.|m\.)", "", (p.netloc or "").lower())
    if host in ("twitch.tv", "clips.twitch.tv", "player.twitch.tv"):
        q = parse_qs(p.query)
        if host == "player.twitch.tv" and q.get("video"):           # embed link -> VOD page
            vid = q["video"][0].lstrip("v")
            return "https://www.twitch.tv/videos/%s" % vid, None
        m = re.search(r"/videos?/(\d+)", p.path)
        if m:
            return "https://www.twitch.tv/videos/%s" % m.group(1), None
        return "https://" + host + p.path, None
    if host == "kick.com":
        m = re.match(r"/video/([\da-f-]{36})", p.path)                # old share format (no channel in it)
        if m:
            return u, ("Kick's old /video/ links sometimes don't download - if it fails, open the streamer's Videos "
                       "page on Kick and copy the VOD link from there (kick.com/<name>/videos/...).")
        return "https://kick.com" + p.path + (("?" + p.query) if "clip=" in p.query else ""), None
    return u, None

# Tried in order. Different YouTube player clients get different bot-check treatment,
# so falling through them recovers many "blocked" downloads without cookies.
YT_CLIENTS = [None, "tv,web_safari", "mweb", "web_embedded,android_vr"]


# yt-dlp through this Python: works even when the app's venv isn't on PATH (launchers don't activate it)
YTDLP = [sys.executable, "-m", "yt_dlp"]


def _ytdlp_base(cfg):
    args = YTDLP + ["--no-warnings", "--retries", "5", "--fragment-retries", "10",
            "--extractor-retries", "3", "--socket-timeout", "30"]
    help_txt = _ytdlp_help()
    if "--js-runtimes" in help_txt:          # YouTube needs a JS runtime: the bundled Deno first, else Node
        rt = js_runtime()
        if rt:
            args += ["--js-runtimes", rt]
    try:                                    # Connections -> "use my browser's logins" (sub-only VODs)
        from .connect import cookies_browser
        br = cookies_browser()
    except Exception:
        br = None
    if br:
        args += ["--cookies-from-browser", br]
    ck = cfg.get("cookies_file")
    if ck and os.path.exists(os.path.expanduser(ck)):
        args += ["--cookies", os.path.expanduser(ck)]
    return args


_HELP = None


def js_runtime():
    """'deno:/path' from the pip 'deno' package installed with Clipbot (works without PATH), else node if present."""
    try:
        import deno
        p = deno.find_deno_bin()
        if p and os.path.exists(p):
            return "deno:" + p
    except Exception:
        pass
    import shutil
    for name in ("deno", "node", "bun"):
        p = shutil.which(name)
        if p:
            return "%s:%s" % (name, p)
    return None


_UPDATED = {"done": False}


def update_ytdlp():
    """Sites (YouTube most of all) break older yt-dlp versions; upgrade once per run and retry."""
    if _UPDATED["done"]:
        return False
    _UPDATED["done"] = True
    global _HELP
    log("download failed - updating the downloader (yt-dlp) and trying again...")
    r = subprocess.run([sys.executable, "-m", "pip", "install", "-q", "-U", "yt-dlp", "yt-dlp-ejs"],
                       capture_output=True, text=True, timeout=600)
    _HELP = None
    return r.returncode == 0


def _ytdlp_help():
    global _HELP
    if _HELP is None:
        try:
            _HELP = subprocess.run(YTDLP + ["--help"], capture_output=True, text=True, timeout=60).stdout
        except Exception:
            _HELP = ""
    return _HELP


def channel_list_url(url, platform):
    u = url.rstrip("/")
    if platform == "youtube" and re.search(r"youtube\.com/(@|channel/|c/|user/)[^/]+$", u):
        return u + "/videos"
    if platform == "kick" and re.search(r"kick\.com/[^/]+$", u):
        return u + "/videos"
    return u


def list_videos(url, platform="youtube", limit=5, cfg=None):
    cfg = cfg or load_config()
    lu = channel_list_url(url, platform)
    r = run(_ytdlp_base(cfg) + ["--flat-playlist", "-J", "--playlist-end", str(limit), lu],
            timeout=180, check=False)
    if r.returncode != 0 and lu != url:  # e.g. kick /videos not supported -> try bare url
        r = run(_ytdlp_base(cfg) + ["--flat-playlist", "-J", "--playlist-end", str(limit), url],
                timeout=180, check=False)
    if r.returncode != 0 or not (r.stdout or "").strip():
        if platform == "kick":
            return kick_api_videos(url, limit)   # yt-dlp often can't list Kick VODs
        raise CmdError("list failed: " + r.stderr[-800:])
    data = json.loads(r.stdout)
    out = []
    for e in (data.get("entries") or [data]):
        if not e:
            continue
        vid = e.get("id")
        u = e.get("url") or e.get("webpage_url") or ""
        if platform == "youtube" and vid and not u.startswith("http"):
            u = "https://www.youtube.com/watch?v=" + vid
        out.append({"id": vid, "url": u, "title": e.get("title"),
                    "duration": e.get("duration"), "live": e.get("live_status") == "is_live"})
    return out


def kick_api_videos(url, limit=5):
    """Kick's public channel API (used when yt-dlp can't list VODs). Cloudflare may still block
    datacenter IPs; then run from the linked computer."""
    import urllib.request
    slug = re.sub(r".*kick\.com/([^/?#]+).*", r"\1", url)
    out = []
    for path in ("/api/v2/channels/%s/videos" % slug, "/api/v1/channels/%s" % slug):
        req = urllib.request.Request("https://kick.com" + path, headers={
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126 Safari/537.36",
            "Accept": "application/json"})
        try:
            data = json.loads(urllib.request.urlopen(req, timeout=30).read())
        except Exception as e:
            log("kick api %s failed: %s" % (path, e))
            continue
        vids = data if isinstance(data, list) else (data.get("previous_livestreams") or [])
        live = isinstance(data, dict) and bool(data.get("livestream"))
        for v in vids[:limit]:
            vv = v.get("video") or {}
            uid = vv.get("uuid") or v.get("uuid") or str(v.get("id"))
            out.append({"id": uid, "url": "https://kick.com/%s/videos/%s" % (slug, uid),
                        "title": v.get("session_title") or v.get("title"), "duration": (v.get("duration") or 0) / 1000.0,
                        "live": bool(v.get("is_live"))})
        if live:
            out.insert(0, {"id": "live", "url": "https://kick.com/" + slug, "title": "LIVE", "live": True})
        if out:
            break
    return out


def _find_source(workdir):
    c = [f for f in glob.glob(os.path.join(workdir, "source.*"))
         if not f.endswith((".part", ".ytdl", ".json")) and ".f" not in os.path.basename(f)[7:]]
    return c[0] if c else None


VIDEO_EXT = (".mp4", ".mov", ".mkv", ".webm", ".m4v", ".avi", ".flv", ".ts", ".mts", ".wmv", ".mpg", ".mpeg")


class LinkError(ValueError):
    """A share link we recognise but can't download (folder link, private file...). Message is user-facing."""


def direct_link(url):
    """Share links -> a URL that returns the file bytes. None if this isn't a cloud/direct file link.
    Dropbox: www.dropbox.com/s/... or /scl/fi/...  -> same URL with dl=1 (keeps rlkey).
    Google Drive: drive.google.com/file/d/ID/... or open?id=ID / uc?id=ID -> usercontent download URL.
    Plain https://.../video.mp4 -> as is."""
    from urllib.parse import parse_qs, urlencode, urlparse, urlunparse
    u = urlparse(url.strip())
    host = (u.netloc or "").lower()
    if "dropbox.com" in host or "dropboxusercontent.com" in host:
        if "/scl/fo/" in u.path or u.path.startswith("/sh/"):
            raise LinkError("That's a Dropbox FOLDER link. Open the folder, click the video file, "
                            "then Share -> Copy link, and paste that file link instead.")
        q = parse_qs(u.query)
        q.pop("dl", None)
        q.pop("raw", None)
        q["dl"] = ["1"]
        host = "www.dropbox.com" if host in ("dropbox.com", "www.dropbox.com") else u.netloc
        return urlunparse((u.scheme or "https", host, u.path, "", urlencode(q, doseq=True), ""))
    if "drive.google.com" in host or "docs.google.com" in host:
        if "/folders/" in u.path:
            raise LinkError("That's a Google Drive FOLDER link. Right-click the video inside it -> Share -> "
                            "Copy link, and paste that file link instead.")
        m = re.search(r"/file/d/([A-Za-z0-9_-]{10,})", u.path)
        fid = m.group(1) if m else (parse_qs(u.query).get("id") or [None])[0]
        if not fid:
            raise LinkError("Couldn't find the file id in that Google Drive link - use Share -> Copy link on the file.")
        return "https://drive.usercontent.google.com/download?id=%s&export=download&confirm=t" % fid
    if u.scheme in ("http", "https") and u.path.lower().endswith(VIDEO_EXT):
        return url.strip()
    return None


def http_download(url, dest, timeout=60, progress=None):
    """Stream a URL to dest. Raises LinkError with a readable reason if we get a web page instead of a video."""
    import urllib.request
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (clipbot)"})
    tmp = dest + ".part"
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            ctype = (r.headers.get("Content-Type") or "").lower()
            total = int(r.headers.get("Content-Length") or 0)
            first = r.read(65536)
            if "text/html" in ctype or first.lstrip()[:15].lower().startswith((b"<!doctype", b"<html")):
                raise LinkError("The link opened a web page, not a video file. Make sure the file is shared as "
                                "'Anyone with the link can view' and that the link points at one video file.")
            got = 0
            with open(tmp, "wb") as f:
                while first:
                    f.write(first)
                    got += len(first)
                    if progress:
                        progress(got, total)
                    first = r.read(1 << 20)
    except LinkError:
        raise
    except Exception as e:
        code = getattr(e, "code", None)
        if code in (401, 403, 404):
            raise LinkError("The link answered %d - the file is private, deleted or the link expired. "
                            "Re-share it as 'Anyone with the link'." % code)
        raise LinkError("Download failed: %s" % str(e)[:160])
    os.replace(tmp, dest)
    return dest


WT_BASE = "https://wetransfer.com"       # (overridable in tests)
WT_HOSTS = ("wetransfer.com", "we.tl")


def is_wetransfer(url):
    from urllib.parse import urlparse
    h = (urlparse(url.strip()).netloc or "").lower()
    return any(h == x or h.endswith("." + x) for x in WT_HOSTS)


def wetransfer_link(url, base=None, timeout=30):
    """WeTransfer share link (we.tl/t-... or wetransfer.com/downloads/<id>/<hash>) -> a direct download URL.
    WeTransfer has no public download API for links; this is the same request its own download page makes
    (session cookie + CSRF token, then POST /api/v4/transfers/<id>/download). If they change it, this raises a
    LinkError telling the user to download the file and drop it in instead."""
    import http.cookiejar
    import urllib.request
    from urllib.parse import urlparse
    base = base or WT_BASE
    jar = http.cookiejar.CookieJar()
    op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
    op.addheaders = [("User-Agent", "Mozilla/5.0 (clipbot)")]
    fail = ("Couldn't open that WeTransfer link (%s). It may have expired (they last 7 days on the free plan). "
            "Otherwise download it in your browser and drop the video in.")
    try:
        u = url.strip()
        if "/downloads/" not in u:                       # we.tl short link -> follow the redirect
            with op.open(u, timeout=timeout) as r:
                u = r.geturl()
        parts = [x for x in urlparse(u).path.split("/") if x]
        if "downloads" not in parts:
            raise LinkError(fail % "not a download link")
        params = parts[parts.index("downloads") + 1:]
        if len(params) == 2:
            tid, rid, sec = params[0], None, params[1]
        elif len(params) >= 3:
            tid, rid, sec = params[0], params[1], params[2]
        else:
            raise LinkError(fail % "link is incomplete")
        with op.open(base + "/", timeout=timeout) as r:
            page = r.read(2 << 20).decode("utf-8", "replace")
        m = re.search(r'name="csrf-token"\s+content="([^"]+)"', page)
        body = {"intent": "entire_transfer", "security_hash": sec}
        if rid:
            body["recipient_id"] = rid
        req = urllib.request.Request("%s/api/v4/transfers/%s/download" % (base, tid), method="POST",
                                     data=json.dumps(body).encode(),
                                     headers={"Content-Type": "application/json", "X-Requested-With": "XMLHttpRequest",
                                              **({"X-CSRF-Token": m.group(1)} if m else {})})
        with op.open(req, timeout=timeout) as r:
            j = json.loads(r.read().decode("utf-8", "replace") or "{}")
    except LinkError:
        raise
    except Exception as e:
        code = getattr(e, "code", None)
        raise LinkError(fail % ("WeTransfer answered %d" % code if code else str(e)[:80]))
    if not j.get("direct_link"):
        raise LinkError(fail % (j.get("message") or j.get("error") or "no download link in the reply"))
    return j["direct_link"]


def _video_from_zip(path, workdir):
    """A transfer with several files arrives as a .zip: take the biggest video inside (safely)."""
    import zipfile
    with zipfile.ZipFile(path) as z:
        vids = [i for i in z.infolist() if not i.is_dir() and i.filename.lower().endswith(VIDEO_EXT)
                and "__MACOSX" not in i.filename]
        if not vids:
            raise LinkError("The transfer is a zip with no video inside it.")
        best = max(vids, key=lambda i: i.file_size)
        out = os.path.join(workdir, "_download_unzipped" + os.path.splitext(best.filename)[1].lower())
        with z.open(best) as src, open(out, "wb") as dst:
            while True:
                b = src.read(1 << 20)
                if not b:
                    break
                dst.write(b)
    os.remove(path)
    return out


def download_direct(url, workdir):
    """Cloud/direct link -> workdir/source.<ext>, validated with ffprobe. Returns (path|None, kind, log)."""
    try:
        dl = wetransfer_link(url) if is_wetransfer(url) else direct_link(url)
    except LinkError as e:
        return None, "bad_link", str(e)
    if not dl:
        return None, "not_direct", ""
    os.makedirs(workdir, exist_ok=True)
    raw = os.path.join(workdir, "_download.tmp")
    try:
        last = [0]

        def prog(got, total):
            if got - last[0] > 50 << 20:
                last[0] = got
                log("  downloaded %d MB%s" % (got >> 20, (" of %d MB" % (total >> 20)) if total else ""))
        http_download(dl, raw, progress=prog)
    except LinkError as e:
        return None, "bad_link", str(e)
    try:
        import zipfile
        if zipfile.is_zipfile(raw):
            raw = _video_from_zip(raw, workdir)
    except LinkError as e:
        return None, "bad_link", str(e)
    except Exception as e:
        return None, "bad_link", "Couldn't unpack the downloaded zip: %s" % str(e)[:100]
    try:
        info = probe(raw)
    except Exception:
        info = {"duration": 0}
    if not info.get("duration"):
        os.remove(raw)
        return None, "bad_link", "The link downloaded, but the file isn't a playable video."
    out = os.path.join(workdir, "source.mp4")
    r = run(["ffmpeg", "-y", "-v", "error", "-i", raw, "-map", "0:v:0", "-map", "0:a:0?", "-c", "copy",
             "-movflags", "+faststart", out], check=False)
    if r.returncode != 0:          # codec mp4 can't hold (e.g. some .mkv/.avi) -> re-encode
        ffmpeg(["-i", raw, "-map", "0:v:0", "-map", "0:a:0?", "-c:v", "libx264", "-preset", "veryfast",
                "-crf", "18", "-c:a", "aac", "-b:a", "192k", out])
    os.remove(raw)
    return out, None, "ok via direct link"


def download(url, workdir, cfg=None, section=None, _retry=False):
    """Download to workdir/source.mp4. Tries several strategies; returns (path|None, error_kind, log).
    section: (start_s, end_s) -> only that part of a long VOD/video is downloaded."""
    cfg = cfg or load_config()
    url, note = vod_url(url)
    os.makedirs(workdir, exist_ok=True)
    existing = _find_source(workdir)
    if existing and probe(existing)["duration"] > 0:
        return existing, None, "cached"
    src, kind, msg = download_direct(url, workdir)
    if src or kind == "bad_link":
        return src, kind, msg
    tmpl = os.path.join(workdir, "source.%(ext)s")
    is_yt = "youtu" in url
    clients = YT_CLIENTS if is_yt else [None]
    errors = []
    for i, client in enumerate(clients):
        cmd = _ytdlp_base(cfg) + quality_args(cfg) + ["--merge-output-format", "mp4", "--no-playlist",
                                                     "--concurrent-fragments", "4", "-o", tmpl]
        if client:
            cmd += ["--extractor-args", "youtube:player_client=" + client]
        if section:
            cmd += ["--download-sections", "*%s-%s" % (hms(section[0]), hms(section[1]))]
        r = run(cmd + [url], timeout=3600, check=False)
        src = _find_source(workdir)
        if r.returncode == 0 and src:
            src = _ensure_mp4_with_audio(src, workdir)
            q = source_quality(src)
            if q:
                log("downloaded source: %s%s" % (q["label"], "" if q["ok"] else
                    "  ** UNDER 1080p: the site only offered this, or a login is needed for higher quality **"))
            return src, None, "ok via client=%s%s" % (client or "default", (", " + q["label"]) if q else "")
        err = (r.stderr or "")[-600:]
        kind = ("sub_only" if SUBONLY_RE.search(err) else "bot_check" if BOT_RE.search(err) else
                "gone" if GONE_RE.search(err) else "blocked" if BLOCK_RE.search(err) else
                "unavailable" if UNAVAIL_RE.search(err) else "error")
        if kind in ("sub_only", "gone"):          # retrying with other clients won't help
            errors.append("[%s] %s: %s" % (client or "default", kind, err.strip().splitlines()[-1] if err.strip() else ""))
            break
        errors.append("[%s] %s: %s" % (client or "default", kind, err.strip().splitlines()[-1] if err.strip() else ""))
        log("download attempt %d failed (%s)" % (i + 1, kind))
        if kind == "bot_check" and i < len(clients) - 1:
            time.sleep(8 + 6 * i)
    kinds = [e.split(":")[0] for e in errors]
    kind = next((k for k in ("sub_only", "gone", "blocked", "bot_check", "unavailable") if any(k in x for x in kinds)),
                "error")
    if kind in ("error", "blocked", "bot_check") and not _retry and cfg.get("auto_update_downloader", True):
        if update_ytdlp():
            return download(url, workdir, cfg, section=section, _retry=True)
    msg = "\n".join(errors)
    if note:
        msg = note + "\n" + msg
    return None, kind, msg


def hms(t):
    t = max(0, int(round(float(t))))
    return "%d:%02d:%02d" % (t // 3600, t // 60 % 60, t % 60)


def parse_time(v):
    """'1:02:03', '62:03', '3723', '1h2m3s' -> seconds (None if empty/invalid)."""
    if v is None or str(v).strip() == "":
        return None
    s = str(v).strip().lower()
    m = re.fullmatch(r"(?:(\d+)h)?\s*(?:(\d+)m)?\s*(?:(\d+(?:\.\d+)?)s)?", s)
    if m and any(m.groups()):
        return int(m.group(1) or 0) * 3600 + int(m.group(2) or 0) * 60 + float(m.group(3) or 0)
    try:
        parts = [float(x) for x in s.split(":")]
    except ValueError:
        return None
    if len(parts) > 3:
        return None
    sec = 0.0
    for x in parts:
        sec = sec * 60 + x
    return sec


def _ensure_mp4_with_audio(src, workdir):
    # yt-dlp occasionally leaves split .fNNN files if the merge step failed; repair that.
    parts = sorted(glob.glob(os.path.join(workdir, "source.f*.*")))
    if parts and len(parts) >= 2:
        out = os.path.join(workdir, "source.mp4")
        ffmpeg(["-i", parts[0], "-i", parts[1], "-c", "copy", "-map", "0:v:0", "-map", "1:a:0", out])
        return out
    if not src.endswith(".mp4"):
        out = os.path.join(workdir, "source.mp4")
        ffmpeg(["-i", src, "-c", "copy", out])
        return out
    return src


# Quality: the best rendition up to max_height (1080 by default), ranked by resolution, then frame rate, then bitrate.
# Never "auto" and never the first/lowest variant of an HLS master playlist.
def quality_args(cfg, combined_only=False):
    h = int(cfg.get("max_height", 1080))
    fmt = ("b[height<=%d]/bv*[height<=%d]+ba/b" % (h, h)) if combined_only else \
        ("bv*[height<=%d]+ba/b[height<=%d]/bv*+ba/b" % (h, h))
    return ["-f", fmt, "-S", "res:%d,fps,br" % h]


VARIANT_FMT = "VARIANT|%(format_id)s|%(width)s|%(height)s|%(fps)s|%(tbr)s"


def resolve_stream(url, cfg, timeout=90):
    """Stream URL(s) for the best variant up to max_height, via `yt-dlp -g`, plus what that variant is.
    -> (urls, {"format_id", "width", "height", "fps", "kbps"} or {})"""
    r = run(_ytdlp_base(cfg) + quality_args(cfg, combined_only=True) + ["--print", VARIANT_FMT, "-g", url],
            timeout=timeout, check=False)
    variant = {}
    urls = []
    for line in (r.stdout or "").splitlines():
        if line.startswith("VARIANT|"):
            _, fid, w, h, fps, tbr = (line.split("|") + [""] * 6)[:6]
            num = lambda v: float(v) if re.match(r"^\d+(\.\d+)?$", v or "") else None
            variant = {"format_id": fid, "width": num(w) and int(num(w)), "height": num(h) and int(num(h)),
                       "fps": num(fps), "kbps": num(tbr) and int(num(tbr))}
        elif line.startswith("http"):
            urls.append(line.strip())
    return urls, variant


def source_quality(path):
    """What the file really is: {"width", "height", "fps", "label", "ok"} - ok is False under 1080p."""
    try:
        p = probe(path)
    except Exception:
        return None
    w, h = int(p.get("width") or 0), int(p.get("height") or 0)
    fps = float(p.get("fps") or 0)
    short = min(w, h) if w and h else 0
    return {"width": w, "height": h, "fps": round(fps, 2), "label": "%dx%d @ %gfps" % (w, h, round(fps, 2)),
            "ok": short >= 1080}


def capture_live(url, workdir, seconds=300, cfg=None):
    """Record the next `seconds` of a live stream with ffmpeg reading the HLS URL directly
    (cleaner than killing yt-dlp mid-write, which can leave an unplayable file)."""
    cfg = cfg or load_config()
    os.makedirs(workdir, exist_ok=True)
    urls, variant = resolve_stream(url, cfg, timeout=120)
    if not urls:
        raise CmdError("not live or no stream URL")
    log("live capture: variant %s %sx%s @ %sfps" % (variant.get("format_id"), variant.get("width"), variant.get("height"),
                                                    variant.get("fps")))
    out = os.path.join(workdir, "source.mp4")
    ins = []
    for u in urls[:2]:
        ins += ["-i", u]
    maps = ["-map", "0:v:0", "-map", ("1:a:0" if len(urls) > 1 else "0:a:0?")]
    ffmpeg(ins + ["-t", str(seconds)] + maps + ["-c", "copy", "-movflags", "+faststart", out],
           timeout=seconds + 120)
    return out


# ---------------------------------------------------------------- queue / state
def scan(cfg=None, st=None, per_channel=8):
    """List every configured channel, add unseen videos to the pending queue. Returns new ids."""
    cfg = cfg or load_config()
    st = st or load_state()
    new, report = [], []
    for ch in cfg["channels"]:
        try:
            vids = list_videos(ch["url"], ch.get("platform", "youtube"), per_channel, cfg)
        except Exception as e:
            report.append({"channel": ch["name"], "platform": ch.get("platform"), "error": str(e)[-300:]})
            continue
        n = 0
        for v in vids:
            vid = v["id"]
            if not vid or vid in st["seen_video_ids"] or vid in st["failed"] or v.get("live"):
                continue
            if vid not in st["pending"]:
                st["pending"][vid] = {"url": v["url"], "title": v["title"], "channel": ch["name"],
                                      "platform": ch.get("platform"), "layout": ch.get("layout", "auto"),
                                      "attempts": 0, "last_error": None, "first_seen": now_iso()}
                new.append(vid)
            n += 1
        report.append({"channel": ch["name"], "platform": ch.get("platform"), "listed": len(vids),
                       "unseen": n, "live_now": any(v.get("live") for v in vids)})
    save_state(st)
    return new, report


def fetch_pending(cfg=None, st=None, limit_per_channel=None):
    """Try to download pending videos (oldest first, capped per channel). Updates attempts."""
    cfg = cfg or load_config()
    st = st or load_state()
    limit = limit_per_channel or cfg["max_new_per_channel"]
    per = {}
    results = []
    for vid, p in sorted(st["pending"].items(), key=lambda kv: kv[1]["first_seen"]):
        if per.get(p["channel"], 0) >= limit:
            continue
        per[p["channel"]] = per.get(p["channel"], 0) + 1
        wd = video_dir(cfg, p["channel"], vid)
        path, kind, info = download(p["url"], wd, cfg)
        p["attempts"] += 1
        if path:
            p["source"] = path
            p["workdir"] = wd
            p["last_error"] = None
            results.append({"id": vid, "ok": True, "source": path, "title": p["title"]})
        else:
            p["last_error"] = "%s @ %s" % (kind, now_iso())
            results.append({"id": vid, "ok": False, "error": kind, "title": p["title"], "detail": info[-500:]})
            if kind == "unavailable" and p["attempts"] >= 3 or p["attempts"] >= cfg["max_download_attempts"]:
                st["failed"][vid] = st["pending"].pop(vid)
    save_state(st)
    return results


def mark_done(vid, st=None):
    st = st or load_state()
    st["pending"].pop(vid, None)
    if vid not in st["seen_video_ids"]:
        st["seen_video_ids"].append(vid)
    save_state(st)


def video_dir(cfg, channel, vid):
    return os.path.join(cfg["work_root"], re.sub(r"[^\w.-]+", "_", channel), vid)

"""Auto-repair the gate's 'repair'-level reason codes.

The quality gate (cb/reasons.py) sorts each defect into pass / repair / block. The 'repair' codes are
the ones a re-finish fixes without touching the edit or the picture content:

    LOUDNESS_OFF   -> normalise to -14 LUFS (one-pass loudnorm)
    TRUE_PEAK_HOT  -> same loudnorm pass caps true peak at -1 dBTP
    NOT_FASTSTART  -> remux with moov before mdat (+faststart)
    CODEC_WRONG    -> re-encode video to H.264 / audio to AAC

repair_file() picks the lightest ffmpeg that fixes every repair code present: a copy-only remux when
only faststart is wrong, an audio-only re-encode for loudness (video copied, untouched), a full
re-encode only when the container/codec itself is wrong. block-level codes (wrong size, black/frozen,
captions reading wrong) are never 'repaired' here - they need a re-render or a human, by design.
"""
import os

from .common import probe, run, safe_remove

REPAIRABLE = {"LOUDNESS_OFF", "TRUE_PEAK_HOT", "NOT_FASTSTART", "CODEC_WRONG"}
_LOUDNORM = "loudnorm=I=-14:TP=-1.0:LRA=11"


def _codes_from(verify):
    if verify and verify.get("codes") is not None:
        return set(verify["codes"])
    # derive from defects if an older verify dict was passed
    from . import reasons
    return {r["code"] for r in reasons.annotate((verify or {}).get("defects", []))}


def plan(verify):
    """Which repair codes present here can this module fix (in the order a user would see them)."""
    present = _codes_from(verify) & REPAIRABLE
    return [c for c in ("CODEC_WRONG", "LOUDNESS_OFF", "TRUE_PEAK_HOT", "NOT_FASTSTART") if c in present]


def repair_file(path, verify, expect=(1080, 1920)):
    """Re-finish `path` in place for whatever repair codes `verify` reports. Returns
    {applied:[codes], changed:bool, note}. No repair codes -> does nothing."""
    codes = plan(verify)
    if not codes:
        return {"applied": [], "changed": False, "note": "nothing to repair"}
    from .common import ffmpeg
    loud = "LOUDNESS_OFF" in codes or "TRUE_PEAK_HOT" in codes
    recode = "CODEC_WRONG" in codes
    tmp = path + ".repair.mp4"

    args = ["-i", path]
    if recode:                                    # container/codec wrong -> full re-encode (30fps, h264/aac)
        args += ["-r", "30", "-c:v", "libx264", "-preset", "veryfast", "-crf", "18", "-pix_fmt", "yuv420p"]
        args += ["-af", _LOUDNORM] if loud else []
        args += ["-c:a", "aac", "-b:a", "256k"]
    elif loud:                                    # keep the picture exactly; re-finish audio only
        args += ["-c:v", "copy", "-af", _LOUDNORM, "-c:a", "aac", "-b:a", "256k"]
    else:                                         # only faststart -> pure remux, no recompression
        args += ["-c", "copy"]
    args += ["-movflags", "+faststart", tmp]

    safe_remove(tmp)
    ffmpeg(args)
    if not os.path.exists(tmp) or os.path.getsize(tmp) < 1024:
        safe_remove(tmp)
        return {"applied": [], "changed": False, "note": "repair produced no output"}
    os.replace(tmp, path)
    return {"applied": codes, "changed": True,
            "note": "re-finished: " + ", ".join(codes).lower().replace("_", " ")}


def finish(path, caption_words=None, expect=(1080, 1920), max_rounds=1, **verify_kw):
    """Verify, auto-repair any repair-level codes, and re-verify. Returns the final verify dict with
    'repaired':[codes] added. Picture/edit are never changed; block-level verdicts are left for a
    re-render. Imported lazily to avoid a cycle with verify."""
    from . import verify as V
    v = V.verify_file(path, caption_words=caption_words, expect=expect, **verify_kw)
    applied = []
    rounds = 0
    while v.get("verdict") == "repair" and rounds < max_rounds:
        r = repair_file(path, v, expect=expect)
        if not r["changed"]:
            break
        applied += r["applied"]
        v = V.verify_file(path, caption_words=caption_words, expect=expect, **verify_kw)
        rounds += 1
    v["repaired"] = applied
    return v

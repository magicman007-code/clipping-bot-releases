"""Transcribe a whole video ONCE (word timestamps), cache it, and write a readable transcript.

Everything downstream (candidate finding, captions, headline writing) reuses this file,
so clips are never re-transcribed and timestamps always agree.

Outputs in <workdir>/:
  words.json       [[start, end, word, prob], ...]   (absolute seconds in the source)
  sentences.json   [{"start","end","text","w0","w1"}]  w0/w1 = word index range
  transcript.txt   "[12:34.5] sentence" one per line - READ THIS to pick moments
"""
import inspect
import json
import os
import re

from .common import ffmpeg, log, probe

_MODELS = {}


def get_model(size):
    if size not in _MODELS:
        from faster_whisper import WhisperModel
        try:
            _MODELS[size] = WhisperModel(size, device="cpu", compute_type="int8",
                                         cpu_threads=max(1, os.cpu_count() or 1))
        except Exception as e:
            msg = str(e)
            if any(k in msg for k in ("403", "401", "Connection", "resolve", "timed out", "SSL", "huggingface",
                                      "LocalEntryNotFound", "offline", "Max retries")):
                raise RuntimeError(
                    "Couldn't download the '%s' speech model (one-time, ~150-500 MB from huggingface.co). "
                    "Check your internet connection / VPN / firewall and try again. (%s)" % (size, msg[:160]))
            raise
    return _MODELS[size]


_BATCHED = {}


LANGUAGE = None


def _language():
    """Forced language (config 'language', default 'en'): auto-detect on noisy stream audio can pick the
    wrong language for a whole clip (seen in Magic Clips: Danish captions on an English clip). 'auto' re-enables it."""
    global LANGUAGE
    if LANGUAGE is None:
        from .common import load_config
        LANGUAGE = load_config().get("language", "en")
    return None if LANGUAGE in ("auto", "", None) else LANGUAGE


def _is_loop(text):
    toks = re.findall(r"[a-z']+", text.lower())
    if len(toks) < 6:
        return False
    grams = [tuple(toks[i:i + 3]) for i in range(len(toks) - 2)]
    return max(grams.count(g) for g in set(grams)) >= 3 or len(set(toks)) / float(len(toks)) < 0.3


def load_audio(path, sr=16000):
    """Any audio/video file -> float32 mono numpy array at 16 kHz, decoded by ffmpeg.
    faster-whisper is handed the samples directly, so it never touches PyAV - whose newer releases
    (av>=15) break faster-whisper's own decoder ("unexpected keyword argument 'metadata_errors'")."""
    import subprocess
    import numpy as np
    r = subprocess.run(["ffmpeg", "-nostdin", "-v", "error", "-i", path, "-vn", "-ac", "1", "-ar", str(sr),
                        "-f", "f32le", "-"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if r.returncode != 0:
        raise RuntimeError("couldn't decode audio: %s" % r.stderr.decode("utf-8", "replace")[-300:])
    return np.frombuffer(r.stdout, np.float32).copy()


def _transcribe_wav(model, wav, vocab, beam, batched=False):
    if isinstance(wav, str):
        wav = load_audio(wav)
    if not len(wav):
        return []
    kw = dict(beam_size=beam, vad_filter=True, word_timestamps=True,
              condition_on_previous_text=False, no_speech_threshold=0.5,
              compression_ratio_threshold=2.2, log_prob_threshold=-1.0,
              temperature=[0.0, 0.2, 0.4, 0.6],
              vad_parameters=dict(min_silence_duration_ms=400))
    if _language():
        kw["language"] = _language()
    params = inspect.signature(model.transcribe).parameters
    if vocab:
        # hotwords bias EVERY window (initial_prompt only biases the first one when
        # condition_on_previous_text=False). This is what fixes mangled names.
        if "hotwords" in params:
            kw["hotwords"] = ", ".join(vocab)
        else:
            kw["initial_prompt"] = ", ".join(vocab)
    segs = None
    if batched and "vad_parameters" in kw:
        try:   # faster-whisper >= 1.1: batched pipeline is several times faster on long audio
            from faster_whisper import BatchedInferencePipeline
            bp = _BATCHED.setdefault(id(model), BatchedInferencePipeline(model=model))
            ok = inspect.signature(bp.transcribe).parameters
            bkw = {k: v for k, v in kw.items() if k in ok and k not in ("vad_parameters",)}
            segs, _ = bp.transcribe(wav, batch_size=8, **bkw)
            segs = list(segs)
        except Exception as e:
            log("batched transcription unavailable (%s) - using standard" % str(e)[:120])
            segs = None
    if segs is None:
        segs, _ = model.transcribe(wav, **kw)
    out = []
    for s in segs:
        # hallucination guards: music/noise "speech", repetition loops, very low confidence
        if getattr(s, "no_speech_prob", 0) > 0.6 and getattr(s, "avg_logprob", 0) < -0.8:
            continue
        if getattr(s, "compression_ratio", 1) > 2.6 or _is_loop(s.text or ""):
            continue
        for w in (s.words or []):
            t = w.word.strip()
            if t:
                out.append([round(w.start, 3), round(w.end, 3), t, round(getattr(w, "probability", 1.0), 3)])
    return merge_number_tokens(out)


def merge_number_tokens(ws):
    """Whisper splits numbers into word tokens: "$100" ",000" / "40" "%" -> one word ("$100,000", "40%"),
    so captions, headlines and subtitles don't show "$100 ,000"."""
    out = []
    for w in ws:
        t = w[2]
        if out and re.match(r"^(?:[,.]\d|%|k\b|K\b)", t) and re.search(r"\d$", out[-1][2]):
            p = out[-1]
            out[-1] = [p[0], max(p[1], w[1]), p[2] + t] + ([min(p[3], w[3])] if len(p) > 3 and len(w) > 3 else p[3:])
        else:
            out.append(list(w))
    return out


def transcribe_video(src, workdir, model_size="small", vocab=None, chunk_s=600, force=False, progress=None):
    """Full-video transcription with resume (safe to call again after a timeout).
    progress(done_chunks, total_chunks) is called before/after each 10-minute chunk."""
    os.makedirs(workdir, exist_ok=True)
    wj = os.path.join(workdir, "words.json")
    if os.path.exists(wj) and not force:
        words = json.load(open(wj))
        write_readables(words, workdir)
        return words
    dur = probe(src)["duration"]
    part = os.path.join(workdir, "words.partial.json")
    st = json.load(open(part)) if os.path.exists(part) and not force else {"next": 0, "words": [], "model": model_size}
    model = get_model(model_size)
    beam = 5 if model_size not in ("tiny", "base") else 3
    n = max(1, int((dur + chunk_s - 1) // chunk_s))
    while st["next"] < n:
        i = st["next"]
        if progress:
            progress(i, n)
        off = i * chunk_s
        wav = os.path.join(workdir, "_chunk.wav")
        # 2s overlap on the left so words at chunk borders are not cut in half
        lead = 2.0 if i > 0 else 0.0
        ffmpeg(["-ss", "%.3f" % (off - lead), "-t", "%.3f" % (min(chunk_s, dur - off) + lead), "-i", src,
                "-vn", "-ac", "1", "-ar", "16000", wav])
        ws = _transcribe_wav(model, wav, vocab, beam, batched=dur > 900)
        last_end = st["words"][-1][1] if st["words"] else -1
        for w in ws:
            w[0] = round(w[0] + off - lead, 3)
            w[1] = round(w[1] + off - lead, 3)
            if w[0] >= last_end - 0.05:
                st["words"].append(w)
        st["next"] = i + 1
        json.dump(st, open(part, "w"))
        log("transcribed chunk %d/%d (%d words)" % (i + 1, n, len(st["words"])))
        os.remove(wav)
    if progress:
        progress(n, n)
    words = st["words"]
    json.dump(words, open(wj, "w"))
    if os.path.exists(part):
        os.remove(part)
    write_readables(words, workdir)
    return words


def sentences_from_words(words, max_gap=0.9, max_len=22.0):
    sents, cur = [], []
    for i, w in enumerate(words):
        if cur and (w[0] - words[i - 1][1] > max_gap or w[1] - words[cur[0]][0] > max_len):
            sents.append(cur); cur = []
        cur.append(i)
        if re.search(r"[.!?]['\"]?$", w[2]):
            sents.append(cur); cur = []
    if cur:
        sents.append(cur)
    out = []
    for idx in sents:
        out.append({"start": words[idx[0]][0], "end": words[idx[-1]][1], "w0": idx[0], "w1": idx[-1],
                    "text": " ".join(words[j][2] for j in idx)})
    return out


def ts(t):
    m, s = divmod(max(0.0, t), 60)
    h, m = divmod(int(m), 60)
    return ("%d:%02d:%04.1f" % (h, m, s)) if h else ("%d:%04.1f" % (m, s))


def write_readables(words, workdir):
    sents = sentences_from_words(words)
    json.dump(sents, open(os.path.join(workdir, "sentences.json"), "w"))
    with open(os.path.join(workdir, "transcript.txt"), "w") as f:
        for s in sents:
            f.write("[%s] %s\n" % (ts(s["start"]), s["text"]))
    return sents


def words_in(words, a, b):
    """Words fully inside [a,b], re-timed to start at 0."""
    return [(w[0] - a, w[1] - a, w[2]) for w in words if w[0] >= a - 0.05 and w[1] <= b + 0.15]

"""Independent verification of a FINISHED clip + the human QC gate.

verify_file() re-measures everything from the delivered mp4 alone (never trusts render
reports - a lesson from Magic Clips' audit, where a QC "pass" was copied from a report):
  container: 1080x1920, ~30fps, h264/aac, faststart (moov before mdat)
  audio:     integrated loudness -14 +/-1.5 LUFS, true peak <= -1.0 dBTP, no long silences
  video:     no black stretches, no frozen stretches, no letterboxing / pillarboxing
  captions:  word error rate of the burned caption words vs an independent re-transcription
             of the delivered audio (only when a whisper model is available; reported as None
             otherwise, never guessed)

QC gate (qc.json beside the clips): every clip is pending until a human approves it.
"""
import json
import os
import re
import time

from .common import safe_remove, probe, run, save_json


def _faststart(path):
    with open(path, "rb") as f:
        head = f.read(1 << 20)
    m, d = head.find(b"moov"), head.find(b"mdat")
    return m != -1 and (d == -1 or m < d)


def _codecs(path):
    r = run(["ffprobe", "-v", "error", "-show_entries", "stream=codec_type,codec_name,avg_frame_rate", "-of", "json", path])
    return json.loads(r.stdout).get("streams", [])


def _loudness(path):
    r = run(["ffmpeg", "-hide_banner", "-nostats", "-i", path, "-vn", "-af", "ebur128=peak=true",
             "-f", "null", "-"], check=False)
    i = re.findall(r"I:\s+(-?[\d.]+) LUFS", r.stderr)
    tp = re.findall(r"Peak:\s+(-?[\d.inf]+) dBFS", r.stderr)
    to = lambda v: None if "inf" in v else float(v)       # -inf = silent / measurement failed
    if r.returncode != 0:
        return None, None
    return (float(i[-1]) if i else None), (to(tp[-1]) if tp else None)


def _detect(path, dur):
    vf = "blackdetect=d=0.5:pix_th=0.08,freezedetect=n=0.0008:d=4,cropdetect=limit=0.08:round=2:reset=0"
    r = run(["ffmpeg", "-hide_banner", "-i", path, "-vf", vf, "-af", "silencedetect=n=-45dB:d=1.2", "-f", "null", "-"],
            check=False, timeout=900)
    e = r.stderr
    black = [(float(a), float(b)) for a, b in re.findall(r"black_start:([\d.]+) black_end:([\d.]+)", e)]
    freeze = [float(x) for x in re.findall(r"freeze_duration: ([\d.]+)", e)]
    sil = [float(x) for x in re.findall(r"silence_duration: ([\d.]+)", e)]
    crops = re.findall(r"crop=(\d+):(\d+):(\d+):(\d+)", e)
    crop = tuple(int(v) for v in crops[-1]) if crops else None
    return black, freeze, sil, crop


_ASR_OK = None


def _asr_available(model):
    """A cached whisper model, or a reachable model host - otherwise skip instead of retrying downloads."""
    global _ASR_OK
    if _ASR_OK is None:
        import glob
        import socket
        cached = glob.glob(os.path.expanduser("~/.cache/huggingface/hub/models--Systran--faster-whisper-%s" % model))
        if cached:
            _ASR_OK = True
        else:
            try:
                socket.create_connection(("huggingface.co", 443), timeout=4).close()
                _ASR_OK = True
            except OSError:
                _ASR_OK = False
    return _ASR_OK


def caption_wer(path, caption_words, model="base"):
    """WER of burned caption words against an independent transcription of the delivered audio."""
    if not _asr_available(model):
        return None, "skipped: no speech model available offline"
    try:
        from .transcribe import _transcribe_wav, get_model
        from .common import ffmpeg
        wav = path + ".verify16k.wav"
        ffmpeg(["-i", path, "-vn", "-ac", "1", "-ar", "16000", wav])
        hyp = [w[2] for w in _transcribe_wav(get_model(model), wav, None, 3)]
        safe_remove(wav)
    except Exception as e:
        return None, "no ASR available (%s)" % str(e)[:80]
    norm = lambda ws: [re.sub(r"[^a-z0-9$%']", "", w.lower()) for w in ws if re.sub(r"[^a-z0-9$%']", "", w.lower())]
    ref, hy = norm(hyp), norm(caption_words)
    if not ref:
        return None, "re-transcription empty"
    d = list(range(len(hy) + 1))
    for i in range(1, len(ref) + 1):
        prev, d[0] = d[0], i
        for j in range(1, len(hy) + 1):
            cur = min(d[j] + 1, d[j - 1] + 1, prev + (ref[i - 1] != hy[j - 1]))
            prev, d[j] = d[j], cur
    return round(d[len(hy)] / float(len(ref)), 3), "vs independent '%s' transcription" % model


def caption_check(path, shown, caption_model="small"):
    """Wrong words ON SCREEN, against an independent transcription of the delivered clip's audio (matched by time).
    The reference is the strongest speech model on this computer, decoded with steadier settings than the captions.
    Returns (rate or None, note, details)."""
    from . import captions as capq
    ref_model = (capq.installed() or [None])[0]
    if not ref_model:
        if not _asr_available("small"):
            return None, "not checked: no speech model on this computer yet", {}
        ref_model = "small"
    try:
        from .transcribe import _transcribe_wav, get_model
        from .common import ffmpeg
        wav = path + ".verify16k.wav"
        ffmpeg(["-i", path, "-vn", "-ac", "1", "-ar", "16000", wav])
        m = get_model(ref_model)
        orig = m.transcribe
        m.transcribe = lambda w, **kw: orig(w, **dict(kw, vad_parameters=dict(min_silence_duration_ms=700, threshold=0.4)))
        try:
            ref = _transcribe_wav(m, wav, None, 5)
        finally:
            m.transcribe = orig
            safe_remove(wav)
    except Exception as e:
        return None, "not checked (%s)" % str(e)[:80], {}
    d = capq.check(shown, ref)
    if d["wer"] is None:
        return None, "not checked: nothing to compare", d
    same = ref_model == caption_model
    note = "%d%% wrong words on screen vs an independent %s transcription%s; %d%% of speech captioned" % (
        round(100 * d["wer"]), ref_model, " (same model, different settings)" if same else "", round(100 * (d["coverage"] or 0)))
    if d.get("unchecked"):
        note += "; %d line(s) not checkable" % d["unchecked"]
    return d["wer"], note, d


def verify_file(path, caption_words=None, wer_model="base", check_wer=True, expect=(1080, 1920), max_silence=1.2,
                caption_model="small", edited=False):
    defects = []
    p = probe(path)
    if (p["width"], p["height"]) != tuple(expect):
        defects.append("resolution %dx%d (want %dx%d)" % (p["width"], p["height"], expect[0], expect[1]))
    if abs(p["fps"] - 30) > 0.5:
        defects.append("frame rate %.2f (want 30)" % p["fps"])
    st = _codecs(path)
    vc = [s["codec_name"] for s in st if s["codec_type"] == "video"]
    ac = [s["codec_name"] for s in st if s["codec_type"] == "audio"]
    if vc != ["h264"] or ac != ["aac"]:
        defects.append("codecs video=%s audio=%s (want h264/aac)" % (vc, ac))
    fs = _faststart(path)
    if not fs:
        defects.append("not faststart (moov after mdat) - slow to start on phones")
    lufs, tp = _loudness(path)
    if lufs is None or abs(lufs + 14) > 1.5:
        defects.append("loudness %s LUFS (want -14 +/-1.5)" % lufs)
    if tp is not None and tp > -1.0:
        defects.append("true peak %.2f dBTP (want <= -1.0; risk of clipping after platform transcode)" % tp)
    black, freeze, sil, crop = _detect(path, p["duration"])
    if black:
        defects.append("black frames: %s" % ", ".join("%.1f-%.1fs" % b for b in black[:4]))
    if freeze:
        defects.append("frozen picture for %.1fs" % max(freeze))
    sil = [x for x in sil if x > max_silence]
    if sil:
        defects.append("dead air: %d silence(s), longest %.1fs" % (len(sil), max(sil)))
    if crop and (crop[0] < expect[0] * 0.93 or crop[1] < expect[1] * 0.93):
        defects.append("letterbox/pillarbox: active picture %dx%d of %dx%d" % (crop[0], crop[1], expect[0], expect[1]))
    wer, wer_note, cap_detail = (None, "skipped", {})
    if check_wer and caption_words:
        if all(isinstance(w, (list, tuple)) and len(w) >= 3 for w in caption_words):
            wer, wer_note, cap_detail = caption_check(path, caption_words, caption_model)
        else:                                   # plain word list (older callers): whole-clip comparison
            wer, wer_note = caption_wer(path, caption_words, wer_model)
        if edited and wer is not None:
            wer_note += "; captions were edited by a person"
        if wer is not None and wer > 0.08 and not edited:
            defects.append("captions: %.0f%% wrong words on screen (bar is 8%%) - check them in Captions, or approve "
                           "them if they're right" % (wer * 100))
    return {"file": path, "ok": not defects, "defects": defects, "duration": round(p["duration"], 2),
            "lufs": lufs, "true_peak": tp, "faststart": fs, "caption_wer": wer, "wer_note": wer_note,
            "caption_coverage": cap_detail.get("coverage"), "caption_worst": cap_detail.get("worst", []),
            "verified_at": time.strftime("%Y-%m-%dT%H:%M:%S")}


# ---------------------------------------------------------------- human QC gate
def _qc_path(outdir):
    return os.path.join(outdir, "qc.json")


def qc_load(outdir):
    p = _qc_path(outdir)
    return json.load(open(p)) if os.path.exists(p) else {}


def qc_save(outdir, q):
    save_json(_qc_path(outdir), q)


def qc_register(outdir, name, out, verify=None, source="render"):
    q = qc_load(outdir)
    prev = q.get(name, {})
    q[name] = {"file": out, "status": "pending", "source": source, "registered": time.strftime("%Y-%m-%dT%H:%M:%S"),
               "verify": verify, "history": prev.get("history", []) + ([prev["status"]] if prev.get("status") else [])}
    qc_save(outdir, q)
    return q[name]


def qc_set(outdir, name, status, note="", watched=False):
    q = qc_load(outdir)
    if name not in q:
        raise KeyError("no clip %r in %s" % (name, _qc_path(outdir)))
    if status == "approved" and not watched:
        raise ValueError("approve requires --watched: a person must watch the whole clip first")
    if status == "approved" and q[name].get("verify") and not q[name]["verify"].get("ok"):
        if not note:
            raise ValueError("clip has verifier defects %s - approve with a note explaining why it's acceptable"
                             % q[name]["verify"]["defects"])
    q[name].update(status=status, note=note, decided=time.strftime("%Y-%m-%dT%H:%M:%S"))
    qc_save(outdir, q)
    return q[name]

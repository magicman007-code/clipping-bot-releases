"""Automatic QA for a rendered clip + a contact sheet to LOOK at before delivering.

Checks: resolution/duration/audio, integrated loudness, headline card actually drawn,
captions not sitting on a face (YuNet run on the OUTPUT frames), black/frozen frames.
"""
import os
import re

import numpy as np

from .common import YUNET, probe, run


def _frame(path, t):
    import cv2
    cap = cv2.VideoCapture(path)
    cap.set(cv2.CAP_PROP_POS_MSEC, t * 1000)
    ok, img = cap.read()
    cap.release()
    return img if ok else None


def integrated_lufs(path):
    r = run(["ffmpeg", "-hide_banner", "-nostats", "-i", path, "-vn", "-af", "ebur128",
             "-f", "null", "-"], check=False)
    m = re.findall(r"I:\s+(-?[\d.]+) LUFS", r.stderr)
    return float(m[-1]) if m else None


def check_clip(out, res, plan, samples, w0, h0, body_h, outdir, expect=(1080, 1920)):
    import cv2
    warn = []
    p = probe(out)
    OW, OH = expect
    if (p["width"], p["height"]) != tuple(expect):
        warn.append("output is %dx%d, expected %dx%d" % (p["width"], p["height"], OW, OH))
    if abs(p["duration"] - res["dur"]) > 0.25:
        warn.append("duration %.2fs differs from cut %.2fs" % (p["duration"], res["dur"]))
    if not p["has_audio"]:
        warn.append("no audio stream")
    lufs = integrated_lufs(out)
    if lufs is None or abs(lufs + 14) > 1.5:
        warn.append("loudness %s LUFS (target -14)" % lufs)
    if res["dur"] > 62:
        warn.append("%.0fs is long for a short; consider jump-cutting to <=45s" % res["dur"])
    if res["words"] == 0:
        warn.append("no caption words")

    # hook checks (viewers decide in ~1.5-3s; first frame must show the subject)
    fw = res.get("first_word_at")
    if fw is not None and fw > 0.8:
        warn.append("speech starts at %.1fs - cold-open closer to the first word" % fw)
    if res.get("words") and res.get("words_first3s", 99) < 4:
        warn.append("slow open: only %d words in the first 3s" % res["words_first3s"])

    dur = p["duration"]
    times = [min(dur - 0.1, max(0.2, dur * k / 8.0 + 0.3)) for k in range(8)]
    frames = [_frame(out, t) for t in times]
    vertical = res["layout"] == "vertical"

    # headline card drawn? (white box pixels where the card should be)
    if res.get("headline"):
        f = frames[1] if frames[1] is not None else frames[0]
        if f is not None:
            y = (res.get("head_y") or 300) if (vertical or res["layout"] == "frame") else 154
            roi = f[max(0, y - 40): y + 40, int(OW * 0.4): int(OW * 0.6)]
            white = float((roi.min(axis=2) > 225).mean())
            if white < 0.12:
                warn.append("headline card not visible (white fraction %.2f)" % white)

    # captions vs faces, measured on the output itself
    dw, dh = OW // 2, OH // 2
    det = cv2.FaceDetectorYN.create(YUNET, "", (dw, dh), 0.6, 0.3, 5000)
    hits = 0
    for t, f in zip(times, frames):
        if f is None:
            continue
        cap_y = next((pl[3] for pl in plan if pl[0] - 0.01 <= t < pl[1]), None)
        if cap_y is None:
            continue
        _, fs = det.detect(cv2.resize(f, (dw, dh)))
        for r in (fs if fs is not None else []):
            x, y, w, h = (r[:4] * 2).tolist()
            # caption block is ~120px tall centred on cap_y; overlap with the face's eyes-to-mouth zone
            if y + 0.15 * h < cap_y + 60 and y + 0.85 * h > cap_y - 60 and w > 90:
                hits += 1
                break
    src_has_faces = any(len(ff) for _, ff in (samples or []))   # faceless content (gameplay, screens) is fine
    if src_has_faces and res["layout"] not in ("facecam_screen", "blur_fit") and frames[0] is not None and not any(
            "fit frame" in x or "blur_fit frame" in x for x in res.get("layout_log", [])):
        f0 = _frame(out, 0.05)
        if f0 is not None:
            _, fs0 = det.detect(cv2.resize(f0, (dw, dh)))
            if fs0 is None or len(fs0) == 0:
                warn.append("no face visible in the first frame - open on the subject")
    if hits >= 2:
        warn.append("captions overlap a face in %d/8 sampled frames" % hits)

    dark = sum(1 for f in frames if f is not None and f[int(OH * 0.15): int(OH * 0.93)].mean() < 12)
    if dark >= 2:
        warn.append("%d/8 sampled frames are near-black" % dark)

    # contact sheet 4x2
    tiles = []
    for t, f in zip(times, frames):
        tw, th = (270, int(270 * OH / OW)) if OW <= OH else (int(480 * OW / OH) // 2 * 2, 480)
        th = th // 2 * 2
        img = cv2.resize(f, (tw, th)) if f is not None else np.zeros((th, tw, 3), np.uint8)
        cv2.putText(img, "%.1fs" % t, (6, th - 8), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1, cv2.LINE_AA)
        tiles.append(img)
    sheet = np.vstack([np.hstack(tiles[:4]), np.hstack(tiles[4:])])
    sp = os.path.join(outdir, res["name"] + "_sheet.jpg")
    cv2.imwrite(sp, sheet, [cv2.IMWRITE_JPEG_QUALITY, 85])
    return {"ok": not warn, "warnings": warn, "lufs": lufs, "sheet": sp}

"""Carousels: swipeable image posts (Instagram, TikTok photo mode, LinkedIn, X) made from the stream's own words.

plan(d, n=7, use_ai=True)   -> {"title", "slides": [{"kind", "heading", "quote", "t", "frame_t"}], "caption", "source"}
    cover (a hook + the streamer's face) -> one slide per best moment (a real quote from the transcript, cleaned of
    "um"/"you know") -> a closing slide. Moments come from the clips you made (best grade first), then the moment list.
    With an AI connected it writes the hook and the short headings; every AI line is fact-checked against what was said
    and quotes must match the transcript word for word, or the plain version is used instead.
render(d, plan, shape, style) -> {"dir", "files": [png...], "caption_file"}
    1080x1350 (4:5, Instagram's tallest), 1080x1080 or 1080x1920 (TikTok photo mode). Each slide uses a real frame
    from that moment of the video.
"""
import json
import os
import re

import numpy as np

from .common import FONT_DIR, load_store, log, save_json

SHAPES = {"4:5": (1080, 1350), "1:1": (1080, 1080), "9:16": (1080, 1920)}
STYLES = {
    "night": {"bg": (14, 15, 20), "fg": (255, 255, 255), "mut": (170, 174, 188), "acc": (255, 210, 64), "acc_fg": (16, 16, 16)},
    "paper": {"bg": (246, 244, 238), "fg": (18, 18, 22), "mut": (96, 98, 110), "acc": (255, 214, 0), "acc_fg": (18, 18, 22)},
    "bold": {"bg": (232, 46, 58), "fg": (255, 255, 255), "mut": (255, 214, 214), "acc": (16, 16, 16), "acc_fg": (255, 255, 255)},
}
NUMW = r"\b(one|two|three|four|five|six|seven|eight|nine|ten|twelve|fifteen|twenty|thirty|forty|fifty|hundred|thousand|million|billion)\b"
UNITS = r"^(k|m|million|billion|thousand|hundred|dollars?|bucks|followers|subs|subscribers|viewers|views|percent|%|grand|times|hours|minutes|days|weeks|years)[.,!?]?$"
FILLERS = r"\b(um+|uh+|erm|you know|i mean|like,|sort of|kind of|basically|literally)\b[,]?\s*"


# ------------------------------------------------------------------------------------------- what goes on the slides
def clean(text):
    t = re.sub(FILLERS, "", " " + text + " ", flags=re.I)
    t = re.sub(r"^\s*(so|and|but|okay|ok|yeah|alright)[,]?\s+", "", t.strip(), flags=re.I)
    t = re.sub(r"\s+([,.!?])", r"\1", re.sub(r"\s{2,}", " ", t)).strip(" ,")
    return (t[:1].upper() + t[1:]) if t else t


def _quote_score(s):
    w = s.split()
    n = len(w)
    if n < 5:
        return -1
    sc = 1.0 - abs(n - 16) / 20.0                              # 10-22 words reads best on a slide
    sc += 0.25 * bool(re.search(r"[!?]", s)) + 0.9 * bool(re.search(r"\$?\d|" + NUMW, s, re.I))
    sc -= 0.5 * bool(re.match(r"^(let's go|we did it|oh my god|no way|yo)\b", s, re.I))
    sc += 0.4 * bool(re.search(r"\b(never|always|nobody|everyone|best|worst|craziest|insane|actually|literally)\b", s, re.I))
    sc -= 0.8 * bool(re.search(r"\b(chart|here|this|that)\b\W*$", s, re.I))   # ends pointing at the screen
    return sc


def _moments(d, n):
    specs = load_store(os.path.join(d, "specs.json"), [], list)
    cands = load_store(os.path.join(d, "candidates.json"), [], list)

    def gnum(sp):
        g = sp.get("grade") or {}
        return g.get("score") if isinstance(g, dict) else g
    out = []
    for sp in sorted(specs, key=lambda s: -(gnum(s) or 0)):
        if "start" in sp and "end" in sp:
            out.append({"a": float(sp["start"]), "b": float(sp["end"]), "heading": sp.get("headline") or "",
                        "name": sp.get("name")})
    for c in sorted(cands, key=lambda c: -c.get("score", 0)):
        if all(c["end"] <= m["a"] or c["start"] >= m["b"] for m in out):
            out.append({"a": float(c["start"]), "b": float(c["end"]), "heading": "", "name": None})
    return out[:n]


def _best_quote(sents, a, b):
    inside = [s for s in sents if s["start"] >= a - 0.5 and s["end"] <= b + 0.5]
    best, bs = None, -9
    for i, s in enumerate(inside):                  # a sentence, or two short neighbours together
        for txt, t0, t1 in [(s["text"], s["start"], s["end"])] + (
                [(s["text"] + " " + inside[i + 1]["text"], s["start"], inside[i + 1]["end"])] if i + 1 < len(inside) else []):
            c = clean(txt)
            if len(c.split()) > 30:
                continue
            sc = _quote_score(c)
            if sc > bs:
                best, bs = (c, t0, t1), sc
    return best


def _norm(s):
    return re.sub(r"[^a-z0-9 ]", "", s.lower().replace("-", " ")).split()


def _verbatim(quote, text):
    """True when every word of the quote appears, in order and next to each other, in the transcript (fillers aside)."""
    q, t = _norm(quote), _norm(clean(text))
    if len(q) < 3:
        return False
    k = len(q)
    return any(t[i:i + k] == q for i in range(len(t) - k + 1))


def plan(d, n=7, use_ai=True, handle=""):
    sents = load_store(os.path.join(d, "sentences.json"), [], list)
    if not sents:
        raise RuntimeError("This project has no transcript yet. Auto-clip it first.")
    full = " ".join(s["text"] for s in sents)
    slides = []
    for m in _moments(d, max(1, n - 2)):
        q = _best_quote(sents, m["a"], m["b"])
        if not q:
            continue
        heading = m["heading"]
        if len(heading.split()) > 9:
            heading = ""
        slides.append({"kind": "quote", "heading": heading, "quote": q[0], "t": round(q[1], 2),
                       "frame_t": round((q[1] + q[2]) / 2, 2)})
    if not slides:
        raise RuntimeError("Couldn't find quotable moments in this stream.")
    slides.sort(key=lambda s: s["t"])                                   # tell it in the order it happened
    top = load_store(os.path.join(d, "specs.json"), [], list)
    hook = (top[0].get("headline") if top else "") or slides[0]["quote"]
    title = hook if len(hook) <= 70 else " ".join(hook.split()[:10]) + "…"
    src = "transcript"
    if use_ai:
        try:
            from .connect import ai_ready, ai_complete, ai_source
            from .packaging import _supported
            if ai_ready():
                system = ("You turn a livestream into an Instagram carousel. Use ONLY what is in the quotes. No invented "
                          "facts, numbers or names. Return JSON: {\"hook\": \"cover line, max 9 words\", \"headings\": "
                          "[one 2-6 word heading per quote, in order]}.")
                prompt = "Quotes from the stream, in order:\n" + "\n".join(
                    "%d. %s" % (i + 1, s["quote"]) for i, s in enumerate(slides)) + "\n\nWrite the hook and the headings."
                out = ai_complete(prompt, system=system, max_tokens=400, wait=5)
                j = json.loads(re.search(r"\{.*\}", out, re.S).group(0))
                ok_hook, _ = _supported(j.get("hook", ""), full)
                if j.get("hook") and ok_hook and len(j["hook"].split()) <= 12:
                    title = j["hook"].strip()
                for s, h in zip(slides, j.get("headings") or []):
                    h = str(h).strip()
                    if h and len(h.split()) <= 7 and _supported(h, s["quote"])[0]:
                        s["heading"] = h
                src = ai_source() or "ai"
        except Exception as e:
            log("carousel AI skipped (%s)" % str(e)[:100])
    for s in slides:                                                    # never put words in their mouth
        if not _verbatim(s["quote"], full):
            s["quote"] = clean(s["quote"])
    face_t = slides[0]["frame_t"]
    out = [{"kind": "cover", "heading": title, "quote": "", "t": slides[0]["t"], "frame_t": face_t}] + slides + \
        [{"kind": "end", "heading": "Follow for more" if not handle else "Follow %s" % handle,
          "quote": "Full stream on the channel", "t": slides[-1]["t"], "frame_t": slides[-1]["frame_t"]}]
    tags = " ".join("#" + t for t in ("stream", "streamer", "clips", "podcast"))
    caption = "%s\n\n%s\n\nSwipe through ➡️\n\n%s" % (title, slides[0]["quote"], tags)
    return {"title": title, "slides": out, "caption": caption, "source": src}


# ------------------------------------------------------------------------------------------- drawing
def _font(name, size):
    from PIL import ImageFont
    for f in (name, "Inter_Black.ttf", "Montserrat-Black.ttf"):
        p = os.path.join(FONT_DIR, f)
        if os.path.exists(p):
            return ImageFont.truetype(p, size)
    return ImageFont.load_default()


def _wrap(draw, text, font, width):
    lines, cur = [], ""
    for w in text.split():
        t = (cur + " " + w).strip()
        if not cur or draw.textlength(t, font=font) <= width:
            cur = t
        else:
            lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines


def _fit(draw, text, fname, width, height, hi, lo=34, gap=1.18):
    for size in range(hi, lo - 1, -2):
        f = _font(fname, size)
        lines = _wrap(draw, text, f, width)
        if len(lines) * size * gap <= height:
            return f, lines, int(size * gap)
    f = _font(fname, lo)
    return f, _wrap(draw, text, f, width), int(lo * gap)


def _frame(video, t):
    import cv2
    cap = cv2.VideoCapture(video)
    cap.set(cv2.CAP_PROP_POS_MSEC, max(0.0, t) * 1000)
    ok, img = cap.read()
    cap.release()
    if not ok:
        return None
    from PIL import Image
    return Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))


def _face_x(im):
    """Centre of the biggest face (0..1), so the crop keeps the person."""
    try:
        import cv2
        from .common import YUNET
        a = np.array(im.convert("RGB"))[:, :, ::-1]
        h, w = a.shape[:2]
        sw = 640
        sh = int(h * sw / w)
        det = cv2.FaceDetectorYN.create(YUNET, "", (sw, sh), 0.6, 0.3, 5000)
        _, fs = det.detect(cv2.resize(a, (sw, sh)))
        if fs is not None and len(fs):
            f = max(fs, key=lambda r: r[2] * r[3])
            return float(f[0] + f[2] / 2) / sw
    except Exception:
        pass
    return 0.5


def _cover_crop(im, W, H, fx=0.5):
    from PIL import Image
    s = max(W / im.width, H / im.height)
    r = im.resize((int(im.width * s + 0.5), int(im.height * s + 0.5)), Image.LANCZOS)
    x = int(min(max(0, fx * r.width - W / 2), r.width - W))
    y = int((r.height - H) / 2)
    return r.crop((x, y, x + W, y + H))


def _highlight_words(text):
    """The words that get the marker: the amount ("$12K", "twelve thousand dollars", "10 million views"), else the
    single strongest word. Max 3 words, so it stays a highlight."""
    ws = text.split()
    isnum = [bool(re.search(r"\d", w) or re.match(NUMW + r"[.,!?]?$", w, re.I)) for w in ws]
    runs, i = [], 0
    while i < len(ws):
        if isnum[i]:
            j = i
            while j + 1 < len(ws) and j - i < 2 and (isnum[j + 1] or re.match(UNITS, ws[j + 1], re.I)):
                j += 1
            run = " ".join(ws[i:j + 1]).lower()
            weight = (j - i + 1) + 3 * bool(re.search(r"\d|\$|hundred|thousand|million|billion|k\b", run))
            runs.append((weight, i, j))
            i = j + 1
        else:
            i += 1
    runs = [r for r in runs if r[0] >= 2 or re.search(r"\d", ws[r[1]])]    # a lone "one" isn't an amount
    if runs:
        _, i, j = max(runs)
        return set(range(i, j + 1))
    strong = [i for i, w in enumerate(ws) if len(re.sub(r"\W", "", w)) >= 6
              and not re.match(r"^(actually|literally|everything|something|anything|because|thought)$", re.sub(r"\W", "", w), re.I)]
    return {max(strong, key=lambda i: len(ws[i]))} if strong else set()


def _draw_lines(d, lines, f, x, y, lh, st, marks=None, start_index=0, align="left", width=0):
    """Text with a highlighter marker behind the marked words (like a real carousel)."""
    k = start_index
    for line in lines:
        words = line.split()
        lw = d.textlength(line, font=f)
        cx = x + (width - lw) / 2 if align == "center" else x
        for w in words:
            ww = d.textlength(w, font=f)
            if marks and k in marks:
                pad = int(lh * 0.08)
                top, bot = (y + lh * 0.16, y + lh * 0.98) if lh < f.size * 1.12 else (y + lh * 0.08, y + lh * 0.86)
                d.rounded_rectangle([cx - pad, top, cx + ww + pad, bot], radius=int(lh * 0.12), fill=st["acc"])
                d.text((cx, y), w, font=f, fill=st["acc_fg"])
            else:
                d.text((cx, y), w, font=f, fill=st["fg"])
            cx += ww + d.textlength(" ", font=f)
            k += 1
        y += lh
    return y


def draw_slide(sl, i, n, img, W, H, st, handle=""):
    from PIL import Image, ImageDraw, ImageFilter
    canvas = Image.new("RGB", (W, H), st["bg"])
    d = ImageDraw.Draw(canvas)
    M = 84
    if sl["kind"] == "cover":
        if img is not None:                                    # the streamer, full bleed, fading into the title
            ph = _cover_crop(img, W, H, _face_x(img))
            canvas.paste(ph, (0, 0))
            grad = Image.new("L", (1, H))
            for y in range(H):
                grad.putpixel((0, y), int(255 * min(1, max(0, (y / H - 0.30) / 0.42)) ** 1.2))
            shade = Image.new("RGB", (W, H), st["bg"])
            canvas = Image.composite(shade, canvas, grad.resize((W, H)))
            d = ImageDraw.Draw(canvas)
        f, lines, lh = _fit(d, sl["heading"].upper(), "Anton-Regular.ttf", W - 2 * M, H * 0.30, 150, 64, 1.05)
        y = H - M - 90 - lh * len(lines)
        _draw_lines(d, lines, f, M, y, lh, st, _highlight_words(sl["heading"].upper()))
        sw = _font("Inter_Black.ttf", 34)
        d.text((M, H - M - 40), "SWIPE", font=sw, fill=st["mut"])
        ax = M + d.textlength("SWIPE", font=sw) + 22
        ay = H - M - 40 + 21                                   # a drawn arrow: not every font has one
        d.line([ax, ay, ax + 46, ay], fill=st["mut"], width=5)
        d.polygon([(ax + 56, ay), (ax + 40, ay - 12), (ax + 40, ay + 12)], fill=st["mut"])
    elif sl["kind"] == "end":
        if img is not None:
            bg = _cover_crop(img, W, H, _face_x(img)).filter(ImageFilter.GaussianBlur(28))
            canvas = Image.blend(Image.new("RGB", (W, H), st["bg"]), bg, 0.28)
            d = ImageDraw.Draw(canvas)
        f, lines, lh = _fit(d, sl["heading"], "Anton-Regular.ttf", W - 2 * M, H * 0.3, 140, 60, 1.05)
        y = H / 2 - lh * len(lines) / 2 - 40
        y = _draw_lines(d, lines, f, M, y, lh, st, None, align="center", width=W - 2 * M)
        sub = _font("Inter_Medium.ttf", 44)
        tw = d.textlength(sl["quote"], font=sub)
        d.text(((W - tw) / 2, y + 56), sl["quote"], font=sub, fill=st["mut"])
    else:                                                      # a quote: photo strip on top, the words below
        ph_h = int(H * (0.42 if H > W else 0.36))
        if img is not None:
            ph = _cover_crop(img, W, ph_h, _face_x(img))
            canvas.paste(ph, (0, 0))
            fade = Image.new("L", (1, ph_h))
            for y in range(ph_h):
                fade.putpixel((0, y), int(255 * max(0, (y / ph_h - 0.72) / 0.28)))
            canvas.paste(Image.new("RGB", (W, ph_h), st["bg"]), (0, 0), fade.resize((W, ph_h)))
            d = ImageDraw.Draw(canvas)
        y = ph_h + 26
        if sl.get("heading"):
            hf, hl, hlh = _fit(d, sl["heading"].upper(), "Inter_Black.ttf", W - 2 * M, 130, 52, 34, 1.12)
            for l in hl:
                d.text((M, y), l, font=hf, fill=st["mut"])
                y += hlh
            y += 18
        qf = _font("Playfair_Display_ExtraBold_Italic.ttf", 150)
        d.text((M - 8, y - 40), "“", font=qf, fill=st["acc"] if st["acc"] != st["bg"] else st["fg"])
        y += 70
        foot = 110
        f, lines, lh = _fit(d, sl["quote"], "Inter_Black.ttf", W - 2 * M, H - y - foot - 20, 88, 38, 1.22)
        _draw_lines(d, lines, f, M, y, lh, st, _highlight_words(sl["quote"]))
    # footer: handle + page number (not on the cover)
    if sl["kind"] != "cover":
        ff = _font("Inter_Medium.ttf", 30)
        d.text((M, H - 70), handle or "", font=ff, fill=st["mut"])
        pg = "%d/%d" % (i + 1, n)
        d.text((W - M - d.textlength(pg, font=ff), H - 70), pg, font=ff, fill=st["mut"])
    return canvas


def render(d, pl, shape="4:5", style="night", handle="", out_dir=None):
    W, H = SHAPES.get(shape, SHAPES["4:5"])
    st = STYLES.get(style, STYLES["night"])
    video = os.path.join(d, "source.mp4")
    out_dir = out_dir or os.path.join(d, "renders", "carousel")
    os.makedirs(out_dir, exist_ok=True)
    for f in os.listdir(out_dir):                                  # a fresh set every time
        if f.startswith("slide_") and f.endswith(".png"):
            os.remove(os.path.join(out_dir, f))
    files = []
    n = len(pl["slides"])
    for i, sl in enumerate(pl["slides"]):
        img = _frame(video, sl.get("frame_t", sl.get("t", 0))) if os.path.exists(video) else None
        im = draw_slide(sl, i, n, img, W, H, st, handle)
        p = os.path.join(out_dir, "slide_%02d.png" % (i + 1))
        im.save(p, optimize=True)
        files.append(p)
    cap = os.path.join(out_dir, "caption.txt")
    with open(cap, "w", encoding="utf-8") as f:
        f.write(pl.get("caption", ""))
    save_json(os.path.join(out_dir, "carousel.json"), dict(pl, shape=shape, style=style, handle=handle))
    return {"dir": out_dir, "files": files, "caption_file": cap, "size": [W, H]}

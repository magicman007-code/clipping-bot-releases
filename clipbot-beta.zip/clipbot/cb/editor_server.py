"""Local web editor backend (stdlib only).

python3 clipbot.py editor [--port 8765] [--root /home/user/clips]
Open http://127.0.0.1:8765 . A "project" is any folder with source.mp4 (+ words.json).
"""
import glob
import json
import mimetypes
import os
import sys
import re
import threading
import time
import traceback
import urllib.parse
import uuid
import wave
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

import numpy as np

from .common import safe_remove, FONT_DIR, ROOT, ffmpeg, load_config, log, probe, save_json, load_json, CONFIG_PATH
from . import connect

EDITOR_HTML = os.path.join(ROOT, "editor", "index.html")
JOBS = {}
LIVE = {}
LIVE_STOPPED = {}          # live ids the user stopped (ends an always-on loop)
LIVE_ALWAYS = set()        # live ids in always-on mode


_BG_LOCK = threading.Lock()


def _scheduled_post(e):
    """Posts one scheduled entry (TikTok draft or posting folder). Raises with a readable reason."""
    from . import post as _post, social
    vid = os.path.join(e["project"], "renders", e["clip"] + ".mp4")
    if not os.path.isfile(vid):
        raise RuntimeError("the rendered clip is gone - render %s again" % e["clip"])
    spec = _post._spec(e["project"], e["clip"]) or {}
    title = e.get("title") or spec.get("headline") or e["clip"]
    try:
        if e["platform"] == "tiktok_draft":
            r = social.tt_upload(vid, "draft")
            r.update(social.tt_wait(r["publish_id"]))
            where = "your TikTok inbox"
        elif e["platform"] == "folder":
            r = _post.to_folder(vid, spec, (connect.get().get("post_folder") or {}).get("path"), os.path.basename(e["project"]))
            where = "your posting folder"
        else:
            raise RuntimeError("can't post to %s on a schedule" % e["platform"])
    except Exception as ex:
        connect.fire("post_failed", {"title": "Scheduled post of %s" % title, "error": str(ex)[:200]})
        raise
    connect.fire("posted", {"title": title, "platform": where, "url": r.get("url")})
    return {k: v for k, v in r.items() if isinstance(v, (str, int, float, bool, list)) or v is None}


def _schedule_youtube(entries):
    """YouTube entries are uploaded now as private videos that YouTube publishes at their time."""
    import datetime as _dt
    from . import post as _post, schedule
    out = []
    for e in entries:
        spec = _post._spec(e["project"], e["clip"]) or {}
        vid = os.path.join(e["project"], "renders", e["clip"] + ".mp4")
        tags = re.findall(r"#?(\w+)", spec.get("hashtags") or "")
        desc = "\n\n".join(x for x in (spec.get("description") or "", " ".join("#" + t for t in tags)) if x)
        when = _dt.datetime.utcfromtimestamp(e["at"]).strftime("%Y-%m-%dT%H:%M:%SZ")
        schedule.update(e["id"], status="posting")
        try:
            r = _post.yt_upload(vid, e.get("title") or spec.get("title") or spec.get("headline") or e["clip"], desc, tags,
                                "private", when)
            _post.track(r["url"], e["project"], e["clip"])
            schedule.update(e["id"], status="scheduled", result={"url": r["url"], "id": r["id"]})
            connect.fire("scheduled", {"title": spec.get("headline") or e["clip"], "platform": "YouTube", "url": r["url"]})
            out.append(r)
        except Exception as ex:
            schedule.update(e["id"], status="failed", error=str(ex)[:300])
            connect.fire("post_failed", {"title": "Scheduling %s on YouTube" % e["clip"], "error": str(ex)[:200]})
    return {"scheduled": len(out), "of": len(entries)}


def _bg(kind, fn, **meta):
    """Run fn in the background. The same job (kind + project + name) already running is joined, not started again,
    so a double-click can't upload twice or render the same edit twice at once. Old finished jobs are forgotten."""
    with _BG_LOCK:
        for j in JOBS.values():
            if (j.get("status") == "running" and j.get("kind") == kind and meta.get("project") is not None
                    and j.get("project") == meta.get("project") and j.get("name") == meta.get("name")):
                return j["id"]
        done = sorted((j for j in JOBS.values() if j.get("status") not in ("running", "queued")),
                      key=lambda j: j.get("finished") or 0)
        for j in done[:max(0, len(JOBS) - 300)]:
            JOBS.pop(j["id"], None)
        jid = uuid.uuid4().hex[:10]
        JOBS[jid] = dict(meta, id=jid, kind=kind, status="running", started=time.time())

    def go():
        try:
            res = fn()
            JOBS[jid].update(status="done", result=res, finished=time.time())
            if kind in ("youtube", "tiktok") and isinstance(res, dict):          # phone alert with the link
                connect.fire("scheduled" if res.get("scheduled") else "posted",
                             {"title": meta.get("name"), "url": res.get("url"),
                              "platform": "YouTube" if kind == "youtube" else
                              ("your TikTok inbox" if res.get("mode") == "draft" else "TikTok")})
        except Exception as e:
            JOBS[jid].update(status="error", error="%s\n%s" % (e, traceback.format_exc()[-1500:]), finished=time.time())
            if kind in ("youtube", "tiktok"):
                connect.fire("post_failed", {"title": "%s post of %s" % (kind.capitalize(), meta.get("name") or "a clip"),
                                             "error": str(e)[:200]})
    threading.Thread(target=go, daemon=True).start()
    return jid


class Ctx:
    root = None
    allowed = []


START = int(time.time() * 1000)              # tells the page when a restart has happened (execv keeps the pid)


def _custom_dir():
    from .common import load_config
    d = os.path.join(load_config()["work_root"], "_custom")
    os.makedirs(d, exist_ok=True)
    return d


TERMINAL_STATES = ("finished", "ended", "error")   # a live session that will produce nothing more


def live_state(se):
    """The session's reported state from its live_status.json, or '' if not written yet."""
    try:
        return json.load(open(os.path.join(se.dir, "live_status.json"))).get("state", "")
    except Exception:
        return ""


def prune_dead_sessions():
    """Drop finished/errored or user-stopped sessions (that aren't in always-on mode) from the
    registry, so a stream that ended or was stopped stops showing as "live clipping". Keeps a
    session that is still finalizing (building its recap). Returns the ids pruned."""
    dead = [k for k, v in LIVE.items()
            if k not in LIVE_ALWAYS
            and (LIVE_STOPPED.get(k) or live_state(v) in TERMINAL_STATES)
            and live_state(v) != "building recap"]
    for k in dead:
        LIVE.pop(k, None)
        LIVE_STOPPED.pop(k, None)
    return dead


def busy():
    """What's still running (an update now would restart Clipbot under it)."""
    out = []
    for j in JOBS.values():
        if j.get("status") in ("queued", "running"):
            out.append(j.get("kind") or "render")
    for lid, se in LIVE.items():
        if LIVE_STOPPED.get(lid) or getattr(se, "ended", False):
            continue                                  # user stopped it, or the stream went offline - not busy
        if live_state(se) in TERMINAL_STATES:         # terminal - never blocks an update
            continue
        if lid in LIVE_ALWAYS or not se.stop.is_set():
            out.append("live clipping")
    return out


def _restart():
    """Run the updated code on the same port and folders. Same on Mac, Windows and Linux: this process frees the
    port, starts the new version as a child in the same terminal window and waits for it (so start.sh / start.bat,
    and closing the window or Ctrl+C, keep working exactly as before)."""
    import subprocess
    time.sleep(1.0)                               # let the HTTP response reach the browser first
    try:
        Ctx.srv.shutdown()
        Ctx.srv.server_close()
        if getattr(Ctx, "poller", None):
            Ctx.poller.stop.set()
            Ctx.poller.kick.set()
        args = [a for a in sys.argv if a != "--open"]
        env = dict(os.environ, CLIPBOT_RESTART_PORT=str(Ctx.port))
        print("\nUpdated - restarting Clipbot...", flush=True)
        code = subprocess.call([sys.executable] + args, env=env)
    except KeyboardInterrupt:
        code = 0
    except Exception as e:
        print("couldn't restart automatically (%s) - close Clipbot and start it again" % e, flush=True)
        code = 1
    os._exit(code)


def _chat_file(p):
    """Only a chat file the editor itself uploaded (into <work_root>/_uploads)."""
    if not p:
        return None
    up = os.path.realpath(os.path.join(Ctx.root, "_uploads"))
    rp = os.path.realpath(p)
    return rp if rp.startswith(up + os.sep) and os.path.isfile(rp) else None


def _section(body):
    """{"from": "1:00:00", "to": "2:30:00"} -> (start_s, end_s) or None; bad values raise ValueError (400)."""
    from .fetch import parse_time
    a, b = parse_time(body.get("from")), parse_time(body.get("to"))
    if a is None and b is None:
        return None
    a = a or 0.0
    if b is not None and b <= a + 10:
        raise ValueError("'to' must be at least 10 seconds after 'from'")
    return (a, b if b is not None else 10 ** 7)


UPLOAD_PATHS = ("/api/upload_source", "/api/upload", "/api/banner_upload", "/api/font_upload", "/api/lore/example_upload")


def _allowed(path):
    """True only for a real path inside a folder Clipbot may use. Empty, non-text or malformed paths are refused
    (an empty path would otherwise mean "the folder Clipbot was started from")."""
    if not isinstance(path, str) or not path.strip() or "\x00" in path or len(path) > 4096:
        return False
    try:
        p = os.path.realpath(path)
    except (ValueError, OSError):
        return False
    return any(p.startswith(os.path.realpath(a) + os.sep) or p == os.path.realpath(a) for a in Ctx.allowed)


def _brand_dir():
    d = os.path.join(load_config()["work_root"], "_settings", "brand")
    os.makedirs(d, exist_ok=True)
    return d


# settings the Brand kit / Settings page may write to config.json (everything else is left untouched)
CONFIG_WRITABLE = {"brand", "music_safety", "caption_style", "accent", "caption_font", "caption_size",
                   "uppercase", "watermark", "whisper_model", "caption_model", "also_aspects"}


def _count(path):
    try:
        v = json.load(open(path))
        return len(v) if isinstance(v, list) else 0
    except Exception:
        return 0


def project_card(d, src):
    """What the Home and Projects grids show for one project, read from files that already exist (no probing)."""
    st = {}
    try:
        st = json.load(open(os.path.join(d, "autoclip_status.json")))
    except Exception:
        pass
    from .autoclip import source_kind
    origin = st.get("source") or ""
    kind = source_kind(origin) if origin else "file"
    renders = glob.glob(os.path.join(d, "renders", "*.mp4"))
    clips = len([r for r in renders if not re.search(r"_(draft|thumb)|\.part", os.path.basename(r))])
    state = st.get("state") or ""
    busy = bool(state) and state not in ("done", "error", "failed", "stopped", "cancelled")
    return {"dir": d, "name": os.path.relpath(d, Ctx.root), "mtime": os.path.getmtime(src),
            "has_words": os.path.exists(os.path.join(d, "words.json")),
            "has_specs": os.path.exists(os.path.join(d, "specs.json")),
            "origin": origin if origin.startswith("http") else "", "kind": kind,
            "clips": clips, "specs": _count(os.path.join(d, "specs.json")),
            "moments": _count(os.path.join(d, "candidates.json")),
            "duration": st.get("duration"), "state": state, "busy": busy,
            "step": st.get("step"), "steps": st.get("steps") or 6, "detail": st.get("detail"),
            "error": st.get("error"), "live": os.path.exists(os.path.join(d, "live_status.json"))}


def list_projects():
    out = []
    for src in glob.glob(os.path.join(Ctx.root, "**", "source.mp4"), recursive=True):
        d = os.path.dirname(src)
        try:
            out.append(project_card(d, src))
        except OSError:
            continue
    return sorted(out, key=lambda x: -x["mtime"])


def project_poster(d):
    """A still from ~15% into the source, made once and kept as <project>/poster.jpg."""
    src = os.path.join(d, "source.mp4")
    out = os.path.join(d, "poster.jpg")
    if os.path.exists(out) and os.path.getmtime(out) >= os.path.getmtime(src):
        return out
    try:
        dur = float(probe(src).get("duration") or 0)
    except Exception:
        dur = 0
    t = max(0.0, min(dur * 0.15, dur - 0.5)) if dur > 1 else 0
    tmp = out + ".tmp.jpg"
    try:
        ffmpeg(["-ss", "%.2f" % t, "-i", src, "-frames:v", "1", "-vf", "scale=640:-2", "-q:v", "4", tmp], timeout=40)
        os.replace(tmp, out)
    except Exception:
        safe_remove(tmp)
        return None
    return out if os.path.exists(out) else None


def load_project(d):
    src = os.path.join(d, "source.mp4")
    from .common import load_store, ensure_readable, BrokenSource
    warnings = []
    try:
        if os.path.exists(src):
            ensure_readable(src)
        pr = probe(src)
    except BrokenSource as e:                    # still open the project: clips, captions and text stay editable
        warnings.append(str(e))
        pr = {"width": 1920, "height": 1080, "duration": 0, "fps": 30.0, "has_audio": True, "broken": True}
    what = {"specs.json": "your clips", "words.json": "the transcript", "sentences.json": "the transcript",
            "candidates.json": "the moment list"}
    bad = object()

    def rd(n, dflt):
        path = os.path.join(d, n)
        if not os.path.exists(path):
            return dflt
        val = load_store(path, bad, list)          # a damaged file is set aside as <name>.broken-<time>, never lost
        if val is not bad:
            return val
        back = load_store(path + ".bak", bad, list) if os.path.exists(path + ".bak") else bad
        if back is not bad:
            save_json(path, back)
            warnings.append("The file with %s was damaged, so Clipbot restored the last good copy." % what.get(n, n))
            return back
        warnings.append("The file with %s was damaged and has been set aside (%s.broken-…). %s" % (
            what.get(n, n), n, "Re-run Auto-clip to make clips again." if n == "specs.json" else
            "Run Auto-clip again to rebuild it." if n in ("words.json", "sentences.json") else "It is rebuilt next time."))
        return dflt
    from .fetch import source_quality
    try:
        pr = dict(pr, quality=source_quality(src))
    except Exception:
        pr = dict(pr, quality=None)
    return {"dir": d, "source": src, "info": pr, "words": rd("words.json", []), "sentences": rd("sentences.json", []),
            "candidates": rd("candidates.json", []), "specs": rd("specs.json", []),
            "renders": sorted(glob.glob(os.path.join(d, "renders", "*.mp4"))),
            "warnings": [w.replace(" (sentences.json.broken-…)", "") for i, w in enumerate(warnings)
                         if "the transcript" not in w or not any("the transcript" in x for x in warnings[:i])]}


def waveform(path, n=4000):
    cache = path + ".peaks.json"
    if os.path.exists(cache) and os.path.getmtime(cache) > os.path.getmtime(path):
        return json.load(open(cache))
    wav = path + ".wf.wav"
    ffmpeg(["-i", path, "-vn", "-ac", "1", "-ar", "2000", wav])
    with wave.open(wav, "rb") as wf:
        x = np.abs(np.frombuffer(wf.readframes(wf.getnframes()), dtype=np.int16).astype(np.float32))
    safe_remove(wav)
    per = 2000 // 20                                   # 20 peaks per second
    m = len(x) // per
    pk = x[: m * per].reshape(m, per).max(1) if m else np.zeros(1)
    pk = (pk / (pk.max() + 1e-6)).round(3).tolist()
    res = {"pps": 20, "peaks": pk}
    save_json(cache, res, indent=None)
    return res


def analyze(d, start, end):
    """Quick layout analysis for the preview: facecam inset, median face x, aspect."""
    from . import render, speaker
    tmp = os.path.join(d, "_editor_tmp")
    os.makedirs(tmp, exist_ok=True)
    raw = os.path.join(tmp, "probe.mp4")
    render.cut_raw(os.path.join(d, "source.mp4"), [(start, min(end, start + 12))], raw, 720)
    pr = probe(raw)
    w0, h0 = pr["width"], pr["height"]
    samples, active = speaker.analyze(raw, w0, h0, tmp)
    fc = render.detect_facecam(raw, samples, w0, h0)
    xs = [f[0] / w0 for _, fs in samples for f in fs]
    ys = [f[1] / h0 for _, fs in samples for f in fs]
    tracks = {}
    for _, fs in samples:
        for f in fs:
            tracks.setdefault(f[5], []).append((f[0] / w0, f[1] / h0, f[3] / h0))
    people = sorted([(float(np.median([q[0] for q in v])), float(np.median([q[1] for q in v])), float(np.median([q[2] for q in v])))
                     for v in tracks.values() if len(v) >= 0.3 * max(1, len(samples))])
    n_people = len(people)
    pn = None
    try:
        from .panels import detect as _pd
        pn = _pd(raw, w0, h0)
    except Exception:
        pn = None
    res = {"panels": [[x / w0, y / h0, w / w0, h / h0] for x, y, w, h in pn] if pn else None,
           "facecam": [fc[0] / w0, fc[1] / h0, fc[2] / w0, fc[3] / h0] if fc else None,
            "face_x": (max(people, key=lambda q: q[2])[0] if people else (float(np.median(xs)) if xs else None)),
            "face_y": (max(people, key=lambda q: q[2])[1] if people else (float(np.median(ys)) if ys else None)),
            "face_h": (max(people, key=lambda q: q[2])[2] if people else None),
            "people_xy": people,
           "people": n_people, "vertical": h0 / float(w0) >= 1.3}
    try:                                   # the renderer reuses this, so the video matches what the preview showed
        from .render import ana_cache_path
        save_json(ana_cache_path(d, start, end), {"panels": res["panels"], "facecam": res["facecam"]}, indent=None)
    except Exception:
        pass
    return res


def run_job(jid, d, spec, draft):
    from .render import make_clip
    j = JOBS[jid]
    try:
        cfg = load_config()
        spec = dict(spec)
        spec["source"] = spec.get("source") or os.path.join(d, "source.mp4")
        if draft:
            spec["_draft"] = True
            spec["name"] = spec["name"] + "_draft"
        outdir = os.path.join(d, "renders")
        res = make_clip(spec, outdir, os.path.join(d, "_work"), cfg)
        if not draft:
            from .review import ledger_append
            ledger_append(res, spec)
            from . import learn
            learn.record("rendered", spec, d)
            connect.fire("clip_rendered", {"name": res.get("name"), "file": res.get("out"), "srt": res.get("srt"),
                                           "title": spec.get("title") or spec.get("headline"),
                                           "aspect": res.get("aspect"), "duration": res.get("dur"),
                                           "versions": [v.get("out") for v in res.get("versions") or []]})
        j.update(status="done", result=res, finished=time.time())
    except Exception as e:
        from .common import BrokenSource
        if isinstance(e, BrokenSource):           # a plain explanation, not a stack of ffmpeg output
            j.update(status="error", error=str(e), finished=time.time())
        else:
            j.update(status="error", error="%s\n%s" % (e, traceback.format_exc()[-2500:]), finished=time.time())


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _json(self, obj, code=200):
        b = json.dumps(obj, default=str).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def _page(self):
        """The editor page: <work_root>/_custom/index.html if the user made their own, else the built-in one,
        plus _custom/custom.css and custom.js when present. Updates never touch _custom."""
        cd = _custom_dir()
        own = os.path.join(cd, "index.html")
        html = open(own if os.path.isfile(own) else EDITOR_HTML, encoding="utf-8").read()
        extra = ""
        if os.path.isfile(os.path.join(cd, "custom.css")):
            extra += '<link rel="stylesheet" href="/custom/custom.css">'
        if os.path.isfile(os.path.join(cd, "custom.js")):
            extra += '<script src="/custom/custom.js" defer></script>'
        if extra:
            html = html.replace("</head>", extra + "</head>", 1)
        body = html.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _file(self, path, ctype=None, download=None):
        if not os.path.isfile(path):
            return self._json({"error": "not found"}, 404)
        size = os.path.getsize(path)
        ctype = ctype or mimetypes.guess_type(path)[0] or "application/octet-stream"
        rng = self.headers.get("Range")
        start, end = 0, size - 1
        if rng and size == 0:
            rng = None
        if rng:
            m = re.match(r"bytes=(\d*)-(\d*)", rng)
            if m:
                if m.group(1):
                    start = int(m.group(1))
                    end = int(m.group(2)) if m.group(2) else size - 1
                elif m.group(2):
                    start = max(0, size - int(m.group(2)))
            end = min(end, size - 1)
            if start > end or start >= size:
                self.send_response(416)
                self.send_header("Content-Range", "bytes */%d" % size)
                self.send_header("Content-Length", "0")
                self.end_headers()
                return
            self.send_response(206)
            self.send_header("Content-Range", "bytes %d-%d/%d" % (start, end, size))
        else:
            self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Accept-Ranges", "bytes")
        if download:                              # "Download" links: the browser saves it with a readable name
            from urllib.parse import quote
            ascii_name = re.sub(r'[^A-Za-z0-9._ -]+', "_", download)
            self.send_header("Content-Disposition", "attachment; filename=\"%s\"; filename*=UTF-8''%s" % (ascii_name, quote(download)))
        self.send_header("Content-Length", str(end - start + 1))
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        with open(path, "rb") as f:
            f.seek(start)
            left = end - start + 1
            try:
                while left > 0:
                    chunk = f.read(min(1 << 20, left))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    left -= len(chunk)
            except (BrokenPipeError, ConnectionResetError):
                pass

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        return self.rfile.read(n) if n else b""

    def _guard(self, post):
        """Only this computer's own Clipbot page may drive the editor.
        - Host must be 127.0.0.1/localhost on our port: stops DNS-rebinding (a website pointing its own name at
          127.0.0.1 to read your files or settings).
        - POSTs need the X-Clipbot header (a cross-site page can't add it without a CORS preflight, which we never
          allow) and, if the browser sends an Origin, it must be ours: stops other websites from triggering uploads,
          posts or changes behind your back."""
        host = (self.headers.get("Host") or "").lower()
        port = self.server.server_address[1]
        ok_hosts = {"127.0.0.1:%d" % port, "localhost:%d" % port, "[::1]:%d" % port}
        bind = self.server.server_address[0]
        if bind not in ("127.0.0.1", "::1", "localhost"):     # started with --host for LAN use: trust the Host it was
            ok_hosts.add(host if bind in ("0.0.0.0", "::") else "%s:%d" % (bind, port))   # reached on, still same-origin
        if host not in ok_hosts:
            self._deny("Clipbot only answers on http://127.0.0.1:%d" % port)
            return False
        if post:
            origin = self.headers.get("Origin")
            if origin and origin.lower().rstrip("/") not in {"http://" + h for h in ok_hosts}:
                self._deny("requests from other websites are blocked")
                return False
            if self.headers.get("X-Clipbot") != "1":
                self._deny("missing Clipbot header - reload the Clipbot page")
                return False
            try:
                n = int(self.headers.get("Content-Length") or 0)
            except ValueError:
                n = -1
            if n < 0 or (n > 64 * 1024 * 1024 and not self.path.startswith(UPLOAD_PATHS)):
                self._deny("request too large", 413)
                return False
        return True

    def _deny(self, msg, code=403):
        b = json.dumps({"error": msg}).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b)))
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(b)
        self.close_connection = True

    def do_OPTIONS(self):                         # never grant cross-origin access
        self._deny("not allowed", 405)

    do_PUT = do_DELETE = do_PATCH = do_OPTIONS

    def do_GET(self):
        u = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(u.query).items()}
        if not self._guard(False):
            return
        try:
            if u.path in ("/", "/index.html"):
                return self._page()
            if u.path.startswith("/custom/"):      # the user's own look/behaviour (never touched by updates)
                fn = os.path.basename(u.path)
                if fn in ("custom.css", "custom.js"):
                    return self._file(os.path.join(_custom_dir(), fn),
                                      "text/css" if fn.endswith(".css") else "text/javascript")
                return self._json({"error": "not found"}, 404)
            if u.path.startswith("/ui/"):          # editor UI fonts + the bundled HLS player
                fn = os.path.basename(u.path)
                return self._file(os.path.join(ROOT, "editor", "ui", fn),
                                  "font/woff2" if fn.endswith(".woff2") else
                                  "text/javascript" if fn.endswith(".js") else "text/plain")
            if u.path in ("/api/live/hls.m3u8", "/api/live/seg"):    # watch a live session inside Clipbot
                sess = LIVE.get(q.get("id"))
                if not sess:
                    return self._json({"error": "that live stream isn't being watched anymore"}, 404)
                segs = sess.all_segments()
                if u.path.endswith("seg"):
                    i = int(q.get("i", -1))
                    if not 0 <= i < len(segs):
                        return self._json({"error": "that part of the stream isn't ready yet"}, 404)
                    return self._file(segs[i]["path"], "video/mp2t")
                import math
                lines = ["#EXTM3U", "#EXT-X-VERSION:3", "#EXT-X-PLAYLIST-TYPE:EVENT",
                         "#EXT-X-TARGETDURATION:%d" % (int(math.ceil(max([s["b"] - s["a"] for s in segs] or [20]))) + 1),
                         "#EXT-X-MEDIA-SEQUENCE:0"]
                for i, sg in enumerate(segs):
                    if i:
                        lines.append("#EXT-X-DISCONTINUITY")       # each chunk restarts its timestamps
                    lines += ["#EXTINF:%.3f," % (sg["b"] - sg["a"]), "/api/live/seg?id=%s&i=%d" % (q["id"], i)]
                if sess.stop.is_set() or getattr(sess, "ended", False):
                    lines.append("#EXT-X-ENDLIST")
                body = ("\n".join(lines) + "\n").encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/vnd.apple.mpegurl")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return
            if u.path == "/api/live/feed":         # chunk times, so the player can map its position to stream time
                sess = LIVE.get(q.get("id"))
                if not sess:
                    return self._json({"error": "that live stream isn't being watched anymore"}, 404)
                return self._json({"segments": [[round(s_["a"], 3), round(s_["b"], 3)] for s_ in sess.all_segments()],
                                   "ended": bool(sess.stop.is_set() or getattr(sess, "ended", False))})
            if u.path.startswith("/fonts/"):
                from .fonts import user_dir
                fn = os.path.basename(u.path)
                p = os.path.join(FONT_DIR, fn)
                if not os.path.exists(p):
                    p = os.path.join(user_dir(), fn)
                return self._file(p, "font/ttf")
            if u.path == "/api/fonts":
                from .fonts import list_fonts
                return self._json([{k: f[k] for k in ("family", "file", "user", "em")} for f in list_fonts()])
            if u.path == "/media":
                p = q.get("path", "")
                if not _allowed(p):
                    return self._json({"error": "path not allowed"}, 403)
                if q.get("dl"):
                    from .downloads import nice_name
                    return self._file(p, download=nice_name(p, q.get("project", "")))
                return self._file(p)
            if u.path == "/api/projects":
                return self._json({"root": Ctx.root, "projects": list_projects()})
            if u.path == "/api/poster":                 # project thumbnail for the Home / Projects grids
                if not _allowed(q["dir"]):
                    return self._json({"error": "path not allowed"}, 403)
                p = project_poster(q["dir"])
                if not p:
                    return self._json({"error": "no picture yet"}, 404)
                return self._file(p)
            if u.path == "/api/giphy/search":
                from . import giphy
                try:
                    return self._json(giphy.search(q.get("q", ""), q.get("kind", "gifs"), int(q.get("offset") or 0)))
                except RuntimeError as e:
                    return self._json({"error": str(e), "need_key": not giphy.ready()}, 400)
            if u.path == "/api/project":
                if not _allowed(q["dir"]):
                    return self._json({"error": "path not allowed"}, 403)
                return self._json(load_project(q["dir"]))
            if u.path == "/api/waveform":
                if not _allowed(q["path"]):
                    return self._json({"error": "path not allowed"}, 403)
                return self._json(waveform(q["path"]))
            if u.path == "/api/analyze":
                from .common import ensure_readable, BrokenSource
                try:
                    ensure_readable(os.path.join(q["dir"], "source.mp4"))
                except BrokenSource as e:
                    return self._json({"error": str(e)}, 409)
                return self._json(analyze(q["dir"], float(q["start"]), float(q["end"])))
            if u.path == "/api/job":
                return self._json(JOBS.get(q["id"], {"status": "unknown"}))
            if u.path == "/api/emoji":
                from .effects import emoji_png
                return self._file(emoji_png(q["ch"]), "image/png")
            if u.path == "/api/icon":
                from .banner import brand_icon, PLATFORMS
                plat = q.get("platform", "kick")
                ic = brand_icon(plat, 256, q.get("color")) if plat in PLATFORMS else None
                if not ic:
                    return self._json({"error": "icon unavailable"}, 404)
                return self._file(ic, "image/png")
            if u.path == "/api/qc":
                from .verify import qc_load
                return self._json(qc_load(os.path.join(q["dir"], "renders")))
            if u.path == "/api/live":
                st = os.path.join(q["dir"], "live_status.json")
                return self._json(json.load(open(st)) if os.path.exists(st) else {})
            if u.path == "/api/jobs":
                return self._json(sorted(JOBS.values(), key=lambda j: -j["started"])[:30])
            if u.path == "/api/autoclip_status":
                if not _allowed(q["dir"]):
                    return self._json({"error": "path not allowed"}, 403)
                pth = os.path.join(q["dir"], "autoclip_status.json")
                return self._json(json.load(open(pth)) if os.path.exists(pth) else {})
            if u.path == "/api/live/sessions":
                _st = live_state
                prune_dead_sessions()   # a stream that ended or was stopped stops showing as "live clipping"
                return self._json([{"id": k, "url": v.url, "dir": v.dir, "clips": v.clips,
                                    "running": not v.stop.is_set() and not getattr(v, "ended", False)
                                    and _st(v) not in TERMINAL_STATES,
                                    "ended": bool(getattr(v, "ended", False)),
                                    "always": k in LIVE_ALWAYS,   # keeps watching for the next stream
                                    "state": _st(v), "went_live": bool(v.went_live or v.segments),
                                    "recap": os.path.join(v.dir, "recap_highlights.mp4")
                                    if os.path.exists(os.path.join(v.dir, "recap_highlights.mp4")) else None,
                                    "segments": len(v.segments), "words": len(v.words), "chat": len(v.chat.msgs),
                                    "problem": getattr(v, "speech_error", None), "chat_error": v.chat.err,
                                    "behind": round(getattr(v, "behind", 0.0)),
                                    "checked": getattr(v, "checked", 0), "best_seen": round(getattr(v, "best_seen", 0.0), 1),
                                    "bar": v.min_quality,
                                    "quality": (getattr(v, "source_q", None) or {}).get("label"),
                                    "elapsed": round(time.time() - v.t0)} for k, v in LIVE.items()])
            if u.path == "/api/banners":
                from .banner import PRESETS, library
                return self._json({"library": library(), "presets": PRESETS})
            if u.path == "/api/learning":
                from . import learn
                L = learn.learned()
                return self._json({"insights": learn.insights(L), "summary": L, "reasons": learn.REASONS})
            if u.path == "/api/edits":
                d = q.get("dir") or ""
                if not _allowed(d):
                    return self._json({"edits": []})
                ed = os.path.join(d, "edits")
                out = []
                if os.path.isdir(ed):
                    for f in sorted(os.listdir(ed), key=lambda f: -os.path.getmtime(os.path.join(ed, f))):
                        if f.endswith(".mp4"):
                            ch = os.path.join(ed, f[:-4] + "_chapters.txt")
                            pl = os.path.join(ed, f[:-4] + "_plan.json")
                            try:
                                plan_ = json.load(open(pl)) if os.path.exists(pl) else None
                            except Exception:
                                plan_ = None
                            out.append({"file": os.path.join(ed, f), "name": f[:-4], "size": os.path.getsize(os.path.join(ed, f)),
                                        "chapters": open(ch).read() if os.path.exists(ch) else None, "plan": plan_})
                return self._json({"edits": out})
            if u.path == "/api/accounts":
                from . import accounts
                return self._json({"accounts": accounts.summary()})
            if u.path == "/api/renders":
                d = q.get("dir") or ""
                rd = os.path.join(d, "renders")
                if not _allowed(d) or not os.path.isdir(rd):
                    return self._json({"rendered": []})
                return self._json({"rendered": sorted(f[:-4] for f in os.listdir(rd) if f.endswith(".mp4") and not f.endswith("_draft.mp4"))})
            if u.path == "/api/clips/reveal":          # open the folder that holds this project's finished clips
                d = q.get("dir") or ""
                if not _allowed(d):
                    return self._json({"error": "path not allowed"}, 403)
                from . import downloads
                rd = os.path.join(d, "renders")
                return self._json({"folder": downloads.reveal(rd if os.path.isdir(rd) else d)})
            if u.path == "/api/clips/reveal_all":        # open the top folder that holds every project's clips
                from . import downloads
                return self._json({"folder": downloads.reveal(Ctx.root)})
            if u.path == "/api/all_renders":             # every finished clip across every project, newest first
                out = []
                for pr in list_projects():
                    d = pr["dir"]
                    for f in glob.glob(os.path.join(d, "renders", "*.mp4")):
                        b = os.path.basename(f)
                        if re.search(r"_(draft|thumb)|\.part", b):
                            continue
                        try:
                            out.append({"project": pr["name"], "dir": d,
                                        "name": os.path.splitext(b)[0], "file": f,
                                        "size": os.path.getsize(f), "mtime": os.path.getmtime(f)})
                        except OSError:
                            continue
                out.sort(key=lambda x: x["mtime"], reverse=True)
                return self._json({"clips": out, "count": len(out)})
            if u.path == "/api/schedule":
                from . import schedule, post as _post
                q = schedule.load()
                for e in q:
                    sp = _post._spec(e["project"], e["clip"]) or {}
                    e["headline"] = sp.get("headline") or e["clip"]
                    e["project_name"] = os.path.basename(e["project"])
                q.sort(key=lambda e: e["at"])
                return self._json({"queue": q, "platforms": schedule.PLATFORMS})
            if u.path == "/api/results":
                from . import results
                return self._json(results.summary())
            if u.path == "/api/posts":
                from . import post as _post
                ps = [p_ for p_ in _post.posts() if not q.get("dir") or p_["project"] == q["dir"]]
                return self._json({"posts": ps})
            if u.path in ("/oauth/tiktok/", "/oauth/tiktok"):   # TikTok sends the user back here
                from . import social
                ok, msg = False, "That sign-in link is out of date. Start again from Settings."
                st = getattr(Ctx, "tt_state", None)
                if q.get("state") and st and q.get("state") == st[0] and q.get("code"):
                    try:
                        social.tt_finish_auth(q["code"], "http://127.0.0.1:%d/oauth/tiktok/" % Ctx.port, st[1])
                        ok, msg = True, "TikTok is connected. You can close this tab and go back to Clipbot."
                    except Exception as e:
                        msg = "Couldn't connect TikTok: %s" % str(e)[:200]
                elif q.get("error"):
                    msg = "TikTok wasn't connected (%s)." % (q.get("error_description") or q["error"])[:120]
                Ctx.tt_state = None
                body = ("<!doctype html><meta charset=utf-8><title>Clipbot</title><body style='background:#000;color:#f3f3f1;"
                        "font:16px system-ui;padding:40px'><h2>%s</h2><p>%s</p>" % ("Done" if ok else "Not connected",
                                                                                  msg.replace("<", "&lt;"))).encode()
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return
            if u.path == "/oauth/youtube":           # Google sends the user back here after they allow Clipbot
                from . import post as _post
                ok, msg = False, "That sign-in link is out of date. Start again from Settings."
                if q.get("state") and q.get("state") == getattr(Ctx, "yt_state", None) and q.get("code"):
                    try:
                        ok = _post.yt_finish_auth(q["code"], "http://127.0.0.1:%d/oauth/youtube" % Ctx.port)
                        msg = "YouTube is connected. You can close this tab and go back to Clipbot."
                    except Exception as e:
                        msg = "Couldn't connect YouTube: %s" % str(e)[:200]
                elif q.get("error"):
                    msg = "YouTube wasn't connected (%s)." % q["error"][:60]
                Ctx.yt_state = None
                body = ("<!doctype html><meta charset=utf-8><title>Clipbot</title><body style='background:#000;color:#f3f3f1;"
                        "font:16px system-ui;padding:40px'><h2>%s</h2><p>%s</p>" % ("Done" if ok else "Not connected",
                                                                                  msg.replace("<", "&lt;"))).encode()
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return
            if u.path == "/api/presets":
                from . import presets as _pr
                return self._json({"presets": _pr.list_presets(), "campaigns": _pr.list_campaigns(), "skills": _pr.list_skills()})
            if u.path == "/api/share/export":       # one file with presets, campaigns and lore to hand to a teammate
                from . import presets as _pr
                sp_ = lambda k: [x for x in (q.get(k) or "").split(",") if x]     # noqa: E731
                try:
                    data = _pr.bundle(sp_("presets"), sp_("campaigns"), sp_("lore"), sp_("skills"))
                except ValueError as e:
                    return self._json({"error": str(e)}, 400)
                body = json.dumps(data, indent=1).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Disposition", 'attachment; filename="clipbot-share.clipbot.json"')
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return
            if u.path == "/api/watch":
                from . import watch
                pl = getattr(Ctx, "poller", None)
                return self._json({"watches": [dict(w, seen=len(w.get("seen") or []), pending=len(w.get("pending") or {}))
                                               for w in watch.load()],
                                   "busy": bool(pl and pl.busy), "last": pl.last if pl else None,
                                   "minutes": pl.minutes if pl else None})
            if u.path == "/api/connections":
                pass
                return self._json(dict(connect.redacted(), ai_ready=connect.ai_ready(), browsers=connect.BROWSERS))
            if u.path == "/api/terms":
                from . import terms
                return self._json(terms.status())
            if u.path == "/api/notify/setup":           # QR code that opens the alert topic on the phone
                nt = connect.get().get("notify") or {}
                if not nt.get("topic"):
                    return self._json({"topic": None})
                link = (nt.get("server") or "https://ntfy.sh").rstrip("/") + "/" + nt["topic"]
                try:
                    import segno
                    qr = segno.make(link, error="m").svg_inline(scale=5, dark="#000", light="#fff", border=2)
                except Exception:
                    qr = None
                return self._json({"topic": nt["topic"], "link": link, "qr_svg": qr})
            if u.path == "/api/ping":                 # "is Clipbot already open?" - the app opens this one instead
                return self._json({"app": "clipbot", "port": Ctx.port})
            if u.path == "/api/app":
                from . import appshell
                return self._json({"installed": appshell.installed(), "platform": sys.platform,
                                   "icon": os.path.join(appshell.ICON_DIR, "clipbot_256.png")})
            if u.path == "/api/version":
                from .updater import current_version
                return self._json({"version": current_version(), "pid": "%d-%d" % (os.getpid(), START)})
            if u.path == "/api/update/check":
                from . import updater
                return self._json(updater.check())
            if u.path == "/api/lore/study_status":
                from . import style
                st = dict(style.status(q.get("name")))
                st.pop("style", None)
                return self._json(st)
            if u.path == "/api/lore":
                from . import lore, style
                if q.get("name"):
                    p = lore.load(q["name"])
                    if p and p.get("style"):
                        p["style_summary"] = style.describe(p["style"])
                        p["style"] = {k: v for k, v in p["style"].items() if k != "centroid"}
                    from .lore import lore_dir, slug
                    exd = os.path.join(lore_dir(), slug(q["name"]) + "_clips")
                    ex = sorted(f for f in os.listdir(exd) if not f.startswith("_")) if os.path.isdir(exd) else []
                    return self._json({"profile": p, "examples": ex})
                return self._json({"profiles": lore.list_profiles()})
            if u.path == "/api/discover":          # live streams to clip, by game, on Twitch + Kick
                from . import discover
                game = q.get("game") or discover.DEFAULT_GAME
                plats = tuple(x for x in (q.get("platforms") or "twitch,kick").split(",") if x in ("twitch", "kick"))
                try:
                    lim = max(1, min(60, int(q.get("limit") or 40)))
                except ValueError:
                    lim = 40
                return self._json(discover.find_streams(game, plats or ("twitch", "kick"), lim))
            if u.path == "/api/config":
                return self._json(load_config())
            return self._json({"error": "unknown endpoint"}, 404)
        except (KeyError, ValueError, TypeError, AttributeError) as e:   # malformed request -> clear 400
            log("bad request %s: %s" % (self.path[:120], traceback.format_exc()[-600:]))
            what = ("missing field %s" % e) if isinstance(e, KeyError) else (
                "invalid JSON" if isinstance(e, json.JSONDecodeError) else "invalid request (%s)" % str(e)[:120])
            return self._json({"error": what}, 400)
        except Exception as e:                    # real failure: message for the user, details in the log only
            log("server error on %s:\n%s" % (self.path[:120], traceback.format_exc()[-2000:]))
            return self._json({"error": str(e)[:300] or e.__class__.__name__}, 500)

    def do_POST(self):
        u = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(u.query).items()}
        if not self._guard(True):
            return
        try:
            if u.path == "/api/demo":                  # one-click demo project: try everything without footage
                from .tools import demo as _demo
                root = Ctx.root or load_config()["work_root"]
                dest = os.path.join(root, "demo")
                if os.path.exists(os.path.join(dest, "specs.json")) and os.path.exists(os.path.join(dest, "source.mp4")):
                    return self._json({"dir": dest, "ready": True})
                self._body()
                return self._json({"id": _bg("demo", lambda: {"dir": _demo(dest)}, project=dest, name="demo")})
            if u.path in ("/api/downloads/save", "/api/downloads/reveal"):
                from . import downloads
                try:
                    b = json.loads(self._body() or b"{}")
                except ValueError:
                    b = {}
                b = b if isinstance(b, dict) else {}
                if u.path == "/api/downloads/reveal":
                    p = b.get("path")
                    if p and os.path.realpath(str(p)).startswith(os.path.realpath(downloads.downloads_dir()) + os.sep):
                        return self._json({"folder": downloads.reveal(p)})
                    if not _allowed(p):
                        return self._json({"error": "path not allowed"}, 403)
                    return self._json({"folder": downloads.reveal(p)})
                d = b.get("dir")
                if d is not None and not _allowed(d):
                    return self._json({"error": "path not allowed"}, 403)
                paths = b.get("paths") if isinstance(b.get("paths"), list) else []
                if b.get("all") and d:
                    paths = downloads.everything(d)
                paths = [p for p in paths if isinstance(p, str)]
                if not paths:
                    return self._json({"error": "Nothing rendered yet. Press Render clip first."}, 400)
                if not all(_allowed(p) for p in paths):
                    return self._json({"error": "path not allowed"}, 403)
                return self._json(downloads.save(paths, os.path.basename(d or os.path.dirname(os.path.dirname(paths[0])))))
            if u.path == "/api/terms/accept":
                from . import terms
                try:
                    tb = json.loads(self._body() or b"{}")
                except ValueError:
                    tb = {}
                tb = tb if isinstance(tb, dict) else {}
                res = terms.accept()
                if "share" in tb:                          # the data choices made on the same screen
                    fb = connect.get().get("feedback") or {}
                    connect.save({"feedback": {"enabled": bool(tb.get("share")), "include_text": bool(tb.get("share") and tb.get("share_text")),
                                               "decided": True, "url": fb.get("url")}})
                    ai = connect.get().get("ai") or {}
                    if not tb.get("free_ai", True) and ai.get("provider") in (None, "", "free"):
                        connect.save({"ai": {"provider": "off"}})
                    elif tb.get("free_ai", True) and ai.get("provider") == "off":
                        connect.save({"ai": {"provider": "free"}})
                return self._json(res)
            if u.path == "/api/upload_source":         # big video -> new project, streamed to disk
                name = re.sub(r"[^\w.-]+", "_", q.get("name", "upload.mp4"))
                stem = os.path.splitext(name)[0][:60]
                d = os.path.join(Ctx.root, "_uploads")
                os.makedirs(d, exist_ok=True)
                pth = os.path.join(d, name)
                n = int(self.headers.get("Content-Length") or 0)
                with open(pth, "wb") as f:
                    while n > 0:
                        chunk = self.rfile.read(min(1 << 22, n))
                        if not chunk:
                            break
                        f.write(chunk)
                        n -= len(chunk)
                if n > 0:
                    safe_remove(pth)
                    return self._json({"error": "upload interrupted - try again"}, 400)
                return self._json({"path": pth, "name": stem})
            if u.path == "/api/lore/example_upload":   # one of the streamer's best clips, streamed to disk
                from . import style
                who = (q.get("streamer") or "").strip()
                name = re.sub(r"[^\w.-]+", "_", q.get("name", "clip.mp4"))[:80]
                if not who:
                    return self._json({"error": "pick a streamer first"}, 400)
                if not name.lower().endswith((".mp4", ".mov", ".mkv", ".webm", ".m4v")):
                    return self._json({"error": "clips must be video files (.mp4, .mov, .mkv, .webm)"}, 400)
                pth = os.path.join(style.examples_dir(who), name)
                n = int(self.headers.get("Content-Length") or 0)
                if n > 2e9:
                    return self._json({"error": "that file is too big to be a clip"}, 400)
                with open(pth, "wb") as f:
                    while n > 0:
                        chunk = self.rfile.read(min(1 << 22, n))
                        if not chunk:
                            break
                        f.write(chunk)
                        n -= len(chunk)
                if n > 0:
                    safe_remove(pth)
                    return self._json({"error": "upload interrupted - try again"}, 400)
                try:
                    probe(pth)
                except Exception:
                    safe_remove(pth)
                    return self._json({"error": "%s isn't a playable video" % name}, 400)
                return self._json({"ok": True, "file": name})
            if u.path == "/api/font_upload":           # .ttf/.otf/.woff/.woff2 -> user font folder
                import tempfile
                from .fonts import add
                name = re.sub(r"[^\w.-]+", "_", q.get("name", "font.ttf"))
                if not name.lower().endswith((".ttf", ".otf", ".woff", ".woff2")):
                    return self._json({"error": "fonts must be .ttf, .otf, .woff or .woff2"}, 400)
                body = self._body()
                if len(body) > 30e6:
                    return self._json({"error": "font file too large"}, 400)
                tmp = tempfile.NamedTemporaryFile(suffix=os.path.splitext(name)[1], delete=False)
                tmp.write(body)
                tmp.close()
                try:
                    return self._json(add(tmp.name))
                except ValueError as e:
                    return self._json({"error": "%s: %s" % (name, e)}, 400)
                finally:
                    safe_remove(tmp.name)
            if u.path == "/api/banner_upload":         # campaign banner -> shared library
                from .banner import library_dir
                name = re.sub(r"[^\w.-]+", "_", q.get("name", "banner.png"))
                if not name.lower().endswith((".png", ".webp", ".gif", ".jpg", ".jpeg")):
                    return self._json({"error": "banner must be an image (PNG with transparency works best)"}, 400)
                data = self._body()
                try:
                    import io
                    from PIL import Image
                    Image.open(io.BytesIO(data)).verify()
                except Exception:
                    return self._json({"error": "that file isn't a readable image - export it as PNG and try again"}, 400)
                p = os.path.join(library_dir(), name)
                with open(p, "wb") as f:
                    f.write(data)
                return self._json({"path": p, "name": os.path.splitext(name)[0]})
            if u.path == "/api/config":                # save Settings / Brand kit (merges a small allowlist)
                body = json.loads(self._body() or b"{}")
                patch = body.get("patch") if isinstance(body, dict) else None
                if not isinstance(patch, dict):
                    return self._json({"error": "send {patch: {...}}"}, 400)
                bad = set(patch) - CONFIG_WRITABLE
                if bad:
                    return self._json({"error": "cannot set: " + ", ".join(sorted(bad))}, 400)
                cfg = load_json(CONFIG_PATH, {})
                if isinstance(patch.get("brand"), dict):          # merge brand so one field doesn't wipe the rest
                    cfg["brand"] = dict(cfg.get("brand") or {}, **patch.pop("brand"))
                cfg.update(patch)
                save_json(CONFIG_PATH, cfg)
                return self._json({"ok": True, "config": load_config()})
            if u.path == "/api/brand/logo":            # raw image body -> <work_root>/_settings/brand/logo.<ext>
                ext = re.sub(r"[^a-z0-9]", "", (q.get("ext", "png")).lower())[:4] or "png"
                if ext not in ("png", "jpg", "jpeg", "webp", "gif"):
                    return self._json({"error": "use a PNG, JPG, WEBP or GIF"}, 400)
                data = self._body()
                if not data or len(data) > 8 * 1024 * 1024:
                    return self._json({"error": "logo must be an image under 8 MB"}, 400)
                for old_ in glob.glob(os.path.join(_brand_dir(), "logo.*")):
                    safe_remove(old_)
                path = os.path.join(_brand_dir(), "logo." + ext)
                with open(path, "wb") as f:
                    f.write(data)
                cfg = load_json(CONFIG_PATH, {})
                cfg["brand"] = dict(cfg.get("brand") or {}, logo=path)
                save_json(CONFIG_PATH, cfg)
                return self._json({"ok": True, "path": path})
            if u.path == "/api/style/upload":          # a video to learn the creator's style from
                ext = re.sub(r"[^a-z0-9]", "", (q.get("ext", "mp4")).lower())[:4] or "mp4"
                if ext not in ("mp4", "mov", "mkv", "webm", "m4v"):
                    return self._json({"error": "upload a video file"}, 400)
                data = self._body()
                if not data or len(data) > 600 * 1024 * 1024:
                    return self._json({"error": "video must be under 600 MB"}, 400)
                d = os.path.join(load_config()["work_root"], "_settings", "style_src")
                os.makedirs(d, exist_ok=True)
                name = re.sub(r"[^\w.-]+", "_", q.get("name", "clip.mp4"))[:80] or "clip.mp4"
                path = os.path.join(d, name)
                with open(path, "wb") as f:
                    f.write(data)
                return self._json({"ok": True, "path": path})
            if u.path == "/api/style/learn":           # measure the uploaded videos -> a style card + brand patch
                body = json.loads(self._body() or b"{}")
                paths = [p for p in (body.get("paths") or []) if isinstance(p, str) and _allowed(p) and os.path.exists(p)]
                if not paths:
                    return self._json({"error": "upload at least one of your videos first"}, 400)
                from . import stylematch
                return self._json({"id": _bg("style", lambda: stylematch.learn(paths), name="style")})
            if u.path == "/api/brand/logo_clear":
                for old_ in glob.glob(os.path.join(_brand_dir(), "logo.*")):
                    safe_remove(old_)
                cfg = load_json(CONFIG_PATH, {})
                if cfg.get("brand"):
                    cfg["brand"].pop("logo", None)
                    save_json(CONFIG_PATH, cfg)
                return self._json({"ok": True})
            if u.path == "/api/upload":                # raw body upload -> <project>/assets/<name>
                d = q["dir"]
                if not _allowed(d):
                    return self._json({"error": "path not allowed"}, 403)
                os.makedirs(os.path.join(d, "assets"), exist_ok=True)
                name = re.sub(r"[^\w.-]+", "_", q.get("name", "upload.bin"))
                p = os.path.join(d, "assets", name)
                with open(p, "wb") as f:
                    f.write(self._body())
                return self._json({"path": p})
            try:
                body = json.loads(self._body() or b"{}")
            except ValueError:
                return self._json({"error": "send the request as JSON"}, 400)
            if not isinstance(body, dict):
                return self._json({"error": "send the request as a JSON object"}, 400)
            for k in ("dir", "name"):                  # the two fields almost every endpoint uses: strings, sane length
                v = body.get(k)
                if v is not None and not (isinstance(v, str) and len(v) <= (4096 if k == "dir" else 120)):
                    return self._json({"error": ("%s is too long" if isinstance(v, str) else "%s must be text") % k}, 400)
            if u.path in ("/api/schedule/plan", "/api/schedule/add", "/api/schedule/cancel", "/api/schedule/retry"):
                from . import schedule
                import datetime as _dt
                try:
                    if u.path.endswith("cancel"):
                        return self._json({"ok": schedule.cancel(str(body.get("id") or "")) > 0})
                    if u.path.endswith("retry"):
                        e = next((x for x in schedule.load() if x["id"] == body.get("id")), None)
                        if not e or e["status"] not in ("failed", "missed"):
                            return self._json({"error": "nothing to retry"}, 400)
                        if e["platform"] == "youtube":
                            e["at"] = max(e["at"], int(time.time()) + 600)
                            schedule.update(e["id"], status="waiting", error=None, at=e["at"])
                            return self._json({"id": _bg("schedule", lambda: _schedule_youtube([e]))})
                        schedule.update(e["id"], status="waiting", error=None, at=int(time.time()))
                        return self._json({"ok": True})
                    clips = [str(c) for c in (body.get("clips") or []) if isinstance(c, str)][:100]
                    start = body.get("start")
                    st = _dt.datetime.strptime(start, "%Y-%m-%d").timestamp() if start else None
                    slots = schedule.plan(len(clips) or int(body.get("n") or 1), st, body.get("per_day") or 2,
                                          body.get("times") or ["12:00", "18:00"])
                    if u.path.endswith("plan"):
                        return self._json({"slots": slots})
                    d = body.get("dir") or ""
                    if not _allowed(d):
                        return self._json({"error": "open a project first"}, 400)
                    plats = [p_ for p_ in (body.get("platforms") or []) if p_ in schedule.PLATFORMS]
                    if not clips or not plats:
                        return self._json({"error": "pick at least one clip and one place to post"}, 400)
                    missing = [c for c in clips if not os.path.isfile(os.path.join(d, "renders", os.path.basename(c) + ".mp4"))]
                    if missing:
                        return self._json({"error": "render these first: %s" % ", ".join(missing[:5]) +
                                                    (" and %d more" % (len(missing) - 5) if len(missing) > 5 else "")}, 400)
                    if "youtube" in plats and not (connect.get().get("youtube") or {}).get("refresh_token"):
                        return self._json({"error": "connect YouTube first (Settings -> Posting)"}, 400)
                    if "tiktok_draft" in plats and not (connect.get().get("tiktok") or {}).get("refresh_token"):
                        return self._json({"error": "connect TikTok first (Settings -> Posting)"}, 400)
                    if "folder" in plats and not (connect.get().get("post_folder") or {}).get("path"):
                        return self._json({"error": "pick a posting folder first (Settings -> Posting)"}, 400)
                    items = [{"project": d, "clip": os.path.basename(c), "platform": p_, "at": slots[i]}
                             for i, c in enumerate(clips) for p_ in plats]
                    added = schedule.add(items)
                    yt = [e for e in added if e["platform"] == "youtube"]
                    job = _bg("schedule", lambda: _schedule_youtube(yt), project=d, name="schedule-" + yt[0]["id"]) if yt else None
                    return self._json({"added": len(added), "first": slots[0], "last": slots[len(clips) - 1], "job": job})
                except ValueError as e:
                    return self._json({"error": str(e)}, 400)
            if u.path in ("/api/accounts/add", "/api/accounts/remove", "/api/accounts/refresh", "/api/instagram/connect"):
                from . import accounts
                try:
                    if u.path.endswith("add"):
                        return self._json({"id": _bg("account", lambda: {"handle": accounts.add(str(body.get("url") or ""))["handle"]},
                                                      project="accounts", name=str(body.get("url") or "")[:200])}) \
                            if accounts.normalize(str(body.get("url") or "")) else None
                    if u.path.endswith("remove"):
                        return self._json({"ok": accounts.remove(str(body.get("url") or "")) > 0})
                    if u.path.endswith("refresh"):
                        return self._json({"id": _bg("accounts", lambda: {"checked": accounts.refresh_all(force=True)},
                                                      project="accounts", name="refresh")})
                    tok = str(body.get("token") or "").strip()
                    if not tok:
                        connect.save({"instagram": None})
                        return self._json({"ok": True, "connected": False})
                    if not re.match(r"^[A-Za-z0-9_\-|.]{40,600}$", tok):
                        return self._json({"error": "that doesn't look like an Instagram access token"}, 400)
                    me = accounts.ig_check(tok)
                    connect.save({"instagram": {"token": tok, "username": me.get("username"), "user_id": me.get("user_id"),
                                                  "saved": int(time.time()), "refreshed": None}})
                    return self._json({"ok": True, "username": me.get("username"), "followers": me.get("followers_count")})
                except (ValueError, RuntimeError) as e:
                    return self._json({"error": str(e)}, 400)
            if u.path == "/api/clip/prompt":          # the prompt box on a clip: plain words -> one focused edit
                from . import clip_prompt
                d = body.get("dir") or ""
                spec = body.get("spec")
                if not _allowed(d) or not isinstance(spec, dict):
                    return self._json({"error": "open a project and pick a clip first"}, 400)
                if not isinstance(body.get("text"), str):
                    return self._json({"error": "type what you'd like to change"}, 400)
                from .common import load_store
                words = load_store(os.path.join(d, "words.json"), [], list)
                ph = body.get("playhead")
                ph = float(ph) if isinstance(ph, (int, float)) else None
                try:
                    return self._json(clip_prompt.plan(body["text"], spec, words, ph))
                except (KeyError, ValueError, TypeError) as e:
                    return self._json({"error": "couldn't read this clip (%s)" % str(e)[:80]}, 400)
            if u.path == "/api/words/fix":            # a misheard word or name, fixed everywhere + remembered
                from . import wordfix
                d = body.get("dir") or ""
                if not _allowed(d):
                    return self._json({"error": "path not allowed"}, 403)
                try:
                    return self._json(wordfix.fix(d, body.get("from"), body.get("to"), bool(body.get("everywhere", True)),
                                                  bool(body.get("remember", True)), body.get("clip")))
                except ValueError as e:
                    return self._json({"error": str(e)}, 400)
            d = body.get("dir")
            if d is not None and not _allowed(d):
                return self._json({"error": "path not allowed"}, 403)
            if u.path == "/api/save":
                if not isinstance(body["specs"], list) or not all(isinstance(x, dict) for x in body["specs"]):
                    raise ValueError("specs must be a list of clips")
                save_json(os.path.join(d, "specs.json"), body["specs"], backup=True)
                return self._json({"ok": True, "saved": len(body["specs"])})
            if u.path == "/api/render":
                jid = uuid.uuid4().hex[:10]
                JOBS[jid] = {"id": jid, "status": "running", "started": time.time(), "name": body["spec"].get("name"),
                             "draft": bool(body.get("draft"))}
                threading.Thread(target=run_job, args=(jid, d, body["spec"], bool(body.get("draft"))), daemon=True).start()
                return self._json({"id": jid})
            if u.path == "/api/qc":
                from .verify import qc_set
                return self._json(qc_set(os.path.join(d, "renders"), body["name"], body["status"], body.get("note", ""),
                                         bool(body.get("watched"))))
            if u.path == "/api/autoclip":
                from .autoclip import run as autorun, _project_dir, project_name
                src = (body.get("source") or "").strip()
                if not src:
                    return self._json({"error": "paste a link or choose a video file first"}, 400)
                if not re.match(r"https?://", src) and not _allowed(src):
                    return self._json({"error": "file must be uploaded first"}, 403)
                if src.startswith("http"):
                    from .fetch import LinkError, direct_link
                    try:
                        direct_link(src)
                    except LinkError as e:          # folder link etc. -> tell them right away
                        return self._json({"error": str(e)}, 400)
                nm = body.get("name") or project_name(src)
                pdir = _project_dir(Ctx.root, nm)
                try:
                    n_clips = max(0, min(100, int(body.get("clips", 0) or 0)))     # 0 = Auto (scales with length)
                except (TypeError, ValueError):
                    n_clips = 0
                jid = _bg("autoclip", lambda: autorun(src, Ctx.root, nm, n_clips,
                                                      float(body.get("min_score", 6.0)), body.get("captions"),
                                                      body.get("banner"), bool(body.get("draft")), True,
                                                      aspect=body.get("aspect") or "9:16",
                                                      also_aspects=body.get("also_aspects") if isinstance(body.get("also_aspects"), list) else None,
                                                      headline=body.get("headline", True) is not False,
                                                      manual=bool(body.get("manual")),
                                                      prompt=(body.get("prompt") or "").strip()[:300] or None,
                                                      streamer=body.get("streamer") or None,
                                                      section=_section(body),
                                                      chat_file=_chat_file(body.get("chat_file")),
                                                      preset=body.get("preset") or None,
                                                      campaign=body.get("campaign") or None,
                                                      skill=body.get("skill") or None),
                          project=pdir, source=src)
                return self._json({"id": jid, "project": pdir})
            if u.path.startswith(("/api/post/", "/api/track", "/api/untrack", "/api/youtube/", "/api/tiktok/", "/api/twitch/")):
                from . import post as _post
                from . import social
                try:
                    if u.path == "/api/tiktok/auth":
                        url_, ver = social.tt_auth_url("http://127.0.0.1:%d/oauth/tiktok/" % Ctx.port, uuid.uuid4().hex)
                        Ctx.tt_state = (urllib.parse.parse_qs(urllib.parse.urlparse(url_).query)["state"][0], ver)
                        return self._json({"url": url_})
                    if u.path == "/api/tiktok/creator":
                        return self._json(social.tt_creator())
                    if u.path == "/api/twitch/device":
                        return self._json(social.tw_device_start())
                    if u.path == "/api/twitch/poll":
                        return self._json(social.tw_device_poll())
                    if u.path == "/api/twitch/clip":
                        return self._json(social.tw_create_clip(body.get("channel"), body.get("title"), body.get("duration")))
                    if u.path == "/api/youtube/auth":
                        Ctx.yt_state = uuid.uuid4().hex
                        return self._json({"url": _post.yt_auth_url("http://127.0.0.1:%d/oauth/youtube" % Ctx.port, Ctx.yt_state)})
                    if u.path == "/api/untrack":
                        return self._json({"ok": _post.untrack(body.get("url")) > 0})
                    if u.path == "/api/track/refresh":
                        jid = _bg("views", lambda: _post.refresh(force=True))
                        return self._json({"id": jid})
                    d = body.get("dir") or ""
                    if not _allowed(d):
                        return self._json({"error": "open a project first"}, 400)
                    name = body.get("name") or ""
                    if u.path == "/api/track":
                        return self._json({"post": _post.track(body.get("url"), d, name)})
                    spec = _post._spec(d, name) or {}
                    if body.get("spec"):                 # the editor's latest title / caption, even if not saved yet
                        spec = dict(spec, **{k: body["spec"][k] for k in ("title", "description", "hashtags", "headline")
                                             if k in body["spec"]})
                    if not name or os.path.basename(name) != name or name.startswith("."):
                        return self._json({"error": "pick a clip"}, 400)
                    vid = os.path.join(d, "renders", name + ".mp4")
                    if not os.path.isfile(vid):
                        return self._json({"error": "render this clip first (Render clip, top right)"}, 400)
                    if u.path == "/api/post/phone":
                        return self._json(_post.start_handoff(vid, _post.caption_text(spec)))
                    if u.path == "/api/post/folder":
                        from .connect import get as _cget
                        return self._json(_post.to_folder(vid, spec, (_cget().get("post_folder") or {}).get("path"),
                                                          os.path.basename(d)))
                    if u.path == "/api/post/everywhere":
                        from . import publish
                        cap = _post.caption_text(spec)
                        targets = []
                        if social.x_connected():
                            targets.append("x")
                        if publish.discord_connected():
                            targets.append("discord")
                        if publish.telegram_connected():
                            targets.append("telegram")
                        if not targets:
                            return self._json({"error": "connect at least one account first (Settings)"}, 400)

                        def postall():
                            out = []
                            for t in targets:
                                try:
                                    if t == "x":
                                        r = social.x_publish(vid, cap)
                                    elif t == "discord":
                                        r = publish.discord_post(vid, cap)
                                    else:
                                        r = publish.telegram_post(vid, cap)
                                    if r.get("url"):
                                        _post.track(r["url"], d, name)
                                    out.append({"platform": t, "ok": True, "url": r.get("url")})
                                except Exception as e:
                                    out.append({"platform": t, "ok": False, "error": str(e)[:200]})
                            return {"results": out, "posted": sum(1 for r in out if r["ok"])}
                        return self._json({"id": _bg("postall", postall, project=d, name=name), "targets": targets})
                    if u.path == "/api/post/x":
                        cap = _post.caption_text(spec)

                        def xp():
                            r = social.x_publish(vid, cap)
                            if r.get("url"):
                                _post.track(r["url"], d, name)
                            return r
                        return self._json({"id": _bg("x", xp, project=d, name=name)})
                    if u.path in ("/api/post/discord", "/api/post/telegram"):
                        from . import publish
                        cap = _post.caption_text(spec)
                        plat = "discord" if u.path.endswith("discord") else "telegram"
                        fn = (lambda: publish.discord_post(vid, cap)) if plat == "discord" else (lambda: publish.telegram_post(vid, cap))
                        return self._json({"id": _bg(plat, fn, project=d, name=name)})
                    if u.path == "/api/post/tiktok":
                        mode = "direct" if body.get("mode") == "direct" else "draft"
                        if mode == "direct" and not body.get("consent"):
                            return self._json({"error": "confirm you agree before posting"}, 400)
                        pinfo = dict(body.get("post") or {})
                        if mode == "direct":
                            pinfo.setdefault("title", _post.caption_text(spec))

                        def tt():
                            r = social.tt_upload(vid, mode, pinfo)
                            st = social.tt_wait(r["publish_id"])
                            r.update(st)
                            who = body.get("username") or ""
                            if st.get("post_ids") and who:
                                r["url"] = "https://www.tiktok.com/@%s/video/%s" % (who, st["post_ids"][0])
                                _post.track(r["url"], d, name)
                            return r
                        return self._json({"id": _bg("tiktok", tt, project=d, name=name)})
                    if u.path == "/api/post/youtube":
                        tags = re.findall(r"#?(\w+)", spec.get("hashtags") or "")
                        desc = "\n\n".join(x for x in (spec.get("description") or "", " ".join("#" + t for t in tags)) if x)
                        when = (body.get("publish_at") or "").strip() or None
                        if when and not re.match(r"^\d{4}-\d\d-\d\dT\d\d:\d\d(:\d\d)?(\.\d+)?(Z|[+-]\d\d:\d\d)$", when):
                            return self._json({"error": "pick a date and time to schedule"}, 400)

                        def up():
                            r = _post.yt_upload(vid, spec.get("title") or spec.get("headline") or name, desc, tags,
                                                body.get("privacy") or "public", when)
                            _post.track(r["url"], d, name)          # its views feed the learning loop
                            return r
                        return self._json({"id": _bg("youtube", up, project=d, name=name)})
                except (ValueError, RuntimeError) as e:
                    return self._json({"error": str(e)}, 400)
                return self._json({"error": "unknown endpoint"}, 404)
            if u.path == "/api/subs/translate":      # the clip's .srt in another language (user's own AI)
                from . import subs
                d, name = body.get("dir") or "", body.get("name") or ""
                if not _allowed(d) or not name or os.path.basename(name) != name:
                    return self._json({"error": "open a clip first"}, 400)
                try:
                    return self._json(subs.translate_srt(os.path.join(d, "renders", name + ".srt"), body.get("lang") or ""))
                except (ValueError, RuntimeError) as e:
                    return self._json({"error": str(e)}, 400)
            if u.path in ("/api/edits/package", "/api/edits/youtube", "/api/edits/shorts"):
                from . import edit_publish as _ep
                from . import post as _post
                d, name = body.get("dir") or "", body.get("name") or ""
                if not _allowed(d):
                    return self._json({"error": "path not allowed"}, 403)
                try:
                    _ep._paths(d, name)
                    if u.path.endswith("shorts"):
                        return self._json({"id": _bg("shorts", lambda: _ep.shorts(d, name, per_part=int(body.get("per_part") or 1)),
                                                      project=d, name=name)})
                    if u.path.endswith("package"):
                        if body.get("saved_only"):
                            return self._json({"package": _ep.saved(d, name)})
                        return self._json({"id": _bg("package", lambda: _ep.package(d, name), project=d, name=name)})
                    vid = os.path.join(d, "edits", name + ".mp4")
                    when = (body.get("publish_at") or "").strip() or None
                    if when and not re.match(r"^\d{4}-\d\d-\d\dT\d\d:\d\d(:\d\d)?(\.\d+)?(Z|[+-]\d\d:\d\d)$", when):
                        return self._json({"error": "pick a date and time to schedule"}, 400)
                    thumb = body.get("thumbnail") or None
                    if thumb and not (_allowed(thumb) and os.path.isfile(thumb)):
                        return self._json({"error": "that thumbnail file isn't available"}, 400)
                    tags = [str(t)[:30] for t in (body.get("tags") or [])][:15]

                    def up():
                        r = _post.yt_upload(vid, str(body.get("title") or name)[:100], str(body.get("description") or "")[:4900],
                                            tags, body.get("privacy") or "public", when, short=False)
                        if thumb:
                            try:
                                _post.yt_thumbnail(r["id"], thumb)
                                r["thumbnail"] = True
                            except Exception as e:
                                r["thumbnail_error"] = str(e)[:200]
                        _post.track(r["url"], d, "edit:" + name)
                        return r
                    return self._json({"id": _bg("youtube", up, project=d, name=name)})
                except (ValueError, RuntimeError) as e:
                    return self._json({"error": str(e)}, 400)
            if u.path in ("/api/edits/longform", "/api/edits/trailer"):
                d = body.get("dir") or ""
                if not _allowed(d) or not os.path.exists(os.path.join(d, "source.mp4")):
                    return self._json({"error": "open a project first"}, 400)
                ename = re.sub(r"[^\w-]+", "_", str(body.get("name") or ""))[:60] or None
                for j in list(JOBS.values()):              # one edit at a time per project: renders are heavy and
                    if j.get("kind") == "edit" and j.get("status") == "running" and j.get("project") == d:   # share files
                        if ename and j.get("ename") == ename:
                            return self._json({"id": j["id"], "joined": True})
                        return self._json({"error": "an edit is already being made for this project - wait for it to finish"}, 409)
                jid = uuid.uuid4().hex[:10]
                JOBS[jid] = {"id": jid, "kind": "edit", "status": "running", "started": time.time(), "project": d,
                             "progress": [0, 1, "starting"], "ename": ename}

                def prog(a_, b_, what):
                    JOBS[jid]["progress"] = [a_, b_, what]
                if u.path.endswith("longform"):
                    from . import longform
                    try:
                        mins = max(1.0, min(60.0, float(body.get("minutes") or 10)))
                    except (TypeError, ValueError):
                        mins = 10.0

                    def work():
                        return longform.build(d, minutes=mins, aspect=body.get("aspect") or "16:9",
                                              title=(body.get("title") or "").strip()[:80] or None,
                                              captions=body.get("captions") or "none", cold=body.get("cold", True) is not False,
                                              chapters=body.get("chapters", True) is not False,
                                              preset=body.get("preset") or None, progress=prog, draft=bool(body.get("draft")),
                                              parts=body.get("parts") or None, cold_range=body.get("cold_range") or None,
                                              name=(body.get("name") or None), end_screen=bool(body.get("end_screen")))
                else:
                    from . import montage_engine
                    prof = body.get("profile") if body.get("profile") in montage_engine.PROFILES else "trailer"
                    try:
                        secs = max(10.0, min(180.0, float(body.get("seconds") or 45)))
                    except (TypeError, ValueError):
                        secs = 45.0
                    music = body.get("music") or None
                    if music and not _allowed(music):
                        return self._json({"error": "upload the music file first"}, 400)
                    src = os.path.join(d, "source.mp4")
                    moments = []
                    if body.get("from") == "clips":
                        try:
                            for sp_ in json.load(open(os.path.join(d, "specs.json"))):
                                moments.append({"source": src, "start": float(sp_["start"]), "end": float(sp_["end"]),
                                                "label": sp_.get("headline") or sp_["name"], "score": (sp_.get("quality") or {}).get("score", 6)})
                        except Exception:
                            pass
                    if not moments:
                        try:
                            for c in json.load(open(os.path.join(d, "candidates.json")))[:16]:
                                moments.append({"source": src, "start": float(c["start"]), "end": float(c["end"]),
                                                "label": " ".join(x[1] for x in c.get("sentences", []))[:60],
                                                "score": (c.get("quality") or {}).get("score", c.get("score", 5))})
                        except Exception:
                            pass
                    if not moments:
                        dur_ = probe(src)["duration"]
                        moments = [{"source": src, "start": round(dur_ * k / 8, 2), "end": round(min(dur_, dur_ * k / 8 + 12), 2),
                                    "label": "moment %d" % (k + 1), "score": 5} for k in range(8)]
                    cards = [c.strip()[:40] for c in (body.get("cards") or []) if str(c).strip()][:6]
                    name = re.sub(r"[^\w-]+", "_", "%s_%s" % (prof, time.strftime("%m%d_%H%M")))
                    brief = {"name": name, "profile": prof, "duration": secs, "music": music,
                             "title": (body.get("title") or "").strip()[:60], "subtitle": (body.get("subtitle") or "").strip()[:60],
                             "cards": cards, "moments": moments}
                    os.makedirs(os.path.join(d, "edits"), exist_ok=True)
                    out_ = os.path.join(d, "edits", name + ".mp4")
                    asp = body.get("aspect") if body.get("aspect") in ("9:16", "16:9", "1:1", "4:5") else "9:16"

                    def work():
                        prog(0, 1, "planning the edit to the beat")
                        r = montage_engine.build(brief, out_, aspect=asp, workdir=os.path.join(d, "edits", "_" + name))
                        prog(1, 1, "done")
                        return {"file": out_, "length": round(probe(out_)["duration"], 1)}

                def go():
                    try:
                        res = work()
                        JOBS[jid].update(status="done", result=res, finished=time.time())
                        connect.fire("edit_ready", {"title": os.path.basename(res.get("file") or "") or "Your edit",
                                                    "length": "%.1f min" % ((res.get("length") or 0) / 60.0)})
                    except Exception as e:
                        JOBS[jid].update(status="error", error=str(e)[:400], finished=time.time())
                        connect.fire("edit_failed", {"title": "Your edit", "error": str(e)[:200]})
                threading.Thread(target=go, daemon=True).start()
                return self._json({"id": jid})
            if u.path == "/api/batch":               # several links: auto-clip them one after another
                from .autoclip import run as autorun, _project_dir, project_name
                from .fetch import LinkError, direct_link
                links, bad = [], []
                for x in re.split(r"[\s,]+", str(body.get("links") or "")):
                    x = x.strip()
                    if not x:
                        continue
                    if not re.match(r"https?://", x):
                        bad.append(x[:80])
                        continue
                    try:
                        direct_link(x)
                    except LinkError as e:
                        bad.append("%s (%s)" % (x[:60], str(e)[:80]))
                        continue
                    if x not in links:
                        links.append(x)
                if not links:
                    return self._json({"error": "no usable links" + (": " + "; ".join(bad[:3]) if bad else "")}, 400)
                links = links[:50]
                o = dict(body)
                jid = uuid.uuid4().hex[:10]
                JOBS[jid] = {"id": jid, "kind": "batch", "status": "running", "started": time.time(), "total": len(links),
                             "done": 0, "items": [{"source": l_, "project": _project_dir(Ctx.root, project_name(l_)),
                                                   "state": "waiting"} for l_ in links], "skipped": bad}

                def go():
                    try:
                        for it in JOBS[jid]["items"]:
                            if JOBS[jid].get("cancel"):
                                it["state"] = "cancelled"
                                continue
                            it["state"] = "running"
                            JOBS[jid]["current"] = it["project"]
                            try:
                                st = autorun(it["source"], Ctx.root, os.path.basename(it["project"]),
                                             max(0, min(100, int(o.get("clips") or 0))), float(o.get("min_score") or 6.0),
                                             o.get("captions"), o.get("banner"), bool(o.get("draft")), True,
                                             aspect=o.get("aspect") or "9:16", also_aspects=o.get("also_aspects") if isinstance(o.get("also_aspects"), list) else None,
                                             headline=o.get("headline", True) is not False, prompt=(o.get("prompt") or None),
                                             streamer=o.get("streamer") or None, preset=o.get("preset") or None,
                                             campaign=o.get("campaign") or None)
                                it["state"] = st.get("state", "done")
                                it["clips"] = len([c for c in st.get("clips") or [] if isinstance(c, dict) and c.get("file")])
                                if st.get("state") == "error":
                                    it["error"] = str(st.get("error") or "")[:300]
                            except Exception as e:      # one bad link never stops the rest
                                it["state"], it["error"] = "error", str(e)[:300]
                            JOBS[jid]["done"] += 1
                        JOBS[jid].update(status="done", finished=time.time(), current=None)
                    except Exception as e:              # the whole batch must always reach a terminal state
                        JOBS[jid].update(status="error", error=str(e)[:400], finished=time.time(), current=None)
                threading.Thread(target=go, daemon=True).start()
                return self._json({"id": jid, "total": len(links), "skipped": bad,
                                   "first": JOBS[jid]["items"][0]["project"]})
            if u.path == "/api/batch/cancel":
                if body.get("id") in JOBS:
                    JOBS[body["id"]]["cancel"] = True
                return self._json({"ok": True})
            if u.path == "/api/more_clips":          # more clips from a video this project already has
                from .autoclip import run as autorun
                d = body.get("dir") or ""
                if not _allowed(d) or not os.path.exists(os.path.join(d, "source.mp4")):
                    return self._json({"error": "open a project first"}, 400)
                st = {}
                try:
                    st = json.load(open(os.path.join(d, "autoclip_status.json")))
                except Exception:
                    pass
                if str(st.get("state", "")).startswith(("importing", "transcribing", "finding", "scored", "rendering")):
                    return self._json({"error": "this project is still working - wait for it to finish"}, 409)
                o = st.get("opts") or {}
                try:
                    n_more = max(1, min(100, int(body.get("clips") or 6)))
                except (TypeError, ValueError):
                    n_more = 6
                src = os.path.join(d, "source.mp4")
                jid = _bg("autoclip", lambda: autorun(src, os.path.dirname(d), os.path.basename(d), n_more,
                                                      float(o.get("min_score") or 6.0), o.get("captions"),
                                                      st.get("banner_used") or False,
                                                      False, True, aspect=o.get("aspect") or "9:16",
                                                      also_aspects=o.get("also_aspects"),
                                                      headline=o.get("headline", True) is not False,
                                                      prompt=o.get("prompt"), streamer=o.get("streamer"), more=True,
                                                      preset=o.get("preset"), campaign=o.get("campaign"),
                                                      skill=o.get("skill")),
                          project=d, source=src)
                return self._json({"id": jid, "project": d})
            if u.path == "/api/live/start":
                from . import connect as _cn
                if body.get("authorized"):
                    try: _cn.save({"clips": {"rights_ack": True}})   # remember the one-time acknowledgement
                    except Exception: pass
                elif not _cn.get().get("clips", {}).get("rights_ack"):
                    return self._json({"error": "Check the box confirming you have the right to clip this channel, then start."}, 403)
                from .live import LiveSession
                always = bool(body.get("always"))     # keep going: clip every stream this channel does

                def make():
                    se = LiveSession(body["url"], name=body.get("name"),
                                     minutes=float(body["minutes"]) if body.get("minutes") else None,
                                     chat=body.get("chat") or None, render=True, outroot=os.path.join(Ctx.root, "live"),
                                     wait_hours=24.0 if always else float(body.get("wait_hours") or 0),
                                     min_quality=float(body.get("min_score") or 6))
                    se.preset = body.get("preset") or None
                    if body.get("steady_minutes") is not None:
                        try:
                            se.steady_s = 60.0 * max(0.0, min(60.0, float(body["steady_minutes"])))
                        except (TypeError, ValueError):
                            pass
                    return se
                sess = make()
                lid = uuid.uuid4().hex[:8]
                LIVE[lid] = sess
                if always:
                    LIVE_ALWAYS.add(lid)

                def loop(se=sess):
                    while True:
                        try:
                            se.run()
                        except Exception as e:
                            print("live: session ended with an error: %s" % e, flush=True)
                        if not always or LIVE_STOPPED.get(lid):
                            break
                        time.sleep(30)            # stream over: wait for the next one, in a fresh folder
                        if LIVE_STOPPED.get(lid):
                            break
                        se = make()
                        LIVE[lid] = se
                threading.Thread(target=loop, daemon=True).start()
                return self._json({"id": lid, "dir": sess.dir})
            if u.path == "/api/category/start":        # Category Watch: clip the top live streams of a game at once
                from . import connect as _cn
                if body.get("authorized"):
                    try: _cn.save({"clips": {"rights_ack": True}})   # remember the one-time acknowledgement
                    except Exception: pass
                elif not _cn.get().get("clips", {}).get("rights_ack"):
                    return self._json({"error": "Check the box confirming you have the right to clip these streams, then start."}, 403)
                from . import category
                from .live import LiveSession
                pl = category.plan(game=body.get("game") or category.discover.DEFAULT_GAME,
                                   platforms=tuple(body.get("platforms") or ("twitch", "kick")),
                                   limit=int(body.get("limit") or 5))
                started = []
                for s in pl["streams"]:
                    try:
                        se = LiveSession(s["url"], name=s.get("name") or s.get("channel"), render=True,
                                         outroot=os.path.join(Ctx.root, "live"),
                                         min_quality=float(body.get("min_score") or 6))
                        se.preset = body.get("preset") or None
                        lid = uuid.uuid4().hex[:8]
                        LIVE[lid] = se

                        def loop(se=se):
                            try:
                                se.run()
                            except Exception as e:
                                print("category: a session ended: %s" % e, flush=True)
                        threading.Thread(target=loop, daemon=True).start()
                        started.append({"id": lid, "dir": se.dir, "name": s.get("name"),
                                        "platform": s.get("platform"), "viewers": s.get("viewers"), "url": s["url"]})
                    except Exception as e:
                        print("category: could not start %s: %s" % (s.get("url"), e), flush=True)
                return self._json({"game": pl["game"], "started": started, "errors": pl["errors"]})
            if u.path == "/api/live/stop":
                if body.get("id") in LIVE:
                    LIVE_STOPPED[body["id"]] = True
                    LIVE[body["id"]].stop.set()
                return self._json({"ok": True})
            if u.path == "/api/live/mark":           # instant manual clip: last N seconds
                sess = LIVE.get(body.get("id"))
                if not sess or not sess.all_segments():
                    return self._json({"error": "nothing recorded yet - wait for the stream to start"}, 400)
                if body.get("start") is not None and body.get("end") is not None:      # marked in/out by hand
                    a_, b_ = float(body["start"]), float(body["end"])
                    if not 1.0 <= b_ - a_ <= 600:
                        return self._json({"error": "mark an in and an out point 1 second to 10 minutes apart"}, 400)
                    c = {"start": a_, "end": b_, "exact": True, "live_score": None, "chat_z": None,
                         "tags": {"manual": 1}, "sentences": []}
                else:
                    edge = sess.all_segments()[-1]["b"]
                    secs = float(body.get("seconds", 30))
                    c = {"start": max(0.0, edge - secs), "end": edge, "live_score": None, "chat_z": None,
                         "tags": {"manual": 1}, "sentences": []}
                k = len(sess.clips) + 1
                cut = sess._cut(c, k)
                if not cut:
                    return self._json({"error": "could not cut"}, 400)
                cd, spec = cut
                sess.clips.append({"clip": spec["name"], "dir": cd, "status": "rendering", "manual": True})
                sess.pool.submit(sess._render, cd, spec)
                return self._json({"clip": spec["name"], "dir": cd})
            if u.path == "/api/titles":
                from .packaging import titles
                from .presets import load_skill
                return self._json({"titles": titles(body.get("text", ""), tuple(body.get("names") or ()), body.get("headline", ""),
                                                    skill=load_skill(body.get("skill")) if body.get("skill") else None)})
            if u.path == "/api/ai/prompt_help":       # turn a rough idea into a prompt that works
                from . import prompt_help
                try:
                    return self._json(prompt_help.improve(body.get("kind", ""), body.get("text", "")))
                except (ValueError, RuntimeError) as e:
                    return self._json({"error": str(e)}, 400)
            if u.path in ("/api/thumbs/frames", "/api/thumbs/make"):   # big-creator thumbnails (thumbs.py)
                from . import thumbs
                d, name = body.get("dir") or "", body.get("name") or ""
                if not _allowed(d) or not name or os.path.basename(name) != name:
                    return self._json({"error": "open a clip first"}, 400)
                src = os.path.join(d, "source.mp4")
                spec = {}
                if body.get("edit"):                       # a long-form edit: thumbnails from the finished video
                    src = os.path.join(d, "edits", os.path.basename(str(body["edit"])) + ".mp4")
                    if not os.path.isfile(src):
                        return self._json({"error": "that edit doesn't exist"}, 400)
                    name = "edit_" + os.path.basename(str(body["edit"]))
                else:
                    try:
                        spec = next((x for x in json.load(open(os.path.join(d, "specs.json"))) if x.get("name") == name), {})
                    except Exception:
                        pass
                a_, b_ = float(body.get("start", spec.get("start", 0)) or 0), float(body.get("end", spec.get("end", 0)) or 0)
                tdir = os.path.join(d, "renders", "_thumbs")
                os.makedirs(tdir, exist_ok=True)
                try:
                    if u.path.endswith("frames"):
                        import cv2
                        out = []
                        for i, f in enumerate(thumbs.frames(src, n=6, a=a_ or None, b=b_ or None)):
                            fn = os.path.join(tdir, "%s_frame%d.jpg" % (name, i))
                            im = f["rgb"]
                            h, w = im.shape[:2]
                            sm = cv2.resize(im, (480, int(480 * h / w)))
                            cv2.imwrite(fn, cv2.cvtColor(sm, cv2.COLOR_RGB2BGR), [cv2.IMWRITE_JPEG_QUALITY, 85])
                            out.append({"t": f["t"], "face": bool(f["face"]), "file": fn})
                        return self._json({"frames": out})
                    styles = [x for x in (body.get("styles") or list(thumbs.STYLES)) if x in thumbs.STYLES] or ["pop"]
                    r = thumbs.make(src, float(body.get("t") or a_), os.path.join(tdir, "%s_%d" % (name, int(time.time()))),
                                    text=str(body.get("text") or "")[:60], styles=styles, emoji=(body.get("emoji") or None),
                                    arrow=bool(body.get("arrow")), circle=bool(body.get("circle")),
                                    ai_scene=str(body.get("scene") or "")[:300] or None, ai_people=bool(body.get("people")))
                    return self._json(r)
                except (ValueError, RuntimeError) as e:
                    return self._json({"error": str(e)}, 400)
            if u.path == "/api/thumbnail":
                from .packaging import thumbnail
                vid = body["video"]
                if not _allowed(vid):
                    return self._json({"error": "path not allowed"}, 403)
                base = os.path.splitext(vid)[0] + "_thumb"
                return self._json(thumbnail(vid, base, body.get("text", ""), emoji=body.get("emoji") or None,
                                            arrow=bool(body.get("arrow")), circle=bool(body.get("circle"))))
            if u.path == "/api/prompt_find":         # "every time he talks about X" -> matching moments
                from . import lore
                from .prompt_clip import find
                from .score import score_candidate
                prompt = (body.get("prompt") or "").strip()[:300]
                if not prompt:
                    return self._json({"error": "describe the moment you want, e.g. 'when he talks about the coin'"}, 400)
                wp = os.path.join(d, "words.json")
                if not os.path.exists(wp):
                    return self._json({"error": "this project has no transcript yet, so there's nothing to search"}, 400)
                prof = lore.load(body.get("streamer"))
                c, info = find(prompt, json.load(open(wp)), os.path.join(d, "source.mp4"), d,
                               n=max(1, min(30, int(body.get("n", 8)))), lore=lore.terms(prof),
                               lore_aliases=lore.aliases(prof))
                for x in c:
                    x["quality"] = score_candidate(x)
                return self._json({"candidates": c, "info": info})
            if u.path in ("/api/rate", "/api/learn_event"):   # learning signals from the editor
                from . import learn
                spec = body.get("spec") or {}
                if u.path == "/api/rate":
                    r = int(body.get("rating") or 0)
                    if r not in (1, -1):
                        return self._json({"error": "rating must be 1 or -1"}, 400)
                    reasons = [x for x in (body.get("reasons") or []) if x in learn.REASONS]
                    learn.record("rated", spec, d, rating=r, reasons=reasons)
                else:
                    kind = body.get("kind")
                    if kind == "title_used":         # which kind of title (and which AI) people actually pick
                        learn.record("title_used", spec, d, style=str(body.get("style") or "")[:20] or None,
                                     src=str(body.get("src") or "")[:80] or None,
                                     supported=bool(body.get("supported")), offered=int(body.get("offered") or 0))
                        return self._json({"ok": True})
                    if kind not in ("deleted", "performance"):
                        return self._json({"error": "unknown event"}, 400)
                    views = body.get("views")
                    if kind == "performance":
                        try:
                            views = max(0.0, float(str(views).replace(",", "")))
                        except (TypeError, ValueError):
                            return self._json({"error": "views must be a number"}, 400)
                    learn.record(kind, spec, d, views=views if kind == "performance" else None,
                                 platform=(body.get("platform") or None))
                return self._json({"ok": True, "insights": learn.insights()})
            if u.path == "/api/learning/send":
                from . import learn
                return self._json(learn.send_report(force=True))
            if u.path == "/api/giphy/add":            # picked GIF -> <project>/assets/giphy_<id>.gif
                from . import giphy
                if not _allowed(d):
                    return self._json({"error": "path not allowed"}, 403)
                try:
                    return self._json(giphy.fetch(body.get("id"), d))
                except (RuntimeError, ValueError) as e:
                    return self._json({"error": str(e)}, 400)
            if u.path == "/api/connections":
                pass
                try:
                    return self._json(dict(connect.save(body.get("patch") or {}), ai_ready=connect.ai_ready(),
                                           browsers=connect.BROWSERS))
                except ValueError as e:
                    return self._json({"error": str(e)}, 400)
            if u.path in ("/api/watch/add", "/api/watch/remove", "/api/watch/check"):
                from . import watch
                try:
                    if u.path.endswith("add"):
                        w = watch.add(body.get("url"), streamer=body.get("streamer") or None,
                                      clips=int(body.get("clips") or 6), min_score=float(body.get("min_score") or 6),
                                      aspect=body.get("aspect") or "9:16", latest=bool(body.get("latest")),
                                      preset=body.get("preset") or None)
                        if body.get("latest") and getattr(Ctx, "poller", None):
                            Ctx.poller.now()
                        return self._json({"ok": True, "watch": dict(w, seen=len(w["seen"]))})
                    if u.path.endswith("remove"):
                        return self._json({"ok": watch.remove(body.get("url")) > 0})
                    if getattr(Ctx, "poller", None):
                        Ctx.poller.now()
                    return self._json({"ok": True})
                except (ValueError, RuntimeError) as e:
                    return self._json({"error": str(e)}, 400)
            if u.path == "/api/connections/test":
                pass
                what = body.get("what")
                try:
                    if what == "ai":
                        t = connect.ai_titles("So last week I bought this coin at $200K and it hit $10 million.", n=2)
                        return self._json({"ok": bool(t), "detail": " / ".join(t) or "no titles returned"})
                    if what == "webhook":
                        return self._json({"ok": connect.fire("test", {"name": "test", "title": "Clipbot webhook test"}),
                                           "detail": "test sent (check your service)"})
                    if what == "notify":
                        if not (connect.get().get("notify") or {}).get("topic"):
                            return self._json({"error": "save an alert name first"}, 400)
                        connect.notify("Clipbot", "Test alert - phone alerts are working")
                        return self._json({"ok": True})
                    if what == "scorer":
                        if not connect.scorer_ready():
                            return self._json({"ok": False, "detail": "save your scorer's URL first"})
                        got = connect.score_external([
                            {"start": 0, "end": 20, "sentences": [[0, "No way, he actually hit the jackpot!"]], "tags": {"reaction": 1}},
                            {"start": 30, "end": 50, "sentences": [[30, "Okay so anyway, hit follow if you're new."]], "tags": {}}])
                        return self._json({"ok": bool(got), "detail": ("scores back: " + ", ".join(
                            "#%d=%s" % (i, v["score"]) for i, v in sorted(got.items()))) if got else
                            "it answered, but with no scores Clipbot could read (see CONNECT.md)"})
                    if what == "feedback":
                        from . import learn
                        r = learn.send_report(force=True)
                        return self._json({"ok": r.get("sent", False), "detail": r.get("why") or "report sent"})
                except RuntimeError as e:
                    return self._json({"ok": False, "detail": str(e)})
                return self._json({"error": "unknown test"}, 400)
            if u.path in ("/api/carousel/make", "/api/carousel/render"):
                from . import carousel
                if not d or not os.path.isdir(d):
                    return self._json({"error": "open a project first"}, 400)
                shape = body.get("shape") if body.get("shape") in carousel.SHAPES else "4:5"
                style = body.get("style") if body.get("style") in carousel.STYLES else "night"
                handle = str(body.get("handle") or "")[:40]
                try:
                    if u.path == "/api/carousel/make":
                        pl = carousel.plan(d, n=max(3, min(12, int(body.get("n") or 7))), use_ai=body.get("use_ai", True),
                                           handle=handle)
                    else:
                        pl = body.get("plan")
                        if not isinstance(pl, dict) or not isinstance(pl.get("slides"), list) or not pl["slides"]:
                            return self._json({"error": "nothing to draw - press Make carousel first"}, 400)
                        pl["slides"] = [x for x in pl["slides"] if isinstance(x, dict)][:15]
                        for x in pl["slides"]:
                            x["heading"], x["quote"] = str(x.get("heading") or "")[:200], str(x.get("quote") or "")[:400]
                            x["kind"] = x.get("kind") if x.get("kind") in ("cover", "quote", "end") else "quote"
                            for k in ("t", "frame_t"):
                                try:
                                    x[k] = max(0.0, min(1e6, float(x.get(k) or 0)))
                                except (TypeError, ValueError):
                                    x[k] = 0.0
                        pl["caption"] = str(pl.get("caption") or "")[:3000]
                    r = carousel.render(d, pl, shape, style, handle)
                except RuntimeError as e:
                    return self._json({"error": str(e)}, 400)
                return self._json(dict(r, plan=pl))
            if u.path in ("/api/writeups/make", "/api/writeups/save"):
                from . import writeups
                if not d or not os.path.isdir(d):
                    return self._json({"error": "open a project first"}, 400)
                try:
                    if u.path == "/api/writeups/make":
                        return self._json(writeups.make(d, use_ai=body.get("use_ai", True),
                                                        handle=str(body.get("handle") or "")[:40],
                                                        url=str(body.get("url") or "")[:300]))
                    items = [x for x in (body.get("items") or []) if isinstance(x, dict)][:10] \
                        if isinstance(body.get("items"), list) else []
                    if not items:
                        return self._json({"error": "nothing to save - press Write my posts first"}, 400)
                    return self._json({"files": writeups.save(d, items)})
                except RuntimeError as e:
                    return self._json({"error": str(e)}, 400)
            if u.path == "/api/quit":
                run_now = busy()
                if run_now and not body.get("force"):
                    return self._json({"ok": False, "busy": run_now, "message": "Clipbot is still working (%s). Quit "
                                       "anyway? Unfinished work stops; your projects are safe." % ", ".join(sorted(set(run_now)))})

                def _bye():
                    time.sleep(0.6)
                    try:
                        Ctx.srv.shutdown()
                    finally:
                        os._exit(0)
                threading.Thread(target=_bye, daemon=True).start()
                return self._json({"ok": True})
            if u.path == "/api/app/install":
                from . import appshell
                return self._json(appshell.install())
            if u.path == "/api/update/apply":
                from . import updater
                run_now = busy()
                if run_now and not body.get("force"):
                    return self._json({"ok": False, "busy": run_now, "message": "Clipbot is still working (%s). "
                                       "Update when it's finished - your projects are safe either way." % ", ".join(sorted(set(run_now)))})
                r = updater.apply()
                if r.get("ok") and r.get("note", "").startswith("updated") and body.get("restart"):
                    r["restarting"] = True
                    r["pid"] = "%d-%d" % (os.getpid(), START)
                    threading.Thread(target=_restart, daemon=False).start()   # outlives serve_forever()
                return self._json(r)
            if u.path.startswith(("/api/presets/", "/api/campaigns/", "/api/share/import", "/api/skills/")):
                from . import presets as _pr
                try:
                    if u.path == "/api/presets/save":
                        return self._json({"preset": _pr.save_preset(body.get("name"), spec=body.get("spec") or {},
                                                                    notes=body.get("notes", ""))})
                    if u.path == "/api/presets/apply":
                        pr = _pr.load_preset(body.get("name"))
                        if not pr:
                            return self._json({"error": "no preset called %s" % body.get("name")}, 404)
                        return self._json({"spec": _pr.apply(body.get("spec") or {}, pr)})
                    if u.path == "/api/skills/save":
                        return self._json({"skill": _pr.save_skill(body.get("name"), body.get("pick"), body.get("avoid"),
                                                                  body.get("titles"))})
                    if u.path == "/api/skills/delete":
                        return self._json({"ok": _pr.delete("skills", body.get("name"))})
                    if u.path in ("/api/presets/delete", "/api/campaigns/delete"):
                        return self._json({"ok": _pr.delete("presets" if "presets" in u.path else "campaigns", body.get("name"))})
                    if u.path == "/api/campaigns/save":
                        return self._json({"campaign": _pr.save_campaign(body.get("name"), body.get("rules") or {},
                                                                        body.get("preset"), body.get("notes", ""))})
                    if u.path == "/api/campaigns/check":
                        return self._json({"checks": _pr.check(body.get("spec") or {}, body.get("campaign"),
                                                               body.get("title"), body.get("caption"))})
                    if u.path == "/api/share/import":
                        return self._json(_pr.load_bundle(body.get("data") or "", overwrite=bool(body.get("overwrite"))))
                except ValueError as e:
                    return self._json({"error": str(e)}, 400)
                return self._json({"error": "unknown endpoint"}, 404)
            if u.path == "/api/lore/save":
                from . import lore
                return self._json({"profile": lore.save(body.get("profile") or {})})
            if u.path == "/api/lore/study":         # learn this streamer's style from their best clips
                from . import style
                name = (body.get("name") or "").strip()
                if not name:
                    return self._json({"error": "pick a streamer first"}, 400)
                if not os.listdir(style.examples_dir(name)):
                    return self._json({"error": "add some of their best clips first"}, 400)
                return self._json(style.study_async(name))
            if u.path == "/api/lore/learn":
                from . import lore
                dirs = [x for x in (body.get("dirs") or []) if _allowed(x)]
                if not dirs:
                    return self._json({"error": "pick at least one project to learn from"}, 400)
                return self._json(lore.learn(dirs, known=body.get("known") or []))
            if u.path == "/api/candidates":
                from .moments import find_candidates, write_candidates
                words = json.load(open(os.path.join(d, "words.json")))
                c = find_candidates(words, os.path.join(d, "source.mp4"), d, niche=tuple(body.get("niche") or ()),
                                    top_k=int(body.get("top", 12)))
                write_candidates(c, d)
                return self._json({"candidates": c})
            return self._json({"error": "unknown endpoint"}, 404)
        except (KeyError, ValueError, TypeError, AttributeError) as e:   # malformed request -> clear 400
            log("bad request %s: %s" % (self.path[:120], traceback.format_exc()[-600:]))
            what = ("missing field %s" % e) if isinstance(e, KeyError) else (
                "invalid JSON" if isinstance(e, json.JSONDecodeError) else "invalid request (%s)" % str(e)[:120])
            return self._json({"error": what}, 400)
        except Exception as e:                    # real failure: message for the user, details in the log only
            log("server error on %s:\n%s" % (self.path[:120], traceback.format_exc()[-2000:]))
            return self._json({"error": str(e)[:300] or e.__class__.__name__}, 500)


def serve(root, port=8765, host="127.0.0.1", extra_allowed=(), open_browser=False, opener=None):
    Ctx.root = os.path.abspath(root)
    from .banner import library_dir
    Ctx.allowed = [Ctx.root, os.path.join(ROOT, "assets"), library_dir()] + [os.path.abspath(p) for p in extra_allowed]
    srv, err = None, None
    again = os.environ.pop("CLIPBOT_RESTART_PORT", None)
    if again:                                 # restarted after an update: the page is waiting on this exact port
        port = int(again)
        open_browser = False                  # (and its window is still open)
        for _ in range(60):
            try:
                srv = ThreadingHTTPServer((host, port), H)
                break
            except OSError as e:
                err = e
                time.sleep(0.25)
    for p in ([] if srv else range(port, port + 11)):   # port busy (old editor still open, other app) -> next one
        try:
            srv = ThreadingHTTPServer((host, p), H)
            port = p
            break
        except OSError as e:
            err = e
    if srv is None:
        raise SystemExit("editor: ports %d-%d are all in use (%s). Close the other editor or pass --port." % (
            port, port + 10, err))
    Ctx.srv, Ctx.port = srv, port
    url = "http://%s:%d" % (host, port)
    from .post import Tracker                  # views of posted clips, checked in the background
    Ctx.tracker = Tracker()
    threading.Thread(target=Ctx.tracker.run, daemon=True).start()
    from .schedule import Runner               # scheduled posts go out on time while Clipbot is open
    Ctx.scheduler = Runner(_scheduled_post)
    threading.Thread(target=Ctx.scheduler.run, daemon=True).start()
    from .watch import Poller                  # channel watch: new VODs get auto-clipped in the background
    Ctx.poller = Poller()
    threading.Thread(target=Ctx.poller.run, daemon=True).start()
    print("Clipbot editor on %s  (projects under %s)  - press Ctrl+C to stop" % (url, Ctx.root), flush=True)
    if open_browser:
        import webbrowser
        threading.Timer(0.8, lambda: (opener or webbrowser.open)(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("editor stopped", flush=True)

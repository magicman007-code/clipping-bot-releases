"""Local web editor backend (stdlib only).

python3 clipbot.py editor [--port 8765] [--root /home/user/clips]
Open http://127.0.0.1:8765 . A "project" is any folder with source.mp4 (+ words.json).
"""
import glob
import json
import mimetypes
import os
import re
import threading
import time
import traceback
import uuid
import wave
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

import numpy as np

from .common import safe_remove, FONT_DIR, ROOT, ffmpeg, load_config, log, probe

EDITOR_HTML = os.path.join(ROOT, "editor", "index.html")
JOBS = {}
LIVE = {}


def _bg(kind, fn, **meta):
    jid = uuid.uuid4().hex[:10]
    JOBS[jid] = dict(meta, id=jid, kind=kind, status="running", started=time.time())

    def go():
        try:
            JOBS[jid].update(status="done", result=fn(), finished=time.time())
        except Exception as e:
            JOBS[jid].update(status="error", error="%s\n%s" % (e, traceback.format_exc()[-1500:]), finished=time.time())
    threading.Thread(target=go, daemon=True).start()
    return jid


class Ctx:
    root = None
    allowed = []


def _chat_file(p):
    """Only a chat file the editor itself uploaded (into <work_root>/_uploads)."""
    if not p:
        return None
    up = os.path.realpath(os.path.join(Ctx.root, "_uploads"))
    rp = os.path.realpath(p)
    return rp if rp.startswith(up + os.sep) and os.path.isfile(rp) else None


def _section(body):
    """{"from": "1:00:00", "to": "2:30:00"} -> (start_s, end_s) or None; bad values raise ValueError (400)."""
    from .fetch import parse_time
    a, b = parse_time(body.get("from")), parse_time(body.get("to"))
    if a is None and b is None:
        return None
    a = a or 0.0
    if b is not None and b <= a + 10:
        raise ValueError("'to' must be at least 10 seconds after 'from'")
    return (a, b if b is not None else 10 ** 7)


def _allowed(path):
    p = os.path.realpath(path)
    return any(p.startswith(os.path.realpath(a) + os.sep) or p == os.path.realpath(a) for a in Ctx.allowed)


def list_projects():
    out = []
    for src in glob.glob(os.path.join(Ctx.root, "**", "source.mp4"), recursive=True):
        d = os.path.dirname(src)
        out.append({"dir": d, "name": os.path.relpath(d, Ctx.root), "has_words": os.path.exists(os.path.join(d, "words.json")),
                    "has_specs": os.path.exists(os.path.join(d, "specs.json")), "mtime": os.path.getmtime(src)})
    return sorted(out, key=lambda x: -x["mtime"])


def load_project(d):
    src = os.path.join(d, "source.mp4")
    pr = probe(src)
    rd = lambda n, dflt: json.load(open(os.path.join(d, n))) if os.path.exists(os.path.join(d, n)) else dflt
    return {"dir": d, "source": src, "info": pr, "words": rd("words.json", []), "sentences": rd("sentences.json", []),
            "candidates": rd("candidates.json", []), "specs": rd("specs.json", []),
            "renders": sorted(glob.glob(os.path.join(d, "renders", "*.mp4")))}


def waveform(path, n=4000):
    cache = path + ".peaks.json"
    if os.path.exists(cache) and os.path.getmtime(cache) > os.path.getmtime(path):
        return json.load(open(cache))
    wav = path + ".wf.wav"
    ffmpeg(["-i", path, "-vn", "-ac", "1", "-ar", "2000", wav])
    with wave.open(wav, "rb") as wf:
        x = np.abs(np.frombuffer(wf.readframes(wf.getnframes()), dtype=np.int16).astype(np.float32))
    safe_remove(wav)
    per = 2000 // 20                                   # 20 peaks per second
    m = len(x) // per
    pk = x[: m * per].reshape(m, per).max(1) if m else np.zeros(1)
    pk = (pk / (pk.max() + 1e-6)).round(3).tolist()
    res = {"pps": 20, "peaks": pk}
    json.dump(res, open(cache, "w"))
    return res


def analyze(d, start, end):
    """Quick layout analysis for the preview: facecam inset, median face x, aspect."""
    from . import render, speaker
    tmp = os.path.join(d, "_editor_tmp")
    os.makedirs(tmp, exist_ok=True)
    raw = os.path.join(tmp, "probe.mp4")
    render.cut_raw(os.path.join(d, "source.mp4"), [(start, min(end, start + 12))], raw, 720)
    pr = probe(raw)
    w0, h0 = pr["width"], pr["height"]
    samples, active = speaker.analyze(raw, w0, h0, tmp)
    fc = render.detect_facecam(raw, samples, w0, h0)
    xs = [f[0] / w0 for _, fs in samples for f in fs]
    ys = [f[1] / h0 for _, fs in samples for f in fs]
    tracks = {}
    for _, fs in samples:
        for f in fs:
            tracks.setdefault(f[5], []).append((f[0] / w0, f[1] / h0, f[3] / h0))
    people = sorted([(float(np.median([q[0] for q in v])), float(np.median([q[1] for q in v])), float(np.median([q[2] for q in v])))
                     for v in tracks.values() if len(v) >= 0.3 * max(1, len(samples))])
    n_people = len(people)
    return {"facecam": [fc[0] / w0, fc[1] / h0, fc[2] / w0, fc[3] / h0] if fc else None,
            "face_x": (max(people, key=lambda q: q[2])[0] if people else (float(np.median(xs)) if xs else None)),
            "face_y": (max(people, key=lambda q: q[2])[1] if people else (float(np.median(ys)) if ys else None)),
            "face_h": (max(people, key=lambda q: q[2])[2] if people else None),
            "people_xy": people,
            "people": n_people, "vertical": h0 / float(w0) >= 1.3}


def run_job(jid, d, spec, draft):
    from .render import make_clip
    j = JOBS[jid]
    try:
        cfg = load_config()
        spec = dict(spec)
        spec["source"] = spec.get("source") or os.path.join(d, "source.mp4")
        if draft:
            spec["_draft"] = True
            spec["name"] = spec["name"] + "_draft"
        outdir = os.path.join(d, "renders")
        res = make_clip(spec, outdir, os.path.join(d, "_work"), cfg)
        if not draft:
            from .review import ledger_append
            ledger_append(res, spec)
            from . import connect, learn
            learn.record("rendered", spec, d)
            connect.fire("clip_rendered", {"name": res.get("name"), "file": res.get("out"), "srt": res.get("srt"),
                                           "title": spec.get("title") or spec.get("headline"),
                                           "aspect": res.get("aspect"), "duration": res.get("dur"),
                                           "versions": [v.get("out") for v in res.get("versions") or []]})
        j.update(status="done", result=res, finished=time.time())
    except Exception as e:
        j.update(status="error", error="%s\n%s" % (e, traceback.format_exc()[-2500:]), finished=time.time())


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _json(self, obj, code=200):
        b = json.dumps(obj, default=str).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def _file(self, path, ctype=None):
        if not os.path.isfile(path):
            return self._json({"error": "not found"}, 404)
        size = os.path.getsize(path)
        ctype = ctype or mimetypes.guess_type(path)[0] or "application/octet-stream"
        rng = self.headers.get("Range")
        start, end = 0, size - 1
        if rng:
            m = re.match(r"bytes=(\d*)-(\d*)", rng)
            if m:
                if m.group(1):
                    start = int(m.group(1))
                    end = int(m.group(2)) if m.group(2) else size - 1
                else:
                    start = size - int(m.group(2))
            end = min(end, size - 1)
            self.send_response(206)
            self.send_header("Content-Range", "bytes %d-%d/%d" % (start, end, size))
        else:
            self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(end - start + 1))
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        with open(path, "rb") as f:
            f.seek(start)
            left = end - start + 1
            try:
                while left > 0:
                    chunk = f.read(min(1 << 20, left))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    left -= len(chunk)
            except (BrokenPipeError, ConnectionResetError):
                pass

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        return self.rfile.read(n) if n else b""

    def do_GET(self):
        u = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(u.query).items()}
        try:
            if u.path in ("/", "/index.html"):
                return self._file(EDITOR_HTML, "text/html; charset=utf-8")
            if u.path.startswith("/ui/"):          # editor UI fonts
                fn = os.path.basename(u.path)
                return self._file(os.path.join(ROOT, "editor", "ui", fn),
                                  "font/woff2" if fn.endswith(".woff2") else "text/plain")
            if u.path.startswith("/fonts/"):
                from .fonts import user_dir
                fn = os.path.basename(u.path)
                p = os.path.join(FONT_DIR, fn)
                if not os.path.exists(p):
                    p = os.path.join(user_dir(), fn)
                return self._file(p, "font/ttf")
            if u.path == "/api/fonts":
                from .fonts import list_fonts
                return self._json([{k: f[k] for k in ("family", "file", "user", "em")} for f in list_fonts()])
            if u.path == "/media":
                p = q.get("path", "")
                if not _allowed(p):
                    return self._json({"error": "path not allowed"}, 403)
                return self._file(p)
            if u.path == "/api/projects":
                return self._json({"root": Ctx.root, "projects": list_projects()})
            if u.path == "/api/project":
                if not _allowed(q["dir"]):
                    return self._json({"error": "path not allowed"}, 403)
                return self._json(load_project(q["dir"]))
            if u.path == "/api/waveform":
                if not _allowed(q["path"]):
                    return self._json({"error": "path not allowed"}, 403)
                return self._json(waveform(q["path"]))
            if u.path == "/api/analyze":
                return self._json(analyze(q["dir"], float(q["start"]), float(q["end"])))
            if u.path == "/api/job":
                return self._json(JOBS.get(q["id"], {"status": "unknown"}))
            if u.path == "/api/emoji":
                from .effects import emoji_png
                return self._file(emoji_png(q["ch"]), "image/png")
            if u.path == "/api/icon":
                from .banner import brand_icon, PLATFORMS
                plat = q.get("platform", "kick")
                ic = brand_icon(plat, 256, q.get("color")) if plat in PLATFORMS else None
                if not ic:
                    return self._json({"error": "icon unavailable"}, 404)
                return self._file(ic, "image/png")
            if u.path == "/api/qc":
                from .verify import qc_load
                return self._json(qc_load(os.path.join(q["dir"], "renders")))
            if u.path == "/api/live":
                st = os.path.join(q["dir"], "live_status.json")
                return self._json(json.load(open(st)) if os.path.exists(st) else {})
            if u.path == "/api/jobs":
                return self._json(sorted(JOBS.values(), key=lambda j: -j["started"])[:30])
            if u.path == "/api/autoclip_status":
                if not _allowed(q["dir"]):
                    return self._json({"error": "path not allowed"}, 403)
                pth = os.path.join(q["dir"], "autoclip_status.json")
                return self._json(json.load(open(pth)) if os.path.exists(pth) else {})
            if u.path == "/api/live/sessions":
                def _st(v):
                    pth = os.path.join(v.dir, "live_status.json")
                    try:
                        return json.load(open(pth)).get("state", "")
                    except Exception:
                        return ""
                return self._json([{"id": k, "url": v.url, "dir": v.dir, "clips": v.clips, "running": not v.stop.is_set(),
                                    "state": _st(v), "went_live": v.went_live,
                                    "recap": os.path.join(v.dir, "recap_highlights.mp4")
                                    if os.path.exists(os.path.join(v.dir, "recap_highlights.mp4")) else None,
                                    "segments": len(v.segments), "words": len(v.words), "chat": len(v.chat.msgs),
                                    "elapsed": round(time.time() - v.t0)} for k, v in LIVE.items()])
            if u.path == "/api/banners":
                from .banner import PRESETS, library
                return self._json({"library": library(), "presets": PRESETS})
            if u.path == "/api/learning":
                from . import learn
                L = learn.learned()
                return self._json({"insights": learn.insights(L), "summary": L, "reasons": learn.REASONS})
            if u.path == "/api/watch":
                from . import watch
                pl = getattr(Ctx, "poller", None)
                return self._json({"watches": [dict(w, seen=len(w.get("seen") or []), pending=len(w.get("pending") or {}))
                                               for w in watch.load()],
                                   "busy": bool(pl and pl.busy), "last": pl.last if pl else None,
                                   "minutes": pl.minutes if pl else None})
            if u.path == "/api/connections":
                from . import connect
                return self._json(dict(connect.redacted(), ai_ready=connect.ai_ready(), browsers=connect.BROWSERS))
            if u.path == "/api/update/check":
                from . import updater
                return self._json(updater.check())
            if u.path == "/api/lore/study_status":
                from . import style
                st = dict(style.status(q.get("name")))
                st.pop("style", None)
                return self._json(st)
            if u.path == "/api/lore":
                from . import lore, style
                if q.get("name"):
                    p = lore.load(q["name"])
                    if p and p.get("style"):
                        p["style_summary"] = style.describe(p["style"])
                        p["style"] = {k: v for k, v in p["style"].items() if k != "centroid"}
                    from .lore import lore_dir, slug
                    exd = os.path.join(lore_dir(), slug(q["name"]) + "_clips")
                    ex = sorted(f for f in os.listdir(exd) if not f.startswith("_")) if os.path.isdir(exd) else []
                    return self._json({"profile": p, "examples": ex})
                return self._json({"profiles": lore.list_profiles()})
            if u.path == "/api/config":
                return self._json(load_config())
            return self._json({"error": "unknown endpoint"}, 404)
        except (KeyError, ValueError, TypeError, AttributeError) as e:   # malformed request -> clear 400
            log("bad request %s: %s" % (self.path[:120], traceback.format_exc()[-600:]))
            what = ("missing field %s" % e) if isinstance(e, KeyError) else (
                "invalid JSON" if isinstance(e, json.JSONDecodeError) else "invalid request (%s)" % str(e)[:120])
            return self._json({"error": what}, 400)
        except Exception as e:                    # real failure: message for the user, details in the log only
            log("server error on %s:\n%s" % (self.path[:120], traceback.format_exc()[-2000:]))
            return self._json({"error": str(e)[:300] or e.__class__.__name__}, 500)

    def do_POST(self):
        u = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(u.query).items()}
        try:
            if u.path == "/api/upload_source":         # big video -> new project, streamed to disk
                name = re.sub(r"[^\w.-]+", "_", q.get("name", "upload.mp4"))
                stem = os.path.splitext(name)[0][:60]
                d = os.path.join(Ctx.root, "_uploads")
                os.makedirs(d, exist_ok=True)
                pth = os.path.join(d, name)
                n = int(self.headers.get("Content-Length") or 0)
                with open(pth, "wb") as f:
                    while n > 0:
                        chunk = self.rfile.read(min(1 << 22, n))
                        if not chunk:
                            break
                        f.write(chunk)
                        n -= len(chunk)
                if n > 0:
                    safe_remove(pth)
                    return self._json({"error": "upload interrupted - try again"}, 400)
                return self._json({"path": pth, "name": stem})
            if u.path == "/api/lore/example_upload":   # one of the streamer's best clips, streamed to disk
                from . import style
                who = (q.get("streamer") or "").strip()
                name = re.sub(r"[^\w.-]+", "_", q.get("name", "clip.mp4"))[:80]
                if not who:
                    return self._json({"error": "pick a streamer first"}, 400)
                if not name.lower().endswith((".mp4", ".mov", ".mkv", ".webm", ".m4v")):
                    return self._json({"error": "clips must be video files (.mp4, .mov, .mkv, .webm)"}, 400)
                pth = os.path.join(style.examples_dir(who), name)
                n = int(self.headers.get("Content-Length") or 0)
                if n > 2e9:
                    return self._json({"error": "that file is too big to be a clip"}, 400)
                with open(pth, "wb") as f:
                    while n > 0:
                        chunk = self.rfile.read(min(1 << 22, n))
                        if not chunk:
                            break
                        f.write(chunk)
                        n -= len(chunk)
                if n > 0:
                    safe_remove(pth)
                    return self._json({"error": "upload interrupted - try again"}, 400)
                try:
                    probe(pth)
                except Exception:
                    safe_remove(pth)
                    return self._json({"error": "%s isn't a playable video" % name}, 400)
                return self._json({"ok": True, "file": name})
            if u.path == "/api/font_upload":           # .ttf/.otf/.woff/.woff2 -> user font folder
                import tempfile
                from .fonts import add
                name = re.sub(r"[^\w.-]+", "_", q.get("name", "font.ttf"))
                if not name.lower().endswith((".ttf", ".otf", ".woff", ".woff2")):
                    return self._json({"error": "fonts must be .ttf, .otf, .woff or .woff2"}, 400)
                body = self._body()
                if len(body) > 30e6:
                    return self._json({"error": "font file too large"}, 400)
                tmp = tempfile.NamedTemporaryFile(suffix=os.path.splitext(name)[1], delete=False)
                tmp.write(body)
                tmp.close()
                try:
                    return self._json(add(tmp.name))
                except ValueError as e:
                    return self._json({"error": "%s: %s" % (name, e)}, 400)
                finally:
                    safe_remove(tmp.name)
            if u.path == "/api/banner_upload":         # campaign banner -> shared library
                from .banner import library_dir
                name = re.sub(r"[^\w.-]+", "_", q.get("name", "banner.png"))
                if not name.lower().endswith((".png", ".webp", ".gif", ".jpg", ".jpeg")):
                    return self._json({"error": "banner must be an image (PNG with transparency works best)"}, 400)
                data = self._body()
                try:
                    import io
                    from PIL import Image
                    Image.open(io.BytesIO(data)).verify()
                except Exception:
                    return self._json({"error": "that file isn't a readable image - export it as PNG and try again"}, 400)
                p = os.path.join(library_dir(), name)
                with open(p, "wb") as f:
                    f.write(data)
                return self._json({"path": p, "name": os.path.splitext(name)[0]})
            if u.path == "/api/upload":                # raw body upload -> <project>/assets/<name>
                d = q["dir"]
                if not _allowed(d):
                    return self._json({"error": "path not allowed"}, 403)
                os.makedirs(os.path.join(d, "assets"), exist_ok=True)
                name = re.sub(r"[^\w.-]+", "_", q.get("name", "upload.bin"))
                p = os.path.join(d, "assets", name)
                with open(p, "wb") as f:
                    f.write(self._body())
                return self._json({"path": p})
            body = json.loads(self._body() or b"{}")
            d = body.get("dir")
            if d and not _allowed(d):
                return self._json({"error": "path not allowed"}, 403)
            if u.path == "/api/save":
                json.dump(body["specs"], open(os.path.join(d, "specs.json"), "w"), indent=1)
                return self._json({"ok": True, "saved": len(body["specs"])})
            if u.path == "/api/render":
                jid = uuid.uuid4().hex[:10]
                JOBS[jid] = {"id": jid, "status": "running", "started": time.time(), "name": body["spec"].get("name"),
                             "draft": bool(body.get("draft"))}
                threading.Thread(target=run_job, args=(jid, d, body["spec"], bool(body.get("draft"))), daemon=True).start()
                return self._json({"id": jid})
            if u.path == "/api/qc":
                from .verify import qc_set
                return self._json(qc_set(os.path.join(d, "renders"), body["name"], body["status"], body.get("note", ""),
                                         bool(body.get("watched"))))
            if u.path == "/api/autoclip":
                from .autoclip import run as autorun, _project_dir, project_name
                src = (body.get("source") or "").strip()
                if not src:
                    return self._json({"error": "paste a link or choose a video file first"}, 400)
                if not re.match(r"https?://", src) and not _allowed(src):
                    return self._json({"error": "file must be uploaded first"}, 403)
                if src.startswith("http"):
                    from .fetch import LinkError, direct_link
                    try:
                        direct_link(src)
                    except LinkError as e:          # folder link etc. -> tell them right away
                        return self._json({"error": str(e)}, 400)
                nm = body.get("name") or project_name(src)
                pdir = _project_dir(Ctx.root, nm)
                jid = _bg("autoclip", lambda: autorun(src, Ctx.root, nm, int(body.get("clips", 6)),
                                                      float(body.get("min_score", 6.0)), body.get("captions"),
                                                      body.get("banner"), bool(body.get("draft")), True,
                                                      aspect=body.get("aspect") or "9:16",
                                                      also_aspects=body.get("also_aspects") or None,
                                                      headline=body.get("headline", True) is not False,
                                                      manual=bool(body.get("manual")),
                                                      prompt=(body.get("prompt") or "").strip()[:300] or None,
                                                      streamer=body.get("streamer") or None,
                                                      section=_section(body),
                                                      chat_file=_chat_file(body.get("chat_file"))),
                          project=pdir, source=src)
                return self._json({"id": jid, "project": pdir})
            if u.path == "/api/live/start":
                if not body.get("authorized"):
                    return self._json({"error": "confirm you own this channel or have permission to clip it"}, 403)
                from .live import LiveSession
                sess = LiveSession(body["url"], name=body.get("name"), minutes=float(body["minutes"]) if body.get("minutes") else None,
                                   chat=body.get("chat") or None, render=True, outroot=os.path.join(Ctx.root, "live"),
                                   wait_hours=float(body.get("wait_hours") or 0), min_quality=float(body.get("min_score") or 6))
                lid = uuid.uuid4().hex[:8]
                LIVE[lid] = sess
                threading.Thread(target=sess.run, daemon=True).start()
                return self._json({"id": lid, "dir": sess.dir})
            if u.path == "/api/live/stop":
                if body.get("id") in LIVE:
                    LIVE[body["id"]].stop.set()
                return self._json({"ok": True})
            if u.path == "/api/live/mark":           # instant manual clip: last N seconds
                sess = LIVE.get(body.get("id"))
                if not sess or not sess.segments:
                    return self._json({"error": "no live session / nothing recorded yet"}, 400)
                edge = sess.segments[-1]["b"]
                secs = float(body.get("seconds", 30))
                c = {"start": max(0.0, edge - secs), "end": edge, "live_score": None, "chat_z": None,
                     "tags": {"manual": 1}, "sentences": []}
                k = len(sess.clips) + 1
                cut = sess._cut(c, k)
                if not cut:
                    return self._json({"error": "could not cut"}, 400)
                cd, spec = cut
                sess.clips.append({"clip": spec["name"], "dir": cd, "status": "rendering", "manual": True})
                sess.pool.submit(sess._render, cd, spec)
                return self._json({"clip": spec["name"], "dir": cd})
            if u.path == "/api/titles":
                from .packaging import titles
                return self._json({"titles": titles(body.get("text", ""), tuple(body.get("names") or ()), body.get("headline", ""))})
            if u.path == "/api/thumbnail":
                from .packaging import thumbnail
                vid = body["video"]
                if not _allowed(vid):
                    return self._json({"error": "path not allowed"}, 403)
                base = os.path.splitext(vid)[0] + "_thumb"
                return self._json(thumbnail(vid, base, body.get("text", ""), emoji=body.get("emoji") or None,
                                            arrow=bool(body.get("arrow")), circle=bool(body.get("circle"))))
            if u.path == "/api/prompt_find":         # "every time he talks about X" -> matching moments
                from . import lore
                from .prompt_clip import find
                from .score import score_candidate
                prompt = (body.get("prompt") or "").strip()[:300]
                if not prompt:
                    return self._json({"error": "describe the moment you want, e.g. 'when he talks about the coin'"}, 400)
                wp = os.path.join(d, "words.json")
                if not os.path.exists(wp):
                    return self._json({"error": "this project has no transcript yet, so there's nothing to search"}, 400)
                prof = lore.load(body.get("streamer"))
                c, info = find(prompt, json.load(open(wp)), os.path.join(d, "source.mp4"), d,
                               n=max(1, min(30, int(body.get("n", 8)))), lore=lore.terms(prof),
                               lore_aliases=lore.aliases(prof))
                for x in c:
                    x["quality"] = score_candidate(x)
                return self._json({"candidates": c, "info": info})
            if u.path in ("/api/rate", "/api/learn_event"):   # learning signals from the editor
                from . import learn
                spec = body.get("spec") or {}
                if u.path == "/api/rate":
                    r = int(body.get("rating") or 0)
                    if r not in (1, -1):
                        return self._json({"error": "rating must be 1 or -1"}, 400)
                    reasons = [x for x in (body.get("reasons") or []) if x in learn.REASONS]
                    learn.record("rated", spec, d, rating=r, reasons=reasons)
                else:
                    kind = body.get("kind")
                    if kind not in ("deleted", "performance"):
                        return self._json({"error": "unknown event"}, 400)
                    views = body.get("views")
                    if kind == "performance":
                        try:
                            views = max(0.0, float(str(views).replace(",", "")))
                        except (TypeError, ValueError):
                            return self._json({"error": "views must be a number"}, 400)
                    learn.record(kind, spec, d, views=views if kind == "performance" else None,
                                 platform=(body.get("platform") or None))
                return self._json({"ok": True, "insights": learn.insights()})
            if u.path == "/api/learning/send":
                from . import learn
                return self._json(learn.send_report(force=True))
            if u.path == "/api/connections":
                from . import connect
                try:
                    return self._json(dict(connect.save(body.get("patch") or {}), ai_ready=connect.ai_ready(),
                                           browsers=connect.BROWSERS))
                except ValueError as e:
                    return self._json({"error": str(e)}, 400)
            if u.path in ("/api/watch/add", "/api/watch/remove", "/api/watch/check"):
                from . import watch
                try:
                    if u.path.endswith("add"):
                        w = watch.add(body.get("url"), streamer=body.get("streamer") or None,
                                      clips=int(body.get("clips") or 6), min_score=float(body.get("min_score") or 6),
                                      aspect=body.get("aspect") or "9:16", latest=bool(body.get("latest")))
                        if body.get("latest") and getattr(Ctx, "poller", None):
                            Ctx.poller.now()
                        return self._json({"ok": True, "watch": dict(w, seen=len(w["seen"]))})
                    if u.path.endswith("remove"):
                        return self._json({"ok": watch.remove(body.get("url")) > 0})
                    if getattr(Ctx, "poller", None):
                        Ctx.poller.now()
                    return self._json({"ok": True})
                except (ValueError, RuntimeError) as e:
                    return self._json({"error": str(e)}, 400)
            if u.path == "/api/connections/test":
                from . import connect
                what = body.get("what")
                try:
                    if what == "ai":
                        t = connect.ai_titles("So last week I bought this coin at $200K and it hit $10 million.", n=2)
                        return self._json({"ok": bool(t), "detail": " / ".join(t) or "no titles returned"})
                    if what == "webhook":
                        return self._json({"ok": connect.fire("test", {"name": "test", "title": "Clipbot webhook test"}),
                                           "detail": "test sent (check your service)"})
                    if what == "scorer":
                        if not connect.scorer_ready():
                            return self._json({"ok": False, "detail": "save your scorer's URL first"})
                        got = connect.score_external([
                            {"start": 0, "end": 20, "sentences": [[0, "No way, he actually hit the jackpot!"]], "tags": {"reaction": 1}},
                            {"start": 30, "end": 50, "sentences": [[30, "Okay so anyway, hit follow if you're new."]], "tags": {}}])
                        return self._json({"ok": bool(got), "detail": ("scores back: " + ", ".join(
                            "#%d=%s" % (i, v["score"]) for i, v in sorted(got.items()))) if got else
                            "it answered, but with no scores Clipbot could read (see CONNECT.md)"})
                    if what == "feedback":
                        from . import learn
                        r = learn.send_report(force=True)
                        return self._json({"ok": r.get("sent", False), "detail": r.get("why") or "report sent"})
                except RuntimeError as e:
                    return self._json({"ok": False, "detail": str(e)})
                return self._json({"error": "unknown test"}, 400)
            if u.path == "/api/update/apply":
                from . import updater
                return self._json(updater.apply())
            if u.path == "/api/lore/save":
                from . import lore
                return self._json({"profile": lore.save(body.get("profile") or {})})
            if u.path == "/api/lore/study":         # learn this streamer's style from their best clips
                from . import style
                name = (body.get("name") or "").strip()
                if not name:
                    return self._json({"error": "pick a streamer first"}, 400)
                if not os.listdir(style.examples_dir(name)):
                    return self._json({"error": "add some of their best clips first"}, 400)
                return self._json(style.study_async(name))
            if u.path == "/api/lore/learn":
                from . import lore
                dirs = [x for x in (body.get("dirs") or []) if _allowed(x)]
                if not dirs:
                    return self._json({"error": "pick at least one project to learn from"}, 400)
                return self._json(lore.learn(dirs, known=body.get("known") or []))
            if u.path == "/api/candidates":
                from .moments import find_candidates, write_candidates
                words = json.load(open(os.path.join(d, "words.json")))
                c = find_candidates(words, os.path.join(d, "source.mp4"), d, niche=tuple(body.get("niche") or ()),
                                    top_k=int(body.get("top", 12)))
                write_candidates(c, d)
                return self._json({"candidates": c})
            return self._json({"error": "unknown endpoint"}, 404)
        except (KeyError, ValueError, TypeError, AttributeError) as e:   # malformed request -> clear 400
            log("bad request %s: %s" % (self.path[:120], traceback.format_exc()[-600:]))
            what = ("missing field %s" % e) if isinstance(e, KeyError) else (
                "invalid JSON" if isinstance(e, json.JSONDecodeError) else "invalid request (%s)" % str(e)[:120])
            return self._json({"error": what}, 400)
        except Exception as e:                    # real failure: message for the user, details in the log only
            log("server error on %s:\n%s" % (self.path[:120], traceback.format_exc()[-2000:]))
            return self._json({"error": str(e)[:300] or e.__class__.__name__}, 500)


def serve(root, port=8765, host="127.0.0.1", extra_allowed=(), open_browser=False):
    Ctx.root = os.path.abspath(root)
    from .banner import library_dir
    Ctx.allowed = [Ctx.root, os.path.join(ROOT, "assets"), library_dir()] + [os.path.abspath(p) for p in extra_allowed]
    srv, err = None, None
    for p in range(port, port + 11):          # port busy (old editor still open, other app) -> next one
        try:
            srv = ThreadingHTTPServer((host, p), H)
            port = p
            break
        except OSError as e:
            err = e
    if srv is None:
        raise SystemExit("editor: ports %d-%d are all in use (%s). Close the other editor or pass --port." % (
            port, port + 10, err))
    url = "http://%s:%d" % (host, port)
    from .watch import Poller                  # channel watch: new VODs get auto-clipped in the background
    Ctx.poller = Poller()
    threading.Thread(target=Ctx.poller.run, daemon=True).start()
    print("Clipbot editor on %s  (projects under %s)  - press Ctrl+C to stop" % (url, Ctx.root), flush=True)
    if open_browser:
        import webbrowser
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("editor stopped", flush=True)

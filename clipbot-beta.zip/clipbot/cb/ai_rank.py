"""Optional second opinion on clip picks from the user's own AI key (Settings -> AI).

Clipbot's scorer finds and scores candidate moments first. If an AI key is connected and "AI re-ranks picks" is on,
the top candidates' transcripts go to that AI together with what Clipbot has learned about this user:
  - the streamer's lore (names, running jokes) and the style of their studied clips
  - what this user keeps and drops, their most common complaints
  - short examples of clips they rated up / down (local transcript text, never video)
The AI scores each moment 1-10 with a one-line reason. The final order blends Clipbot's score with the AI's.

It keeps learning: every clip remembers the AI's score, and learn.learned() checks whether clips the AI liked are
actually the ones this user keeps. The blend weight follows that (more weight if the AI is right for this user,
less if it isn't). The AI can only reorder moments that already passed Clipbot's quality bar - it can't add
moments, invent text, or push a clip under the bar into the results.
"""
import json
import re

from .common import log

MAX_CANDS = 15
DEFAULT_W = 0.4


def enabled():
    from . import connect
    ai = connect.get().get("ai") or {}
    return bool(connect.ai_ready() and ai.get("rerank", True))


def _text(c, n=700):
    return " ".join(t for _, t in c.get("sentences", []))[:n]


def examples(evs=None, k=3):
    """Short texts of clips this user rated up / down (newest first), from the local learning log."""
    from . import learn
    evs = evs if evs is not None else learn.events()
    text, rate = {}, {}
    for e in evs:
        ck = e.get("clip")
        if not ck:
            continue
        if e.get("_text"):
            text[ck] = e["_text"]
        if e.get("kind") == "rated":
            rate[ck] = (e.get("rating", 0), e.get("reasons") or [], e.get("t", 0))
    up, down = [], []
    for ck, (r, reasons, t) in sorted(rate.items(), key=lambda kv: -kv[1][2]):
        if ck not in text:
            continue
        (up if r > 0 else down).append({"text": text[ck][:300],
                                        "why": [learn.REASONS.get(x, x) for x in reasons]})
    return up[:k], down[:k]


def context(streamer=None, prof=None, prompt=None):
    """Everything Clipbot knows that should shape the AI's judgement, as plain text."""
    from . import learn, lore as _lore, style as _style
    lines = []
    if streamer:
        lines.append("Streamer: %s" % streamer)
    terms = [t for t in list((prof or {}).get("names", [])) + list((prof or {}).get("phrases", [])) if t.strip()]
    if (prof or {}).get("notes"):
        lines.append("Notes about them: %s" % str(prof["notes"])[:400])
    if terms:
        lines.append("Their lore (names, running jokes, recurring topics - callbacks to these land well): %s"
                     % ", ".join(list(terms)[:25]))
    sty = (prof or {}).get("style")
    if sty:
        try:
            lines.append("Their best-performing clips: %s" % _style.describe(sty))
        except Exception:
            pass
    if prompt:
        lines.append("The user asked for: \"%s\" - only moments that fit this are good." % prompt[:200])
    try:
        L = learn.learned()
        if L["labelled"]:
            ins = [x for x in learn.insights(L) if not x.startswith(("Starts adjusting", "Now applied"))]
            lines.append("What this user keeps and drops: " + " ".join(ins))
    except Exception:
        pass
    up, down = examples()
    for e in up:
        lines.append("Clip they LIKED%s: \"%s\"" % ((" (" + ", ".join(e["why"]) + ")") if e["why"] else "", e["text"]))
    for e in down:
        lines.append("Clip they REJECTED%s: \"%s\"" % ((" (" + ", ".join(e["why"]) + ")") if e["why"] else "", e["text"]))
    return "\n".join(lines)


SYSTEM = ("You are a senior short-form editor who picks livestream moments that do well on TikTok, Shorts and Reels. "
          "Judge each moment only from its transcript: does it hook in the first seconds, does it pay off, does it make "
          "sense without the rest of the stream, would a viewer share it. Use the user's preferences and examples. "
          "Return only a JSON array: [{\"id\": <number>, \"score\": <1-10>, \"why\": \"<under 12 words>\"}], one entry "
          "per moment.")


def parse(out, ids):
    m = re.search(r"\[.*\]", out or "", re.S)
    try:
        arr = json.loads(m.group(0)) if m else []
    except ValueError:
        arr = []
    res = {}
    for x in arr if isinstance(arr, list) else []:
        try:
            i, s = int(x.get("id")), float(x.get("score"))
        except (TypeError, ValueError, AttributeError):
            continue
        if i in ids and 0 <= s <= 10:
            res[i] = {"score": round(s, 1), "why": str(x.get("why") or "")[:120]}
    return res


def rerank(cands, streamer=None, prof=None, prompt=None, weight=None, complete=None, source=None):
    """Score cands (already quality-filtered, best first) with the user's AI and reorder them in place.
    Returns an info dict for the job status; never raises."""
    if not cands:
        return {"used": False, "why": "no candidates"}
    if complete is None:
        if not enabled():
            return {"used": False, "why": "off"}
        from .connect import ai_complete as complete
    if weight is None:
        weight = ai_weight()
    top = cands[:MAX_CANDS]
    items = "\n\n".join("#%d (%.0f s, Clipbot score %.1f): \"%s\"" % (i, c["end"] - c["start"], c["quality"]["score"], _text(c))
                        for i, c in enumerate(top))
    ctx = context(streamer, prof, prompt)
    msg = ("%s\n\nMoments from this video:\n\n%s\n\nScore every moment." % (("What you know:\n" + ctx) if ctx else "", items)).strip()
    try:
        out = complete(msg, system=SYSTEM, max_tokens=1200)
    except Exception as e:
        log("AI re-rank skipped: %s" % e)
        return {"used": False, "why": str(e)[:160]}
    got = parse(out, set(range(len(top))))
    if len(got) < max(1, len(top) // 2):
        return {"used": False, "why": "the AI's answer couldn't be read"}
    try:
        from .connect import ai_source
        src = source or ai_source()
    except Exception:
        src = source
    for v in got.values():
        v["src"] = src
    for i, c in enumerate(top):
        q = c["quality"]["score"]
        if i in got:
            c["ai"] = got[i]
            c["rank_score"] = round((1 - weight) * q + weight * got[i]["score"], 2)
        else:
            c["rank_score"] = q
    order = sorted(range(len(top)), key=lambda i: -top[i]["rank_score"])
    moved = sum(1 for pos, i in enumerate(order) if pos != i)
    cands[:len(top)] = [top[i] for i in order]
    return {"used": True, "scored": len(got), "weight": weight, "moved": moved, "source": src}


def ai_weight(L=None):
    """How much the AI's opinion counts, learned from whether its picks were kept."""
    try:
        from . import learn
        a = (L or learn.learned()).get("ai") or {}
        return a.get("weight", DEFAULT_W)
    except Exception:
        return DEFAULT_W


def external(cands, weight=None, score=None):
    """The user's own scoring software (Settings -> Connect your own scorer): same blend as the AI, its weight
    also learned from what gets kept (learn.py 'scorer'). Reorders cands in place; never raises."""
    from . import connect
    if not cands:
        return {"used": False, "why": "no candidates"}
    if score is None:
        if not connect.scorer_ready():
            return {"used": False, "why": "off"}
        score = connect.score_external
    top = cands[:MAX_CANDS]
    try:
        got = score(top)
    except Exception as e:
        log("outside scorer skipped: %s" % e)
        return {"used": False, "why": str(e)[:160]}
    if not got:
        return {"used": False, "why": "the scorer returned no scores"}
    if weight is None:
        try:
            from . import learn
            st = learn.learned().get("scorer") or {}
            weight = st["weight"] if st.get("clips", 0) >= learn.AI_MIN else \
                float((connect.get().get("scorer") or {}).get("weight") or DEFAULT_W)
            weight = min(0.8, max(0.0, weight))
        except Exception:
            weight = DEFAULT_W
    for i, c in enumerate(top):
        base = c.get("rank_score", c["quality"]["score"])
        if i in got:
            c["ext"] = got[i]
            c["rank_score"] = round((1 - weight) * base + weight * got[i]["score"], 2)
        else:
            c["rank_score"] = base
    order = sorted(range(len(top)), key=lambda i: -top[i]["rank_score"])
    moved = sum(1 for pos, i in enumerate(order) if pos != i)
    cands[:len(top)] = [top[i] for i in order]
    return {"used": True, "scored": len(got), "weight": weight, "moved": moved}

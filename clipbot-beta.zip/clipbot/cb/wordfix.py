"""Fix a misheard word everywhere in a project, and remember the spelling for future transcriptions.

fix(project, wrong, right, everywhere=True, remember=True) ->
    {"words": n changed in the transcript, "clips": n clips whose own words changed, "remembered": bool}
Matching is whole-word and case-insensitive; punctuation around the word is kept ("brez," -> "Brezz,").
A multi-word fix ("breast gales" -> "Brez Gales") matches consecutive words.
"""
import json
import os
import re

from .common import load_config, save_json, load_store

_PUNCT = re.compile(r"^(\W*)(.*?)(\W*)$", re.S)


def _norm(w):
    return re.sub(r"\W+", "", str(w)).lower()


def _apply(words, src, dst):
    """words: [[start, end, text, ...]] in place. src/dst: lists of tokens. Returns number of replacements."""
    n, i = 0, 0
    k = len(src)
    while i + k <= len(words):
        if all(_norm(words[i + j][2]) == src[j] for j in range(k)):
            pre = _PUNCT.match(str(words[i][2])).group(1)
            post = _PUNCT.match(str(words[i + k - 1][2])).group(3)
            if len(dst) == k:
                for j in range(k):
                    words[i + j][2] = (pre if j == 0 else "") + dst[j] + (post if j == k - 1 else "")
            else:                                  # different word count: keep the first word's timing span
                a, b = words[i][0], words[i + k - 1][1]
                step = (b - a) / max(1, len(dst))
                new = []
                for j, t in enumerate(dst):
                    w = list(words[i])
                    w[0], w[1] = round(a + j * step, 3), round(a + (j + 1) * step - 0.02, 3)
                    w[2] = (pre if j == 0 else "") + t + (post if j == len(dst) - 1 else "")
                    new.append(w)
                words[i:i + k] = new
                i += len(dst) - 1
            n += 1
            i += k if len(dst) == k else 1
        else:
            i += 1
    return n


def remember(right):
    d = os.path.join(load_config()["work_root"], "_settings")
    os.makedirs(d, exist_ok=True)
    p = os.path.join(d, "vocab.json")
    cur = [w for w in load_store(p, [], list) if isinstance(w, str)]
    if right not in cur:
        cur.append(right)
    save_json(p, cur[-300:])


def fix(project, wrong, right, everywhere=True, remember_it=True, only_clip=None):
    wrong, right = str(wrong or "").strip(), str(right or "").strip()
    if not wrong or not right:
        raise ValueError("type the word as it should be")
    if len(right) > 80 or len(wrong) > 80:
        raise ValueError("that's too long for one word or name")
    src = [t for t in (_norm(x) for x in wrong.split()) if t]
    dst = right.split()
    if not src:
        raise ValueError("pick a word to fix")
    res = {"words": 0, "clips": 0, "remembered": False}
    if everywhere:
        wp = os.path.join(project, "words.json")
        if os.path.exists(wp):
            ws = json.load(open(wp))
            res["words"] = _apply(ws, src, dst)
            if res["words"]:
                save_json(wp, ws)
    sp_path = os.path.join(project, "specs.json")
    if os.path.exists(sp_path):
        specs = json.load(open(sp_path))
        ch = 0
        for s in specs:
            if s.get("words") and (everywhere or s.get("name") == only_clip):
                if _apply(s["words"], src, dst):
                    ch += 1
            if everywhere and s.get("headline") and wrong.lower() in s["headline"].lower():
                s["headline"] = re.sub(re.escape(wrong), right, s["headline"], flags=re.I)
                ch += 1
        if ch:
            save_json(sp_path, specs)
        res["clips"] = ch
    if remember_it:                            # future transcriptions get this spelling as a hint
        remember(right)
        res["remembered"] = True
    return res

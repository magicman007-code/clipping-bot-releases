"""Stream-overlay layouts: a reaction video in one window, the streamer's webcam in another, both sitting on a
static or slowly animated overlay background. A single 9:16 crop cuts through those windows; the right move is to
find each window and stack them.

detect(clip, w0, h0) finds 2 (or 3) rectangular video windows:
  - pixels that keep changing over the clip (temporal std of sampled frames) form the candidate regions
  - regions must be big, roughly rectangular and fill most of their bounding box
  - each box edge is snapped to the strongest straight border in the median frame (window frames are hard lines)
  - accepted only if the windows leave a real overlay around them (they cover < 85% of the frame) - a normal
    full-frame video never qualifies
Returns [(x, y, w, h), ...] in clip pixels, top-to-bottom reading order, or None.
"""
import numpy as np

SAMPLES = 16
SW = 320                      # analysis width


def _frames(clip, n=SAMPLES):
    import cv2
    cap = cv2.VideoCapture(clip)
    nfr = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    out = []
    for k in range(n):
        cap.set(cv2.CAP_PROP_POS_FRAMES, int(max(0, nfr - 1) * (k + 0.5) / n))
        ok, img = cap.read()
        if ok:
            out.append(img)
    cap.release()
    return out


def _snap(prof, pos, span):
    """Move pos to the strongest edge in prof within +-span (if it's clearly an edge)."""
    lo, hi = int(max(0, pos - span)), int(min(len(prof) - 1, pos + span))
    if hi <= lo:
        return pos
    seg = prof[lo:hi + 1]
    i = int(np.argmax(seg))
    if seg[i] > max(3.0 * float(np.median(prof)), 12.0):
        return lo + i
    return pos


def _grow(box, bg, max_iter=400):
    """Grow box (x0, y0, x1, y1, exclusive) while the strip just outside each side is mostly not background."""
    x0, y0, x1, y1 = box
    H, W = bg.shape
    for _ in range(max_iter):
        moved = False
        if x0 > 0 and bg[y0:y1, x0 - 1].mean() < 0.5:
            x0 -= 1; moved = True
        if x1 < W and bg[y0:y1, x1].mean() < 0.5:
            x1 += 1; moved = True
        if y0 > 0 and bg[y0 - 1, x0:x1].mean() < 0.5:
            y0 -= 1; moved = True
        if y1 < H and bg[y1, x0:x1].mean() < 0.5:
            y1 += 1; moved = True
        if not moved:
            break
    return x0, y0, x1, y1


def detect(clip, w0, h0, frames=None):
    import cv2
    fr = frames if frames is not None else _frames(clip)
    if len(fr) < 6:
        return None
    sh = int(round(SW * h0 / float(w0)))
    col = np.stack([cv2.resize(f, (SW, sh), interpolation=cv2.INTER_AREA) for f in fr]).astype(np.float32)
    gray = col.mean(3)
    std = gray.std(0)
    thr = max(6.0, float(np.percentile(std, 35)) * 2.0)
    mask = (std > thr).astype(np.uint8)
    k = max(3, SW // 40)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((k, k), np.uint8))
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((k, k), np.uint8))
    n, lab, stats, _ = cv2.connectedComponentsWithStats(mask, 8)
    boxes = []
    for i in range(1, n):
        x, y, w, h, area = stats[i]
        if w * h < 0.04 * SW * sh or area < 0.5 * w * h:
            continue                                      # small, or not a filled rectangle
        if not (0.3 <= w / float(h) <= 3.4):
            continue
        boxes.append([x, y, x + w, y + h])
    if not 2 <= len(boxes) <= 3:
        return None
    # what the overlay background looks like: colours far from the moving windows, and it barely moves
    near = np.zeros((sh, SW), np.uint8)
    for x0, y0, x1, y1 in boxes:
        mx, my = int(0.45 * (x1 - x0)) + 2, int(0.45 * (y1 - y0)) + 2   # still part of the window, likely
        near[max(0, y0 - my):y1 + my, max(0, x0 - mx):x1 + mx] = 1
    med = np.median(col, axis=0)
    labc = cv2.cvtColor(np.clip(med, 0, 255).astype(np.uint8), cv2.COLOR_BGR2LAB).astype(np.float32)
    out_px = labc[near == 0]
    if len(out_px) < 0.05 * SW * sh:
        return None                                       # no overlay around the windows: a normal video
    K = 4
    crit = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 20, 1.0)
    smp = out_px[::max(1, len(out_px) // 4000)]
    _, lbl, centers = cv2.kmeans(smp, K, None, crit, 2, cv2.KMEANS_PP_CENTERS)
    share = np.bincount(lbl.ravel(), minlength=K) / float(len(lbl))
    centers = centers[share >= 0.15]                      # the overlay's main colours, not stray bits
    dist = np.min(np.linalg.norm(labc[:, :, None, :] - centers[None, None, :, :], axis=3), axis=2)
    bg = ((dist < 14.0) & (std < thr)).astype(np.float32)
    if bg[near == 0].mean() < 0.6:
        return None                                       # the "background" isn't a calm overlay
    grown = [_grow(tuple(b), bg) for b in boxes]
    cover = sum((x1 - x0) * (y1 - y0) for x0, y0, x1, y1 in grown) / float(SW * sh)
    if cover > 0.85:
        return None
    # snap to the windows' hard borders in full resolution
    medf = np.median(np.stack([f.mean(2) for f in fr]), axis=0).astype(np.float32)
    gx = np.abs(cv2.Sobel(medf, cv2.CV_32F, 1, 0, ksize=3))
    gy = np.abs(cv2.Sobel(medf, cv2.CV_32F, 0, 1, ksize=3))
    s = w0 / float(SW)
    out = []
    for x0, y0, x1, y1 in grown:
        X0, Y0, X1, Y1 = x0 * s, y0 * s, x1 * s, y1 * s
        rows = slice(int(Y0 + 0.15 * (Y1 - Y0)), int(Y1 - 0.15 * (Y1 - Y0)))
        cols = slice(int(X0 + 0.15 * (X1 - X0)), int(X1 - 0.15 * (X1 - X0)))
        colp, rowp = gx[rows].mean(0), gy[:, cols].mean(1)
        span = 1.5 * s
        X0, X1 = _snap(colp, X0, span), _snap(colp, X1, span)
        Y0, Y1 = _snap(rowp, Y0, span), _snap(rowp, Y1, span)
        X0, Y0, X1, Y1 = max(0, X0), max(0, Y0), min(w0, X1), min(h0, Y1)
        out.append(tuple(int(round(v / 2.0) * 2) for v in (X0, Y0, X1 - X0, Y1 - Y0)))
    out.sort(key=lambda b: (b[1] + b[3] / 2.0, b[0]))
    return out


def body(panels, samples, W, BODY_H, fit_blur):
    """Filter chain producing [body] (W x BODY_H): the windows stacked full-width, cropped only as much as needed
    to fit, around the faces inside each. Returns (chain, seam_y_in_body)."""
    hs = [W * h / float(w) for x, y, w, h in panels]
    k = min(1.0, BODY_H / sum(hs))
    ts = [int(h * k) // 2 * 2 for h in hs]
    parts, labels = ["[0:v]split=%d%s" % (len(panels) + 1, "".join("[p%d]" % i for i in range(len(panels) + 1)))], []
    for i, ((x, y, w, h), t) in enumerate(zip(panels, ts)):
        cw = min(w, int(round(h * W / float(t))) // 2 * 2)        # crop width that keeps the full window height
        xs = [f[0] for _, fs in samples for f in fs if x <= f[0] <= x + w and y <= f[1] <= y + h and f[4] > 0.6]
        cx = float(np.median(xs)) if xs else x + w / 2.0
        cx0 = int(min(max(x, cx - cw / 2.0), x + w - cw)) // 2 * 2
        parts.append("[p%d]crop=%d:%d:%d:%d,scale=%d:%d:flags=lanczos,setsar=1[q%d]" % (i, cw, h, cx0, y, W, t, i))
        labels.append("[q%d]" % i)
    stack_h = sum(ts)
    parts.append("%svstack=inputs=%d[stk]" % ("".join(labels), len(panels)))
    parts.append(fit_blur("p%d" % len(panels), "bg", W, BODY_H, "pn"))
    parts.append("[bg][stk]overlay=0:%d[body]" % ((BODY_H - stack_h) // 2))
    return ";".join(parts), (BODY_H - stack_h) // 2 + ts[0]

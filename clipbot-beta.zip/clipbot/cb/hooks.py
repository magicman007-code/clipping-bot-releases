"""Hooks: the headline on the clip and the post titles - short, a bit clickbait, funny when the moment is, and TRUE.

headlines(c, name=None, used=()) -> [{"text", "style", "score"}] best first, no emoji (the headline card can't draw them)
titles(c, name=None) -> same, with an emoji fitting the moment, for posts
best_headline(c, name=None, used=()) -> str

How a hook is built from a moment (c = a candidate: sentences, tags, room_laugh, looks):
  setup  = the line that sets the stakes (an amount, a decision, a story start), cleaned of "so um like"
  payoff = the line where it turns (the last laugh / shock / reaction beat)
  forms  = "POV: you <setup>" · "<setup>, then <payoff>" · "<setup>... wait for it" · "How do you <lose $40K>?"
           · "<Name> <setup>" · a short punchy quote · "<setup> (the ending)".
Facts: spoken numbers become hook numbers ("forty thousand dollars" -> "$40K"), and a hook is only kept if every
number in it was said in the clip and every outcome word (won, lost, rugged...) is in the clip. Without a known name
the hook never guesses "he" or "she" - it uses POV / "you" / no subject.
ai_batch(cands, names) asks a connected AI for hooks for many clips in one call; each is fact-checked the same way.
"""
import json
import re

from .common import log

ONES = {"zero": 0, "one": 1, "a": 1, "an": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7,
        "eight": 8, "nine": 9, "ten": 10, "eleven": 11, "twelve": 12, "thirteen": 13, "fourteen": 14, "fifteen": 15,
        "sixteen": 16, "seventeen": 17, "eighteen": 18, "nineteen": 19}
TENS = {"twenty": 20, "thirty": 30, "forty": 40, "fifty": 50, "sixty": 60, "seventy": 70, "eighty": 80, "ninety": 90}
MULT = {"hundred": 100, "thousand": 1000, "k": 1000, "grand": 1000, "million": 10 ** 6, "m": 10 ** 6, "mil": 10 ** 6,
        "billion": 10 ** 9, "b": 10 ** 9}
MONEY = re.compile(r"\$|dollars?|bucks|grand|usd|cash|paid|pay|wallet|bet|market cap|balance|slots?|casino|spin|"
                   r"\bdown\b|\bup\b|profit|lost|won|bank|price|cost|rent|salary|tip|donat|bought|buy|sold|sell|market", re.I)
OUTCOMES = re.compile(r"\b(lost|lose|losing|won|win|winning|rugged|sold|bought|hit|crashed|exposed|caught|quit|banned|"
                      r"failed|beat|cried|fired|scammed|dumped|made|turned|broke|kicked out|arrested|called)\b", re.I)
LEAD = re.compile(r"^(?:(?:so|okay|ok|um+|uh+|like|yeah|and|but|then|anyway|alright|bro|dude|man|chat|guys|"
                  r"basically|honestly|literally|one time|last story|true story|you know)[,!.]?\s+)+", re.I)
FIRST = [(r"\bI'm\b", "you're"), (r"\bI am\b", "you're"), (r"\bI've\b", "you've"), (r"\bI'd\b", "you'd"),
         (r"\bI'll\b", "you'll"), (r"\bI\b", "you"), (r"\bme\b", "you"), (r"\bmy\b", "your"), (r"\bmine\b", "yours"),
         (r"\bmyself\b", "yourself"), (r"\bwe\b", "you"), (r"\bour\b", "your"), (r"\bus\b", "you"),
         (r"\bwe're\b", "you're"), (r"\bwas\b", "were")]
EMOJI = {"laugh": "😭", "fail": "💀", "money": "💰", "shock": "😳", "drama": "😤", "win": "🔥", "wholesome": "🥹"}


# ------------------------------------------------------------------------------------------- numbers
def _num_tokens(tokens, i):
    """Parse a spoken / written number starting at tokens[i] -> (value, j) or (None, i)."""
    total, cur, j, seen = 0, 0, i, False
    while j < len(tokens):
        t = tokens[j].lower().strip(",.!?")
        m = re.match(r"^\$?(\d+(?:[.,]\d+)?)(k|m|b|mil)?$", t)
        if m:
            cur += float(m.group(1).replace(",", ""))
            if m.group(2):
                cur *= MULT[m.group(2)]
            seen, j = True, j + 1
            continue
        if t in ONES and (t not in ("a", "an") or (j + 1 < len(tokens) and tokens[j + 1].lower().strip(",.") in MULT)):
            cur += ONES[t]
            seen, j = True, j + 1
            continue
        if t in TENS:
            cur += TENS[t]
            seen, j = True, j + 1
            continue
        if t in MULT and seen:
            if MULT[t] == 100:
                cur = max(cur, 1) * 100
            else:
                total += max(cur, 1) * MULT[t]
                cur = 0
            j += 1
            continue
        if t == "and" and seen and j + 1 < len(tokens) and tokens[j + 1].lower() in ONES.keys() | TENS.keys():
            j += 1
            continue
        break
    return ((total + cur), j) if seen else (None, i)


def compact(v, money=False):
    if v >= 10 ** 9:
        s = "%gB" % round(v / 10 ** 9, 1)
    elif v >= 10 ** 6:
        s = "%gM" % round(v / 10 ** 6, 1)
    elif v >= 10 ** 4 or (money and v >= 1000):
        s = "%gK" % round(v / 1000, 1)
    else:
        s = "%g" % v
    return ("$" + s) if money else s


def numbers_in(text):
    """[(value, is_money, start_token, end_token)] for every number said in a text."""
    toks = text.split()
    out, i = [], 0
    while i < len(toks):
        v, j = _num_tokens(toks, i)
        if v is not None and j > i:
            around = " ".join(toks[max(0, i - 3):j + 2])
            out.append((v, bool(MONEY.search(around)) or toks[i].startswith("$"), i, j))
            i = j
        else:
            i += 1
    return out


def with_numbers(text):
    """'I put twelve thousand dollars in' -> 'I put $12K in'."""
    toks = text.split()
    nums = numbers_in(text)
    if not nums:
        return text
    out, i = [], 0
    for v, money, a, b in nums:
        if v < 10:                         # "one spin", "two of us": keep the words
            continue
        out += toks[i:a]
        word = compact(v, money)
        tail = toks[b - 1]
        if money and b < len(toks) and re.match(r"^(dollars?|bucks|grand)[,.!?]?$", toks[b], re.I):
            punct = re.sub(r"^[a-zA-Z]+", "", toks[b])
            b += 1
            word += punct
        elif re.search(r"[,.!?]$", tail):
            word += tail[-1]
        out.append(word)
        i = b
    out += toks[i:]
    return " ".join(out)


# ------------------------------------------------------------------------------------------- facts check
def supported(hook, text):
    """Every number in the hook was said in the clip (same value), every outcome word is in the clip."""
    said = {round(v) for v, *_ in numbers_in(text)}
    for v, money, *_ in numbers_in(hook.replace("$", "$ ").replace("$ ", "$")):
        if v >= 10 and round(v) not in said:
            return False
    low = text.lower()
    stem = lambda w: w.lower()[:4]
    for m in OUTCOMES.finditer(hook):
        if stem(m.group(1)) not in low:
            return False
    return True


# ------------------------------------------------------------------------------------------- building blocks
def _clean(s):
    s = re.sub(r"\b(um+|uh+|erm|you know|i mean|kind of|sort of)\b,?\s*", "", s, flags=re.I)
    s = LEAD.sub("", s.strip())
    s = re.sub(r"\s{2,}", " ", s).strip(" ,")
    return s


END_WEAK = re.compile(r"\s+(?:the|a|an|to|of|and|or|in|on|at|with|for|my|your|his|her|their|this|that|it|got|was|were|"
                      r"is|be|been|so|just|really|very|like|then|if|when|but|because)$", re.I)


def _clause(s, n=10, prefer_number=False):
    """The main clause of a sentence, at most n words, never ending on a dangling word ("...and it got")."""
    s = with_numbers(_clean(s)).rstrip(".!?")
    parts = [p.strip() for p in re.split(r",\s+|\s+(?:but|because|and then|so|and)\s+", s) if p.strip()]
    FRAG = re.compile(r"^(?:for|of|to|where|which|that|who|whom|in|on|at|with|from|about|than|as|into|by|the latest|"
                      r"this latest|\.\.\.|-)\b", re.I)
    whole = [p for p in parts if len(p.split()) >= 3 and not FRAG.match(p)]
    c = whole[0] if whole else next((p for p in parts if len(p.split()) >= 3), parts[0] if parts else s)
    if prefer_number:
        c = next((p for p in parts if re.search(r"\$|\d", p) and len(p.split()) >= 2), c)
    # a question that reports what happened -> a statement ("did that just hit $10M?" -> "it hit $10M")
    c = re.sub(r"^(?:did|does|is|was)\s+(?:that|this|it)\s+(?:just\s+)?", "it ", c, flags=re.I)
    c = re.sub(r"^(?:wait|okay|yo|bro|chat|guys)[,!]?\s+", "", c, flags=re.I)
    w = c.split()
    if len(w) > n:
        c = " ".join(w[:n])
    for _ in range(4):
        c2 = END_WEAK.sub("", c)
        if c2 == c:
            break
        c = c2
    c = re.sub(r"\b(this|that)\s+(coin|stock|game|guy|girl|dude|stream|bet|spin|car|house)\b", r"a \2", c, flags=re.I)
    c = re.sub(r"\b(bought|sold|got|aped into|found|grabbed)\s+(this|that)\b", r"\1 it", c, flags=re.I)
    return c.strip()


def _pov(s):
    """First person -> 'you' (POV hooks work without knowing who the streamer is)."""
    out = " " + s + " "
    for a, b in FIRST:
        out = re.sub(a, b, out)
    return out.strip()


def _tone(c):
    t = c.get("tags") or {}
    text = " ".join(x[1] for x in c.get("sentences", [])).lower()
    if re.search(r"\b(lost|rugged|scammed|crashed|broke|banned|fired|caught|dumped)\b", text):
        return "fail"
    if c.get("room_laugh", 0) >= 0.5 or t.get("humor"):
        return "laugh"
    if t.get("drama") or t.get("rage"):
        return "drama"
    if t.get("stakes") and re.search(r"\b(won|hit|made|paid|10x|100x)\b", text):
        return "money"
    if t.get("shock") or t.get("reaction"):
        return "shock"
    return "win"


STORY = re.compile(r"\b(found out|quit|put|bet|aped|bought|sold|lost|won|was down|was up|got (?:fired|banned|caught|"
                   r"kicked|scammed|rugged)|asked|told|tried|decided|walked|showed up|called|broke|crashed|hit)\b", re.I)
CHORE = re.compile(r"\b(check the chat|chat real quick|shout ?out|hit follow|subscribe|sub(?:scribe)? button|"
                   r"see you tomorrow|let'?s scroll|be right back|brb|thanks? for the|link in)\b", re.I)
GENERIC = re.compile(r"^(?:no way|i'?m dead|i'?m crying|oh my god|let'?s go+|that was (?:hilarious|crazy|insane)|"
                     r"hilarious|bro+|wait|what|lol|haha+|yes+|we did it)[.!?]*$", re.I)


def _setup_payoff(c):
    sents = [s for _, s in c.get("sentences", []) if len(s.split()) >= 3 and not GENERIC.match(_clean(s))
             and not CHORE.search(s)]
    if not sents:
        return None, None
    def strength(s):
        return 2 * bool(STORY.search(s)) + 1.5 * any(v >= 10 for v, *_ in numbers_in(s)) + 0.5 * bool(re.search(r"\b(I|my|we)\b", s))
    # setup: the first strong line (a decision, a story start, the stakes) in the first two thirds
    head = sents[:max(1, (2 * len(sents) + 2) // 3)]
    si = max(range(len(head)), key=lambda k: (strength(head[k]) >= 2,
                                              bool(re.search(r"\b(I|my|we)\b", head[k])) and bool(STORY.search(head[k])), -k))
    if strength(head[si]) < 1:
        si = 0
    setup = sents[si]
    # payoff: a later line that turns it - a new number, an outcome, the cops showing up - else the next strong line
    later = sents[si + 1:]
    beat = re.compile(r"(lost|rugged|sold everything|hit|paid|caught|called|showed up|found out|quit|banned|crashed|won|"
                      r"died|broke|fired|kicked|watches|texts|bought the top|50x|10x|100x)", re.I)
    sv = {round(v) for v, *_ in numbers_in(setup)}
    newnum = lambda s: any(v >= 10 and round(v) not in sv for v, *_ in numbers_in(s))
    others = [x for x in sents if x != setup]
    pay = next((s for s in later if beat.search(s) and newnum(s)), None) \
        or next((s for s in later if beat.search(s) and not re.search(r"\b(I|we)\s+(put|bet|bought)\b", s)), None) \
        or next((s for s in others if newnum(s) and re.search(r"\b(hit|paid|won|made|lost)\b", s, re.I)), None) \
        or None                                  # no turn in this moment: no "then ..." hook
    return setup, pay


def _shape(t):
    t = re.sub(r"\s+", " ", t).strip()
    t = re.sub(r"^POV: ([A-Z])([a-z])", lambda m: "POV: " + m.group(1).lower() + m.group(2), t)
    t = re.sub(r"\bi\b", "I", t)
    return t[:1].upper() + t[1:]


def candidates(c, name=None):
    text = " ".join(s for _, s in c.get("sentences", []))
    setup, pay = _setup_payoff(c)
    if not setup:
        return []
    tone = _tone(c)
    s_cl = _clause(setup, 11)
    p_cl = _clause(pay, 9, prefer_number=True) if pay else ""
    p_cl = re.sub(r"^(?:\w+ (?:weeks?|days?|hours?|minutes?|months?) later|later|after that|now)\s+", "", p_cl, flags=re.I)
    raw = []
    happens = bool(STORY.search(setup)) or any(v >= 10 for v, *_ in numbers_in(setup))
    first_person = re.search(r"\b(I|I'm|my|me|we)\b", s_cl) and happens       # POV only when something happens
    if not happens:                             # talk with no event: the best clean full quote instead of a forced hook
        qs = [with_numbers(_clean(x)).rstrip(".") for _, x in c.get("sentences", [])]
        qs = [q for q in qs if 5 <= len(q.split()) <= 11 and not GENERIC.match(q) and not CHORE.search(q)
              and q[:1].isalpha() and not re.match(r"^(?:where|which|that|who|for|of|to|and|but|because|as|than)\b", q, re.I)
              and not END_WEAK.search(q)]
        if qs:
            q = max(qs, key=lambda q: (bool(re.search(r"[!?]", q)), -abs(len(q.split()) - 8)))
            raw.append(("quote", "\u201c%s\u201d" % _shape(q)))
    if first_person:
        raw.append(("pov", "POV: " + _pov(s_cl)))
        if name:
            subj = re.sub(r"^(I|we)\s+", name + " ", s_cl)
            if subj != s_cl:
                raw.append(("name", _pov(subj).replace("you", "they") if False else subj.replace(" my ", " their ")))
    elif happens:
        raw.append(("plain", s_cl))
    if p_cl and happens and p_cl.lower() != s_cl.lower():
        p2 = re.sub(r"^(then|and|so|but)\s+", "", p_cl, flags=re.I)
        lead = "POV: " + _pov(s_cl) if first_person else s_cl
        if len((lead + " " + p2).split()) <= 16:
            raw.append(("twist", "%s, then %s" % (lead, _pov(p2) if first_person else p2)))
    if happens:
        raw.append(("wait", "%s... wait for it" % ("POV: " + _pov(s_cl) if first_person else s_cl)))
    m = re.search(r"\b(lost|lose|won|made|put|bet|spent|paid)\b\s+(\$[\d.]+[KMB]?)", with_numbers(text), re.I)
    if m:
        verb = {"lost": "lose", "won": "win", "made": "make", "put": "risk", "bet": "bet", "spent": "spend",
                "paid": "get paid"}.get(m.group(1).lower(), m.group(1).lower())
        raw.append(("question", "How do you %s %s like this?" % (verb, m.group(2))))
    short = [_clean(s).rstrip(".") for _, s in c.get("sentences", []) if 3 <= len(_clean(s).split()) <= 8
             and not GENERIC.match(_clean(s))]
    punch = [s for s in short if re.search(r"(dead|crying|no way|cops|police|mom|dad|fired|banned|rugged|scam|why|what)", s, re.I)]
    if punch:
        raw.append(("quote", "“%s”" % with_numbers(punch[-1])))
    out, seen = [], set()
    for style, t in raw:
        t = _shape(t)
        k = t.lower()
        if k in seen or not t:
            continue
        seen.add(k)
        out.append({"text": t, "style": style, "tone": tone, "ok": supported(t, text)})
    return out


def _score(h, used=()):
    w = len(re.sub(r"[^\w$ ]", "", h["text"]).split())
    s = 3.0 - 0.5 * max(0, 5 - w) - 0.3 * max(0, w - 11)   # 5-11 words reads in one glance
    s += 0.8 * bool(STORY.search(h["text"]))               # something actually happens in it
    s += 1.4 * bool(re.search(r"\$|\d", h["text"]))     # a specific number beats vague words
    s += {"twist": 1.2, "pov": 0.9, "question": 0.8, "name": 1.0, "ai": 1.6, "quote": 0.3, "wait": 0.2, "plain": 0.0}.get(h["style"], 0)
    s -= 0.8 * (h["style"] in used)                    # don't make every clip the same template
    s -= 2.0 * bool(re.search(r"\b(this|that|it|they|he|she)\b\W*$", h["text"], re.I))   # ends pointing nowhere
    s -= 4.0 * (not h["ok"])
    return round(s, 2)


def headlines(c, name=None, used=(), extra=()):
    hs = candidates(c, name) + list(extra)
    for h in hs:
        h["score"] = _score(h, used)
    hs = [h for h in hs if h["ok"]]
    return sorted(hs, key=lambda h: -h["score"])


def best_headline(c, name=None, used=(), extra=()):
    hs = headlines(c, name, used, extra)
    return (hs[0]["text"], hs[0]["style"]) if hs else ("", None)


def titles(c, name=None, extra=()):
    """Post titles: the whole story (setup, then twist) reads best under a post, so twists rank first here."""
    out = []
    hs = headlines(c, name, extra=extra)
    hs.sort(key=lambda h: -(h["score"] + (2.0 if h["style"] == "twist" else 0.0)))
    for h in hs:
        e = EMOJI.get(h.get("tone") or "win", "🔥")
        t = h["text"] if h["text"].endswith(("?", "”")) else h["text"].rstrip(".") + " " + e
        out.append({"style": "hook-" + h["style"], "title": t, "chars": len(t), "supported": True, "note": None})
    return out


# ------------------------------------------------------------------------------------------- AI, many clips at once
def ai_batch(cands, names=(), wait=40):
    """{index: [hook, ...]} from the connected AI (one call for all clips), fact-checked. {} when no AI."""
    try:
        from .connect import ai_ready, ai_complete
        if not ai_ready() or not cands:
            return {}
    except Exception:
        return {}
    system = ("You write the on-screen headline for short vertical clips of livestreams - the hook that makes people "
              "stop scrolling. Style: 4-9 words, punchy, a bit clickbait, funny when the moment is funny, but it MUST "
              "make sense and be TRUE to the transcript: no invented numbers, names, outcomes or events. Good forms: "
              "'POV: you ...', '<setup>, then <twist>', a question, the funniest short quote. Use 'you'/'POV' or the "
              "given name; never guess he/she. No hashtags, no emoji. Return JSON: {\"1\": [\"hook\", ...], ...} "
              "with 3 hooks per clip.")
    lines = []
    for i, c in enumerate(cands, 1):
        lines.append("Clip %d: %s" % (i, " ".join(s for _, s in c.get("sentences", []))[:700]))
    prompt = ("Streamer name: %s\n\n" % (names[0] if names else "unknown")) + "\n\n".join(lines)
    try:
        out = ai_complete(prompt, system=system, max_tokens=1200, wait=wait)
        j = json.loads(re.search(r"\{.*\}", out, re.S).group(0))
    except Exception as e:
        log("AI hooks skipped (%s)" % str(e)[:100])
        return {}
    res = {}
    for k, v in j.items():
        try:
            i = int(k) - 1
        except ValueError:
            continue
        if not (0 <= i < len(cands)) or not isinstance(v, list):
            continue
        text = " ".join(s for _, s in cands[i].get("sentences", []))
        good = []
        for h in v[:5]:
            h = _shape(re.sub(r"[#\U0001F300-\U0001FAFF☀-➿]", "", str(h))).strip()
            if 3 <= len(h.split()) <= 12 and supported(h, text) and _names_ok(h, text, names):
                good.append({"text": h, "style": "ai", "tone": _tone(cands[i]), "ok": True})
        res[i] = good
    return res


def _names_ok(h, text, names=()):
    low = text.lower() + " " + " ".join(n.lower() for n in names)
    for w in re.findall(r"(?<!^)\b([A-Z][a-z]{2,})\b", h):
        if w.lower() not in low and w not in ("POV", "How", "Why", "What", "When", "Then", "Wait", "The", "This",
                                              "Chat", "Nobody", "You", "Your"):
            return False
    return True

"""Big-creator thumbnails: the expressive frame, the person cut out with a thick white outline, a pumped background,
huge 2-3 word text, and an arrow / circle / emoji if wanted.

  frames(video, n)     -> the n most expressive, sharp frames (big face, open mouth, eyes visible), spread over the clip
  make(video, t, ...)  -> one thumbnail per style x size: 1280x720 (YouTube) and 1080x1920 (Shorts / TikTok cover)

Styles
  pop      bright and saturated, face huge on the right, yellow text with a black stroke (the "challenge video" look)
  hype     dark, red rim glow behind the person, red-and-white text, slight tilt (the "streamer freak-out" look)
  clean    no cutout: the frame graded, text on a dark side panel (works for anything, including no face)

Person cutout: U^2-Net human segmentation (Apache-2.0, github.com/xuebinqin/U-2-Net) via onnxruntime, downloaded once
(176 MB, checksum verified) to <work_root>/_models/cutout; the small 4.6 MB model is the fallback. If neither can be
used, styles that need a cutout fall back to 'clean' and say so.
"""
import hashlib
import math
import os
import threading
import urllib.request

import numpy as np

from .common import FONT_DIR, load_config, log, probe, YUNET

MODELS = {
    "human": ("https://github.com/danielgatis/rembg/releases/download/v0.0.0/u2net_human_seg.onnx",
              "01eb6a29a5c4d8edb30b56adad9bb3a2a0535338e480724a213e0acfd2d1c73c"),
    "small": ("https://github.com/danielgatis/rembg/releases/download/v0.0.0/u2netp.onnx",
              "309c8469258dda742793dce0ebea8e6dd393174f89934733ecc8b14c76f4ddd8"),
}
STYLES = ("pop", "studio", "hype", "clean", "ai", "remix")
_LOCK = threading.Lock()
_SESS = {}


def _sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def _model(kind):
    url, want = MODELS[kind]
    d = os.path.join(load_config()["work_root"], "_models", "cutout")
    os.makedirs(d, exist_ok=True)
    dst = os.path.join(d, kind + ".onnx")
    if os.path.exists(dst) and _sha(dst) == want:
        return dst
    log("downloading the person cutout model (%s, one time)..." % ("176 MB" if kind == "human" else "5 MB"))
    tmp = dst + ".part"
    with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "clipbot"}), timeout=60) as r, open(tmp, "wb") as f:
        while True:
            b = r.read(1 << 20)
            if not b:
                break
            f.write(b)
    if _sha(tmp) != want:
        os.remove(tmp)
        raise RuntimeError("cutout model download was corrupted")
    os.replace(tmp, dst)
    return dst


def _session():
    with _LOCK:
        if "s" in _SESS:
            return _SESS["s"]
        import onnxruntime as ort
        err = None
        for kind in ("human", "small"):
            try:
                _SESS["s"] = ort.InferenceSession(_model(kind), providers=["CPUExecutionProvider"])
                _SESS["kind"] = kind
                return _SESS["s"]
            except Exception as e:
                err = e
                log("cutout model %s unavailable: %s" % (kind, e))
        _SESS["s"] = None
        _SESS["err"] = str(err)[:160]
        return None


def cutout(rgb, face=None):
    """Soft alpha mask (H x W, 0..1) of the main person in an RGB uint8 image, or None."""
    import cv2
    s = _session()
    if s is None:
        return None
    x = cv2.resize(rgb, (320, 320), interpolation=cv2.INTER_LANCZOS4).astype(np.float32) / 255.0
    x = (x - np.array([0.485, 0.456, 0.406], np.float32)) / np.array([0.229, 0.224, 0.225], np.float32)
    o = s.run(None, {s.get_inputs()[0].name: x.transpose(2, 0, 1)[None].astype(np.float32)})[0][0, 0]
    o = (o - o.min()) / (o.max() - o.min() + 1e-8)
    m = cv2.resize(o, (rgb.shape[1], rgb.shape[0]), interpolation=cv2.INTER_LINEAR)
    # keep the person: the blob that holds the face (or the biggest one), drop stray bits (flags, props)
    hard = (m > 0.5).astype(np.uint8)
    n, lab, st, _ = cv2.connectedComponentsWithStats(hard, 8)
    if n <= 1:
        return None
    if face is not None:
        cx, cy = int(face[0] + face[2] / 2), int(face[1] + face[3] / 2)
        keep = lab[min(max(cy, 0), lab.shape[0] - 1), min(max(cx, 0), lab.shape[1] - 1)]
        if keep == 0:
            keep = 1 + int(np.argmax(st[1:, cv2.CC_STAT_AREA]))
    else:
        keep = 1 + int(np.argmax(st[1:, cv2.CC_STAT_AREA]))
    if st[keep, cv2.CC_STAT_AREA] < 0.02 * hard.size:
        return None
    body = cv2.dilate((lab == keep).astype(np.uint8), np.ones((9, 9), np.uint8))
    return np.clip(m * body, 0, 1)


# ------------------------------------------------------------------ frames
def frames(video, n=6, a=None, b=None, samples=36):
    """Most thumbnail-worthy frames: [{t, face (x,y,w,h) or None, score, rgb}], spread over the clip."""
    import cv2
    pr = probe(video)
    a = a or 0.0
    b = b or pr["duration"]
    w0, h0 = pr["width"], pr["height"]
    aw = 640
    ah = int(aw * h0 / w0)
    det = cv2.FaceDetectorYN.create(YUNET, "", (aw, ah), 0.6, 0.3, 5000)
    cap = cv2.VideoCapture(video)
    cands = []
    for t in np.linspace(a + 0.3, max(a + 0.4, b - 0.3), samples):
        cap.set(cv2.CAP_PROP_POS_MSEC, t * 1000)
        ok, img = cap.read()
        if not ok:
            continue
        small = cv2.resize(img, (aw, ah))
        gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
        sharp = min(cv2.Laplacian(gray, cv2.CV_64F).var(), 600) / 600
        _, fs = det.detect(small)
        face, sc = None, 0.2 * sharp
        if fs is not None and len(fs):
            f = max(fs, key=lambda r: r[2] * r[3])
            x, y, fw, fh = [float(v) for v in f[:4]]
            lm = f[4:14].reshape(5, 2)
            y0, y1 = int(min(lm[3][1], lm[4][1])), int(min(ah, max(lm[3][1], lm[4][1]) + fh * 0.22))
            x0, x1 = int(min(lm[3][0], lm[4][0])), int(max(lm[3][0], lm[4][0]) + 1)
            mouth = gray[max(0, y0):y1, max(0, x0):x1]
            open_ = min(1.0, float(mouth.std()) / 50) if mouth.size else 0.0      # open mouth = contrast
            size = min(1.0, (fw * fh) / (aw * ah) * 6)
            sc = 1.0 + 1.4 * size + 1.0 * open_ + 0.6 * sharp + 0.5 * float(f[14])
            k = w0 / float(aw)
            face = (x * k, y * k, fw * k, fh * k)
        cands.append({"t": round(float(t), 2), "score": round(sc, 3), "face": face,
                      "rgb": cv2.cvtColor(img, cv2.COLOR_BGR2RGB)})
    cap.release()
    cands.sort(key=lambda c: -c["score"])
    out = []
    gap = max(0.6, (b - a) / (n * 2.5))
    for c in cands:                       # spread out: not six near-identical frames
        if all(abs(c["t"] - o["t"]) >= gap for o in out):
            out.append(c)
        if len(out) == n:
            break
    return out


# ------------------------------------------------------------------ drawing
def _font(name, size):
    from PIL import ImageFont
    for f in (name, "Anton-Regular.ttf", "Montserrat-Black.ttf"):
        p = os.path.join(FONT_DIR, f)
        if os.path.exists(p):
            return ImageFont.truetype(p, size)
    return ImageFont.load_default()


def _fit_text(draw, text, font_name, box_w, box_h, max_size, lines_max=3):
    """Biggest size where the words wrap into <= lines_max lines inside the box."""
    words = text.split()
    for size in range(max_size, 28, -4):
        f = _font(font_name, size)
        lines, cur = [], ""
        for w in words:
            t = (cur + " " + w).strip()
            if draw.textlength(t, font=f) <= box_w or not cur:
                cur = t
            else:
                lines.append(cur)
                cur = w
        lines.append(cur)
        lh = int(size * 1.0)
        if len(lines) <= lines_max and lh * len(lines) <= box_h and all(draw.textlength(l, font=f) <= box_w for l in lines):
            return f, lines, lh
    f = _font(font_name, 32)
    return f, [text], 34


def _text_layer(W, H, text, font_name, box, fill, stroke, angle=0.0, shadow=True, second_fill=None):
    from PIL import Image, ImageDraw, ImageFilter
    x0, y0, bw, bh = box
    lay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(lay)
    f, lines, lh = _fit_text(d, text.upper(), font_name, bw, bh, int(bh / 1.6))
    sw = max(6, int(f.size * 0.09))
    y = y0 + (bh - lh * len(lines)) / 2
    depth = max(4, int(f.size * 0.06))
    for i, l in enumerate(lines):
        tw = d.textlength(l, font=f)
        x = x0 + (bw - tw) / 2
        col = (second_fill if (second_fill and i == len(lines) - 1 and len(lines) > 1) else fill)
        for k in range(depth, 0, -1):            # 3D extrude: stacked dark copies down and to the right
            d.text((x + k, y + k), l, font=f, fill=(0, 0, 0, 255), stroke_width=sw, stroke_fill=(0, 0, 0, 255))
        d.text((x, y), l, font=f, fill=col, stroke_width=sw, stroke_fill=stroke)
        y += lh
    if angle:
        lay = lay.rotate(angle, resample=Image.BICUBIC, center=(x0 + bw / 2, y0 + bh / 2))
    if shadow:
        sh = lay.split()[-1].point(lambda v: 200 if v > 0 else 0).filter(ImageFilter.GaussianBlur(10))
        base = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        base.paste((0, 0, 0, 255), (8, 10), sh)
        base.alpha_composite(lay)
        return base
    return lay


def _arrow(W, H, tip, color=(255, 40, 40, 255), scale=1.0, frm=None):
    """A fat arrow pointing at tip, coming from frm (default: up and to the left), with a white outline."""
    from PIL import Image, ImageDraw
    lay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(lay)
    tx, ty = tip
    L = 260 * scale
    sx, sy = frm if frm else (tx - L * 0.82, ty - L * 0.57)
    dx, dy = tx - sx, ty - sy
    n = math.hypot(dx, dy) or 1.0
    ux, uy = dx / n, dy / n
    px, py = -uy, ux
    hl, hw, sw = 92 * scale, 64 * scale, 30 * scale

    def shape(grow):
        bx, by = tx - ux * hl, ty - uy * hl
        tipx, tipy = tx + ux * grow * 1.4, ty + uy * grow * 1.4
        shaft = [(sx - ux * grow + px * (sw / 2 + grow), sy - uy * grow + py * (sw / 2 + grow)),
                 (bx + px * (sw / 2 + grow), by + py * (sw / 2 + grow)),
                 (bx + px * (hw + grow * 1.6), by + py * (hw + grow * 1.6)),
                 (tipx, tipy),
                 (bx - px * (hw + grow * 1.6), by - py * (hw + grow * 1.6)),
                 (bx - px * (sw / 2 + grow), by - py * (sw / 2 + grow)),
                 (sx - ux * grow - px * (sw / 2 + grow), sy - uy * grow - py * (sw / 2 + grow))]
        return shaft
    d.polygon(shape(9 * scale), fill=(255, 255, 255, 255))
    d.polygon(shape(0), fill=color)
    return lay


def _ring(W, H, center, r, color=(255, 40, 40, 255)):
    from PIL import Image, ImageDraw
    lay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(lay)
    cx, cy = center
    d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=(255, 255, 255, 255), width=24)
    d.ellipse([cx - r + 4, cy - r + 4, cx + r - 4, cy + r - 4], outline=color, width=14)
    return lay


def _compose(rgb, face, mask, W, H, style, text, emoji, arrow, circle, ai_bg=None):
    import cv2
    from PIL import Image, ImageEnhance, ImageFilter
    src = Image.fromarray(rgb)
    sw, sh = src.size
    land = W > H
    use_cut = style in ("pop", "hype", "studio", "ai") and mask is not None and face is not None
    # --- background: the frame itself, scaled to cover, graded per style
    k = max(W / sw, H / sh)
    if face is not None:
        fx, fy = (face[0] + face[2] / 2) * k, (face[1] + face[3] / 2) * k
    else:
        fx, fy = sw * k / 2, sh * k / 2
    bg = src.resize((int(sw * k) + 1, int(sh * k) + 1), Image.LANCZOS)
    bx = int(min(max(0, fx - W * (0.68 if land else 0.5)), bg.width - W))
    by = int(min(max(0, fy - H * (0.45 if land else 0.4)), bg.height - H))
    bg = bg.crop((bx, by, bx + W, by + H)).convert("RGB")
    if style == "studio" and use_cut:                  # bright studio backdrop: radial glow, no clutter
        yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
        cx_, cy_ = W * (0.68 if land else 0.5), H * (0.45 if land else 0.38)
        r = np.clip(np.sqrt(((xx - cx_) / (W * 0.75)) ** 2 + ((yy - cy_) / (H * 0.85)) ** 2), 0, 1)[..., None]
        inner, outer = np.array([120, 210, 255], np.float32), np.array([10, 70, 230], np.float32)
        bg = Image.fromarray((inner * (1 - r) + outer * r).astype(np.uint8))
    elif style == "ai" and ai_bg is not None:          # AI-made scene (background only, never the person)
        g = ai_bg.convert("RGB")
        k2 = max(W / g.width, H / g.height)
        g = g.resize((int(g.width * k2) + 1, int(g.height * k2) + 1), Image.LANCZOS)
        gx, gy = (g.width - W) // 2, (g.height - H) // 2
        bg = ImageEnhance.Color(g.crop((gx, gy, gx + W, gy + H))).enhance(1.15)
    elif style == "pop":
        bg = ImageEnhance.Color(bg.filter(ImageFilter.GaussianBlur(6 if use_cut else 0))).enhance(1.6)
        bg = ImageEnhance.Brightness(bg).enhance(1.05)
    elif style == "hype":
        bg = ImageEnhance.Brightness(ImageEnhance.Color(bg.filter(ImageFilter.GaussianBlur(8 if use_cut else 0))).enhance(1.3)).enhance(0.55)
    else:
        bg = ImageEnhance.Sharpness(ImageEnhance.Contrast(ImageEnhance.Color(bg).enhance(1.35)).enhance(1.15)).enhance(1.4)
    canvas = bg.convert("RGBA")
    if style == "hype":                                 # dark vignette
        vg = np.zeros((H, W), np.float32)
        yy, xx = np.mgrid[0:H, 0:W]
        vg = np.clip(((xx - W / 2) ** 2 / (W * 0.62) ** 2 + (yy - H / 2) ** 2 / (H * 0.62) ** 2), 0, 1)
        canvas.alpha_composite(Image.fromarray((np.dstack([np.zeros_like(vg)] * 3 + [vg * 200])).astype(np.uint8), "RGBA"))
    # --- the person, bigger than life, with a thick white outline (and a red rim glow for hype)
    head_x = W * (0.70 if land else 0.5)
    if use_cut:
        x, y, fw, fh = face
        scale = (H * (0.42 if land else 0.27)) / max(1.0, fh)
        pw, ph = int(sw * scale), int(sh * scale)
        person = src.resize((pw, ph), Image.LANCZOS)
        person = ImageEnhance.Sharpness(ImageEnhance.Color(ImageEnhance.Contrast(ImageEnhance.Brightness(person)
                 .enhance(1.06)).enhance(1.12)).enhance(1.18)).enhance(1.5).convert("RGBA")   # the subject pops
        a = cv2.resize((mask * 255).astype(np.uint8), (pw, ph), interpolation=cv2.INTER_LINEAR)
        person.putalpha(Image.fromarray(a))
        ox = int(head_x - (x + fw / 2) * scale)
        oy = int(H * (0.50 if land else 0.40) - (y + fh / 2) * scale)
        hard = (a > 110).astype(np.uint8)
        ring = int(max(10, H * 0.018))
        outline = cv2.dilate(hard, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * ring + 1, 2 * ring + 1)))
        lay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        if style == "hype":
            glow = cv2.GaussianBlur(cv2.dilate(hard, np.ones((ring * 3, ring * 3), np.uint8)).astype(np.float32), (0, 0), ring * 2)
            g = Image.fromarray(np.dstack([np.full_like(glow, 255), np.full_like(glow, 30), np.full_like(glow, 30),
                                           np.clip(glow * 255 * 1.6, 0, 235)]).astype(np.uint8), "RGBA")
            lay.paste(g, (ox, oy), g)
        white = Image.new("RGBA", (pw, ph), (255, 255, 255, 255))
        white.putalpha(Image.fromarray((outline * 255).astype(np.uint8)))
        lay.paste(white, (ox, oy), white)
        lay.paste(person, (ox, oy), person)
        sh_ = lay.split()[-1].filter(ImageFilter.GaussianBlur(14))
        shadow = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        shadow.paste((0, 0, 0, 160), (10, 14), sh_)
        canvas.alpha_composite(shadow)
        canvas.alpha_composite(lay)
        face_box = (ox + x * scale, oy + y * scale, fw * scale, fh * scale)
    else:
        face_box = None
        if face is not None:
            face_box = (face[0] * k - bx, face[1] * k - by, face[2] * k, face[3] * k)
        if style == "clean" and land:                   # dark side panel behind the text
            sh_ = Image.new("RGBA", (W, H), (0, 0, 0, 0))
            arr = np.zeros((H, W, 4), np.uint8)
            arr[:, :, 3] = np.clip(170 * (1 - np.arange(W) / (W * 0.62)), 0, 170).astype(np.uint8)[None, :]
            canvas.alpha_composite(Image.fromarray(arr, "RGBA"))
    # --- text
    if text:
        if land:
            box = (int(W * 0.03), int(H * 0.08), int(W * 0.50), int(H * 0.84))
        else:
            box = (int(W * 0.05), int(H * 0.62), int(W * 0.90), int(H * 0.30))
        if style in ("pop", "studio", "ai"):
            lay = _text_layer(W, H, text, "Anton-Regular.ttf", box, (255, 221, 0, 255), (0, 0, 0, 255), angle=3,
                              second_fill=(255, 255, 255, 255))
        elif style == "hype":
            lay = _text_layer(W, H, text, "Anton-Regular.ttf", box, (255, 255, 255, 255), (0, 0, 0, 255), angle=-4,
                              second_fill=(255, 45, 45, 255))
        else:
            lay = _text_layer(W, H, text, "Montserrat-Black.ttf", box, (255, 255, 255, 255), (0, 0, 0, 255))
        canvas.alpha_composite(lay)
    # --- arrow / circle / emoji
    if arrow and face_box is not None:
        if land:     # from the text side, pointing at the face
            tip = (face_box[0] - face_box[2] * 0.05, face_box[1] + face_box[3] * 0.55)
            frm = (tip[0] - W * 0.17, tip[1] + H * 0.20)
        else:        # from below the face, pointing up at it
            tip = (face_box[0] + face_box[2] * 0.15, face_box[1] + face_box[3] * 1.02)
            frm = (tip[0] - W * 0.22, tip[1] + H * 0.10)
        canvas.alpha_composite(_arrow(W, H, tip, scale=H / 720.0 if land else W / 1080.0, frm=frm))
    if circle and face_box is not None:
        r = int(max(face_box[2], face_box[3]) * 0.85)
        canvas.alpha_composite(_ring(W, H, (int(face_box[0] + face_box[2] / 2), int(face_box[1] + face_box[3] / 2)), r))
    if emoji:
        try:
            from .effects import emoji_png
            em = Image.open(emoji_png(emoji)).convert("RGBA")
            es = int(H * (0.26 if land else 0.12))
            em = em.resize((es, es), Image.LANCZOS)
            pos = (int(W * 0.86 - es / 2), int(H * 0.06)) if land else (int(W * 0.78 - es / 2), int(H * 0.05))
            canvas.alpha_composite(em, pos)
        except Exception as e:
            log("emoji skipped: %s" % e)
    return canvas.convert("RGB")


def ai_remix(rgb, text, scene, W, H, people=True, remix=None):
    """The whole thumbnail redrawn by the AI from the real frame (people and text included). PIL image."""
    from PIL import Image
    import io
    fr = Image.fromarray(rgb)
    fr.thumbnail((1536, 1536))
    b = io.BytesIO()
    fr.save(b, "PNG")
    size = "1536x1024" if W > H else ("1024x1536" if H > W else "1024x1024")
    instr = ("Turn this video frame into a top-creator YouTube thumbnail. Keep the same person, recognisable, with an "
             "exaggerated, expressive version of their expression; make them big and sharp with a bright outline. "
             "Saturated colours, dramatic light, a clean bold background%s.%s" % (
                 (" showing " + scene) if scene else "",
                 (" Big bold 3D text that reads exactly: \"%s\"." % text.upper()) if text else " No text."))
    if remix is None:
        from .connect import ai_remix as remix
    im = Image.open(io.BytesIO(remix(b.getvalue(), instr, size=size))).convert("RGB")
    k = max(W / im.width, H / im.height)
    im = im.resize((int(im.width * k) + 1, int(im.height * k) + 1), Image.LANCZOS)
    x, y = (im.width - W) // 2, (im.height - H) // 2
    return im.crop((x, y, x + W, y + H))


def ai_background(scene, W, H, cache_dir, gen=None, people=False):
    """AI-made background scene for this shape (cached per scene + shape). PIL image."""
    from PIL import Image
    import io
    size = "1536x1024" if W > H else ("1024x1536" if H > W else "1024x1024")
    key = hashlib.sha256(("%s|%s|%d" % (scene.strip().lower(), size, people)).encode()).hexdigest()[:16]
    p = os.path.join(cache_dir, "aibg_%s.png" % key)
    if not os.path.exists(p):
        if gen is None:
            from .connect import ai_image as gen
        data = gen(scene, size=size, people=people)
        Image.open(io.BytesIO(data)).convert("RGB").save(p)
    return Image.open(p)


def make(video, t, out_base, text="", styles=("pop", "hype", "clean"), emoji=None, arrow=False, circle=False,
         sizes=((1280, 720), (1080, 1920)), face=None, ai_scene=None, gen=None, remix=None, ai_people=False):
    """Thumbnails for the frame at t. Returns [{style, size, file}] (+ 'note' if the cutout wasn't available)."""
    import cv2
    cap = cv2.VideoCapture(video)
    cap.set(cv2.CAP_PROP_POS_MSEC, float(t) * 1000)
    ok, img = cap.read()
    cap.release()
    if not ok:
        raise ValueError("couldn't read that moment of the video")
    rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    if face is None:
        h0, w0 = rgb.shape[:2]
        aw, ah = 640, int(640 * h0 / w0)
        det = cv2.FaceDetectorYN.create(YUNET, "", (aw, ah), 0.6, 0.3, 5000)
        _, fs = det.detect(cv2.resize(img, (aw, ah)))
        if fs is not None and len(fs):
            f = max(fs, key=lambda r: r[2] * r[3])
            k = w0 / float(aw)
            face = tuple(float(v) * k for v in f[:4])
    mask, note = None, None
    if any(s in ("pop", "hype") for s in styles):
        if face is None:
            note = "no face found in that frame, so the cutout styles use the whole picture"
        else:
            try:
                mask = cutout(rgb, face)
            except Exception as e:
                log("cutout failed: %s" % e)
            if mask is None:
                note = "the person cutout wasn't available (%s), so these use the whole picture" % (_SESS.get("err") or "no clear person")
    out = []
    for st in styles:
        if st not in STYLES:
            continue
        for W, H in sizes:
            ai_bg = None
            if st == "remix":
                try:
                    im = ai_remix(rgb, (text or "").strip()[:60], (ai_scene or "").strip(), W, H, remix=remix)
                except Exception as e:
                    note = str(e)[:200]
                    break
                fn = "%s_%s_%dx%d.jpg" % (out_base, st, W, H)
                im.save(fn, quality=92)
                out.append({"style": st, "size": "%dx%d" % (W, H), "file": fn})
                continue
            if st == "ai":
                if not (ai_scene or "").strip():
                    note = "describe a scene for the AI background (e.g. 'a vault full of gold coins'), then try again"
                    break
                if mask is None:
                    break
                try:
                    ai_bg = ai_background(ai_scene, W, H, os.path.dirname(out_base) or ".", gen, people=ai_people)
                except Exception as e:
                    note = str(e)[:200]
                    break
            im = _compose(rgb, face, mask, W, H, st, (text or "").strip()[:60], emoji, arrow, circle, ai_bg)
            fn = "%s_%s_%dx%d.jpg" % (out_base, st, W, H)
            im.save(fn, quality=92)
            out.append({"style": st, "size": "%dx%d" % (W, H), "file": fn})
    return {"files": out, "note": note, "cutout": mask is not None}

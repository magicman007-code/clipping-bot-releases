"""Streamer lore: the names, nicknames, catchphrases and running jokes a community knows.

One profile per streamer in <work_root>/_lore/<slug>.json:
  {"streamer": "Orangie", "names": ["Orangie", "Cupsey"], "aliases": {"Orangie": ["orange", "the orange guy"]},
   "phrases": ["dev sold", "we're so back"], "notes": "...", "projects": [dirs it learned from]}

Used for:
  * transcription hotwords  -> names spelled right in captions/headlines
  * moment scoring          -> a callback to a running joke or a known person scores higher ("lore" tag)
  * prompt clipping         -> "when the orange guy shows up" also searches "Orangie"
learn() suggests names/phrases from the streamer's past projects; the user confirms them in the editor.
Nothing here leaves the computer.
"""
import json
import os
import re
from collections import Counter, defaultdict

from .common import load_config, save_json

COMMON = set("""i im i'm the a an and or but so if of to in on at for with from by as is are was were be been it its this that
these those he she they them his her their him me my we us our you your yeah yes no oh okay ok like just really
right well now then there here what when where who why how not do does did done have has had get got go going
gonna wanna gotta one two three four five six seven eight nine ten first last next all any some every much many more
most very too also only even still back up down out over again chat guys bro dude man god thank thanks please
today tomorrow yesterday monday tuesday wednesday thursday friday saturday sunday january february march april may
june july august september october november december english american youtube twitch kick tiktok instagram twitter
discord google iphone""".split())
FUNC = set("""a an the and or but so if of to in on at for with from by as into onto about than then that this these those
it its is are was were be been am i me my we our you your he him his she her they them their there here what which who
when where how why not no do does did have has had will would can could should just like very really also too
because while if until up down out over off again some any each every all both few more most other such own same
one two three four five six seven eight nine ten hundred thousand million billion first last next much many""".split())
NUMBERISH = re.compile(r"\d|^(?:hundred|thousand|million|billion|dollars?|bucks|percent)$")
FILLER_PHRASES = {"you know", "i mean", "kind of", "sort of", "a lot", "going to", "want to", "i think", "i don't",
                  "it's like", "and then", "oh my", "my god", "oh my god", "let's go", "thank you", "you guys"}


def lore_dir():
    d = os.path.join(load_config()["work_root"], "_lore")
    os.makedirs(d, exist_ok=True)
    return d


def slug(name):
    return re.sub(r"[^a-z0-9]+", "_", (name or "").lower()).strip("_") or "streamer"


def list_profiles():
    out = []
    for f in sorted(os.listdir(lore_dir())):
        if f.endswith(".json"):
            try:
                p = json.load(open(os.path.join(lore_dir(), f), encoding="utf-8"))
                out.append({"streamer": p.get("streamer") or f[:-5], "names": len(p.get("names", [])),
                            "phrases": len(p.get("phrases", [])), "projects": len(p.get("projects", []))})
            except Exception:
                continue
    return out


def load(name):
    if not name:
        return None
    p = os.path.join(lore_dir(), slug(name) + ".json")
    if not os.path.exists(p):
        return None
    try:
        return clean(json.load(open(p, encoding="utf-8")))
    except Exception:
        return None


def clean(p):
    p = dict(p or {})
    p["streamer"] = str(p.get("streamer") or "").strip()[:60]

    def lst(x, n=300):
        seen, out = set(), []
        for v in x or []:
            v = re.sub(r"\s+", " ", str(v)).strip()[:60]
            if v and v.lower() not in seen:
                seen.add(v.lower())
                out.append(v)
        return out[:n]
    p["names"] = lst(p.get("names"))
    p["phrases"] = lst(p.get("phrases"))
    al = {}
    for k, v in (p.get("aliases") or {}).items():
        k = str(k).strip()[:60]
        if k:
            al[k] = lst(v if isinstance(v, list) else [v], 20)
    p["aliases"] = al
    p["notes"] = str(p.get("notes") or "")[:4000]
    p["projects"] = lst(p.get("projects"), 500)
    return p


def save(p):
    p = clean(p)
    if not p["streamer"]:
        raise ValueError("give the streamer a name")
    path = os.path.join(lore_dir(), slug(p["streamer"]) + ".json")
    save_json(path, p)
    return p


# ------------------------------------------------------------------ use
def vocab(p):
    """Hotwords for transcription: names + aliases' canonical spellings + short catchphrases."""
    if not p:
        return []
    v = list(p.get("names", [])) + list((p.get("aliases") or {}).keys())
    v += [x for x in p.get("phrases", []) if len(x.split()) <= 3]
    return v[:60]


def terms(p):
    """Regex alternatives the moment finder counts as lore hits."""
    if not p:
        return []
    out = []
    for t in list(p.get("names", [])) + list(p.get("phrases", [])) + \
            [a for v in (p.get("aliases") or {}).values() for a in v]:
        t = t.strip()
        if len(t) >= 3:
            out.append(re.escape(t).replace("\\ ", r"\s+"))
    return out


def aliases(p):
    """{canonical: [other ways people say it]} for prompt search."""
    if not p:
        return {}
    al = {k: list(v) for k, v in (p.get("aliases") or {}).items()}
    for k, v in list(al.items()):
        for a in v:                      # "the orange guy" in a prompt should also search "Orangie"
            al.setdefault(a, []).append(k)
    return al


# ------------------------------------------------------------------ learn
def _project_words(d):
    p = os.path.join(d, "words.json")
    if not os.path.exists(p):
        return []
    try:
        return json.load(open(p))
    except Exception:
        return []


def learn(project_dirs, known=None, max_names=25, max_phrases=25):
    """Suggest names and recurring phrases from a streamer's projects.
    Names: words said capitalised mid-sentence again and again (whisper capitalises proper nouns).
    Phrases: 2-4 word sequences that come back across different streams (running jokes, catchphrases)."""
    known = {k.lower() for k in (known or [])}
    cap, low, cap_proj = Counter(), Counter(), defaultdict(set)
    grams, gram_proj, unig = Counter(), defaultdict(set), Counter()
    nproj = 0
    for d in project_dirs:
        ws = _project_words(d)
        if not ws:
            continue
        nproj += 1
        toks = [w[2] for w in ws]
        prev_end = True
        for t in toks:
            core = re.sub(r"^[^\w$]+|[^\w']+$", "", t)
            if core:
                if not prev_end and core[0].isupper() and not core.isupper() and len(core) > 2:
                    cap[core] += 1
                    cap_proj[core].add(d)
                low[core.lower()] += 1
            prev_end = bool(re.search(r"[.!?]$", t))
        norm = [re.sub(r"[^\w']+", "", t.lower()) for t in toks]
        norm = [t for t in norm if t]
        unig.update(norm)
        for n in (2, 3, 4):
            for i in range(len(norm) - n + 1):
                g = norm[i:i + n]
                # catchphrase shape: starts and ends on a content word, mostly content, no amounts/numbers
                if g[0] in FUNC or g[-1] in FUNC or any(NUMBERISH.search(x) for x in g):
                    continue
                if sum(1 for x in g if x in COMMON or x in FUNC) > n // 2:
                    continue
                s = " ".join(g)
                if s in FILLER_PHRASES:
                    continue
                grams[s] += 1
                gram_proj[s].add(d)
    names = []
    for w, c in cap.most_common():
        lw = w.lower()
        if lw in COMMON or lw in known:
            continue
        # a real name is (almost) always capitalised; "Okay"/"Crazy" mid-sentence are not
        if c < 3 or c < 0.7 * low[lw]:
            continue
        spread = len(cap_proj[w])
        names.append({"text": w, "count": c, "streams": spread})
    names.sort(key=lambda x: (-x["streams"], -x["count"]))
    phrases = []
    min_streams = 2 if nproj >= 2 else 1
    for g, c in grams.most_common(4000):
        if g in known or c < 3 or len(gram_proj[g]) < min_streams:
            continue
        # a catchphrase's words stick together: most uses of its rarest word are inside the phrase
        if c < 0.4 * min(unig[w] for w in g.split()):
            continue
        if any(g in p["text"] and p["count"] >= c for p in phrases):      # keep the longest form only
            continue
        phrases = [p for p in phrases if not (p["text"] in g and p["count"] <= c)]
        phrases.append({"text": g, "count": c, "streams": len(gram_proj[g])})
    phrases.sort(key=lambda x: (-x["streams"], -x["count"]))
    return {"names": names[:max_names], "phrases": phrases[:max_phrases], "projects_read": nproj}

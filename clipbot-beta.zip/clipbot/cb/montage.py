"""Stitch finished clips into one compilation (single encode, consistent loudness)."""
import os

from .common import FONT_DIR, ffmpeg, fpath, probe
from .render import audio_chain, esc, fmt, measure_loudness


def build_montage(specs, out, workdir, intro=None, outro=None, labels=True, label_secs=2.5):
    """specs: [{"file": path, "label": "VOD 2 · Cop finds a gun"}]. Every part is re-normalised to
    1080x1920/30fps/48k inside one filter graph, so mismatched sources never break the concat."""
    os.makedirs(workdir, exist_ok=True)
    parts = ([{"file": intro}] if intro else []) + list(specs) + ([{"file": outro}] if outro else [])
    ins, fc, cat, t, events = [], [], "", 0.0, []
    for i, s in enumerate(parts):
        p = probe(s["file"])
        ins += ["-i", s["file"]]
        fc.append("[%d:v]fps=30,scale=1080:1920:force_original_aspect_ratio=decrease,"
                  "pad=1080:1920:(ow-iw)/2:(oh-ih)/2,setsar=1,format=yuv420p[v%d]" % (i, i))
        if p["has_audio"]:
            fc.append("[%d:a]aresample=48000,aformat=channel_layouts=stereo[a%d]" % (i, i))
        else:
            fc.append("anullsrc=r=48000:cl=stereo,atrim=0:%.3f[a%d]" % (p["duration"], i))
        cat += "[v%d][a%d]" % (i, i)
        if labels and s.get("label"):
            events.append("Dialogue: 0,%s,%s,Tag,,0,0,0,,%s" % (fmt(t), fmt(t + label_secs), esc(s["label"].upper())))
        t += p["duration"]
    ass = os.path.join(workdir, "labels.ass")
    open(ass, "w").write(
        "[Script Info]\nScriptType: v4.00+\nPlayResX: 1080\nPlayResY: 1920\n[V4+ Styles]\n"
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, "
        "Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, "
        "MarginV, Encoding\nStyle: Tag,Montserrat Black,36,&H00FFFFFF,&H00FFFFFF,&H00000000,&H99000000,0,0,0,0,100,100,0,0,"
        "3,10,0,7,40,40,330,1\n[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"
        + "\n".join(events) + "\n")
    fc.append(cat + "concat=n=%d:v=1:a=1[vc][ac]" % len(parts))
    fc.append("[vc]ass=filename=%s:fontsdir=%s[vout]" % (fpath(ass), fpath(FONT_DIR)))
    # pass 1: plain concat to measure loudness, pass 2: final with linear loudnorm
    tmp = os.path.join(workdir, "montage_tmp.mp4")
    ffmpeg(ins + ["-filter_complex", ";".join(fc), "-map", "[vout]", "-map", "[ac]", "-c:v", "libx264",
                  "-preset", "veryfast", "-crf", "16", "-c:a", "aac", "-b:a", "256k", tmp], timeout=7200)
    meas = measure_loudness(tmp, pre="anull")
    chain = audio_chain(meas, t, pre="anull")
    ffmpeg(["-i", tmp, "-filter_complex", chain, "-map", "0:v", "-map", "[aout]", "-c:v", "copy",
            "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", out], timeout=3600)
    os.remove(tmp)
    return {"file": out, "parts": len(parts), "duration": round(t, 2)}

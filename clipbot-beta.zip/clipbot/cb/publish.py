"""Post a finished clip straight to Discord or Telegram.

Both are "paste one thing, post the clip" - no app review, no OAuth:
  Discord   a channel Webhook URL (Server Settings -> Integrations -> Webhooks -> New Webhook -> Copy URL)
  Telegram  a bot token from @BotFather + the chat/channel id to post to (add the bot to the channel as admin)

The clip is uploaded directly from the user's computer; nothing is stored by Clipbot.
"""
import json
import os
import urllib.error
import urllib.request
import uuid

MB = 1 << 20


def _cfg(sect):
    from .connect import get
    return get().get(sect) or {}


def _multipart(fields, file_field=None, file_path=None, file_name=None, file_ctype="video/mp4"):
    """Build a multipart/form-data body. fields: dict of text parts. Optional one file part."""
    boundary = "----clipbot" + uuid.uuid4().hex
    nl = b"\r\n"
    out = []
    for k, v in fields.items():
        out.append(b"--" + boundary.encode())
        out.append(('Content-Disposition: form-data; name="%s"' % k).encode())
        out.append(b"")
        out.append(str(v).encode("utf-8"))
    if file_field and file_path:
        with open(file_path, "rb") as f:
            data = f.read()
        out.append(b"--" + boundary.encode())
        out.append(('Content-Disposition: form-data; name="%s"; filename="%s"'
                    % (file_field, file_name or os.path.basename(file_path))).encode())
        out.append(("Content-Type: %s" % file_ctype).encode())
        out.append(b"")
        out.append(data)
    out.append(b"--" + boundary.encode() + b"--")
    out.append(b"")
    return "multipart/form-data; boundary=" + boundary, nl.join(out)


def _post_multipart(url, fields, file_field, file_path, timeout=600, file_name=None):
    ctype, body = _multipart(fields, file_field, file_path, file_name=file_name)
    req = urllib.request.Request(url, data=body, headers={"Content-Type": ctype,
                                                          "Content-Length": str(len(body)), "User-Agent": "Clipbot"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read()
            return r.status, (json.loads(raw) if raw and raw[:1] in (b"{", b"[") else {})
    except urllib.error.HTTPError as e:
        raw = e.read() or b""
        try:
            j = json.loads(raw)
        except ValueError:
            j = {"message": raw.decode("utf-8", "replace")[:200]}
        return e.code, j


# ================================================================== Discord
def discord_connected():
    return bool(_cfg("discord").get("webhook"))


def discord_post(path, caption="", webhook=None):
    """Post a clip to a Discord channel via its webhook. Returns {ok, url}."""
    if not os.path.isfile(path):
        raise ValueError("render the clip first")
    hook = webhook or _cfg("discord").get("webhook")
    if not hook:
        raise ValueError("add your Discord webhook first (Settings -> Discord)")
    if os.path.getsize(path) > 25 * MB:
        raise ValueError("Discord takes files up to 25 MB on most servers - this clip is bigger; "
                         "post a shorter clip or a lower-quality render")
    sep = "&" if "?" in hook else "?"
    code, j = _post_multipart(hook + sep + "wait=true", {"content": (caption or "")[:2000]},
                              "files[0]", path)
    if code >= 400:
        raise RuntimeError("Discord: %s" % (j.get("message") or code))
    url = None
    if j.get("id") and j.get("channel_id"):
        url = "https://discord.com/channels/@me/%s/%s" % (j["channel_id"], j["id"])
    return {"ok": True, "id": j.get("id"), "url": url}


# ================================================================== Telegram
TG_API = "https://api.telegram.org"


def telegram_connected():
    c = _cfg("telegram")
    return bool(c.get("bot_token") and c.get("chat_id"))


def telegram_post(path, caption="", api=None):
    """Post a clip to a Telegram chat/channel with the user's bot. Returns {ok, message_id}."""
    if not os.path.isfile(path):
        raise ValueError("render the clip first")
    c = _cfg("telegram")
    tok, chat = c.get("bot_token"), c.get("chat_id")
    if not (tok and chat):
        raise ValueError("add your Telegram bot token and chat id first (Settings -> Telegram)")
    if os.path.getsize(path) > 50 * MB:
        raise ValueError("a Telegram bot can send videos up to 50 MB - post a shorter clip")
    url = "%s/bot%s/sendVideo" % (api or TG_API, tok)
    code, j = _post_multipart(url, {"chat_id": str(chat), "caption": (caption or "")[:1024],
                                    "supports_streaming": "true"}, "video", path)
    if not j.get("ok"):
        raise RuntimeError("Telegram: %s" % (j.get("description") or code))
    r = j.get("result") or {}
    return {"ok": True, "message_id": r.get("message_id")}

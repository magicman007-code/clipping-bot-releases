"""In-app updates: friends click "Update" (or run `clipbot update`) and get your latest build.

You publish two files anywhere with a stable download link (Dropbox, Google Drive, GitHub releases, any web host):
  latest.json   {"version": "1.6.0", "zip": "<link to clipbot-beta.zip>", "sha256": "<of the zip>", "notes": "..."}
  the zip       built by `clipbot release` (which also writes latest.json for you)
Their config.json has "update_url": "<link to latest.json>" (baked into the zip by `clipbot release --url`).

Applying an update: download -> verify SHA-256 -> unpack to a temp folder -> copy app files over the install.
Kept as-is: .venv, their config values (new keys from the update are added), state, ledger, uploaded banners,
stickers and fonts, projects (those live in ~/Clipbot anyway). New Python packages are installed if the update
lists more than they have. The previous version is kept in _previous/ so a bad update can be rolled back.
"""
import hashlib
import json
import re
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile

from .common import ROOT, load_config, log, save_json

KEEP = {".venv", ".clipbot_python", "config.json", "state.json", "ledger.jsonl", "_previous", "__pycache__",
        ".pytest_cache"}
KEEP_DIRS_CONTENT = {os.path.join("assets", "banners"), os.path.join("assets", "stickers")}
VERSION_FILE = os.path.join(ROOT, "VERSION")


def current_version():
    try:
        return open(VERSION_FILE).read().strip()
    except OSError:
        return "0.0.0"


def _v(s):
    out = []
    for p in str(s).strip().lstrip("v").split("."):
        try:
            out.append(int("".join(ch for ch in p if ch.isdigit()) or 0))
        except ValueError:
            out.append(0)
    return tuple(out + [0] * (3 - len(out)))


def _get(url, dest=None, timeout=60):
    """Download text (dest=None) or a file. Share links (Dropbox/Drive) are turned into direct downloads."""
    import urllib.request
    from .fetch import direct_link
    u = direct_link(url) or url
    req = urllib.request.Request(u, headers={"User-Agent": "clipbot-updater", "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        if dest is None:
            return r.read(1 << 20).decode("utf-8", "replace")
        with open(dest, "wb") as f:
            shutil.copyfileobj(r, f, 1 << 20)
    return dest


def check(url=None):
    """-> {current, latest, available, notes} (or {error})."""
    url = url or load_config().get("update_url")
    cur = current_version()
    if not url:
        return {"current": cur, "available": False, "error": "no update link set (config.json \"update_url\")"}
    try:
        m = json.loads(_get(url))
    except Exception as e:
        return {"current": cur, "available": False, "error": "couldn't read the update info: %s" % str(e)[:160]}
    if not m.get("zip") or not m.get("version"):
        return {"current": cur, "available": False, "error": "update info is missing 'version' or 'zip'"}
    return {"current": cur, "latest": m["version"], "available": _v(m["version"]) > _v(cur),
            "notes": m.get("notes", ""), "zip": m["zip"], "sha256": m.get("sha256")}


def _sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def _merge_config(new_cfg_path):
    """Add keys the new version introduces; never overwrite the user's own values."""
    mine_p = os.path.join(ROOT, "config.json")
    try:
        mine = json.load(open(mine_p))
        new = json.load(open(new_cfg_path))
    except Exception:
        return

    def merge(a, b):
        for k, v in b.items():
            if k not in a:
                a[k] = v
            elif isinstance(a[k], dict) and isinstance(v, dict):
                merge(a[k], v)
    merge(mine, new)
    save_json(mine_p, mine, indent=2)


def _install_deps(app):
    req = os.path.join(app, "requirements.txt")
    if not os.path.exists(req):
        return
    pkgs = [l.split("#")[0].strip() for l in open(req) if l.split("#")[0].strip()]
    pkgs = [p for p in pkgs if not p.lower().startswith("faster-whisper")]
    try:
        subprocess.run([sys.executable, "-m", "pip", "install", "-q"] + pkgs, check=False, timeout=1800)
    except Exception as e:
        log("package update skipped: %s" % e)


def apply(info=None, url=None):
    """Download + install the latest version. Returns {ok, version, note}."""
    info = info or check(url)
    if info.get("error"):
        return {"ok": False, "error": info["error"]}
    if not info.get("available"):
        return {"ok": True, "version": info["current"], "note": "already up to date"}
    tmpd = tempfile.mkdtemp(prefix="clipbot_update_")
    try:
        z = _get(info["zip"], os.path.join(tmpd, "update.zip"), timeout=600)
        if info.get("sha256") and _sha(z) != info["sha256"].lower():
            # a CDN can still hand out the previous zip for a few minutes after a release: ask for a fresh copy
            fresh = info["zip"] + ("&" if "?" in info["zip"] else "?") + "v=" + info["sha256"][:12]
            z = _get(fresh, os.path.join(tmpd, "update.zip"), timeout=600)
            if _sha(z) != info["sha256"].lower():
                return {"ok": False, "error": "the download didn't match the release (it may still be publishing) - "
                                              "try again in a few minutes"}
        with zipfile.ZipFile(z) as zf:
            for n in zf.namelist():                       # refuse paths that escape the folder
                if n.startswith("/") or ".." in n.replace("\\", "/").split("/"):
                    return {"ok": False, "error": "update zip has unsafe paths - not installed"}
            zf.extractall(os.path.join(tmpd, "x"))
            for zi in zf.infolist():                       # zipfile drops Unix permissions: restore +x
                mode = (zi.external_attr >> 16) & 0o777
                if mode:
                    try:
                        os.chmod(os.path.join(tmpd, "x", zi.filename), mode)
                    except OSError:
                        pass
        x = os.path.join(tmpd, "x")
        tops = [d for d in os.listdir(x) if not d.startswith("__MACOSX")]
        app = os.path.join(x, tops[0]) if len(tops) == 1 and os.path.isdir(os.path.join(x, tops[0])) else x
        if not os.path.exists(os.path.join(app, "clipbot.py")):
            return {"ok": False, "error": "that zip isn't a Clipbot build"}
        kept = _keep_changed()                                 # files the user edited: copied out first
        prev = os.path.join(ROOT, "_previous")                 # rollback copy of the current app files
        shutil.rmtree(prev, ignore_errors=True)
        os.makedirs(prev)
        for name in os.listdir(ROOT):
            if name in KEEP:
                continue
            src = os.path.join(ROOT, name)
            (shutil.copytree if os.path.isdir(src) else shutil.copy2)(src, os.path.join(prev, name))
        for dirpath, dirs, files in os.walk(app):
            rel = os.path.relpath(dirpath, app)
            dirs[:] = [d for d in dirs if d not in KEEP and os.path.normpath(os.path.join(rel, d)) not in KEEP_DIRS_CONTENT]
            os.makedirs(os.path.join(ROOT, rel), exist_ok=True)
            for f in files:
                if rel == "." and f in KEEP:
                    continue
                shutil.copy2(os.path.join(dirpath, f), os.path.join(ROOT, rel, f))
        for f in ("clipbot", "install.sh", "start.sh"):         # launchers must stay runnable on Mac/Linux
            fp = os.path.join(ROOT, f)
            if os.path.exists(fp) and os.name != "nt":
                os.chmod(fp, 0o755)
        _merge_config(os.path.join(app, "config.json"))
        _install_deps(app)
        return {"ok": True, "version": current_version(), "note": "updated - restart Clipbot to use it",
                "notes": info.get("notes", ""), "kept": kept}
    finally:
        shutil.rmtree(tmpd, ignore_errors=True)


def _keep_changed():
    """App files the user changed since they were installed (compared with files.json) are copied to
    <work_root>/_my_changes/<version>/ before the update replaces them. Returns {"dir", "files"} or None."""
    try:
        shipped = json.load(open(os.path.join(ROOT, "files.json")))
    except Exception:
        return None
    changed = []
    for rel, h in shipped.items():
        p = os.path.join(ROOT, *rel.split("/"))
        try:
            if os.path.isfile(p) and _sha(p) != h:
                changed.append(rel)
        except OSError:
            continue
    if not changed:
        return None
    dest = os.path.join(load_config()["work_root"], "_my_changes", current_version())
    for rel in changed:
        d = os.path.join(dest, *rel.split("/"))
        os.makedirs(os.path.dirname(d), exist_ok=True)
        shutil.copy2(os.path.join(ROOT, *rel.split("/")), d)
    return {"dir": dest, "files": changed}


def rollback():
    prev = os.path.join(ROOT, "_previous")
    if not os.path.isdir(prev):
        return {"ok": False, "error": "no previous version saved"}
    for dirpath, dirs, files in os.walk(prev):
        rel = os.path.relpath(dirpath, prev)
        os.makedirs(os.path.join(ROOT, rel), exist_ok=True)
        for f in files:
            shutil.copy2(os.path.join(dirpath, f), os.path.join(ROOT, rel, f))
    return {"ok": True, "version": current_version(), "note": "rolled back - restart Clipbot"}


def release(out_dir, version, url=None, notes="", feedback_url=None):
    """Build <out_dir>/clipbot-beta.zip + latest.json from this folder (what you run before sharing).
    url: the link where latest.json will live - baked into the zip's config.json as update_url."""
    out_dir = os.path.abspath(os.path.expanduser(out_dir))
    os.makedirs(out_dir, exist_ok=True)
    open(VERSION_FILE, "w").write(version + "\n")
    zp = os.path.join(out_dir, "clipbot-beta.zip")
    skip_top = KEEP | {"_previous", "ledger.jsonl", "release", ".git"}
    shipped = {}                       # files.json: fingerprint of every app file, so the next update can tell
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as zf:   # which files the user changed (and keep them)
        for dirpath, dirs, files in os.walk(ROOT):
            rel = os.path.relpath(dirpath, ROOT)
            dirs[:] = [d for d in dirs if not (rel == "." and d in skip_top) and d not in ("__pycache__", ".pytest_cache")
                       and os.path.normpath(os.path.join(rel, d)) not in KEEP_DIRS_CONTENT]
            for f in files:
                if rel == "." and f in ("ledger.jsonl", ".clipbot_python"):
                    continue
                arc = os.path.join("clipbot", rel, f) if rel != "." else os.path.join("clipbot", f)
                full = os.path.join(dirpath, f)
                if rel == "." and f == "config.json":
                    cfg = json.load(open(full))
                    if url:
                        cfg["update_url"] = url
                    if feedback_url:
                        cfg["feedback_url"] = feedback_url
                    zf.writestr(arc, json.dumps(cfg, indent=2))
                elif rel == "." and f == "state.json":
                    zf.writestr(arc, json.dumps({"seen_video_ids": [], "pending": {}, "failed": {}}, indent=1))
                elif rel == "." and f == "files.json":
                    continue
                else:
                    zf.write(full, arc)
                    shipped[os.path.relpath(full, ROOT).replace(os.sep, "/")] = _sha(full)
        zf.writestr(os.path.join("clipbot", "files.json"), json.dumps(shipped, indent=0, sort_keys=True))
        for d in KEEP_DIRS_CONTENT:
            zf.writestr(os.path.join("clipbot", d, ".keep"), "")
    manifest = {"version": version, "zip": "REPLACE WITH THE SHARE LINK OF clipbot-beta.zip", "sha256": _sha(zp),
                "notes": notes}
    mp = os.path.join(out_dir, "latest.json")
    old = {}
    if os.path.exists(mp):
        try:
            old = json.load(open(mp))
        except Exception:
            old = {}
    if old.get("zip", "").startswith("http"):
        manifest["zip"] = old["zip"]          # same Dropbox/Drive file replaced -> same link keeps working
    save_json(mp, manifest, indent=2)
    return {"zip": zp, "manifest": mp, "version": version, "sha256": manifest["sha256"]}


def publish_github(version, repo, notes="", gh=None, feedback_url=None, workdir=None, remote=None, git="git"):
    """Publish an update by committing clipbot-beta.zip + latest.json to a public GitHub repo (e.g.
    yourname/clipbot-releases). GitHub serves them at links that never change:
      update file  https://raw.githubusercontent.com/<repo>/main/latest.json   (baked into the app)
      download     https://github.com/<repo>/raw/main/clipbot-beta.zip
    Needs git with GitHub access on this computer (easiest: install GitHub's `gh` and run `gh auth login`,
    then `gh auth setup-git`). workdir/remote are for tests."""
    import shutil as _sh
    if not re.fullmatch(r"[\w.-]+/[\w.-]+", repo or ""):
        raise ValueError("repo must look like yourname/clipbot-releases")
    if not _sh.which(git):
        raise RuntimeError("git isn't installed. Mac: xcode-select --install   Windows: winget install Git.Git")
    url = "https://raw.githubusercontent.com/%s/main/latest.json" % repo
    zip_url = "https://github.com/%s/raw/main/clipbot-beta.zip" % repo
    out = tempfile.mkdtemp(prefix="clipbot_release_")
    r = release(out, version, url=url, notes=notes, feedback_url=feedback_url)
    m = json.load(open(r["manifest"]))
    m["zip"] = zip_url
    save_json(r["manifest"], m, indent=2)
    wd = workdir or os.path.join(os.path.expanduser("~"), ".clipbot_publish", repo.replace("/", "__"))
    rem = remote or "https://github.com/%s.git" % repo

    def g(*a, cwd=wd):
        p = subprocess.run([git] + list(a), cwd=cwd, capture_output=True, text=True)
        if p.returncode != 0:
            err = (p.stderr or p.stdout).strip()[-400:]
            if "Authentication" in err or "could not read Username" in err or "403" in err:
                err += "\n-> give git access to GitHub: install gh, then run 'gh auth login' and 'gh auth setup-git'"
            if "not found" in err.lower() or "does not exist" in err.lower():
                err += "\n-> create the repo first (public): https://github.com/new?name=%s&visibility=public" % repo.split("/")[1]
            raise RuntimeError("publishing failed: git %s: %s" % (a[0], err))
        return p.stdout
    if not os.path.isdir(os.path.join(wd, ".git")):
        os.makedirs(os.path.dirname(wd), exist_ok=True)
        g("clone", rem, wd, cwd=os.path.dirname(wd))
    else:
        try:
            g("pull", "--ff-only")
        except RuntimeError:
            pass                                     # empty repo / first publish
    shutil.copy2(r["zip"], os.path.join(wd, "clipbot-beta.zip"))
    shutil.copy2(r["manifest"], os.path.join(wd, "latest.json"))
    g("add", "clipbot-beta.zip", "latest.json")
    g("-c", "user.name=Clipbot release", "-c", "user.email=clipbot@users.noreply.github.com",
      "commit", "-m", "Clipbot %s%s" % (version, (" - " + notes) if notes else ""))
    g("branch", "-M", "main")
    g("push", "-u", "origin", "main")
    return {"version": version, "download": zip_url, "update_url": url, "sha256": m["sha256"],
            "page": "https://github.com/%s" % repo}

"""Brand-safety review flags for a clip's transcript.

Borrowed idea from the way good clip pickers warn before posting: a flag never changes a clip's
score or whether it's made — it just tells the clipper "check this before you send it to a brand
campaign or a monetised page." Profanity may need a bleep; sexual content is skipped by brand-safe
pages. Purely advisory, computed from the words already transcribed, nothing uploaded.

review_flags(text) -> list[{"flag","label","hint"}]  (empty when the clip looks clean)
"""
import re

# Conservative patterns: aim for "worth a look", not to catch every word. False positives nag; keep them rare.
_PROFANITY = re.compile(
    r"\b(f+u+c+k\w*|motherf\w*|sh+i+t+\w*|b+i+t+c+h\w*|asshole\w*|d+i+c+k(?:head|face)?\b|"
    r"c+u+n+t\w*|bastard\w*|pussy|cock\w*)\b", re.I)
_SEXUAL = re.compile(
    r"\b(strip ?club\w*|stripper\w*|naked|nude\w*|boob\w*|titt(?:y|ies)|porn\w*|horny|"
    r"twerk\w*|lap ?dance\w*|only ?fans|sex(?:y|ual)?)\b", re.I)
# A slur guard (kept deliberately tiny and non-enumerated here): flags the clip without naming anything.
_SLUR = re.compile(r"\b(n[i1]gg\w*|f[a4]gg?\w*|r[e3]tard\w*)\b", re.I)


def review_flags(text):
    text = text or ""
    out = []
    if _SLUR.search(text):
        out.append({"flag": "slur", "label": "Slur",
                    "hint": "A slur may be in this clip. Most campaigns and platforms reject these — review before posting."})
    if _PROFANITY.search(text):
        out.append({"flag": "language", "label": "Language",
                    "hint": "Strong language here — a brand campaign may want it bleeped."})
    if _SEXUAL.search(text):
        out.append({"flag": "sensitive", "label": "Sensitive",
                    "hint": "Sexual or adult wording — brand-safe pages usually skip these."})
    return out


def flag_labels(flags):
    """Short labels for a list of flags (for compact UI)."""
    return [f["label"] for f in (flags or [])]

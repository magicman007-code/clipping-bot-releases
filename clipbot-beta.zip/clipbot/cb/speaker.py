"""Face tracking + active-speaker detection (no extra models).

For every tracked face we measure motion in the MOUTH region (from YuNet's mouth-corner
landmarks) minus motion in the EYE region (cancels head bobbing), and compare it with the
audio envelope. The face whose mouth moves while there is voice - and moves in sync with
it - is the speaker. This is the classic audio-visual synchrony idea behind SyncNet-style
detectors, done with signal processing instead of a neural net, so it runs on CPU in
seconds and needs no downloads.

analyze(clip) -> samples [(t, [(cx, cy, w, h, score, track_id), ...])], active [track_id|'both'|None]
"""
import os
import wave

import numpy as np

from .common import YUNET, ffmpeg


def _roi(gray, cx, cy, w, h, size=(24, 16)):
    import cv2
    x0, y0 = int(max(0, cx - w / 2)), int(max(0, cy - h / 2))
    x1, y1 = int(min(gray.shape[1], cx + w / 2)), int(min(gray.shape[0], cy + h / 2))
    if x1 - x0 < 4 or y1 - y0 < 4:
        return None
    return cv2.resize(gray[y0:y1, x0:x1], size, interpolation=cv2.INTER_AREA).astype(np.float32)


LAST_INFO = {}


def analyze(clip, w0, h0, workdir, fps=10):
    """Who is talking when. Uses the neural active-speaker model when it's installed (much more reliable on real
    footage: crosstalk, laughing listeners, noisy IRL audio) and this module's signal-processing method otherwise."""
    from . import asd
    if asd.available():
        try:
            samples, active, info = asd.analyze(clip, w0, h0, workdir, fps)
            LAST_INFO.clear()
            LAST_INFO.update(info)
            return samples, active
        except Exception as e:                   # never lose a clip over the speaker model
            from .common import log
            log("speaker model failed (%s); using the simple method" % e)
    LAST_INFO.clear()
    LAST_INFO.update({"method": "mouth-motion"})
    return analyze_simple(clip, w0, h0, workdir, fps)


def analyze_simple(clip, w0, h0, workdir, fps=10):
    import cv2
    aw = 960
    ah = int(round(aw * h0 / float(w0)))
    k = w0 / float(aw)
    det = cv2.FaceDetectorYN.create(YUNET, "", (aw, ah), 0.6, 0.3, 5000)
    cap = cv2.VideoCapture(clip)
    vfps = cap.get(cv2.CAP_PROP_FPS) or 30
    step = max(1, int(round(vfps / fps)))
    samples, tracks, prev, motion = [], [], {}, {}   # tracks: [[cx, cy, last_i]]
    i = n = 0
    while cap.grab():
        if i % step == 0:
            ok, img = cap.retrieve()
            if not ok:
                break
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            _, f = det.detect(cv2.resize(img, (aw, ah)))
            faces = []
            for r in (f if f is not None else []):
                x, y, fw, fh = (r[:4] * k).tolist()
                cx, cy = x + fw / 2, y + fh / 2
                lm = (r[4:14] * k).reshape(5, 2)           # r-eye, l-eye, nose, r-mouth, l-mouth
                # --- track association (nearest previous centre, gated)
                best, bd = None, 0.09 * w0
                for tid, tr in enumerate(tracks):
                    d = np.hypot(tr[0] - cx, tr[1] - cy)
                    if d < bd and tr[2] != n:
                        best, bd = tid, d
                if best is None:
                    tracks.append([cx, cy, n])
                    best = len(tracks) - 1
                else:
                    tracks[best][:] = [cx, cy, n]
                # --- mouth vs eye motion
                mc = (lm[3] + lm[4]) / 2
                mw = max(8.0, float(np.linalg.norm(lm[3] - lm[4])))
                ec = (lm[0] + lm[1]) / 2
                ew = max(8.0, float(np.linalg.norm(lm[0] - lm[1])))
                mro = _roi(gray, mc[0], mc[1] + 0.1 * mw, 1.7 * mw, 1.1 * mw)
                ero = _roi(gray, ec[0], ec[1], 1.6 * ew, 0.6 * ew)
                if mro is not None and ero is not None:
                    pm, pe = prev.get(best, (None, None))
                    if pm is not None:
                        m = float(np.abs(mro - pm).mean()) - 0.7 * float(np.abs(ero - pe).mean())
                        motion.setdefault(best, {})[n] = max(0.0, m)
                    prev[best] = (mro, ero)
                faces.append((cx, cy, fw, fh, float(r[14]), best))
            samples.append((i / vfps, faces))
            n += 1
        i += 1
    cap.release()
    env = _audio_env(clip, workdir, fps, len(samples))
    active = _assign(samples, motion, env, fps, h0)
    return samples, active


def _audio_env(clip, workdir, fps, n):
    wav = os.path.join(workdir, "spk16k.wav")
    ffmpeg(["-i", clip, "-vn", "-ac", "1", "-ar", "16000", "-af", "highpass=f=120,lowpass=f=4000", wav])
    with wave.open(wav, "rb") as wf:
        x = np.frombuffer(wf.readframes(wf.getnframes()), dtype=np.int16).astype(np.float32)
    hop = int(16000 / fps)
    m = len(x) // hop
    if m == 0:
        return np.zeros(n)
    e = 20 * np.log10(np.sqrt((x[: m * hop].reshape(m, hop) ** 2).mean(1)) + 1)
    e = np.pad(e, (0, max(0, n - m)))[:n]
    lo, hi = np.percentile(e, 20), np.percentile(e, 95)
    return np.clip((e - lo) / max(1e-3, hi - lo), 0, 1)


def _assign(samples, motion, env, fps, h0, win=1.5, min_turn=1.0):
    """Per-sample speaker decision with hysteresis: a new speaker must dominate for
    `min_turn` seconds before the camera cuts to them (cuts follow turns, not flicker)."""
    n = len(samples)
    tids = sorted(motion)
    if not tids:
        return [None] * n
    T = len(tids)
    M = np.zeros((T, n))
    present = np.zeros((T, n), bool)
    for a, tid in enumerate(tids):
        for j, v in motion[tid].items():
            M[a, j] = v
    for j, (_, fs) in enumerate(samples):
        for f in fs:
            if f[5] in motion and f[3] > 0.05 * h0:
                present[tids.index(f[5]), j] = True
    # normalise each track's motion by its own scale (big faces move more pixels)
    for a in range(T):
        s = np.percentile(M[a][present[a]], 90) if present[a].any() else 1.0
        M[a] /= max(1e-3, s)
    hw = max(1, int(win * fps / 2))
    voiced = env > 0.35
    score = np.zeros((T, n))
    for j in range(n):
        lo, hi = max(0, j - hw), min(n, j + hw + 1)
        e = env[lo:hi]
        for a in range(T):
            if not present[a, j]:
                score[a, j] = -1
                continue
            m = M[a, lo:hi]
            act = float((m * voiced[lo:hi]).mean())
            c = float(np.corrcoef(m, e)[0, 1]) if m.std() > 1e-6 and e.std() > 1e-6 else 0.0
            score[a, j] = act + 0.5 * max(0.0, c)
    raw = []
    for j in range(n):
        live = [a for a in range(T) if score[a, j] >= 0]
        if len(live) < 2:
            raw.append(tids[live[0]] if live else None)
            continue
        live.sort(key=lambda a: -score[a, j])
        s1, s2 = score[live[0], j], score[live[1], j]
        if not voiced[max(0, j - hw):j + hw + 1].any():
            raw.append(None)                       # silence: hold whatever was on screen
        elif s2 > 0.12 and s2 > 0.7 * s1:
            raw.append("both")                     # overlap / both laughing -> split
        else:
            raw.append(tids[live[0]])
    # hysteresis
    # hysteresis, then BACK-DATE each confirmed switch to where the new speaker started
    # (offline, we can look ahead - so the cut lands on the turn, not a second late)
    out, cur, cand, since, cand_start = [], None, None, 0, 0
    need = int(min_turn * fps)
    for j, r in enumerate(raw):
        if r is None or r == cur:
            cand, since = None, 0
        elif r == cand:
            since += 1
            if since >= need:
                cur, cand, since = r, None, 0
                lag = 0                             # centred window already sees onsets early
                for q in range(max(0, cand_start - lag), j):
                    out[q] = cur
        else:
            cand, since, cand_start = r, 1, j
            if cur is None:
                cur = r
        out.append(cur)
    # back-fill the opening before the first decision
    first = next((x for x in out if x is not None), None)
    return [x if x is not None else first for x in out]

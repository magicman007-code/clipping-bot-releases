"""Fonts: the bundled clip-font pack + fonts the user uploads.

Every font is stored as a plain .ttf whose name table is rewritten to ONE display name (e.g. "Poppins ExtraBold"),
so the same name works everywhere: the editor preview (@font-face), libass captions (Fontname) and Pillow
(banners/thumbnails). That is what keeps preview and render identical.

  bundled:  <app>/fonts/            (shipped, OFL/Apache - see fonts/LICENSE.txt)
  uploaded: <work_root>/_fonts/     (survives app updates)
  render:   <work_root>/_fonts_render/  merged copy handed to libass (it takes a single fontsdir)
"""
import os
import re
import shutil

from .common import FONT_DIR

_CACHE = {"sig": None, "fonts": []}


def user_dir():
    from .common import load_config
    d = os.path.join(load_config()["work_root"], "_fonts")
    os.makedirs(d, exist_ok=True)
    return d


def _name(tt, nid):
    for rec in tt["name"].names:
        if rec.nameID == nid:
            try:
                return rec.toUnicode().strip()
            except Exception:
                continue
    return ""


def display_name(tt):
    fam = _name(tt, 16) or _name(tt, 1)
    sub = _name(tt, 17) or _name(tt, 2)
    if sub and sub.lower() not in ("regular", "normal", "book", "roman"):
        if sub.lower() not in fam.lower():
            fam = "%s %s" % (fam, sub)
    return re.sub(r"\s+", " ", fam).strip() or "Custom Font"


def normalize(src, dst_dir, display=None):
    """Any .ttf/.otf/.woff/.woff2 -> <dst_dir>/<Display_Name>.ttf with a single clean family name.
    Raises ValueError for files that aren't usable fonts."""
    from fontTools.ttLib import TTFont
    try:
        tt = TTFont(src, fontNumber=0)
    except Exception as e:
        raise ValueError("not a font file I can read (%s)" % str(e)[:80])
    if "name" not in tt or "cmap" not in tt:
        raise ValueError("font is missing its name/character tables")
    best = tt.getBestCmap() or {}
    if not any(c in best for c in range(0x41, 0x5B)):
        raise ValueError("font has no Latin letters (A-Z), so captions can't use it")
    disp = display or display_name(tt)
    ps = re.sub(r"[^A-Za-z0-9-]", "", disp.replace(" ", "-"))[:60] or "CustomFont"
    name = tt["name"]
    for nid in (16, 17, 21, 22):
        name.removeNames(nameID=nid)
    for nid, val in ((1, disp), (2, "Regular"), (3, ps + "-clipbot"), (4, disp), (6, ps)):
        name.setName(val, nid, 3, 1, 0x409)     # Windows/Unicode
        name.setName(val, nid, 1, 0, 0)         # Mac/Roman
    if "OS/2" in tt:                            # mark as the regular style of its own family
        tt["OS/2"].fsSelection = (tt["OS/2"].fsSelection & ~0b1100001) | 0b1000000
        tt["OS/2"].usWeightClass = 400
    if "head" in tt:
        tt["head"].macStyle = 0
    tt.flavor = None
    os.makedirs(dst_dir, exist_ok=True)
    out = os.path.join(dst_dir, re.sub(r"[^A-Za-z0-9]+", "_", disp).strip("_") + ".ttf")
    tt.save(out)
    return disp, out


def _sig():
    sig = []
    for d in (FONT_DIR, user_dir()):
        for f in sorted(os.listdir(d)) if os.path.isdir(d) else []:
            if f.lower().endswith((".ttf", ".otf")):
                p = os.path.join(d, f)
                sig.append((p, os.path.getmtime(p)))
    return tuple(sig)


def list_fonts():
    """[{family, file, path, user, em}] - em = canvas px per ASS font-size unit (libass/VSFilter scale)."""
    sig = _sig()
    if sig == _CACHE["sig"]:
        return _CACHE["fonts"]
    from fontTools.ttLib import TTFont
    out, seen = [], set()
    udir = user_dir()
    for p, _ in sig:
        try:
            tt = TTFont(p, lazy=True)
            fam = _name(tt, 1) or os.path.splitext(os.path.basename(p))[0]
            upm = tt["head"].unitsPerEm
            os2 = tt["OS/2"] if "OS/2" in tt else None
            h = (os2.usWinAscent + os2.usWinDescent) if os2 and (os2.usWinAscent + os2.usWinDescent) else upm
            em = upm / float(h)
            tt.close()
        except Exception:
            continue
        if fam in seen:
            continue
        seen.add(fam)
        out.append({"family": fam, "file": os.path.basename(p), "path": p, "user": p.startswith(udir),
                    "em": round(em, 4)})
    out.sort(key=lambda f: (f["user"], f["family"].lower()))
    _CACHE.update(sig=sig, fonts=out)
    return out


def find(family):
    """Font file for a display family (case-insensitive); None if unknown."""
    if not family:
        return None
    fl = family.lower()
    for f in list_fonts():
        if f["family"].lower() == fl:
            return f["path"]
    aliases = {"montserrat": "Montserrat Black", "impact": "Anton"}
    if fl in aliases:
        return find(aliases[fl])
    return None


def resolve(family, default="Anton"):
    """The canonical family name libass/Pillow will actually find (aliases resolved; else the default)."""
    p = find(family)
    if not p:
        return default
    for f in list_fonts():
        if f["path"] == p:
            return f["family"]
    return default


def render_dir():
    """One folder with every font (bundled + uploaded) for libass's fontsdir."""
    from .common import load_config
    d = os.path.join(load_config()["work_root"], "_fonts_render")
    os.makedirs(d, exist_ok=True)
    want = {}
    for f in list_fonts():
        want[f["file"] if not f["user"] else "u_" + f["file"]] = f["path"]
    for fn in os.listdir(d):
        if fn not in want:
            try:
                os.remove(os.path.join(d, fn))
            except OSError:
                pass
    for fn, src in want.items():
        dst = os.path.join(d, fn)
        if not (os.path.exists(dst) and os.path.getsize(dst) == os.path.getsize(src)
                and os.path.getmtime(dst) >= os.path.getmtime(src)):
            shutil.copy2(src, dst)
    return d


def add(src):
    """Install an uploaded font into the user font folder. Returns its display family."""
    disp, out = normalize(src, user_dir())
    _CACHE["sig"] = None
    return {"family": disp, "path": out}

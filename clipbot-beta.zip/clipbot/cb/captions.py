"""Caption quality: the best speech model on this computer, unsure lines dropped, and an honest check.

best_model(current)       the strongest faster-whisper model already downloaded (never downloads here), if it beats
                          `current` (the model the project was transcribed with) - used for a per-clip caption pass
drop_unsure(words)        -> (kept words, dropped lines). Whisper gives every word a confidence. A caption line with a
                          word below MIN_WORD or a line average below MIN_LINE is left out: on noisy IRL audio that's
                          where the misheard and crosstalk words are (measured: wrong words shown 3.6% -> 1.6% on IRL
                          crosstalk + crowd noise, keeping ~90% of lines). Words a person typed or fixed are never dropped.
check(words, audio_words) -> caption error rate of the lines SHOWN, against an independent transcription matched by
                          time, plus coverage (share of speech that got a caption). Missing lines are not "wrong
                          words": they're reported as coverage so a dropped line can't hide as a pass or fail.
"""
import glob
import os
import re

MIN_WORD = 0.3
MIN_LINE = 0.6
MAX_WER = 0.08                 # the bar: <= 8% wrong words on screen, or a person approves the captions

# best first. Turbo is close to large-v3 accuracy at a fraction of the cost; distil models are English-tuned.
RANKED = ["large-v3", "large-v3-turbo", "turbo", "large-v2", "distil-large-v3.5", "distil-large-v3", "medium",
          "small", "base", "tiny"]
_REPO = {"large-v3-turbo": "mobiuslabsgmbh--faster-whisper-large-v3-turbo", "turbo": "mobiuslabsgmbh--faster-whisper-large-v3-turbo",
         "distil-large-v3.5": "distil-whisper--distil-large-v3.5-ct2", "distil-large-v3": "Systran--faster-distil-whisper-large-v3"}


def _cached(name):
    repo = _REPO.get(name, "Systran--faster-whisper-%s" % name)
    hub = os.environ.get("HF_HUB_CACHE") or os.path.join(os.path.expanduser("~"), ".cache", "huggingface", "hub")
    return any(os.path.exists(os.path.join(d, "model.bin"))
               for d in glob.glob(os.path.join(hub, "models--" + repo, "snapshots", "*")))


def installed():
    return [m for m in RANKED if _cached(m)]


def best_model(current="small"):
    """The strongest downloaded model if it is stronger than `current`, else None."""
    have = installed()
    if not have:
        return None
    rank = {m: i for i, m in enumerate(RANKED)}
    best = have[0]
    return best if rank.get(best, 99) < rank.get(current, 99) else None


def _lines(words):
    from .render import chunk_words
    return chunk_words([list(w) for w in words])


def drop_unsure(words, min_word=MIN_WORD, min_line=MIN_LINE):
    """words [[s, e, text, prob?], ...] -> (kept, dropped_lines [[s, e, text], ...])"""
    kept, dropped = [], []
    for line in _lines(words):
        probs = [w[3] for w in line if len(w) > 3 and w[3] is not None]
        if probs and (min(probs) < min_word or sum(probs) / len(probs) < min_line):
            dropped.append([line[0][0], line[-1][1], " ".join(w[2] for w in line)])
        else:
            kept += line
    return kept, dropped


_NUM = {"0": "zero", "1": "one", "2": "two", "3": "three", "4": "four", "5": "five", "6": "six", "7": "seven",
        "8": "eight", "9": "nine", "10": "ten"}


def norm(text):
    t = re.sub(r"[^a-z0-9$%' ]", " ", text.lower().replace("-", " "))
    return [_NUM.get(w, w) for w in t.split() if w.strip("'")]


def _join_compounds(a, b):
    """'euro bank notes' vs 'eurobank notes', 'every one' vs 'everyone': the same words, split differently.
    Joins adjacent tokens in `a` whose concatenation is a single token in `b` (and vice versa)."""
    def join(x, other):
        o = set(other)
        out, i = [], 0
        while i < len(x):
            for n in (3, 2):
                if i + n <= len(x) and "".join(x[i:i + n]) in o:
                    out.append("".join(x[i:i + n]))
                    i += n
                    break
            else:
                out.append(x[i])
                i += 1
        return out
    a = join(a, b)
    return a, join(b, a)


def _edits(r, h):
    """(substitutions, deletions, insertions) of hypothesis h against reference r"""
    n, m = len(r), len(h)
    d = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(n + 1):
        d[i][0] = i
    for j in range(m + 1):
        d[0][j] = j
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            d[i][j] = min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (r[i - 1] != h[j - 1]))
    i, j, S, D, I = n, m, 0, 0, 0
    while i > 0 or j > 0:
        if i > 0 and j > 0 and d[i][j] == d[i - 1][j - 1] + (r[i - 1] != h[j - 1]):
            S += r[i - 1] != h[j - 1]
            i, j = i - 1, j - 1
        elif i > 0 and d[i][j] == d[i - 1][j] + 1:
            D += 1
            i -= 1
        else:
            I += 1
            j -= 1
    return S, D, I


def check(shown, reference, pad=0.2):
    """shown / reference: [[s, e, text, ...], ...] in the same clock (the clip's).
    The words spoken while captions are on screen (reference words inside a shown line, +-pad) are aligned with the
    caption words in one pass, so two transcriptions that place a word 50 ms apart don't count it twice.
    Returns {"wer": wrong words on screen / words on screen (0..1), "coverage": share of heard words that got a
    caption line, "lines": n, "worst": [[s, e, shown, heard], ...]} - worst = lines that disagree most."""
    lines = _lines(shown)
    if not lines:
        return {"wer": None, "coverage": 0.0 if reference else None, "lines": 0, "worst": []}
    # Where the reference heard nothing for a long stretch, it may simply have skipped that audio (a known
    # Whisper failure on long files). Lines there can't be judged: they're reported as unchecked, not as errors.
    mids = sorted((w[0] + w[1]) / 2.0 for w in reference)

    def judged(a, b):
        import bisect
        i = bisect.bisect_left(mids, a)
        if i < len(mids) and mids[i] <= b:
            return True
        before = mids[i - 1] if i > 0 else -1e9
        after = mids[i] if i < len(mids) else 1e9
        return after - before < 2.5                 # a short pause in the reference: the line really has no match
    keep = [(line, a, b) for line, (a, b) in zip(lines, [(l[0][0], l[-1][1]) for l in lines]) if judged(a - pad, b + pad)]
    unchecked = len(lines) - len(keep)
    lines = [k[0] for k in keep]
    if not lines:
        return {"wer": None, "coverage": None, "lines": 0, "unchecked": unchecked, "worst": []}
    spans = [(line[0][0] - pad, line[-1][1] + pad) for line in lines]
    inside = [k for k, w in enumerate(reference) if any(a <= (w[0] + w[1]) / 2.0 <= b for a, b in spans)]
    H = sum((norm(w[2]) for line in lines for w in line), [])
    R = sum((norm(reference[k][2]) for k in inside), [])
    R, H = _join_compounds(R, H)
    S, D, I = _edits(R, H)
    total_ref = sum(len(norm(w[2])) for w in reference)
    worst = []
    for line, (a, b) in zip(lines, spans):        # per-line view, only for showing the person where to look
        h = sum((norm(w[2]) for w in line), [])
        heard = [reference[k] for k in inside if a + pad <= (reference[k][0] + reference[k][1]) / 2.0 <= b - pad]
        e = sum(_edits(*_join_compounds(sum((norm(w[2]) for w in heard), []), h)))
        if e >= 2:
            worst.append([round(line[0][0], 2), round(line[-1][1], 2), " ".join(w[2] for w in line),
                          " ".join(w[2] for w in heard), e])
    worst.sort(key=lambda x: -x[4])
    return {"wer": round((S + D + I) / float(max(len(H), 1)), 3),
            "coverage": round(len(R) / float(total_ref), 3) if total_ref else None,
            "lines": len(lines), "unchecked": unchecked, "worst": [w[:4] for w in worst[:5]]}

"""Connections: services a user plugs in themselves. Stored on their computer only
(<work_root>/_settings/connections.json, outside the app folder so updates keep it). Keys are never sent anywhere
except to the service they belong to.

  ai        {"provider": "anthropic"|"openai"|"custom", "key": "...", "model": "...", "base_url": "..."}
            -> extra title/headline ideas (still fact-checked against what was said in the clip)
  cookies   {"browser": "chrome"|"firefox"|"edge"|"safari"|"brave"|"chromium"|"opera"|"vivaldi"}
            -> yt-dlp uses that browser's logins (subscriber-only / age-restricted VODs)
  webhook   {"url": "https://...", "events": ["clip_rendered", "autoclip_done"]}
            -> POST JSON when a clip finishes (Zapier, Make, n8n, a Discord webhook, your own server)
  feedback  {"enabled": bool, "url": "...", "include_text": bool}
            -> anonymous learning reports to the app's publisher (opt-in; see learn.py)
  scorer    {"url": "https://...", "weight": 0.3, "token": "..."}
            -> any outside tool scores auto-clip's candidates (your own model, an n8n/Make flow, a local server).
               Clipbot POSTs {"app": "clipbot", "candidates": [{"id", "start", "end", "text", "score", "tags"}]}
               and reads back [{"id": 0, "score": 0-10, "why": "..."}] (or {"scores": [...]}). See CONNECT.md.
"""
import json
import os
import threading
import urllib.request

from .common import load_config, log

BROWSERS = ("chrome", "firefox", "edge", "safari", "brave", "chromium", "opera", "vivaldi")
_LOCK = threading.Lock()


def _path():
    d = os.path.join(load_config()["work_root"], "_settings")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "connections.json")


def get():
    try:
        c = json.load(open(_path()))
    except Exception:
        c = {}
    fb = c.setdefault("feedback", {})
    fb.setdefault("url", load_config().get("feedback_url") or "")      # baked in by the publisher
    fb.setdefault("enabled", False)
    fb.setdefault("include_text", False)
    return c


def save(patch):
    """Merge a partial update. Empty-string keys mean 'unchanged' for secrets, None means 'remove'."""
    with _LOCK:
        c = get()
        for sect, vals in (patch or {}).items():
            if sect not in ("ai", "cookies", "webhook", "feedback", "scorer"):
                continue
            if vals is None:
                c.pop(sect, None)
                continue
            cur = c.setdefault(sect, {})
            for k, v in vals.items():
                if k in ("key", "token") and v == "":
                    continue                    # keep the stored key when the field is left blank
                if v is None:
                    cur.pop(k, None)
                else:
                    cur[k] = v
        _validate(c)
        tmp = _path() + ".tmp"
        json.dump(c, open(tmp, "w"), indent=1)
        os.replace(tmp, _path())
        try:
            os.chmod(_path(), 0o600)
        except OSError:
            pass
        return redacted(c)


def _validate(c):
    ai = c.get("ai") or {}
    if ai.get("provider") and ai["provider"] not in ("anthropic", "openai", "custom"):
        raise ValueError("AI provider must be anthropic, openai or custom")
    if ai.get("provider") == "custom" and not str(ai.get("base_url", "")).startswith("http"):
        raise ValueError("a custom AI provider needs its base URL (https://...)")
    br = (c.get("cookies") or {}).get("browser")
    if br and br not in BROWSERS:
        raise ValueError("browser must be one of: " + ", ".join(BROWSERS))
    for sect in ("webhook", "feedback", "scorer"):
        u = (c.get(sect) or {}).get("url")
        if u and not str(u).startswith(("https://", "http://127.0.0.1", "http://localhost")):
            raise ValueError("%s URL must start with https://" % sect)


def redacted(c=None):
    """Safe to show in the UI: keys reduced to their last 4 characters."""
    c = json.loads(json.dumps(c or get()))
    for sect, field in (("ai", "key"), ("scorer", "token")):
        k = (c.get(sect) or {}).get(field)
        if k:
            c[sect][field] = ""
            c[sect][field + "_hint"] = "…" + k[-4:]
    return c


def cookies_browser():
    return (get().get("cookies") or {}).get("browser") or None


# ------------------------------------------------------------------ webhook
def fire(event, payload):
    """POST {event, ...payload} to the user's webhook in the background. Never raises."""
    wh = get().get("webhook") or {}
    url = wh.get("url")
    if not url or (wh.get("events") and event not in wh["events"]):
        return False
    body = dict(payload or {}, event=event, app="clipbot")
    if "discord.com/api/webhooks" in url:           # Discord wants {"content": "..."}
        body = {"content": "**Clipbot** - %s: %s" % (event.replace("_", " "),
                                                     payload.get("title") or payload.get("name") or "")[:1900]}

    def go():
        try:
            req = urllib.request.Request(url, data=json.dumps(body).encode(), method="POST",
                                         headers={"Content-Type": "application/json", "User-Agent": "clipbot"})
            urllib.request.urlopen(req, timeout=15).read()
        except Exception as e:
            log("webhook failed: %s" % str(e)[:120])
    threading.Thread(target=go, daemon=True).start()
    return True


# ------------------------------------------------------------------ AI text (titles / headlines)
def _local(url):
    return str(url or "").startswith(("http://localhost", "http://127.0.0.1"))


def ai_ready():
    ai = get().get("ai") or {}
    return bool(ai.get("provider") and (ai.get("key") or (ai.get("provider") == "custom" and _local(ai.get("base_url")))))


def ai_complete(prompt, system="", max_tokens=600, timeout=45):
    """One text completion with the user's own key. Raises RuntimeError with a readable reason."""
    ai = get().get("ai") or {}
    if not ai.get("key") and not _local(ai.get("base_url")):
        raise RuntimeError("no AI key connected")
    prov = ai.get("provider", "anthropic")
    try:
        if prov == "anthropic":
            url = (ai.get("base_url") or "https://api.anthropic.com").rstrip("/") + "/v1/messages"
            body = {"model": ai.get("model") or "claude-haiku-5-5", "max_tokens": max_tokens,
                    "messages": [{"role": "user", "content": prompt}]}
            if system:
                body["system"] = system
            req = urllib.request.Request(url, data=json.dumps(body).encode(), method="POST", headers={
                "x-api-key": ai["key"], "anthropic-version": "2023-06-01", "content-type": "application/json"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                j = json.loads(r.read())
            return "".join(b.get("text", "") for b in j.get("content", []) if b.get("type") == "text")
        base = (ai.get("base_url") or "https://api.openai.com/v1").rstrip("/")
        if not ai.get("model"):
            raise RuntimeError("set the model name for this AI provider")
        msgs = ([{"role": "system", "content": system}] if system else []) + [{"role": "user", "content": prompt}]
        req = urllib.request.Request(base + "/chat/completions", method="POST",
                                     data=json.dumps({"model": ai["model"], "messages": msgs,
                                                      "max_tokens": max_tokens}).encode(),
                                     headers={"Authorization": "Bearer " + (ai.get("key") or "local"),
                                              "Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            j = json.loads(r.read())
        return j["choices"][0]["message"]["content"] or ""
    except RuntimeError:
        raise
    except Exception as e:
        code = getattr(e, "code", None)
        detail = ""
        try:
            detail = e.read().decode("utf-8", "replace")[:200] if hasattr(e, "read") else ""
        except Exception:
            pass
        if code in (401, 403):
            raise RuntimeError("the AI service rejected the key (check it in Settings)")
        if code == 429:
            raise RuntimeError("the AI service is rate-limiting this key - try again in a minute")
        raise RuntimeError("AI request failed: %s %s" % (code or str(e)[:100], detail))


def ai_titles(text, headline="", n=6):
    """Extra title ideas from the user's AI. Plain list of strings (the caller fact-checks them)."""
    system = ("You write titles for short vertical clips of livestreams. Every claim, number and name in a title "
              "must be stated in the transcript. No invented facts. Under 70 characters. Return only a JSON array "
              "of strings.")
    prompt = "Transcript of the clip:\n\"\"\"%s\"\"\"\n%sWrite %d different titles, from plain to curiosity-driven." % (
        text[:4000], ("Current headline: %s\n" % headline) if headline else "", n)
    out = ai_complete(prompt, system=system, max_tokens=500)
    import re
    m = re.search(r"\[.*\]", out, re.S)
    try:
        arr = json.loads(m.group(0)) if m else []
    except Exception:
        arr = []
    if not arr:
        arr = [l.strip(" -*\"0123456789.") for l in out.splitlines() if l.strip()]
    return [str(t).strip()[:100] for t in arr if str(t).strip()][:n]


# ------------------------------------------------------------------ outside scorer (any software)
def scorer_ready():
    return bool((get().get("scorer") or {}).get("url"))


def score_external(cands, timeout=60):
    """POST candidates to the user's scorer. -> {index: {"score", "why"}}. Raises RuntimeError on failure."""
    sc = get().get("scorer") or {}
    body = {"app": "clipbot", "version": 1, "candidates": [
        {"id": i, "start": c["start"], "end": c["end"], "text": " ".join(t for _, t in c.get("sentences", []))[:2000],
         "score": (c.get("quality") or {}).get("score"), "tags": sorted((c.get("tags") or {}).keys()),
         "chat_z": c.get("chat_z")} for i, c in enumerate(cands)]}
    h = {"Content-Type": "application/json", "User-Agent": "clipbot"}
    if sc.get("token"):
        h["Authorization"] = "Bearer " + sc["token"]
    try:
        req = urllib.request.Request(sc["url"], data=json.dumps(body).encode(), method="POST", headers=h)
        with urllib.request.urlopen(req, timeout=timeout) as r:
            j = json.loads(r.read() or b"[]")
    except Exception as e:
        raise RuntimeError("your scorer didn't answer: %s" % str(e)[:120])
    arr = j.get("scores") if isinstance(j, dict) else j
    out = {}
    for x in arr or []:
        try:
            i, s_ = int(x["id"]), float(x["score"])
        except (KeyError, TypeError, ValueError):
            continue
        if 0 <= i < len(cands) and 0 <= s_ <= 10:
            out[i] = {"score": round(s_, 1), "why": str(x.get("why") or "")[:120]}
    return out

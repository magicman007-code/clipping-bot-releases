"""Platform handle banner (+ uploaded campaign banners) ("KICK.COM/ORANGIE") auto-injected into clips.

spec / config key:
  "banner": {"platform": "kick"|"twitch"|"youtube"|"tiktok"|"x"|"custom", "handle": "orangie",
             "position": "auto"|"top"|"bottom"|[x, y], "style": "pill"|"bar"|"minimal",
             "logo": "/path/official_logo.png" (optional, your own copy of the platform's brand asset),
             "animate": "slide"|"fade"|"none", "start": 0, "end": null, "scale": 1.0,
             "text": "custom text" (overrides platform/handle)}

The default badge is drawn here (coloured block + live dot + text), not a copy of any platform logo.
Pass `logo` to use an official asset you're allowed to use.
"""
import glob
import hashlib
import os

from .common import FONT_DIR, ROOT

PLATFORMS = {
    # logo_bg = colour behind an official logo file; slash = text when the logo carries the brand
    "kick":    {"color": (83, 252, 24), "ink": (0, 0, 0), "fmt": "kick.com/{h}", "logo_bg": (0, 0, 0)},
    "twitch":  {"color": (145, 70, 255), "ink": (255, 255, 255), "fmt": "twitch.tv/{h}", "logo_bg": (145, 70, 255)},
    "youtube": {"color": (255, 0, 51), "ink": (255, 255, 255), "fmt": "youtube.com/@{h}"},
    "tiktok":  {"color": (37, 244, 238), "ink": (0, 0, 0), "fmt": "@{h}"},
    "x":       {"color": (240, 240, 240), "ink": (0, 0, 0), "fmt": "@{h}"},
    "custom":  {"color": (255, 217, 61), "ink": (0, 0, 0), "fmt": "{h}"},
}
CACHE = os.path.join(ROOT, "assets", "banners")
# Organic-feed safe band on 1080x1920 (TikTok hides ~220px top / ~480px bottom, Shorts has a 192px right rail)
SAFE_TOP, SAFE_BOTTOM, SAFE_RIGHT, SAFE_LEFT = 240, 1440, 960, 60
PRESETS = {
    # paid Kick clips carry a big "kick.com/<name>" credit (per Clavicular, Dexerto 2025)
    "kick_campaign": {"platform": "kick", "format": "domain", "style": "pill", "scale": 1.45, "position": "top"},
    "kick_small": {"platform": "kick", "format": "slash", "style": "native", "scale": 1.0, "position": "auto"},
    "twitch_tag": {"platform": "twitch", "format": "slash", "style": "pill", "scale": 1.1, "position": "top"},
    "kick_moving": {"platform": "kick", "format": "slash", "style": "native", "motion": "hop", "opacity": 0.9},
    # account icon (the platform this streamer is on) + big outlined name; add "platforms" for more icons
    "socials": {"platform": "kick", "style": "socials", "scale": 0.62, "position": "top"},
}


def library_dir():
    from .common import load_config
    d = os.path.join(load_config()["work_root"], "_banners")
    os.makedirs(d, exist_ok=True)
    return d


def library():
    """Uploaded banners (campaign-supplied PNGs etc.), shared by every project."""
    d = library_dir()
    out = []
    for f in sorted(os.listdir(d)):
        if f.lower().endswith((".png", ".webp", ".gif", ".jpg", ".jpeg")):
            out.append({"name": os.path.splitext(f)[0], "path": os.path.join(d, f)})
    return out


def resolve(b):
    """Expand presets and library names into a full banner dict."""
    if not b:
        return b
    b = dict(b)
    if b.get("preset") in PRESETS:
        b = dict(PRESETS[b["preset"]], **{k: v for k, v in b.items() if k != "preset"})
    if b.get("library") and not b.get("image"):
        hit = [x for x in library() if x["name"] == b["library"]]
        if hit:
            b["image"] = hit[0]["path"]
    return b
LOGO_DIR = os.path.join(ROOT, "assets", "logos")


ICON_COLOR = {"kick": "#53FC19", "twitch": "#FFFFFF", "youtube": "#FFFFFF", "tiktok": "#FFFFFF", "x": "#000000"}
# tile background + icon colour for the multi-platform "socials" banner
TILES = {"kick": ("#53FC19", "#000000"), "twitch": ("#9146FF", "#FFFFFF"), "youtube": ("#FF0000", "#FFFFFF"),
         "x": ("#000000", "#FFFFFF"), "tiktok": ("#000000", "#FFFFFF"), "discord": ("#5865F2", "#FFFFFF"),
         "instagram": ("#E4405F", "#FFFFFF"), "kick_dark": ("#000000", "#53FC19")}


def brand_icon(platform, size=256, color=None):
    """Platform brand icon rendered from the Simple Icons package (CC0 project; the marks belong to their
    owners - used here only to point viewers to the creator's channel, per each platform's brand guidelines).
    Bundled from the Simple Icons package (CC0), downloaded if missing; never redrawn by us. Returns a PNG path or None (offline)."""
    out = os.path.join(LOGO_DIR, "_icon_%s_%d%s.png" % (platform, size, (color or "").replace("#", "_")))
    if os.path.exists(out):
        return out
    pkg = os.path.join(LOGO_DIR, "_simple-icons")
    svg = os.path.join(pkg, "package", "icons", "%s.svg" % platform)
    if not os.path.exists(svg):
        os.makedirs(os.path.dirname(svg), exist_ok=True)
        _fetch_simple_icons(os.path.dirname(svg))
    if not os.path.exists(svg):
        return None
    try:
        import resvg_py
        txt = open(svg).read().replace("<svg ", '<svg width="%d" height="%d" fill="%s" ' % (
            size, size, color or ICON_COLOR.get(platform, "#FFFFFF")), 1)
        data = resvg_py.svg_to_bytes(svg_string=txt)
        open(out, "wb").write(bytes(data))
        return out
    except Exception:
        return None


SIMPLE_ICONS_TGZ = "https://registry.npmjs.org/simple-icons/-/simple-icons-16.36.0.tgz"
WANTED_ICONS = ("kick", "twitch", "youtube", "tiktok", "x", "discord", "instagram")


def _fetch_simple_icons(dest):
    """Pull just the icons we use out of the Simple Icons package straight from the npm registry
    (plain HTTPS - no npm/node needed on the tester's machine)."""
    import io
    import tarfile
    import urllib.request
    try:
        data = urllib.request.urlopen(SIMPLE_ICONS_TGZ, timeout=60).read()
    except Exception:
        try:      # fallback: npm CLI if the registry needs a proxy only npm knows about
            import subprocess
            import tempfile
            tmp = tempfile.mkdtemp()
            subprocess.run(["npm", "pack", "simple-icons@16.36.0"], cwd=tmp, capture_output=True, timeout=120)
            data = open(glob.glob(os.path.join(tmp, "*.tgz"))[0], "rb").read()
        except Exception:
            return False
    with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as tf:
        for name in WANTED_ICONS:
            try:
                m = tf.getmember("package/icons/%s.svg" % name)
            except KeyError:
                continue
            open(os.path.join(dest, name + ".svg"), "wb").write(tf.extractfile(m).read())
    return True


def official_logo(b):
    """Logo for the banner: spec 'logo' (your own file), else assets/logos/<platform>.png, else the
    platform's brand icon from Simple Icons."""
    if b.get("logo") and os.path.exists(b["logo"]):
        return b["logo"]
    plat = b.get("platform", "kick")
    for ext in ("png", "webp", "jpg"):
        p = os.path.join(LOGO_DIR, "%s.%s" % (plat, ext))
        if os.path.exists(p):
            return p
    if plat in ICON_COLOR and b.get("brand_icon", True):
        return brand_icon(plat)
    return None


def banner_text(b):
    if b.get("text"):
        return b["text"]
    p = PLATFORMS.get(b.get("platform", "kick"), PLATFORMS["custom"])
    h = str(b.get("handle", "")).lstrip("@")
    fmt = b.get("format", "auto")
    if fmt == "slash" or (fmt == "auto" and official_logo(b) and b.get("platform") in ("kick", "twitch")):
        return "/" + h                     # logo + /handle: the common clip-page look
    if fmt == "handle":
        return "@" + h
    return p["fmt"].format(h=h)


def render_png(b, width=1080):
    """Draw the banner to a transparent PNG; returns (path, w, h)."""
    from PIL import Image, ImageDraw, ImageFont
    os.makedirs(CACHE, exist_ok=True)
    if b.get("image"):                      # uploaded banner: use it as-is, just scaled
        im = Image.open(b["image"]).convert("RGBA")
        bb = im.getbbox()
        im = im.crop(bb) if bb else im
        w = int(min(1000, float(b.get("width", 640))))
        im = im.resize((w, max(1, int(im.height * w / im.width))), Image.LANCZOS)
        if b.get("opacity") is not None:
            im.putalpha(im.getchannel("A").point(lambda v: int(v * float(b["opacity"]))))
        out = os.path.join(CACHE, "img_%s.png" % hashlib.md5((b["image"] + str(w) + str(b.get("opacity")) +
                                                               str(os.path.getmtime(b["image"]))).encode()).hexdigest()[:10])
        im.save(out)
        return out, im.width, im.height
    lp_ = official_logo(b)
    key = hashlib.md5((repr(sorted(b.items())) + str(lp_) + str(os.path.getmtime(lp_) if lp_ else "")).encode()).hexdigest()[:10]
    out = os.path.join(CACHE, "banner_%s.png" % key)
    plat = PLATFORMS.get(b.get("platform", "kick"), PLATFORMS["custom"])
    col = tuple(b.get("color") or plat["color"])
    ink = tuple(plat["ink"])
    style = b.get("style", "pill")
    sc = float(b.get("scale", 1.12))
    text = banner_text(b).upper() if style != "minimal" else banner_text(b)
    H = int(round(76 * sc))
    font = ImageFont.truetype(os.path.join(FONT_DIR, "Montserrat-Black.ttf"), int(H * 0.44))
    tw = font.getlength(text)
    logo = None
    lp = official_logo(b)
    if lp:
        lg = Image.open(lp).convert("RGBA")
        bb = lg.getbbox()
        lg = lg.crop(bb) if bb else lg
        lh = int(H * 0.62)
        logo = lg.resize((max(1, int(lg.width * lh / lg.height)), lh), Image.LANCZOS)
    icon_w = (logo.width + int(H * 0.36)) if logo else H
    pad = int(H * 0.34)
    if style == "socials":
        return _socials_png(b, out)
    if style == "native":
        H2 = int(H * 0.86)
        f2 = ImageFont.truetype(os.path.join(FONT_DIR, "Montserrat-Black.ttf"), int(H2 * 0.5))
        tw2 = f2.getlength(text)
        lw = logo.width * H2 // max(1, logo.height) if logo else 0
        Wd = int(lw + (H2 * 0.25 if logo else 0) + tw2 + 16)
        img = Image.new("RGBA", (Wd + 8, H2 + 8), (0, 0, 0, 0))
        sh = Image.new("RGBA", img.size, (0, 0, 0, 0))
        ds = ImageDraw.Draw(sh)
        if logo:
            lg2 = logo.resize((lw, H2), Image.LANCZOS)
            sh.paste((0, 0, 0, 170), (3, 4), lg2)
        tx2 = int(lw + (H2 * 0.25 if logo else 0))
        ds.text((tx2 + 3, (H2 - f2.getbbox(text)[3]) // 2 + 4), text, font=f2, fill=(0, 0, 0, 170))
        from PIL import ImageFilter
        img.alpha_composite(sh.filter(ImageFilter.GaussianBlur(3)))
        d2 = ImageDraw.Draw(img)
        if logo:
            img.alpha_composite(logo.resize((lw, H2), Image.LANCZOS), (0, 0))
        d2.text((tx2, (H2 - f2.getbbox(text)[3]) // 2), text, font=f2, fill=(255, 255, 255, 235))
        img.save(out)
        return out, img.width, img.height
    if style == "bar":
        Wd = width
    else:
        Wd = int(min(width - 40, icon_w + pad + tw + pad))
    img = Image.new("RGBA", (Wd, H + 8), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    r = H // 2 if style == "pill" else (0 if style == "bar" else int(H * 0.22))
    # shadow
    d.rounded_rectangle([3, 7, Wd - 1, H + 7], radius=r, fill=(0, 0, 0, 110))
    if style == "minimal":
        d.rounded_rectangle([0, 0, Wd - 4, H], radius=r, fill=(0, 0, 0, 150))
        badge_fill, text_fill = col, (255, 255, 255)
    else:
        d.rounded_rectangle([0, 0, Wd - 4, H], radius=r, fill=(14, 15, 18, 235))
        badge_fill, text_fill = col, (255, 255, 255)
    # badge block on the left
    if logo is not None and plat.get("logo_bg"):
        badge_fill = tuple(plat["logo_bg"])
    d.rounded_rectangle([0, 0, icon_w, H], radius=r, fill=badge_fill + (255,))
    if style != "pill":
        d.rectangle([icon_w - r - 1, 0, icon_w, H], fill=badge_fill + (255,))
    if logo:
        img.alpha_composite(logo, (int(H * 0.18), (H - logo.height) // 2))
    else:   # generic "live" glyph: ring + dot (not a platform logo)
        cx, cy, R = icon_w // 2, H // 2, int(H * 0.22)
        d.ellipse([cx - R, cy - R, cx + R, cy + R], outline=ink + (255,), width=max(3, int(H * 0.06)))
        rr = int(R * 0.45)
        d.ellipse([cx - rr, cy - rr, cx + rr, cy + rr], fill=ink + (255,))
    ty = (H - font.getbbox(text)[3]) // 2 - int(H * 0.02)
    tx = icon_w + pad if style != "bar" else (Wd - tw) // 2 + icon_w // 2
    d.text((tx, ty), text, font=font, fill=text_fill + (255,))
    img.save(out)
    return out, img.width, img.height


def placement(b, layout, plan, head_y, W=1080, H=1920, band=300, faces=()):
    """Centre point for the banner that stays clear of headline, captions and platform UI."""
    pos = b.get("position", "auto")
    if isinstance(pos, (list, tuple)):
        return int(pos[0]), int(pos[1])
    cap_y = plan[0][3] if plan else 1350
    if layout == "frame":                 # 1:1 / 4:5 / 16:9: under the headline (or top), else bottom, never on captions
        top = int(head_y + 130) if head_y else int(0.09 * H)
        bot = int(H - 0.07 * H)
        for y in ([bot] if pos == "bottom" else []) + [top, bot, int(H * 0.5)]:
            if abs(y - cap_y) > 100 and all(not (y + 50 > f0 and y - 50 < f1) for f0, f1 in faces):
                return W // 2, y
        return W // 2, (bot if abs(bot - cap_y) > 100 else top)
    if pos == "bottom":
        y = SAFE_BOTTOM - 70
        return W // 2, (y if abs(y - cap_y) > 150 else max(SAFE_TOP + 60, cap_y - 170))
    if layout == "vertical":
        top = (head_y or 300) + 150           # just under the headline card
    elif layout == "gameplay":
        top = 960 - 70                        # bottom edge of the clip pane
    else:
        top = band + 58                       # top of the video body, under the headline band
    def clear(y):    # banner (~90px tall) must not sit on a face or the captions
        return all(not (y + 50 > f0 and y - 50 < f1) for f0, f1 in faces) and abs(y - cap_y) > 150
    top = max(SAFE_TOP + 50, int(top))
    for y in ([top] if pos == "top" else []) + [top, SAFE_BOTTOM - 70, max(SAFE_TOP + 50, int(band + 58)), 1200]:
        if SAFE_TOP + 40 <= y <= SAFE_BOTTOM - 40 and clear(y):
            return W // 2, y
    return W // 2, top


def overlay_steps(b, layout, plan, head_y, dur, in_index, faces=(), W=1080, H=1920):
    """-> (ffmpeg input args, filter step producing label from [vin]) for render.make_clip."""
    b = resolve(b)
    png, bw, bh = render_png(b)
    x, y = placement(b, layout, plan, head_y, W=W, H=H, faces=faces)
    st = float(b.get("start", 0) or 0)
    en = float(b.get("end") or dur)
    if b.get("outro"):
        en = min(en, dur - 1.7)
    anim = b.get("animate", "slide")
    x0 = "%d" % (x - bw // 2)
    if b.get("motion") == "hop":     # like Kick's own download watermark: jumps between safe spots
        spots = hop_spots(b, layout, plan, head_y, faces, bw, bh, W=W, H=H)
        per = float(b.get("hop_seconds", 4.0))
        n = len(spots)
        xs = ys = None
        for k in range(n - 1, -1, -1):
            sx, sy = spots[k]
            xs = "%d" % sx if xs is None else "if(lt(mod(t,%.2f),%.2f),%d,%s)" % (per * n, per * (k + 1), sx, xs)
            ys = "%d" % sy if ys is None else "if(lt(mod(t,%.2f),%.2f),%d,%s)" % (per * n, per * (k + 1), sy, ys)
        prep = "[%d:v]format=rgba,colorchannelmixer=aa=%.2f[bnr]" % (in_index, float(b.get("opacity", 0.9)))
        ov = "overlay=x='%s':y='%s':enable='between(t,%.3f,%.3f)':eof_action=repeat" % (xs, ys, st, en)
        return ["-loop", "1", "-i", png], prep, ov
    if anim == "slide":
        x0 = "if(lt(t,%.3f),-w,if(lt(t,%.3f),-w+(%d+w)*(1-pow(1-(t-%.3f)/0.35,3)),%d))" % (
            st, st + 0.35, x - bw // 2, st, x - bw // 2)
    prep = "[%d:v]format=rgba%s[bnr]" % (in_index, ",fade=t=in:st=%.2f:d=0.3:alpha=1" % st if anim == "fade" else "")
    ov = "overlay=x='%s':y=%d:enable='between(t,%.3f,%.3f)':eof_action=repeat" % (x0, y - bh // 2, st, en)
    return ["-loop", "1", "-i", png], prep, ov


def hop_spots(b, layout, plan, head_y, faces, bw, bh, W=1080, H=1920):
    """Three watermark positions (top-left, mid-right, lower-left) that avoid faces, captions,
    the headline card and the platform UI zones (top 140px, right rail, bottom 330px)."""
    cap_y = plan[0][3] if plan else 1350
    if layout == "frame":
        m = int(0.04 * min(W, H))
        cands = [(m, m), (W - bw - m, H // 2 - bh // 2), (m, H - bh - m), (W - bw - m, m)]
        ok = [(x, y) for x, y in cands if abs(y + bh / 2 - cap_y) > 110 and not (head_y and y < head_y + 110)]
        return (ok or cands)[:3]
    top = (head_y or 300) + 150 if layout == "vertical" else 300 + 40
    top = max(SAFE_TOP + 10, top)
    rx = max(SAFE_LEFT, min(W - bw - (W - SAFE_RIGHT), W - bw - 140))
    cands = [(SAFE_LEFT, top), (rx, int(H * 0.47)), (SAFE_LEFT, SAFE_BOTTOM - bh - 20), (rx, top + 220), (SAFE_LEFT, int(H * 0.6))]
    ok = []
    for x, y in cands:
        yc = y + bh / 2
        if abs(yc - cap_y) < 120 or y < SAFE_TOP or y + bh > SAFE_BOTTOM:
            continue
        if any(yc + bh / 2 > f0 and yc - bh / 2 < f1 for f0, f1 in faces):
            continue
        ok.append((int(x), int(y)))
    return (ok or [(40, top)])[:3]


def outro_card(b, dur, in_index, W=1080, H=1920):
    """1.6s end card: dimmed frame + big brand icon + FOLLOW + kick.com/handle (like Kick's clip outro)."""
    from PIL import Image, ImageDraw, ImageFont
    os.makedirs(CACHE, exist_ok=True)
    plat = b.get("platform", "kick")
    key = hashlib.md5(("outro2" + repr(sorted(b.items())) + "%dx%d" % (W, H)).encode()).hexdigest()[:10]
    out = os.path.join(CACHE, "outro_%s.png" % key)
    if not os.path.exists(out):
        TW, TH = 1080, 1920
        img = Image.new("RGBA", (TW, TH), (8, 9, 12, 250))
        d = ImageDraw.Draw(img)
        lp = official_logo(b)
        y = 700
        if lp:
            lg = Image.open(lp).convert("RGBA")
            bb = lg.getbbox()
            lg = lg.crop(bb) if bb else lg
            s_ = 220 / float(lg.height)
            lg = lg.resize((int(lg.width * s_), 220), Image.LANCZOS)
            col = PLATFORMS.get(plat, PLATFORMS["custom"])["color"]
            pad = 46
            d.rounded_rectangle([TW // 2 - lg.width // 2 - pad, y - pad, TW // 2 + lg.width // 2 + pad, y + 220 + pad],
                                radius=48, fill=((0, 0, 0) if plat == "kick" else col) + (255,))
            img.alpha_composite(lg, (TW // 2 - lg.width // 2, y))
        f1 = ImageFont.truetype(os.path.join(FONT_DIR, "Anton-Regular.ttf"), 120)
        f2 = ImageFont.truetype(os.path.join(FONT_DIR, "Montserrat-Black.ttf"), 64)
        t1 = b.get("outro_text", "FOLLOW")
        b2 = dict(b, format="domain")
        t2 = banner_text(b2).upper()
        d.text(((TW - f1.getlength(t1)) / 2, 1040), t1, font=f1, fill=(255, 255, 255, 255))
        d.text(((TW - f2.getlength(t2)) / 2, 1210), t2, font=f2, fill=PLATFORMS.get(plat, PLATFORMS["custom"])["color"] + (255,))
        if (W, H) != (TW, TH):          # other aspect ratios: same card content, centred on a W x H card
            band = img.crop((0, 600, TW, 1320))
            k = min(W / float(TW), H * 0.8 / band.height)
            band = band.resize((int(TW * k), int(band.height * k)), Image.LANCZOS)
            img = Image.new("RGBA", (W, H), (8, 9, 12, 250))
            img.alpha_composite(band, ((W - band.width) // 2, (H - band.height) // 2))
        img.save(out)
    st = max(0.0, dur - 1.6)
    prep = "[%d:v]format=rgba,fade=t=in:st=%.2f:d=0.25:alpha=1[outro]" % (in_index, st)
    ov = "overlay=0:0:enable='gte(t,%.3f)':eof_action=repeat" % st
    return ["-loop", "1", "-i", out], prep, ov


def _socials_png(b, out, W=1000):
    """Row of platform tiles above a big outlined username (multi-platform credit)."""
    from PIL import Image, ImageDraw, ImageFilter, ImageFont
    plats = b.get("platforms") or [b.get("platform", "kick")]
    sc = float(b.get("scale", 1.0))
    T = int(108 * sc)                                 # tile size
    gap = int(16 * sc)
    name = str(b.get("text") or b.get("handle") or "username").lstrip("@").upper()
    fsize = int(150 * sc)
    font = ImageFont.truetype(os.path.join(FONT_DIR, "Montserrat-Black.ttf"), fsize)
    while font.getlength(name) * 1.15 > W - 40 and fsize > 50:
        fsize -= 6
        font = ImageFont.truetype(os.path.join(FONT_DIR, "Montserrat-Black.ttf"), fsize)
    inline = len(plats) == 1
    if inline:                                        # one account icon: icon left of the name, same height
        T = int(fsize * 1.02)
    row_w = len(plats) * T + (len(plats) - 1) * gap
    tw = int(font.getlength(name) * 1.15) + 60
    Wd = (T + tw + 80) if inline else max(row_w, tw) + 40
    Hd = (int(fsize * 1.5) + 40) if inline else T + int(fsize * 1.25) + 60
    img = Image.new("RGBA", (Wd, Hd), (0, 0, 0, 0))
    # tiles
    x = 20 if inline else (Wd - row_w) // 2
    accent = b.get("accent")
    for p in plats:
        bg, fg = TILES.get(p, ("#222222", "#FFFFFF"))
        tile = Image.new("RGBA", (T + 12, T + 12), (0, 0, 0, 0))
        d = ImageDraw.Draw(tile)
        d.rounded_rectangle([0, 0, T + 11, T + 11], radius=int(T * 0.26), fill=(0, 0, 0, 255))          # outline
        d.rounded_rectangle([6, 6, T + 5, T + 5], radius=int(T * 0.22), fill=bg)
        ic = brand_icon(p if p != "kick_dark" else "kick", 256, fg)
        if ic:
            icon = Image.open(ic).convert("RGBA")
            s_ = int(T * 0.62)
            icon = icon.resize((s_, s_), Image.LANCZOS)
            tile.alpha_composite(icon, ((T + 12 - s_) // 2, (T + 12 - s_) // 2))
        img.alpha_composite(tile, (max(0, x - 6), (Hd - T) // 2 - 6 if inline else 10))
        if accent is None and p == b.get("platform", plats[0]):
            accent = bg
        x += T + gap
    # username: italic (sheared), thick black stroke, accent outer stroke, drop shadow
    acc = accent or "#53FC19"
    txt = Image.new("RGBA", (tw + 80, int(fsize * 1.5)), (0, 0, 0, 0))
    d = ImageDraw.Draw(txt)
    pos = (40, int(fsize * 0.12))
    d.text(pos, name, font=font, fill=acc, stroke_width=int(fsize * 0.16), stroke_fill=acc)
    d.text(pos, name, font=font, fill="#FFFFFF", stroke_width=int(fsize * 0.09), stroke_fill="#000000")
    shear = 0.18
    txt = txt.transform((txt.width + int(txt.height * shear), txt.height), Image.AFFINE,
                        (1, shear, -txt.height * shear, 0, 1, 0), Image.BICUBIC)
    shadow = Image.new("RGBA", txt.size, (0, 0, 0, 0))
    shadow.putalpha(txt.getchannel("A").point(lambda v: int(v * 0.55)))
    shadow = shadow.filter(ImageFilter.GaussianBlur(6))
    ty = (Hd - txt.height) // 2 if inline else T + 30
    tx = T + 10 if inline else (Wd - txt.width) // 2
    img.alpha_composite(shadow, (max(0, tx + 6), ty + 8))
    img.alpha_composite(txt, (max(0, tx), ty))
    bb = img.getbbox()
    img = img.crop(bb) if bb else img
    img.save(out)
    return out, img.width, img.height


def from_url(url, preset=None):
    """kick.com/x, twitch.tv/x, youtube.com/@x, tiktok.com/@x, x.com/x -> banner dict for that account."""
    import re
    pats = [("kick", r"kick\.com/([A-Za-z0-9_\-]+)"), ("twitch", r"twitch\.tv/([A-Za-z0-9_]+)"),
            ("youtube", r"youtube\.com/@([A-Za-z0-9_.\-]+)"), ("tiktok", r"tiktok\.com/@([A-Za-z0-9_.]+)"),
            ("x", r"(?:x|twitter)\.com/([A-Za-z0-9_]+)")]
    for plat, rx in pats:
        m = re.search(rx, url or "", re.I)
        if m and m.group(1).lower() not in ("videos", "clips", "video", "watch", "channel"):
            b = {"platform": plat, "handle": m.group(1)}
            if preset:
                b["preset"] = preset
            return b
    return None

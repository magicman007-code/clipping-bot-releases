"""Montage engine: sick edits, cinematic montages and trailers from many moments.

  python3 clipbot.py montage-build brief.json out.mp4 [--aspect 9:16|16:9] [--from-plan]

brief.json:
  {"name": "miami_trailer", "profile": "trailer"|"hype"|"cinematic"|"comedic"|"emotional"|"fast",
   "duration": 45, "music": "/path/licensed_track.mp3"|null, "music_start": 0,
   "title": "THE MIAMI HOUSE", "subtitle": "streaming live", "cards": ["THIS NOVEMBER", "ONE HOUSE", "NO RULES"],
   "intensity": 0.7, "grade": "teal_orange"|"film"|"bw_pop"|"none",
   "moments": [{"source": ".../source.mp4", "start": 12.0, "end": 40.0, "label": "pool fight", "score": 8,
                "line": [31.2, 34.0]}]}            # optional dialogue line to keep audible

Pipeline (each stage writes into <out>.plan.json, which stays editable - re-render with --from-plan
after swapping a shot's source/in-point/effects; nothing is ever flattened):
  1. music analysis   tempo, beat grid, downbeats, drop, per-beat energy (numpy, no extra deps)
  2. moment analysis  voice-energy peaks, dialogue lines from words.json, subject x for reframing
                      (cached per moment - variants reuse it)
  3. narrative plan   hook -> setup -> escalation -> payoff -> ending, per pacing profile;
                      shot lengths come from the beat grid, so cuts land on beats/downbeats
  4. render           per-shot reframe + speed + effects (punch, push-in, shake, RGB split, flash,
                      B&W-to-colour, bars, grain), title cards, xfades for cinematic,
                      music + dialogue + synthesized SFX (impact, riser, braam, whoosh, drone)
  5. verify           independent media checks on the result
Music must be licensed by the user; without music, trailers get a synthesized drone bed (license-free).
"""
import hashlib
import json
import os
import wave

import numpy as np

from .common import safe_remove, FONT_DIR, ffmpeg, log, probe

ASPECTS = {"9:16": (1080, 1920), "16:9": (1920, 1080), "1:1": (1080, 1080), "4:5": (1080, 1350)}
FPS = 30
PROFILES = {
    #            beats/shot pre-drop, post-drop, speed pre, fx level, transitions, bars, dialogue share
    "hype":      dict(pre=2, post=1, slowmo=0.6, fx=1.0, xfade=False, bars=False, dialog=0.15, max_dialog_beats=4, grade="punchy"),
    "fast":      dict(pre=1, post=0.5, slowmo=1.0, fx=0.8, xfade=False, bars=False, dialog=0.1, max_dialog_beats=2, grade="punchy"),
    "cinematic": dict(pre=4, post=2, slowmo=0.8, fx=0.35, xfade=True, bars=True, dialog=0.25, max_dialog_beats=8, grade="teal_orange"),
    "trailer":   dict(pre=4, post=1, slowmo=0.85, fx=0.7, xfade=False, bars=True, dialog=0.45, max_dialog_beats=8, grade="teal_orange"),
    "comedic":   dict(pre=4, post=2, slowmo=1.0, fx=0.4, xfade=False, bars=False, dialog=0.8, max_dialog_beats=12, grade="none"),
    # sick-edit styles
    "velocity":  dict(pre=2, post=1, slowmo=1.0, fx=1.0, xfade=False, bars=False, dialog=0.0, max_dialog_beats=2, grade="punchy",
                      velocity=True),
    "glam":      dict(pre=4, post=2, slowmo=0.5, fx=0.45, xfade=True, bars=False, dialog=0.0, max_dialog_beats=2, grade="glam",
                      glow=True),
    "emotional": dict(pre=8, post=4, slowmo=0.75, fx=0.15, xfade=True, bars=True, dialog=0.4, max_dialog_beats=12, grade="film"),
}


# ======================================================================= audio analysis
def _load_mono(path, sr, workdir, tag):
    wav = os.path.join(workdir, "%s_%d.wav" % (tag, sr))
    if not os.path.exists(wav):
        ffmpeg(["-i", path, "-vn", "-ac", "1", "-ar", str(sr), wav])
    with wave.open(wav, "rb") as wf:
        return np.frombuffer(wf.readframes(wf.getnframes()), dtype=np.int16).astype(np.float32) / 32768.0


def analyze_music(path, workdir, start=0.0):
    """Beat grid, downbeats, drop and per-beat energy. Spectral-flux onsets + autocorrelation tempo
    + phase search + local refinement; downbeat phase = the one with the most low-end (kick) energy."""
    sr, n_fft, hop = 22050, 2048, 256
    x = _load_mono(path, sr, workdir, "music")[int(start * sr):]
    if len(x) < sr * 4:
        raise ValueError("music too short")
    nfr = 1 + (len(x) - n_fft) // hop
    idx = np.arange(n_fft)[None, :] + hop * np.arange(nfr)[:, None]
    frames = x[idx] * np.hanning(n_fft)[None, :]
    mag = np.abs(np.fft.rfft(frames, axis=1))
    lo_bin = int(60 * n_fft / sr) + 1                  # ignore sub-bass swells (pads/808 tails), keep transients
    logm = np.log1p(10 * mag[:, lo_bin:])
    flux = np.concatenate([[0], np.maximum(0, np.diff(logm, axis=0)).sum(1)])
    low = np.log1p(10 * mag[:, lo_bin: int(170 * n_fft / sr)]).sum(1)
    lowflux = np.concatenate([[0], np.maximum(0, np.diff(low))])
    lowflux_n = lowflux / (lowflux.std() + 1e-9)
    flux_n = flux / (flux.std() + 1e-9)
    raw = flux_n + 1.5 * lowflux_n                        # kick/bass transients define the beat
    env = np.maximum(0, raw - np.convolve(raw, np.ones(32) / 32, mode="same"))
    env = env / (env.std() + 1e-9)
    fps = sr / hop
    # tempo: autocorrelation 70..180 bpm, log-gaussian prior around 120, parabolic sub-frame peak
    ac = np.correlate(env, env, mode="full")[len(env) - 1:]
    lags = np.arange(int(fps * 60 / 180), int(fps * 60 / 70) + 2)
    bpms = 60 * fps / lags
    sc = ac[lags] * np.exp(-0.5 * (np.log2(bpms / 120.0) / 0.9) ** 2)
    k = int(np.argmax(sc))
    if 0 < k < len(sc) - 1:
        a_, b_, c_ = sc[k - 1], sc[k], sc[k + 1]
        off = 0.5 * (a_ - c_) / (a_ - 2 * b_ + c_ + 1e-12)
    else:
        off = 0.0
    P = float(lags[k] + off)
    # dynamic-programming beat tracker (Ellis 2007): onsets vs. tempo-consistency penalty
    alpha = 100.0
    n = len(env)
    score, back = env.copy(), -np.ones(n, dtype=int)
    lo, hi = int(round(P / 2)), int(round(2 * P))
    prev = np.arange(-hi, -lo + 1)
    pen = -alpha * np.log(-prev / P) ** 2
    for t in range(hi, n):
        cand = score[t + prev] + pen
        q = int(np.argmax(cand))
        score[t] = env[t] + cand[q]
        back[t] = t + prev[q]
    t = int(np.argmax(score[-int(P * 2):])) + n - int(P * 2)
    beats = []
    while t >= 0:
        beats.append(t)
        t = back[t]
    beats = np.array(beats[::-1])
    lag = int(round(P))
    LATENCY = 0.07                                        # STFT window latency, calibrated on a click track
    # one global phase: anchor on the strongest kick, snap beats that drifted onto off-beats (e.g. hats in a
    # kick-less intro) back onto that grid
    kick_at = np.array([lowflux[max(0, b - 2):b + 3].max() for b in beats])
    if kick_at.max() > 3 * (np.median(kick_at) + 1e-9) or True:
        anchor = beats[int(np.argmax(kick_at))]
        r = ((beats - anchor) / P) % 1.0
        fix = (r > 0.25) & (r < 0.75)
        if fix.mean() < 0.6:
            beats = np.where(fix, np.round(anchor + np.round((beats - anchor) / P - r + np.where(r < 0.5, 0, 1)) * P), beats)
            beats = np.unique(beats.astype(int))
    bt = beats / fps + LATENCY
    # downbeat phase
    kick = [lowflux[max(0, b - 2):b + 3].max() for b in beats]
    ph4 = int(np.argmax([sum(kick[p::4]) for p in range(4)]))
    down = bt[ph4::4]
    # energy per beat + drop (largest rise of the 8-beat mean after the first 15%)
    rms = np.sqrt((frames ** 2).mean(1))
    e = np.array([rms[b:b + lag].mean() if b < len(rms) else 0 for b in beats])
    drop_i = None
    if len(e) > 24:
        rises = [(e[i:i + 8].mean() - e[i - 8:i].mean(), i) for i in range(max(8, int(len(e) * 0.15)), len(e) - 8)]
        r, i = max(rises)
        if r > 0.15 * e.mean():
            drop_i = i
    drop_t = float(bt[drop_i]) if drop_i is not None else None
    if drop_i is not None:
        Pt = P / fps                                 # drops land on a downbeat: anchor the bar phase there
        q = (bt - drop_t) / (4 * Pt)
        down = bt[np.abs(q - np.round(q)) < 0.08]
    return {"bpm": round(60 * fps / P, 1), "beats": [round(float(b) + start, 3) for b in bt],
            "downbeats": [round(float(d) + start, 3) for d in down], "drop": round(drop_t + start, 3) if drop_t else None,
            "beat_energy": [round(float(v), 4) for v in e / (e.max() + 1e-9)], "duration": round(len(x) / sr, 2)}


def synthetic_grid(duration, bpm=90.0):
    """A pulse grid for montages without music (trailer drone bed / dialogue-led edits)."""
    step = 60.0 / bpm
    beats = [round(i * step, 3) for i in range(int(duration / step) + 1)]
    return {"bpm": bpm, "beats": beats, "downbeats": beats[::4], "drop": round(duration * 0.62 / step) * step,
            "beat_energy": [min(1.0, 0.3 + i / max(1, len(beats))) for i in range(len(beats))], "duration": duration,
            "synthetic": True}


# ======================================================================= moment analysis
def analyze_moment(m, workdir):
    key = hashlib.md5(("%s|%s|%s" % (m["source"], m["start"], m["end"])).encode()).hexdigest()[:12]
    cache = os.path.join(workdir, "moment_%s.json" % key)
    if os.path.exists(cache):
        return json.load(open(cache))
    from .render import sample_faces, _real
    a, b = float(m["start"]), float(m["end"])
    small = os.path.join(workdir, "m_%s.mp4" % key)
    ffmpeg(["-ss", "%.3f" % a, "-t", "%.3f" % (b - a), "-i", m["source"], "-vf", "fps=6,scale=640:-2", "-c:v", "libx264",
            "-preset", "ultrafast", "-crf", "30", "-c:a", "aac", small])
    pr = probe(small)
    w0, h0 = pr["width"], pr["height"]
    samples = sample_faces(small, w0, h0, fps=2)
    track = []                                   # main subject per sample: the biggest real face
    for t_, fs in samples:
        rf = _real(fs, h0, 0.05)
        if rf:
            f = max(rf, key=lambda q: q[2] * q[3])
            track.append((round(a + t_, 2), round(f[0] / w0, 4), round(f[1] / h0, 4)))
    xs = [q[1] for q in track]
    ys = [q[2] for q in track]
    x = _load_mono(small, 8000, workdir, "m_%s" % key)
    hop = 4000
    k = len(x) // hop
    db = 20 * np.log10(np.sqrt((x[:k * hop].reshape(k, hop) ** 2).mean(1)) + 1e-4) if k else np.zeros(1)
    z = (db - np.median(db)) / (np.std(db) + 1e-6)
    peaks = sorted([(float(z[i]), round(a + i * 0.5, 2)) for i in range(len(z))], reverse=True)[:6]
    lines = []
    wj = os.path.join(os.path.dirname(os.path.abspath(m["source"])), "words.json")
    if os.path.exists(wj):
        from .moments import LEX, _rx
        from .transcribe import sentences_from_words
        ws = [w for w in json.load(open(wj)) if a <= w[0] and w[1] <= b]
        rx = [_rx(LEX[t]) for t in ("humor", "shock", "stakes", "drama", "story")]
        for s in sentences_from_words(ws, max_gap=0.6, max_len=6):
            d = s["end"] - s["start"]
            if 0.8 <= d <= 6:
                hits = sum(len(r.findall(s["text"])) for r in rx)
                lines.append({"start": round(s["start"], 2), "end": round(s["end"] + 0.15, 2), "text": s["text"],
                              "score": hits + 0.2 * len(s["text"].split())})
        lines.sort(key=lambda l: -l["score"])
    res = {"w": pr["width"], "h": pr["height"], "src_aspect": w0 / float(h0),
           "face_x": float(np.median(xs)) if xs else 0.5, "face_y": float(np.median(ys)) if ys else 0.45,
           "has_face": bool(xs), "track": track, "peaks": peaks, "lines": lines[:6], "energy": float(np.percentile(db, 90))}
    json.dump(res, open(cache, "w"))
    safe_remove(small)
    return res


# ======================================================================= narrative planner
def _order_moments(ms):
    """hook = strongest, then rising intensity, payoff = 2nd strongest, ending = a callback."""
    ranked = sorted(ms, key=lambda m: -(m.get("score") or m["_a"]["energy"]))
    if len(ranked) <= 2:
        return ranked
    hook, payoff = ranked[0], ranked[1]
    mid = sorted(ranked[2:], key=lambda m: (m.get("score") or 0) + 0.01 * m["_a"]["energy"])
    return [hook] + mid + [payoff]


def plan(brief, grid, workdir):
    prof = dict(PROFILES.get(brief.get("profile", "hype"), PROFILES["hype"]))
    inten = float(brief.get("intensity", 0.7))
    target = float(brief.get("duration", 30))
    if brief.get("profile") == "trailer":
        target = max(10.0, target - 3.5 - (2.6 if brief.get("title") else 0) - 2.5)   # cold open, title, button
    ms = [dict(m) for m in brief["moments"]]
    for m in ms:
        m["_a"] = analyze_moment(m, workdir)
    order = _order_moments(ms)
    beats = [b for b in grid["beats"] if b >= grid["beats"][0]]
    t0 = beats[0] if beats else 0.0
    drop = grid.get("drop") or (t0 + target * 0.45)
    if grid.get("synthetic"):
        drop = t0 + target * 0.55                  # no music: the climax starts a little past halfway
        step = 60.0 / grid["bpm"]
        drop = t0 + round((drop - t0) / step) * step
    used = {id(m): [] for m in order}
    shots, cards, sfx = [], [], []
    mi = 0
    t = t0
    is_trailer = brief.get("profile") == "trailer"
    card_texts = list(brief.get("cards") or [])
    end_t = t0 + target

    def next_beat(after, n):
        cand = [b for b in beats if b > after + 0.05]
        if len(cand) >= max(1, int(round(n))):
            return cand[max(1, int(round(n))) - 1]
        return after + n * 60.0 / grid["bpm"]

    def take(m, dur, prefer_line=False, prefer_peak=True):
        """choose an unused source window of `dur` seconds inside moment m."""
        a, b = float(m["start"]), float(m["end"])
        A = m["_a"]
        if prefer_line and A["lines"]:
            for ln in A["lines"]:
                if all(ln["end"] <= u[0] or ln["start"] >= u[1] for u in used[id(m)]):
                    used[id(m)].append((ln["start"], ln["end"]))
                    return ln["start"], ln["end"] - ln["start"], ln["text"]
        cands = [p[1] - dur * 0.35 for p in A["peaks"]] if prefer_peak else []
        cands += list(np.linspace(a, max(a, b - dur), 6))
        for s in cands:
            s = min(max(a, s), max(a, b - dur))
            if all(s + dur <= u[0] or s >= u[1] for u in used[id(m)]):
                used[id(m)].append((s, s + dur))
                return s, dur, None
        return a, min(dur, b - a), None

    # ---- trailer cold open: one dialogue line, no music
    if is_trailer:
        m = order[0]
        s, d, txt = take(m, 3.0, prefer_line=True)
        d = min(d, 4.0)
        shots.append(dict(role="cold_open", source=m["source"], src_in=round(s, 3), dur=round(d, 3), speed=1.0,
                          audio="dialogue", fx=["push_in"], label=m.get("label"), line=txt))
        t = max(t, t0)
        music_offset = d + 0.4
    else:
        music_offset = 0.0
    # ---- body
    while t < end_t - 0.3 and order:
        pre = t < drop
        if is_trailer and card_texts and (pre and len(shots) in (1, 4, 7) or (not pre and not any(c["at"] >= drop for c in cards))):
            ct = card_texts.pop(0)
            nb = next_beat(t, 4 if pre else 2)
            cards.append({"text": ct, "at": round(t, 3), "dur": round(nb - t, 3)})
            sfx.append({"kind": "boom" if not pre else "hit", "at": round(t, 3)})
            shots.append(dict(role="card", text=ct, dur=round(nb - t, 3)))
            t = nb
            continue
        m = order[mi % len(order)]
        mi += 1
        if pre:
            n_beats = prof["pre"] * (2 if prof["pre"] < 2 and inten < 0.5 else 1)
        else:
            n_beats = prof["post"] if (mi % 5) else max(prof["post"] * 2, 1)
        nb = next_beat(t, max(0.5, n_beats)) if n_beats >= 1 else t + 0.5 * 60.0 / grid["bpm"]
        if not pre and t < drop <= nb:
            nb = drop
        dur = nb - t
        if dur < 0.18:
            t = nb
            continue
        speed = prof["slowmo"] if pre and prof["slowmo"] < 1 else 1.0
        role = "setup" if pre else ("payoff" if t > end_t - 3 * 60.0 / grid["bpm"] else "escalation")
        if len(shots) == 0 or (shots and shots[-1].get("role") == "cold_open"):
            role = "hook"
        climax_music_only = (not pre) and brief.get("profile", "hype") in ("hype", "fast", "trailer")
        dialog = (not climax_music_only) and (np.random.RandomState(mi).rand() < prof["dialog"]) and m["_a"]["lines"]
        if dialog:
            s, d, txt = take(m, dur, prefer_line=True)
            nbeats = max(1, min(prof.get("max_dialog_beats", 8), round(d / (60.0 / grid["bpm"]))))
            nb = next_beat(t, nbeats)
            if not pre and t < drop <= nb:
                nb = drop
            dur = nb - t
            shots.append(dict(role=role, source=m["source"], src_in=round(s, 3), dur=round(dur, 3), speed=1.0,
                              audio="dialogue", fx=_fx_for(role, pre, prof, inten, t, drop, grid), label=m.get("label"),
                              line=txt))
        else:
            s, d, _ = take(m, dur * speed)
            shots.append(dict(role=role, source=m["source"], src_in=round(s, 3), dur=round(dur, 3), speed=speed,
                              audio="music", fx=_fx_for(role, pre, prof, inten, t, drop, grid), label=m.get("label")))
        if abs(t - drop) < 0.05:
            sfx.append({"kind": "impact", "at": round(t, 3)})
            sfx.append({"kind": "riser_end", "at": round(t, 3)})
        t = nb
    # ---- ending: title card (+ trailer button line after it)
    if brief.get("title"):
        shots.append(dict(role="title", text=brief["title"], sub=brief.get("subtitle", ""), dur=2.6))
        sfx.append({"kind": "braam" if is_trailer else "impact", "at": round(t, 3)})
    if is_trailer and len(order) > 1:
        m = order[-1]
        s, d, txt = take(m, 2.5, prefer_line=True)
        shots.append(dict(role="button", source=m["source"], src_in=round(s, 3), dur=round(min(d, 3.5), 3), speed=1.0,
                          audio="dialogue", fx=[], label=m.get("label"), line=txt))
    return {"profile": brief.get("profile", "hype"), "grid": grid, "music_offset": round(music_offset, 3),
            "shots": shots, "sfx": sfx, "grade": brief.get("grade", prof["grade"]), "bars": prof["bars"],
            "xfade": prof["xfade"], "fx_level": prof["fx"] * inten,
            "moments": {m["source"] + "@%s" % m["start"]: m["_a"] for m in order}}


def _fx_for(role, pre, prof, inten, t, drop, grid):
    fx = []
    lvl = prof["fx"] * inten
    if role == "hook":
        fx.append("push_in")
    if pre:
        if prof["slowmo"] < 1:
            fx.append("slowmo")
        if lvl > 0.5:
            fx.append("desat")
    else:
        if any(abs(t - d) < 0.05 for d in grid["downbeats"]) and lvl > 0.3:
            fx.append("flash")
        if lvl > 0.5:
            fx.append("punch")
    if abs(t - drop) < 0.05 and lvl > 0.3:
        fx += ["flash", "shake", "rgb"]
    if prof.get("velocity"):
        fx = [f for f in fx if f != "punch"]
        fx.append("velocity")                         # fast-in, slow-out ramp on every shot
        if any(abs(t - d) < 0.05 for d in grid["downbeats"]):
            fx += ["zoom_blur", "flash"]
    if prof.get("glow"):
        fx = [f for f in fx if f not in ("desat", "shake", "rgb", "punch")]
        fx.append("glow")
        if any(abs(t - d) < 0.05 for d in grid["downbeats"]):
            fx.append("soft_flash")
    return sorted(set(fx))


# ======================================================================= sound design (synthesized, license-free)
def sfx_file(kind, workdir):
    p = os.path.join(workdir, "sfx_%s.wav" % kind)
    if os.path.exists(p):
        return p
    expr = {
        "impact": "0.9*sin(2*PI*(45+60*exp(-8*t))*t)*exp(-3.2*t)",
        "boom": "0.8*sin(2*PI*(38+40*exp(-5*t))*t)*exp(-1.6*t)",
        "hit": "0.6*sin(2*PI*(70+90*exp(-14*t))*t)*exp(-6*t)",
        "braam": "0.35*(sin(2*PI*55*t)+0.6*sin(2*PI*110.4*t)+0.45*sin(2*PI*165*t)+0.3*sin(2*PI*220.8*t)+0.2*sin(2*PI*277*t))"
                 "*min(1,t*12)*exp(-0.55*t)",
        "riser": "0.25*sin(2*PI*(120+700*t*t/9)*t)*(t/3)",
        "drone": "0.18*sin(2*PI*55*t)*(0.75+0.25*sin(2*PI*0.25*t))+0.1*sin(2*PI*82.4*t)+0.06*sin(2*PI*110*t)",
    }
    dur = {"impact": 1.6, "boom": 2.8, "hit": 0.8, "braam": 4.0, "riser": 3.0, "drone": 120}[kind]
    src = "aevalsrc='%s':s=48000:d=%.2f" % (expr[kind], dur)
    if kind in ("impact", "boom", "riser"):
        ffmpeg(["-f", "lavfi", "-i", src, "-f", "lavfi", "-i", "anoisesrc=d=%.2f:c=pink:a=0.6:r=48000" % dur,
                "-filter_complex", "[1]lowpass=f=%d,volume='%s':eval=frame[n];[0][n]amix=2:normalize=0,alimiter=limit=0.9"
                % (400 if kind != "riser" else 6000, "exp(-4*t)" if kind != "riser" else "(t/3)^2"),
                "-ac", "2", p])
    else:
        ffmpeg(["-f", "lavfi", "-i", src, "-af", "lowpass=f=2500,alimiter=limit=0.9" if kind == "braam" else "lowpass=f=900",
                "-ac", "2", p])
    return p


# ======================================================================= render
GRADES = {
    "none": "",
    "punchy": "eq=contrast=1.12:saturation=1.3,unsharp=5:5:0.6",
    "teal_orange": "colorbalance=rs=-0.06:bs=0.08:rm=0.03:bm=-0.03:rh=0.07:bh=-0.07,eq=contrast=1.1:saturation=1.12",
    "film": "curves=preset=vintage,eq=saturation=0.88,noise=alls=7:allf=t",
    "bw_pop": "hue=s=0,eq=contrast=1.25",
    "glam": "colorbalance=rs=0.05:gs=0.01:bs=-0.04:rh=0.06:bh=-0.03,eq=contrast=1.04:saturation=1.08:gamma=1.04",
}


def _font(name="Anton-Regular.ttf"):
    from .common import fpath
    return fpath(os.path.join(FONT_DIR, name))


def _title_font(plan_):
    """Title-card font from the brief ("font": any bundled/uploaded family), default Anton."""
    from .common import fpath
    from .fonts import find
    p = find(plan_.get("font")) if plan_.get("font") else None
    return fpath(p) if p else _font()


def _esc_dt(s):
    return s.replace("\\", "").replace(":", "\\:").replace("'", "’").replace("%", "\\%")


_DUR = {}


def _src_duration(path):
    if path not in _DUR:
        try:
            _DUR[path] = probe(path)["duration"]
        except Exception:
            _DUR[path] = 0.0
    return _DUR[path]


def render_shot(sh, i, W, H, plan_, workdir):
    out = os.path.join(workdir, "shot_%03d.mp4" % i)
    d = sh["dur"]
    n = max(1, int(round(d * FPS)))
    lvl = plan_["fx_level"]
    if sh["role"] in ("card", "title"):
        big = sh["role"] == "title"
        size = int(min(W, H) * (0.13 if big else 0.085))
        txt = _esc_dt(sh["text"].upper())
        vf = ("drawtext=fontfile=%s:text='%s':fontsize=%d:fontcolor=white:x=(w-tw)/2:y=(h-th)/2:"
              "alpha='min(1,t/0.35)*min(1,(%.3f-t)/0.25)'" % (_title_font(plan_), txt, size, d))
        if big and sh.get("sub"):
            vf += (",drawtext=fontfile=%s:text='%s':fontsize=%d:fontcolor=0xBFC4CC:x=(w-tw)/2:y=(h/2)+%d:"
                   "alpha='min(1,max(0,t-0.4)/0.4)'" % (_font("Montserrat-Black.ttf"), _esc_dt(sh["sub"].upper()),
                                                     int(size * 0.32), int(size * 0.85)))
        vf += ",zoompan=z='1+0.0006*on':d=1:s=%dx%d:fps=%d" % (W, H, FPS) if big else ""
        ffmpeg(["-f", "lavfi", "-i", "color=c=0x07080A:s=%dx%d:r=%d:d=%.3f" % (W, H, FPS, d), "-vf", vf,
                "-frames:v", str(n), "-c:v", "libx264", "-preset", "veryfast", "-crf", "16", "-pix_fmt", "yuv420p", out])
        return out
    A = plan_["moments"].get(sh.get("_mkey")) or {}
    speed = float(sh.get("speed", 1.0))
    src_len = d * speed
    vel = "velocity" in set(sh.get("fx", []))
    if vel:     # first 45% of the shot at 2.6x, then 0.4x: the classic velocity edit
        d1, s1, s2 = 0.45 * d, 2.6, 0.4
        src_len = d1 * s1 + (d - d1) * s2
        A1 = d1 * s1
    sw, shh = A.get("w", 1920), A.get("h", 1080)
    # reframe: crop the source to the output aspect around the subject, else blur-fit
    tgt = W / float(H)
    src_ar = sw / float(shh)
    fx = set(sh.get("fx", []))
    fxw = [q[1] for q in A.get("track", []) if sh["src_in"] - 0.3 <= q[0] <= sh["src_in"] + src_len + 0.3]
    face_x = float(np.median(fxw)) if fxw else A.get("face_x", 0.5)
    if src_ar > tgt * 1.05 and A.get("has_face", True):
        crop_w = "ih*%.5f" % tgt
        cx = "min(max(iw*%.4f-%s/2,0),iw-%s)" % (face_x, crop_w, crop_w)
        base = "crop=%s:ih:'%s':0,scale=%d:%d:flags=lanczos" % (crop_w, cx, W, H)
    elif abs(src_ar - tgt) < 0.05 * tgt:
        base = "scale=%d:%d:flags=lanczos" % (W, H)
    else:
        base = None
    chain = []
    if vel:
        chain.append("setpts='(if(lt(T,%.4f),T/%.3f,%.4f/%.3f+(T-%.4f)/%.3f))/TB'" % (A1, s1, A1, s1, A1, s2))
    elif speed != 1.0:
        chain.append("setpts=PTS/%.4f" % speed)
    chain.append("fps=%d" % FPS)
    if base:
        chain.append(base)
    # dynamic zoom: push-in over the shot, or a snap punch on its first beat
    z = None
    if "push_in" in fx:
        z = "1+%.3f*t/%.3f" % (0.06 + 0.05 * lvl, max(0.1, d))
    if "punch" in fx:
        z = "if(lt(t,0.12),%.3f,1+0.02*t)" % (1.08 + 0.06 * lvl)
    if "shake" in fx:
        amp = int(10 + 22 * lvl)
        chain.append("scale=%d:%d,crop=%d:%d:'%d+%d*sin(t*55)*exp(-3*t)':'%d+%d*cos(t*47)*exp(-3*t)'" % (
            W + 2 * amp, H + 2 * amp, W, H, amp, amp, amp, amp))
    if z:
        chain.append("scale=w='2*trunc(%d*(%s)/2)':h='2*trunc(%d*(%s)/2)':eval=frame,crop=%d:%d" % (W, z, H, z, W, H))
    if "zoom_blur" in fx:
        chain.append("scale=w='2*trunc(%d*if(lt(t,0.14),1.22-1.5*t,1)/2)':h='2*trunc(%d*if(lt(t,0.14),1.22-1.5*t,1)/2)':"
                     "eval=frame,crop=%d:%d,gblur=sigma=14:steps=2:enable='lt(t,0.12)'" % (W, H, W, H))
    if "glow" in fx:
        chain.append("format=gbrp,split=2[g0][g1];[g1]gblur=sigma=18[g2];[g0][g2]blend=all_mode=screen:all_opacity=0.28,format=yuv420p")
    if "rgb" in fx:
        chain.append("rgbashift=rh=-%d:bh=%d:enable='lt(t,0.35)'" % (int(6 + 10 * lvl), int(6 + 10 * lvl)))
    if "desat" in fx:
        chain.append("hue=s=0.25")
    g = GRADES.get(plan_.get("grade") or "none", "")
    if g:
        chain.append(g)
    if plan_.get("bars"):
        bh = int(round((H - W / 2.39) / 2)) if W > H else int(H * 0.06)
        chain.append("drawbox=x=0:y=0:w=iw:h=%d:color=black:t=fill,drawbox=x=0:y=ih-%d:w=iw:h=%d:color=black:t=fill"
                     % (bh, bh, bh))
    if "flash" in fx:
        chain.append("fade=t=in:st=0:d=%.2f:color=white" % (0.10 + 0.08 * lvl))
    elif "soft_flash" in fx:
        chain.append("fade=t=in:st=0:d=0.25:color=0xFFF4E0")
    chain.append("vignette=angle=PI/9" if plan_.get("profile") in ("cinematic", "trailer", "emotional") else "null")
    chain.append("tpad=stop_mode=clone:stop_duration=3")      # never run short (source ending inside a ramp)
    chain.append("setsar=1,format=yuv420p")
    vf = ",".join(chain)
    src_dur = _src_duration(sh["source"])
    src_in = max(0.0, min(sh["src_in"], src_dur - src_len - 0.05)) if src_dur else sh["src_in"]
    ins = ["-ss", "%.3f" % src_in, "-t", "%.3f" % (src_len + 0.2), "-i", sh["source"]]
    if base is None:   # blur-fit for mismatched aspect / no subject
        fc = ("[0:v]%s,split=2[a][b];[a]scale=%d:%d:force_original_aspect_ratio=increase,crop=%d:%d,gblur=sigma=30,"
              "eq=brightness=-0.15[bg];[b]scale=%d:%d:force_original_aspect_ratio=decrease[fg];[bg][fg]overlay=(W-w)/2:(H-h)/2,%s[v]"
              % (",".join(chain[:2]), W, H, W, H, W, H, ",".join(chain[2:])))
        ffmpeg(ins + ["-filter_complex", fc, "-map", "[v]", "-an", "-frames:v", str(n), "-c:v", "libx264", "-preset",
                      "veryfast", "-crf", "16", out])
    else:
        ffmpeg(ins + ["-vf", vf, "-an", "-frames:v", str(n), "-c:v", "libx264", "-preset", "veryfast", "-crf", "16", out])
    return out


def build(brief, out, aspect=None, from_plan=False, workdir=None):
    aspect = aspect or brief.get("aspect", "9:16")
    W, H = ASPECTS[aspect]
    workdir = workdir or os.path.splitext(out)[0] + "_work"
    os.makedirs(workdir, exist_ok=True)
    plan_path = os.path.splitext(out)[0] + ".plan.json"
    if from_plan and os.path.exists(plan_path):
        P = json.load(open(plan_path))
        log("montage: re-rendering edited plan %s" % plan_path)
    else:
        music = brief.get("music")
        if music and os.path.exists(music):
            grid = analyze_music(music, workdir, float(brief.get("music_start", 0)))
        else:
            grid = synthetic_grid(float(brief.get("duration", 30)) + 10)
        P = plan(brief, grid, workdir)
        P["music"] = music if music and os.path.exists(music) else None
        P["font"] = brief.get("font")
        P["music_start"] = float(brief.get("music_start", 0))
        for sh in P["shots"]:
            if "source" in sh:
                m = next(m for m in brief["moments"] if m["source"] == sh["source"] and
                         float(m["start"]) - 0.01 <= sh["src_in"] <= float(m["end"]) + 0.01)
                sh["_mkey"] = m["source"] + "@%s" % m["start"]
        json.dump(P, open(plan_path, "w"), indent=1)
    # ---- shots
    files = []
    for i, sh in enumerate(P["shots"]):
        files.append(render_shot(sh, i, W, H, P, workdir))
    durs = [s["dur"] for s in P["shots"]]
    # ---- video concat (+ cross-dissolves for cinematic profiles)
    ins = []
    for f in files:
        ins += ["-i", f]
    if P.get("xfade") and len(files) > 1:
        fc, last, acc = [], "[0:v]", durs[0]
        for k in range(1, len(files)):
            xd = min(0.35, durs[k] / 3, durs[k - 1] / 3)
            fc.append("%s[%d:v]xfade=transition=fade:duration=%.3f:offset=%.3f[x%d]" % (last, k, xd, acc - xd, k))
            last, acc = "[x%d]" % k, acc + durs[k] - xd
        total = acc
        vmap = last
    else:
        fc = ["".join("[%d:v]" % k for k in range(len(files))) + "concat=n=%d:v=1:a=0[vc]" % len(files)]
        total, vmap = sum(durs), "[vc]"
    starts, t = [], 0.0
    for k, d in enumerate(durs):
        starts.append(t)
        t += d - (min(0.35, d / 3, durs[k - 1] / 3) if P.get("xfade") and k > 0 and k < len(durs) else 0)
    vid = os.path.join(workdir, "video.mp4")
    ffmpeg(ins + ["-filter_complex", ";".join(fc), "-map", vmap, "-c:v", "libx264", "-preset", "medium", "-crf", "17",
                  "-pix_fmt", "yuv420p", "-r", str(FPS), vid], timeout=7200)
    # ---- audio: music bed (ducked under dialogue) + dialogue + sfx
    a_ins, a_fc, mix = ["-i", vid], [], []
    idx = 1
    dlg = [(starts[k], sh) for k, sh in enumerate(P["shots"]) if sh.get("audio") == "dialogue"]
    if P.get("music"):
        a_ins += ["-ss", "%.3f" % P["music_start"], "-i", P["music"]]
        duck = "+".join("between(t,%.2f,%.2f)" % (s0 - 0.1, s0 + sh["dur"]) for s0, sh in dlg) or "0"
        mo = P.get("music_offset", 0.0)
        a_fc.append("[%d:a]aresample=48000,aformat=channel_layouts=stereo,adelay=%d|%d,"
                    "volume='if(%s,0.22,1)':eval=frame,afade=t=out:st=%.2f:d=1.5[mus]"
                    % (idx, int(mo * 1000), int(mo * 1000), duck, max(0, total - 1.5)))
        mix.append("[mus]")
        idx += 1
    elif P["profile"] in ("trailer", "cinematic", "emotional"):
        a_ins += ["-i", sfx_file("drone", workdir)]
        a_fc.append("[%d:a]atrim=0:%.3f,afade=t=in:d=1.5,afade=t=out:st=%.2f:d=2,volume=0.9[mus]"
                    % (idx, total, max(0, total - 2)))
        mix.append("[mus]")
        idx += 1
    for k, (s0, sh) in enumerate(dlg):
        a_ins += ["-ss", "%.3f" % sh["src_in"], "-t", "%.3f" % sh["dur"], "-i", sh["source"]]
        a_fc.append("[%d:a]aresample=48000,aformat=channel_layouts=stereo,highpass=f=80,acompressor=threshold=-20dB:ratio=3,"
                    "afade=t=in:d=0.04,afade=t=out:st=%.3f:d=0.08,volume=1.6,adelay=%d|%d[d%d]"
                    % (idx, max(0, sh["dur"] - 0.08), int(s0 * 1000), int(s0 * 1000), k))
        mix.append("[d%d]" % k)
        idx += 1
    for k, e in enumerate(P["sfx"]):
        kind = {"riser_end": "riser"}.get(e["kind"], e["kind"])
        at = e["at"] - P["grid"]["beats"][0] + P.get("music_offset", 0) if P["grid"]["beats"] else e["at"]
        if e["kind"] == "riser_end":
            at -= 3.0
        if at < 0:
            continue
        a_ins += ["-i", sfx_file(kind, workdir)]
        a_fc.append("[%d:a]volume=%.2f,adelay=%d|%d[s%d]" % (idx, 0.9 if kind != "riser" else 0.6, int(at * 1000),
                                                              int(at * 1000), k))
        mix.append("[s%d]" % k)
        idx += 1
    if not mix:
        a_ins += ["-f", "lavfi", "-i", "anullsrc=r=48000:cl=stereo"]
        mix.append("[%d:a]" % idx)
    a_fc.append("%samix=inputs=%d:duration=longest:normalize=0,atrim=0:%.3f,alimiter=limit=0.95[am]" % (
        "".join(mix), len(mix), total))
    a_fc.append("[am]loudnorm=I=-14:TP=-2:LRA=11,aresample=192000,alimiter=limit=0.70:level=false,aresample=48000[aout]")
    ffmpeg(a_ins + ["-filter_complex", ";".join(a_fc), "-map", "0:v", "-map", "[aout]", "-c:v", "copy", "-c:a", "aac",
                    "-b:a", "192k", "-ar", "48000", "-movflags", "+faststart", "-t", "%.3f" % total, out], timeout=7200)
    from .verify import verify_file
    v = verify_file(out, check_wer=False, expect=(W, H), max_silence=2.5)
    intentional = []
    if P.get("bars"):
        intentional.append("letterbox")       # cinematic bars are a style choice
    if any(s["role"] in ("card", "title") for s in P["shots"]):
        intentional.append("black frames")    # title cards are dark by design
    v["intentional"] = [d for d in v["defects"] if any(d.startswith(k) for k in intentional)]
    v["defects"] = [d for d in v["defects"] if d not in v["intentional"]]
    v["ok"] = not v["defects"]
    res = {"out": out, "plan": plan_path, "aspect": aspect, "duration": round(total, 2), "shots": len(P["shots"]),
           "bpm": P["grid"]["bpm"], "drop": P["grid"].get("drop"), "verify": v,
           "structure": [(s["role"], round(s["dur"], 2)) for s in P["shots"]]}
    json.dump(res, open(os.path.splitext(out)[0] + ".result.json", "w"), indent=1)
    return res

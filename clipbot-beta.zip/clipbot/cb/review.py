"""Clip ledger (for learning what performs), posting copy, and a static review gallery."""
import html
import json
import os
import time

from .common import ROOT

LEDGER = os.path.join(ROOT, "ledger.jsonl")


def ledger_append(res, spec):
    """One line per delivered clip with the features that might explain performance later
    (layout, length, caption style, teaser, tightening, hook stats). Paste views/retention from
    YouTube Studio into the 'perf' field later and compare like with like."""
    row = {"ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "name": res.get("name"), "file": res.get("out"),
           "source": spec.get("source"), "headline": res.get("headline"), "title": spec.get("title"),
           "dur": res.get("dur"), "layout": res.get("layout"), "captions": res.get("caption_style"),
           "teaser": bool(res.get("teaser")), "tightened_s": res.get("tightened_s"),
           "first_word_at": res.get("first_word_at"), "words_first3s": res.get("words_first3s"),
           "speakers": res.get("speakers"), "qa_ok": res.get("qa", {}).get("ok"), "perf": None}
    with open(LEDGER, "a") as f:
        f.write(json.dumps(row) + "\n")


def write_posts(results, outdir):
    lines = ["# Posting copy", ""]
    for r in results:
        if "error" in r:
            continue
        lines += ["## %s" % r["name"], "- file: `%s`" % r["out"],
                  "- title: %s" % (r.get("title") or r.get("headline", "")),
                  "- description: %s" % (r.get("description") or ""),
                  "- hashtags: %s" % (r.get("hashtags") or ""), ""]
    p = os.path.join(outdir, "posts.md")
    open(p, "w").write("\n".join(lines))
    return p


def write_gallery(results, outdir):
    cards = []
    for r in results:
        if "error" in r:
            cards.append("<div class=card bad><h3>%s</h3><pre>%s</pre></div>" % (html.escape(r["name"]),
                                                                                 html.escape(r["error"][:800])))
            continue
        q = r.get("qa", {})
        warn = "".join("<li>%s</li>" % html.escape(w) for w in q.get("warnings", []))
        cards.append(
            "<div class='card %s'><video src='%s' controls playsinline preload=metadata></video>"
            "<h3>%s</h3><p class=h>%s</p><p class=m>%.1fs · %s · %s captions%s</p><ul>%s</ul>"
            "<details><summary>transcript</summary><p>%s</p></details></div>" % (
                "ok" if q.get("ok") else "warn", html.escape(os.path.basename(r["out"])), html.escape(r["name"]),
                html.escape(r.get("headline", "")), r.get("dur", 0), html.escape(r.get("layout", "")),
                html.escape(r.get("caption_style", "")), " · teaser" if r.get("teaser") else "", warn,
                html.escape(r.get("text", ""))))
    doc = """<!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1">
<title>Clip review</title><style>
:root{--bg:#0f1115;--fg:#e8e8ea;--mut:#9aa0aa;--ok:#2ecc71;--warn:#f5b041;--card:#181b22}
body{margin:0;background:var(--bg);color:var(--fg);font:14px/1.4 system-ui,sans-serif;padding:16px}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:16px}
.card{background:var(--card);border-radius:12px;padding:10px;border-top:3px solid var(--ok)}
.card.warn{border-top-color:var(--warn)} .card.bad{border-top-color:#e74c3c}
video{width:100%%;aspect-ratio:9/16;background:#000;border-radius:8px} h3{margin:8px 0 2px;font-size:15px}
.h{font-weight:600;margin:0} .m{color:var(--mut);margin:4px 0} ul{color:var(--warn);padding-left:18px;margin:4px 0}
</style><h1>Clip review</h1><div class=grid>%s</div>""" % "".join(cards)
    p = os.path.join(outdir, "review.html")
    open(p, "w").write(doc)
    return p

"""Titles and thumbnails.

titles(): 8 title options from the clip's own transcript, from plain to maximum-curiosity, each tagged
with whether every concrete claim in it (numbers, names, outcomes) is actually said in the clip.
Unsupported claims are flagged, not hidden: misleading titles get punished by "viewed vs swiped" and
satisfaction signals, and clipping campaigns reject them.

thumbnail(): picks the most expressive, sharpest frame with a face, punches the colour, and adds big
outlined text (+ optional emoji, arrow, circle) in 16:9 (YouTube) and 9:16 (cover) versions.
"""
import os
import re

import numpy as np

from .common import FONT_DIR, YUNET, probe

EMOJI_BY_TONE = {"money": "💰", "shock": "😳", "fail": "💀", "win": "🔥", "laugh": "😭", "drama": "😤"}


OUTCOME_RX = re.compile(r"\b(lost|won|rugged|sold|bought|hit|crashed|exposed|caught|quit|banned|failed|beat|cried|fired|"
                        r"scammed|dumped|made|turned|10x'?d|50x|100x)\b", re.I)
NUM_RX = re.compile(r"\$\s?\d[\d,.]*\s?(?:k|m|million|thousand)?|\b\d+(?:\.\d+)?\s?(?:x|k|m|%)(?![a-z])|"
                    r"\b(?:(?:one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|fifteen|twenty|fifty|a|"
                    r"hundred)\s)?(?:hundred|thousand|million|billion|grand|k)\b(?:\s(?:dollars|bucks))?", re.I)
BASE = {"lost": "lose", "won": "win", "sold": "sell", "bought": "buy", "hit": "hit", "crashed": "crash", "made": "make",
        "turned": "turn", "beat": "beat", "quit": "quit", "failed": "fail", "cried": "cry", "rugged": "get rugged"}
STOPCAPS = {"The", "And", "But", "That", "This", "What", "When", "Then", "Wait", "Let", "Okay", "Yeah", "So", "Oh", "No",
            "Turns", "Bro", "God", "Let's", "Lets", "My", "Our", "Its", "It's", "I'm"}


def facts(text, names=()):
    """Claims are taken PER SENTENCE so an outcome is never paired with a number from another line."""
    sents = [x.strip() for x in re.split(r"(?<=[.!?])\s+", text) if x.strip()]
    pairs = []
    for sn in sents:
        o, n = OUTCOME_RX.search(sn), NUM_RX.search(sn)
        if o and n:
            subj = [w for w in re.findall(r"\b([A-Z][a-zA-Z0-9]{2,})\b", sn[:o.start()]) if w not in STOPCAPS]
            pairs.append({"outcome": o.group(1).lower(), "number": n.group(0).strip(), "sentence": sn,
                          "who": subj[-1] if subj else None})
    caps = []
    for sn in sents:
        for w in re.findall(r"\b([A-Z][a-zA-Z0-9]{2,})\b", sn):
            if w not in STOPCAPS and w not in caps:
                caps.append(w)
    t = text.lower()
    tone = ("money" if pairs or NUM_RX.search(text) else "") or ("fail" if re.search(r"\blost|rugged|crash|fail|scam", t) else "") \
        or ("laugh" if re.search(r"haha|i'?m dead|hilarious|lmao", t) else "") \
        or ("shock" if re.search(r"no way|oh my god|can'?t believe", t) else "") or "win"
    return {"pairs": pairs, "who": list(names) + caps, "tone": tone, "sentences": sents}


def _supported(title, text):
    """Each number must appear in a sentence that also has the title's outcome verb (if any)."""
    sents = [x.lower() for x in re.split(r"(?<=[.!?])\s+", text)]
    nums = [m.group(0).strip().lower() for m in NUM_RX.finditer(title)]
    outs = [m.group(1).lower() for m in OUTCOME_RX.finditer(title)]
    missing = []
    for n in nums:
        ok = any(n in sn and (not outs or any(o in sn for o in outs)) for sn in sents)
        if not ok:
            missing.append(n + (" with '%s'" % outs[0] if outs else ""))
    if not nums:
        for o in outs:
            if not any(re.search(r"\b%s\b" % re.escape(o), sn) for sn in sents):
                missing.append(o)
    return not missing, missing


def titles(text, names=(), headline=""):
    f = facts(text, names)
    named = bool(f["who"])
    who = f["who"][0] if named else "He"
    poss = (who + "'s") if named else "his"
    emo = EMOJI_BY_TONE.get(f["tone"], "🔥")
    first = f["sentences"][0][:80] if f["sentences"] else ""
    pr = f["pairs"][0] if f["pairs"] else None
    raw = [("plain", headline or first)]
    if pr:
        o, n = pr["outcome"], pr["number"]
        who_c = pr["who"] or "He"           # the claim's own subject, never a name from another line
        raw += [("specific", "%s %s %s on stream" % (who_c, o, n)),
                ("stakes", "%s %s %s %s" % (who_c, o, n, emo)),
                ("question", "How did %s %s %s?" % (pr["who"] or "he", BASE.get(o, o), n)),
                ("caps", "%s JUST %s %s %s" % (who_c.upper(), o.upper(), n.upper(), emo))]
    raw += [("quote", "\"%s\"" % first.rstrip(".")),
            ("curiosity", "%s didn't see this coming %s" % (who, emo)),
            ("wait", "Wait for %s reaction %s" % (poss, emo)),
            ("watch", "Watch %s face when it happens %s" % (poss if named else "his", emo))]
    res, seen = [], set()
    for style, t in raw:
        t = re.sub(r"\s+", " ", t).strip()
        if not t or t.lower() in seen:
            continue
        seen.add(t.lower())
        ok, miss = _supported(t, text)
        res.append({"style": style, "title": t, "chars": len(t), "supported": ok,
                    "note": None if ok else "claim not said in the clip: %s" % ", ".join(miss)})
    return res


# ---------------------------------------------------------------- thumbnails
def _best_frame(video, a=None, b=None, n=40):
    import cv2
    pr = probe(video)
    a = a or 0.0
    b = b or pr["duration"]
    cap = cv2.VideoCapture(video)
    w0, h0 = pr["width"], pr["height"]
    aw = 640
    ah = int(aw * h0 / w0)
    det = cv2.FaceDetectorYN.create(YUNET, "", (aw, ah), 0.6, 0.3, 5000)
    best = None
    for t in np.linspace(a + 0.3, b - 0.3, n):
        cap.set(cv2.CAP_PROP_POS_MSEC, t * 1000)
        ok, img = cap.read()
        if not ok:
            continue
        small = cv2.resize(img, (aw, ah))
        _, fs = det.detect(small)
        gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
        sharp = cv2.Laplacian(gray, cv2.CV_64F).var()
        sc, face = 0.1 * min(sharp, 500) / 500, None
        if fs is not None and len(fs):
            f = max(fs, key=lambda r: r[2] * r[3])
            x, y, fw, fh = f[:4]
            lm = f[4:14].reshape(5, 2)
            mouth = gray[int(min(lm[3][1], lm[4][1])):int(min(ah, lm[3][1] + fh * 0.25)),
                         int(min(lm[3][0], lm[4][0])):int(max(lm[3][0], lm[4][0]) + 1)]
            open_ = float(mouth.std()) / 64 if mouth.size else 0       # open mouth = dark cavity = contrast
            sc += 1.0 + (fw * fh) / (aw * ah) * 3 + open_ + float(f[14])
            k = w0 / float(aw)
            face = (x * k, y * k, fw * k, fh * k)
        if best is None or sc > best[0]:
            best = (sc, t, img, face)
    cap.release()
    return best


def thumbnail(video, out_base, text="", start=None, end=None, emoji=None, arrow=False, circle=False,
              accent="#FFD93D", sizes=((1280, 720), (1080, 1920))):
    import cv2
    from PIL import Image, ImageDraw, ImageEnhance, ImageFont
    sc, t, img, face = _best_frame(video, start, end)
    src = Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    src = ImageEnhance.Color(src).enhance(1.35)
    src = ImageEnhance.Contrast(src).enhance(1.15)
    src = ImageEnhance.Sharpness(src).enhance(1.4)
    outs = []
    for W, H in sizes:
        # crop around the face; in 16:9 put the face on the right third so text fits on the left
        sw, sh = src.size
        s = max(W / sw, H / sh) * (1.25 if face else 1.0)
        im = src.resize((int(sw * s), int(sh * s)), Image.LANCZOS)
        if face:
            fx, fy = (face[0] + face[2] / 2) * s, (face[1] + face[3] / 2) * s
        else:
            fx, fy = im.width / 2, im.height / 2
        tx = W * (0.68 if W > H else 0.5)
        ty = H * (0.45 if W > H else 0.40)
        x0 = int(min(max(0, fx - tx), im.width - W))
        y0 = int(min(max(0, fy - ty), im.height - H))
        canvas = im.crop((x0, y0, x0 + W, y0 + H)).convert("RGBA")
        d = ImageDraw.Draw(canvas)
        # darken the text side for legibility
        shade = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        sd = ImageDraw.Draw(shade)
        if W > H:
            for i in range(int(W * 0.6)):
                sd.line([(i, 0), (i, H)], fill=(0, 0, 0, int(150 * (1 - i / (W * 0.6)))))
        else:
            for i in range(int(H * 0.35)):
                sd.line([(0, H - i), (W, H - i)], fill=(0, 0, 0, int(170 * (1 - i / (H * 0.35)))))
        canvas.alpha_composite(shade)
        if text:
            words = text.upper().split()
            box_w = W * (0.56 if W > H else 0.9)
            size = int(H * (0.16 if W > H else 0.085))
            font = ImageFont.truetype(os.path.join(FONT_DIR, "Anton-Regular.ttf"), size)
            lines, cur = [], ""
            for w in words:
                if cur and font.getlength(cur + " " + w) > box_w:
                    lines.append(cur)
                    cur = w
                else:
                    cur = (cur + " " + w).strip()
            lines.append(cur)
            lines = lines[:3]
            y = int(H * 0.12) if W > H else int(H * 0.68)
            for i, ln in enumerate(lines):
                x = int(W * 0.05) if W > H else int((W - font.getlength(ln)) / 2)
                fill = accent if i == len(lines) - 1 else "#FFFFFF"
                d.text((x, y), ln, font=font, fill=fill, stroke_width=max(6, size // 10), stroke_fill="#000000")
                y += int(size * 1.08)
        if face and (circle or arrow):
            fx, fy = (face[0] + face[2] / 2) * s - x0, (face[1] + face[3] / 2) * s - y0
            r = face[2] * s * 0.85
            if circle:
                d.ellipse([fx - r, fy - r, fx + r, fy + r], outline="#FF2D2D", width=max(8, W // 120))
            if arrow:
                ax, ay = fx - r * 2.2, fy + r * 1.4
                d.line([(ax, ay), (fx - r * 1.05, fy + r * 0.45)], fill="#FF2D2D", width=max(14, W // 70))
                d.polygon([(fx - r * 1.0, fy + r * 0.4), (fx - r * 1.45, fy + r * 0.38), (fx - r * 1.12, fy + r * 0.82)],
                          fill="#FF2D2D")
        if emoji:
            from .effects import emoji_png
            e = Image.open(emoji_png(emoji, 256)).convert("RGBA")
            es = int(min(W, H) * 0.22)
            e = e.resize((es, es), Image.LANCZOS)
            canvas.alpha_composite(e, (int(W * 0.05) if W > H else W - es - 40, H - es - 40 if W > H else int(H * 0.12)))
        p = "%s_%dx%d.jpg" % (out_base, W, H)
        canvas.convert("RGB").save(p, quality=92)
        outs.append(p)
    return {"files": outs, "frame_time": round(float(t), 2), "face": bool(face)}

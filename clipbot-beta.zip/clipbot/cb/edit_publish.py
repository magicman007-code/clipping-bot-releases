"""Getting a long-form edit out the door: a YouTube title, description (with chapters) and tags.

package(project, name) -> {"title", "description", "tags", "ai"}   (saved to edits/<name>_package.json)
Uses the connected AI (or the free built-in one) on what the chosen parts actually say; without AI it builds a plain
package from the part titles and the most-said words. Chapters are always the real ones from <name>_chapters.txt.
"""
from .common import save_json
import collections
import json
import os
import re

STOP = set("""a an the and or but if so to of in on at for with from by as is are was were be been it its this that
these those i you he she we they me him her us them my your his our their what which who when where why how not no
yes just like really very gonna wanna got get go going know think yeah okay ok oh um uh mean right all out up down
then there here now one two do did does dont can cant will would could should have has had about into over more some
any thing things kind sort lot little bit gotta lets let im youre hes thats whats time back still even much
zero one two three four five six seven eight nine ten eleven twelve twenty thirty forty fifty hundred thousand
million okay well because guys literally actually basically""".split())


def _paths(project, name):
    ed = os.path.join(project, "edits")
    if not re.match(r"^[\w-]{1,80}$", name or "") or not os.path.isfile(os.path.join(ed, name + ".mp4")):
        raise ValueError("that edit doesn't exist")
    return ed, os.path.join(ed, name + ".mp4")


def _text_of(project, parts, limit=6000):
    try:
        words = json.load(open(os.path.join(project, "words.json")))
    except Exception:
        return ""
    out = []
    for p in parts:
        out.append(" ".join(w[2] for w in words if p["start"] <= w[0] <= p["end"]))
    t = "\n".join(out)
    return t[:limit]


def keywords(text, n=12):
    c = collections.Counter(w for w in re.findall(r"[a-z][a-z']{3,}", text.lower()) if w.replace("'", "") not in STOP)
    return [w for w, k in c.most_common(n) if k >= 2]


def package(project, name, complete=None, use_ai=True):
    ed, _vid = _paths(project, name)
    try:
        plan = json.load(open(os.path.join(ed, name + "_plan.json")))
    except Exception:
        plan = {"parts": []}
    parts = plan.get("parts") or []
    chapters = ""
    cp = os.path.join(ed, name + "_chapters.txt")
    if os.path.exists(cp):
        chapters = open(cp).read().strip()
    text = _text_of(project, parts)
    kws = keywords(text)
    title = (plan.get("title") or (parts[0]["title"] if parts else name.replace("_", " "))).strip()
    summary = ""
    tags = kws[:10]
    ai = False
    if use_ai and text:
        try:
            if complete is None:
                from .connect import ai_complete, ai_ready
                if not ai_ready():
                    raise RuntimeError("off")
                complete = ai_complete
            system = ("You package a YouTube video made from a livestream. Using ONLY what is in the transcript (never "
                      "invent events, numbers or names), return JSON: {\"title\": under 70 characters, curiosity without "
                      "lying, no clickbait the video doesn't deliver; \"summary\": 2-3 short sentences for the "
                      "description; \"tags\": 8-12 search tags}.")
            parts_txt = "\n".join("- %s" % p["title"] for p in parts)
            out = complete("Chapter titles:\n%s\n\nTranscript of the video:\n%s" % (parts_txt, text), system=system,
                           max_tokens=500)
            m = re.search(r"\{.*\}", out or "", re.S)
            j = json.loads(m.group(0)) if m else {}
            if j.get("title"):
                title, ai = str(j["title"]).strip()[:100], True
            summary = str(j.get("summary") or "").strip()[:1200]
            t2 = [re.sub(r"[^\w\s'-]", "", str(t)).strip()[:30] for t in (j.get("tags") or []) if str(t).strip()]
            if t2:
                tags = t2[:12]
        except Exception:
            pass
    if not summary:
        summary = "In this video: " + "; ".join(p["title"] for p in parts[:6]) + "." if parts else ""
    desc = "\n\n".join(x for x in (summary, ("Chapters:\n" + chapters) if chapters else "",
                                   " ".join("#" + re.sub(r"\W", "", t) for t in tags[:3] if re.sub(r"\W", "", t))) if x)
    res = {"title": title[:100], "description": desc[:4900], "tags": tags, "ai": ai}
    save_json(os.path.join(ed, name + "_package.json"), res)
    return res


def saved(project, name):
    try:
        return json.load(open(os.path.join(project, "edits", name + "_package.json")))
    except Exception:
        return None


def shorts(project, name, per_part=1, min_len=15.0, max_len=58.0):
    """Shorts from a long-form edit: the best short moment inside each of its parts becomes a new 9:16 clip in the
    project (not rendered yet - render them like any clip). Moments that overlap existing clips are skipped."""
    from .autoclip import draft_headline
    from .moments import find_candidates
    from .score import score_candidate
    ed, _ = _paths(project, name)
    plan = json.load(open(os.path.join(ed, name + "_plan.json")))
    parts = plan.get("parts") or []
    if not parts:
        raise ValueError("this edit has no parts")
    words = json.load(open(os.path.join(project, "words.json")))
    src = os.path.join(project, "source.mp4")
    spath = os.path.join(project, "specs.json")
    try:
        old = json.load(open(spath))
    except Exception:
        old = []
    taken = [(float(x["start"]), float(x["end"])) for x in old if "start" in x]
    nums = [int(m.group(1)) for m in (re.match(r"(\d+)_", x.get("name", "")) for x in old) if m]
    n = max(nums) + 1 if nums else 1
    per_part = max(1, min(3, int(per_part)))
    new = []
    for p in parts:
        ws = [w for w in words if p["start"] <= w[0] and w[1] <= p["end"]]
        if len(ws) < 8:
            continue
        cs = find_candidates(ws, src, project, min_len=min_len, max_len=max_len, top_k=6)
        for c in cs:
            c["quality"] = score_candidate(c)
        cs.sort(key=lambda c: -c["quality"]["score"])
        got = 0
        for c in cs:
            if got >= per_part:
                break
            if any(min(c["end"], b) - max(c["start"], a) > 2.0 for a, b in taken):
                continue
            taken.append((c["start"], c["end"]))
            new.append({"name": "%02d_short" % n, "source": src, "start": c["start"], "end": c["end"],
                        "segments": [[c["start"], c["end"]]], "headline": draft_headline(c), "headline_draft": True,
                        "aspect": "9:16", "captions": "karaoke", "layout": "auto", "quality": c["quality"],
                        "orig": [c["start"], c["end"]], "origin": "edit", "from_edit": name, "part": p.get("title")})
            n += 1
            got += 1
    if not new:
        raise ValueError("no short moments in this edit that aren't already clips")
    save_json(spath, old + new)
    return {"clips": [x["name"] for x in new], "count": len(new)}

"""TikTok and Twitch, through the user's OWN developer apps (nothing is shared, nothing goes through us).

TikTok (Content Posting API, https://developers.tiktok.com)
  - Login Kit for Desktop with PKCE; redirect http://127.0.0.1:<port>/oauth/tiktok/ (register http://127.0.0.1:*/oauth/tiktok/)
  - draft:  POST /v2/post/publish/inbox/video/init/   (scope video.upload)  -> lands in the TikTok app's inbox,
            the creator finishes the post there. Max 5 pending drafts per 24 h.
  - direct: POST /v2/post/publish/video/init/         (scope video.publish) -> posts straight away. Until TikTok
            audits the app, posts can only be private (SELF_ONLY). TikTok's UX rules are followed in the editor:
            creator nickname shown, privacy picked from creator_info with no default, interactions off by default,
            commercial-content disclosure, consent line, nothing sent until the user presses Post.
  - access tokens last 24 h, refresh tokens 365 days (a refresh may return a new refresh token - saved).

Twitch (Helix)
  - device code flow (no redirect, no secret: register the app as a Public client)
  - create_clip: POST /helix/clips?broadcaster_id=..  (scope channel:manage:clips or editor:manage:clips)
    makes a real Twitch clip of the live stream - for the broadcaster or an editor of the channel.
"""
import hashlib
import json
import os
import secrets
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

TT_AUTH = "https://www.tiktok.com/v2/auth/authorize/"
TT_API = "https://open.tiktokapis.com"
TT_SCOPES = "user.info.basic,video.upload,video.publish,video.list"
TW_ID = "https://id.twitch.tv/oauth2"
TW_API = "https://api.twitch.tv/helix"
TW_SCOPES = "channel:manage:clips editor:manage:clips"
MB = 1 << 20
_TOKEN_LOCK = threading.Lock()          # refreshes one at a time: Twitch refresh tokens can only be used once


def _cfg(sect):
    from .connect import get
    return get().get(sect) or {}


def _save(sect, d):
    from .connect import save
    save({sect: d})


def _req(url, data=None, headers=None, method=None, timeout=60, form=False):
    h = dict(headers or {})
    body = None
    if data is not None:
        if form:
            body = urllib.parse.urlencode(data).encode()
            h.setdefault("Content-Type", "application/x-www-form-urlencoded")
        else:
            body = json.dumps(data).encode()
            h.setdefault("Content-Type", "application/json; charset=UTF-8")
    req = urllib.request.Request(url, data=body, headers=h, method=method or ("POST" if data is not None else "GET"))
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read()
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:
        try:
            j = json.loads(e.read() or b"{}")
        except ValueError:
            j = {}
        j["_status"] = e.code
        return j


def _err(j):
    """TikTok wraps errors as {"error": {"code", "message"}}; Twitch as {"status", "message"}."""
    e = j.get("error")
    if isinstance(e, dict) and e.get("code") not in (None, "ok"):
        return "%s: %s" % (e.get("code"), (e.get("message") or "")[:200])
    if isinstance(e, str):
        return "%s: %s" % (e, (j.get("error_description") or j.get("message") or "")[:200])
    if j.get("_status", 200) >= 400:
        return "%s %s" % (j.get("_status"), (j.get("message") or "")[:200])
    return None


# ================================================================== TikTok
def tt_auth_url(redirect, state):
    """-> (url, code_verifier). TikTok's desktop PKCE uses the HEX SHA-256 of the verifier as the challenge."""
    c = _cfg("tiktok")
    if not c.get("client_key"):
        raise ValueError("paste your TikTok client key and secret first (Settings -> TikTok)")
    verifier = secrets.token_urlsafe(48)[:64]
    challenge = hashlib.sha256(verifier.encode()).hexdigest()
    return TT_AUTH + "?" + urllib.parse.urlencode({
        "client_key": c["client_key"], "scope": TT_SCOPES, "response_type": "code", "redirect_uri": redirect,
        "state": state, "code_challenge": challenge, "code_challenge_method": "S256"}), verifier


def _tt_store(j):
    if not j.get("access_token"):
        raise RuntimeError("TikTok didn't return a token (%s)" % (_err(j) or "no reason given"))
    d = {"access_token": j["access_token"], "expires_at": int(time.time()) + int(j.get("expires_in") or 86400) - 120,
         "open_id": j.get("open_id"), "scopes": j.get("scope", "")}
    if j.get("refresh_token"):
        d["refresh_token"] = j["refresh_token"]
    _save("tiktok", d)
    return d


def tt_finish_auth(code, redirect, verifier, api=None):
    c = _cfg("tiktok")
    j = _req((api or TT_API) + "/v2/oauth/token/", {
        "client_key": c.get("client_key", ""), "client_secret": c.get("client_secret", ""),
        "code": urllib.parse.unquote(code), "grant_type": "authorization_code", "redirect_uri": redirect,
        "code_verifier": verifier}, form=True)
    return _tt_store(j)


def _tt_access(api=None):
    with _TOKEN_LOCK:
        return _tt_access_locked(api)


def _tt_access_locked(api=None):
    c = _cfg("tiktok")
    if not c.get("refresh_token"):
        raise RuntimeError("connect TikTok first (Settings -> TikTok -> Connect)")
    if c.get("access_token") and c.get("expires_at", 0) > time.time():
        return c["access_token"]
    j = _req((api or TT_API) + "/v2/oauth/token/", {
        "client_key": c.get("client_key", ""), "client_secret": c.get("client_secret", ""),
        "grant_type": "refresh_token", "refresh_token": c["refresh_token"]}, form=True)
    if not j.get("access_token"):
        raise RuntimeError("TikTok sign-in expired or was revoked - connect again (%s)" % (_err(j) or ""))
    return _tt_store(j)["access_token"]


def tt_creator(api=None):
    """Who will receive the post, and what they're allowed to do right now (TikTok requires showing this)."""
    tok = _tt_access(api)
    j = _req((api or TT_API) + "/v2/post/publish/creator_info/query/", {}, {"Authorization": "Bearer " + tok})
    e = _err(j)
    if e:
        raise RuntimeError("TikTok: " + e)
    d = j.get("data") or {}
    return {"nickname": d.get("creator_nickname") or d.get("creator_username") or "",
            "username": d.get("creator_username") or "", "avatar": d.get("creator_avatar_url") or "",
            "privacy_options": d.get("privacy_level_options") or [],
            "comment_disabled": bool(d.get("comment_disabled")), "duet_disabled": bool(d.get("duet_disabled")),
            "stitch_disabled": bool(d.get("stitch_disabled")),
            "max_seconds": d.get("max_video_post_duration_sec")}


def _chunks(size):
    """TikTok: one chunk up to 64 MB; above that, 10 MB chunks with the remainder folded into the last one."""
    if size <= 64 * MB:
        return size, 1
    chunk = 10 * MB
    return chunk, size // chunk


def tt_upload(path, mode="draft", post=None, api=None):
    """mode 'draft' (inbox) or 'direct'. post = {title, privacy_level, disable_comment, disable_duet, disable_stitch,
    brand_content_toggle, brand_organic_toggle, is_aigc}. Returns {"publish_id"}."""
    if not os.path.isfile(path):
        raise ValueError("render the clip first")
    size = os.path.getsize(path)
    if size > 4 << 30:
        raise ValueError("TikTok takes videos up to 4 GB")
    chunk, n = _chunks(size)
    src = {"source": "FILE_UPLOAD", "video_size": size, "chunk_size": chunk, "total_chunk_count": n}
    tok = _tt_access(api)
    hdr = {"Authorization": "Bearer " + tok}
    if mode == "direct":
        post = dict(post or {})
        if not post.get("privacy_level"):
            raise ValueError("pick who can see it")
        info = {"privacy_level": post["privacy_level"], "title": str(post.get("title") or "")[:2200]}
        for k in ("disable_comment", "disable_duet", "disable_stitch", "brand_content_toggle", "brand_organic_toggle", "is_aigc"):
            if k in post:
                info[k] = bool(post[k])
        if info.get("brand_content_toggle") and info["privacy_level"] == "SELF_ONLY":
            raise ValueError("branded content can't be private on TikTok")
        j = _req((api or TT_API) + "/v2/post/publish/video/init/", {"post_info": info, "source_info": src}, hdr)
    else:
        j = _req((api or TT_API) + "/v2/post/publish/inbox/video/init/", {"source_info": src}, hdr)
    e = _err(j)
    if e:
        if "too_many_pending" in e:
            raise RuntimeError("TikTok allows 5 drafts waiting in your inbox per day - post or delete some in the TikTok app")
        if "unaudited" in e or "privacy_level_option_mismatch" in e:
            raise RuntimeError("TikTok: %s. Until TikTok audits your app, direct posts can only be 'Only me' "
                               "and your account must be private." % e)
        raise RuntimeError("TikTok: " + e)
    d = j.get("data") or {}
    url, pid = d.get("upload_url"), d.get("publish_id")
    if not url or not pid:
        raise RuntimeError("TikTok didn't return an upload link")
    with open(path, "rb") as f:
        for i in range(n):
            a = i * chunk
            b = size - 1 if i == n - 1 else a + chunk - 1
            f.seek(a)
            data = f.read(b - a + 1)
            req = urllib.request.Request(url, data=data, method="PUT", headers={
                "Content-Type": "video/mp4", "Content-Length": str(len(data)),
                "Content-Range": "bytes %d-%d/%d" % (a, b, size)})
            try:
                urllib.request.urlopen(req, timeout=600).read()
            except urllib.error.HTTPError as e2:
                raise RuntimeError("TikTok upload stopped at part %d of %d (%s)" % (i + 1, n, e2.code))
    return {"publish_id": pid, "mode": mode}


def tt_status(publish_id, api=None):
    tok = _tt_access(api)
    j = _req((api or TT_API) + "/v2/post/publish/status/fetch/", {"publish_id": publish_id}, {"Authorization": "Bearer " + tok})
    e = _err(j)
    if e:
        raise RuntimeError("TikTok: " + e)
    d = j.get("data") or {}
    return {"status": d.get("status"), "fail_reason": d.get("fail_reason"),
            "post_ids": d.get("publicaly_available_post_id") or d.get("publicly_available_post_id") or []}


def tt_wait(publish_id, api=None, tries=60, every=5.0):
    """Poll until TikTok has the video (inbox or posted) or it failed."""
    st = {}
    for _ in range(tries):
        st = tt_status(publish_id, api)
        if st["status"] in ("SEND_TO_USER_INBOX", "PUBLISH_COMPLETE", "FAILED"):
            break
        time.sleep(every)
    if st.get("status") == "FAILED":
        raise RuntimeError("TikTok couldn't process it: %s" % (st.get("fail_reason") or "no reason given"))
    return st


def tt_views(video_ids, api=None):
    """{video_id: view_count} for the connected account's own videos (scope video.list), up to 20 per request."""
    tok = _tt_access(api)
    out = {}
    ids = [str(i) for i in video_ids]
    for k in range(0, len(ids), 20):
        j = _req((api or TT_API) + "/v2/video/query/?fields=id,view_count,like_count,share_url",
                 {"filters": {"video_ids": ids[k:k + 20]}}, {"Authorization": "Bearer " + tok})
        e = _err(j)
        if e:
            raise RuntimeError("TikTok: " + e)
        for v in (j.get("data") or {}).get("videos") or []:
            if v.get("id") is not None and v.get("view_count") is not None:
                out[str(v["id"])] = int(v["view_count"])
    return out


def tt_connected():
    c = _cfg("tiktok")
    return bool(c.get("refresh_token")) and "video.list" in (c.get("scopes") or "")


# ================================================================== Twitch
_TW = {"device": None}


def tw_device_start(id_url=None):
    c = _cfg("twitch")
    if not c.get("client_id"):
        raise ValueError("paste your Twitch app's Client ID first (Settings -> Twitch)")
    j = _req((id_url or TW_ID) + "/device", {"client_id": c["client_id"], "scopes": TW_SCOPES}, form=True)
    if not j.get("device_code"):
        raise RuntimeError("Twitch: %s (is the app set to 'Public' client type?)" % (_err(j) or "no code returned"))
    _TW["device"] = {"code": j["device_code"], "until": time.time() + int(j.get("expires_in") or 1800)}
    return {"user_code": j.get("user_code"), "url": j.get("verification_uri"), "interval": int(j.get("interval") or 5)}


def tw_device_poll(id_url=None, api=None):
    """-> {"state": "pending"|"connected"|"expired", "login"}"""
    dv = _TW.get("device")
    if not dv or time.time() > dv["until"]:
        return {"state": "expired"}
    c = _cfg("twitch")
    j = _req((id_url or TW_ID) + "/token", {"client_id": c["client_id"], "scopes": TW_SCOPES, "device_code": dv["code"],
                                            "grant_type": "urn:ietf:params:oauth:grant-type:device_code"}, form=True)
    if not j.get("access_token"):
        if "pending" in str(j.get("message", "")):
            return {"state": "pending"}
        _TW["device"] = None
        return {"state": "expired", "error": _err(j)}
    _TW["device"] = None
    me = _req((api or TW_API) + "/users", headers={"Client-Id": c["client_id"], "Authorization": "Bearer " + j["access_token"]})
    u = (me.get("data") or [{}])[0]
    _save("twitch", {"refresh_token": j.get("refresh_token"), "access_token": j["access_token"],
                     "expires_at": int(time.time()) + int(j.get("expires_in") or 14400) - 120,
                     "user_id": u.get("id"), "login": u.get("login")})
    return {"state": "connected", "login": u.get("login")}


def _tw_access(id_url=None):
    with _TOKEN_LOCK:
        return _tw_access_locked(id_url)


def _tw_access_locked(id_url=None):
    c = _cfg("twitch")
    if not c.get("refresh_token"):
        raise RuntimeError("connect Twitch first (Settings -> Twitch -> Connect)")
    if c.get("access_token") and c.get("expires_at", 0) > time.time():
        return c
    j = _req((id_url or TW_ID) + "/token", {"client_id": c["client_id"], "grant_type": "refresh_token",
                                            "refresh_token": c["refresh_token"]}, form=True)
    if not j.get("access_token"):
        raise RuntimeError("Twitch sign-in expired - connect again (%s)" % (_err(j) or ""))
    _save("twitch", {"access_token": j["access_token"], "refresh_token": j.get("refresh_token") or c["refresh_token"],
                     "expires_at": int(time.time()) + int(j.get("expires_in") or 14400) - 120})
    return _cfg("twitch")


def tw_create_clip(channel, title=None, duration=None, api=None, id_url=None):
    """A real Twitch clip of what's live right now on <channel> (login name or twitch.tv link)."""
    c = _tw_access(id_url)
    h = {"Client-Id": c["client_id"], "Authorization": "Bearer " + c["access_token"]}
    login = str(channel or "").rstrip("/").split("/")[-1].lower()
    if not login:
        raise ValueError("which Twitch channel?")
    u = _req((api or TW_API) + "/users?" + urllib.parse.urlencode({"login": login}), headers=h)
    bid = ((u.get("data") or [{}])[0]).get("id")
    if not bid:
        raise RuntimeError("Twitch has no channel called %s" % login)
    q = {"broadcaster_id": bid}
    if title:
        q["title"] = str(title)[:100]
    if duration:
        q["duration"] = "%.1f" % max(5.0, min(60.0, float(duration)))
    j = _req((api or TW_API) + "/clips?" + urllib.parse.urlencode(q), {}, h)
    if _err(j):
        st = j.get("_status")
        if st == 401:
            raise RuntimeError("Twitch says you can't clip this channel - you need to be its broadcaster or an editor")
        if st == 404:
            raise RuntimeError("%s isn't live right now" % login)
        raise RuntimeError("Twitch: " + _err(j))
    d = (j.get("data") or [{}])[0]
    if not d.get("id"):
        raise RuntimeError("Twitch didn't make the clip")
    return {"id": d["id"], "url": "https://clips.twitch.tv/" + d["id"], "edit_url": d.get("edit_url")}

"""Editor-level extras: text layers, emoji/image stickers, colour grade, music bed with
ducking, playback speed, and the 'gameplay below' (Crayo-style) layout."""
import glob
import hashlib
import os
import random

from .common import ROOT, probe

STICKER_DIR = os.path.join(ROOT, "assets", "stickers")
FONTS = {"Montserrat": "Montserrat Black", "Impact": "Anton", "Arial": "Inter Medium"}   # legacy names -> bundled


def _ass_color(hexstr, default="&H00FFFFFF&"):
    h = (hexstr or "").lstrip("#")
    if len(h) != 6:
        return default
    return ("&H00%s%s%s&" % (h[4:6], h[2:4], h[0:2])).upper()


def _num(v, d):
    try:
        return float(v) if v not in (None, "") else d
    except (TypeError, ValueError):
        return d


def _esc(s):
    return s.replace("{", "(").replace("}", ")").replace("\\", "").replace("\n", "\\N")


def text_layer_events(layers, fmt):
    """layers: [{text, start, end, x, y (px on 1080x1920), size, color, stroke_color, font,
    box (bool), box_color, bold, rotate, anim: none|pop|fade|slide}] -> ASS events (style 'Cap' based)."""
    ev = []
    for L in layers or []:
        txt = _esc(str(L.get("text", "")))
        if not txt:
            continue
        x, y = int(L.get("x", 540)), int(L.get("y", 700))
        from .fonts import resolve
        fam = resolve(FONTS.get(L.get("font", "Anton"), L.get("font", "Anton")), "Anton")
        tags = ["\\an5", "\\pos(%d,%d)" % (x, y), "\\fn%s" % fam,
                "\\fs%d" % int(L.get("size", 90)), "\\1c%s" % _ass_color(L.get("color"), "&H00FFFFFF&"),
                "\\3c%s" % _ass_color(L.get("stroke_color"), "&H00000000&")]
        if L.get("box"):
            tags += ["\\bord%d" % int(L.get("pad", 14)), "\\3c%s" % _ass_color(L.get("box_color"), "&H00FFFFFF&"),
                     "\\shad0"]
            style = "Head"
        else:
            tags += ["\\bord%d" % int(L.get("stroke", 8))]
            style = "Cap"
        tags += ["\\b%d" % (1 if L.get("bold") else 0), "\\i%d" % (1 if L.get("italic") else 0),
                 "\\fsp%g" % _num(L.get("spacing"), 1)]
        if L.get("rotate"):
            tags.append("\\frz%d" % int(L["rotate"]))
        a = L.get("anim", "pop")
        if a == "pop":
            tags.append("\\fscx70\\fscy70\\t(0,120,\\fscx100\\fscy100)")
        elif a == "fade":
            tags.append("\\fad(200,200)")
        elif a == "slide":
            tags[1] = "\\move(%d,%d,%d,%d,0,220)" % (x - 300, y, x, y)
        ev.append("Dialogue: 3,%s,%s,%s,,0,0,0,,{%s}%s" % (fmt(float(L.get("start", 0))), fmt(float(L.get("end", 9999))),
                                                          style, "".join(tags), txt))
    return ev


def emoji_png(ch, size=160):
    """Render an emoji to a transparent PNG (system colour-emoji font, else Twemoji PNG over HTTPS)."""
    os.makedirs(STICKER_DIR, exist_ok=True)
    code_ = "-".join("%x" % ord(c) for c in ch if ord(c) != 0xFE0F)
    out = os.path.join(STICKER_DIR, "emoji_%s.png" % code_)
    if os.path.exists(out):
        return out
    bundled = os.path.join(ROOT, "assets", "emoji", "%s.png" % code_)     # shipped set (Noto Emoji, Apache-2.0)
    if os.path.exists(bundled):
        from PIL import Image
        Image.open(bundled).convert("RGBA").resize((size, size), Image.LANCZOS).save(out)
        return out
    from PIL import Image, ImageDraw, ImageFont
    fonts = glob.glob("/usr/share/fonts/**/NotoColorEmoji*.ttf", recursive=True)
    if fonts:
        f = ImageFont.truetype(fonts[0], 109)           # CBDT bitmap font only renders at 109
        img = Image.new("RGBA", (136, 128), (0, 0, 0, 0))
        ImageDraw.Draw(img).text((0, 0), ch, font=f, embedded_color=True)
        img = img.crop(img.getbbox() or (0, 0, 136, 128)).resize((size, size), Image.LANCZOS)
        img.save(out)
        return out
    code = "-".join("%x" % ord(c) for c in ch if ord(c) != 0xFE0F)
    # macOS: Apple Color Emoji renders at 160px with Pillow; Windows: Segoe UI Emoji (COLR)
    for fp, sz in (("/System/Library/Fonts/Apple Color Emoji.ttc", 160), ("C:/Windows/Fonts/seguiemj.ttf", 109)):
        if os.path.exists(fp):
            try:
                f = ImageFont.truetype(fp, sz)
                img = Image.new("RGBA", (sz + 40, sz + 40), (0, 0, 0, 0))
                ImageDraw.Draw(img).text((0, 0), ch, font=f, embedded_color=True)
                bb = img.getbbox()
                if bb:
                    img.crop(bb).resize((size, size), Image.LANCZOS).save(out)
                    return out
            except Exception:
                pass
    # last resort: Twemoji PNG (CC-BY 4.0) over HTTPS
    import urllib.request
    try:
        data = urllib.request.urlopen("https://cdn.jsdelivr.net/gh/jdecked/twemoji@15.1.0/assets/72x72/%s.png" % code,
                                      timeout=20).read()
        tmp = out + ".dl"
        open(tmp, "wb").write(data)
        Image.open(tmp).convert("RGBA").resize((size, size), Image.LANCZOS).save(out)
        os.remove(tmp)
        return out
    except Exception:
        raise RuntimeError("no emoji renderer available for %r (offline and no emoji font)" % ch)


def sticker_inputs(stickers, first_index):
    """stickers: [{emoji|path, start, end, x, y, w, anim}] -> (ffmpeg input args, filter steps, last label)."""
    args, steps = [], []
    idx = first_index
    for s in stickers or []:
        path = s.get("path") or (emoji_png(s["emoji"]) if s.get("emoji") else None)
        if not path or not os.path.exists(path):
            continue
        args += ["-loop", "1", "-i", path] if path.lower().endswith((".png", ".jpg", ".jpeg", ".webp")) else ["-i", path]
        w = int(s.get("w", 200))
        st, en = float(s.get("start", 0)), float(s.get("end", 9999))
        steps.append(("[%d:v]scale=%d:-1,format=rgba[stk%d]" % (idx, w, idx),
                      "overlay=x=%d-w/2:y=%d-h/2:enable='between(t,%.3f,%.3f)':shortest=0:eof_action=pass"
                      % (int(s.get("x", 540)), int(s.get("y", 900)), st, en), idx))
        idx += 1
    return args, steps, idx


def blur_steps(blurs, src, W, H):
    """blurs: [{x, y, w, h (output pixels, top-left), start, end, mode: blur|pixel|black, strength 1-10}]
    -> (filter list, output label). Hides faces, usernames, chat or anything on screen, only while start-end."""
    out, cur, k = [], src, 0
    for b in (blurs or [])[:12]:
        try:
            x, y = max(0, int(b.get("x", 0))), max(0, int(b.get("y", 0)))
            w, h = int(b.get("w", 200)), int(b.get("h", 120))
            st, en = float(b.get("start", 0)), float(b.get("end", 9999))
        except (TypeError, ValueError):
            continue
        w, h = min(w, W - x), min(h, H - y)
        w, h = w - w % 2, h - h % 2
        if w < 8 or h < 8 or en <= st:
            continue
        mode = b.get("mode") if b.get("mode") in ("blur", "pixel", "black") else "blur"
        en_ = "enable='between(t,%.3f,%.3f)'" % (st, en)
        nxt = "[blr%d]" % k
        if mode == "black":
            out.append("%sdrawbox=x=%d:y=%d:w=%d:h=%d:color=black@1:t=fill:%s%s" % (cur, x, y, w, h, en_, nxt))
        else:
            sv = max(1, min(10, int(b.get("strength", 6) or 6)))
            if mode == "pixel":
                cell = max(4, int(min(w, h) / (26 - sv * 2)))
                fx = "scale=%d:%d:flags=area,scale=%d:%d:flags=neighbor" % (max(1, w // cell), max(1, h // cell), w, h)
            else:
                r = max(2, min(int(min(w, h) / 2) - 1, sv * 4))
                fx = "boxblur=%d:2" % r
            out.append("%ssplit=2[bA%d][bB%d];[bB%d]crop=%d:%d:%d:%d,%s[bC%d];[bA%d][bC%d]overlay=%d:%d:%s%s"
                       % (cur, k, k, k, w, h, x, y, fx, k, k, k, x, y, en_, nxt))
        cur, k = nxt, k + 1
    return out, cur


def grade_chain(g):
    """g: {brightness -1..1, contrast 0..2, saturation 0..3, warmth -1..1, vignette bool, sharpen 0..2, lut: none|punchy|film|bw}"""
    if not g:
        return ""
    parts = []
    preset = g.get("look", "none")
    b, c, s = float(g.get("brightness", 0)), float(g.get("contrast", 1)), float(g.get("saturation", 1))
    if preset == "punchy":
        c, s = c * 1.12, s * 1.25
    elif preset == "film":
        c, s = c * 0.95, s * 0.85
        parts.append("curves=preset=vintage")
    elif preset == "bw":
        s = 0
    if (b, c, s) != (0, 1, 1):
        parts.append("eq=brightness=%.3f:contrast=%.3f:saturation=%.3f" % (b, c, s))
    w = float(g.get("warmth", 0))
    if w:
        parts.append("colorbalance=rs=%.3f:bs=%.3f:rm=%.3f:bm=%.3f" % (0.12 * w, -0.12 * w, 0.06 * w, -0.06 * w))
    if float(g.get("sharpen", 0)):
        parts.append("unsharp=5:5:%.2f" % float(g["sharpen"]))
    if g.get("vignette"):
        parts.append("vignette=PI/5")
    return ",".join(parts)


def music_chain(voice_label, music_idx, dur, volume=0.18, duck=True, out="[aout]"):
    """Background music under the voice, ducked whenever someone talks (sidechain)."""
    m = "[%d:a]aresample=48000,aformat=channel_layouts=stereo,volume=%.3f,afade=t=out:st=%.2f:d=1.2[mus]" % (
        music_idx, volume, max(0, dur - 1.2))
    if duck:
        return (m + ";%sasplit=2[vo1][vo2];[mus][vo2]sidechaincompress=threshold=0.03:ratio=8:attack=20:release=350[mduck];"
                "[vo1][mduck]amix=inputs=2:duration=first:normalize=0%s") % (voice_label, out)
    return m + ";%s[mus]amix=inputs=2:duration=first:normalize=0%s" % (voice_label, out)


def gameplay_body(samples, active, w0, h0, bg_index, bg_dur, dur, top_h=960, seed=None):
    """Crayo/brainrot layout: the clip (face-following crop) on top, looping background
    gameplay (muted) underneath. Returns (filter producing [body], caption y)."""
    import numpy as np
    from .render import W, H, lerp_expr, smooth_track
    cw = int(min(w0, h0 * W / float(top_h))) // 2 * 2
    ch = int(round(cw * top_h / float(W))) // 2 * 2
    xs = []
    for j, (t, fs) in enumerate(samples):
        if not fs:
            continue
        a = active[j] if active else None
        mine = [f for f in fs if len(f) > 5 and f[5] == a]
        f = mine[0] if mine else max(fs, key=lambda q: q[2] * q[3])
        xs.append((t, f[0]))
    if xs:
        kf = smooth_track(xs, 0, dur, w0)
        kf = [(t, min(max(x, cw / 2), w0 - cw / 2) - cw / 2) for t, x in kf]
        xexpr = lerp_expr(kf)
    else:
        xexpr = "%d" % ((w0 - cw) // 2)
    cy = float(np.median([f[1] for _, fs in samples for f in fs])) if any(fs for _, fs in samples) else h0 / 2
    y0 = int(min(max(0, cy - 0.42 * ch), h0 - ch))
    off = random.Random(seed).uniform(0, max(0.0, bg_dur - dur - 1)) if bg_dur > dur + 2 else 0.0
    fc = ("[0:v]crop=%d:%d:'%s':%d,scale=%d:%d:flags=lanczos,setsar=1[top];"
          "[%d:v]trim=start=%.3f,setpts=PTS-STARTPTS,fps=30,scale=%d:%d:force_original_aspect_ratio=increase,"
          "crop=%d:%d,setsar=1[bot];[top][bot]vstack=inputs=2,trim=duration=%.3f[body]") % (
        cw, ch, xexpr, y0, W, top_h, bg_index, off, W, H - top_h, W, H - top_h, dur)
    return fc, top_h


def bg_duration(path):
    try:
        return probe(path)["duration"]
    except Exception:
        return 0.0


def key(*parts):
    return hashlib.md5("|".join(str(p) for p in parts).encode()).hexdigest()[:10]

"""Channel watch: add a streamer's channel once; every new VOD gets auto-clipped.

  watches.json (<work_root>/_settings) holds [{url, streamer, clips, min_score, aspect, seen, pending, ...}].
  check() lists each channel's newest VODs (yt-dlp; Kick via its public channel API), and auto-clips a VOD once it
  has SETTLED - seen twice with the same length - so a stream that's still live (its VOD still growing) isn't
  clipped half-way. VODs that already existed when you added the channel are skipped unless you ask for the latest.

Supported channel links:
  Twitch    https://www.twitch.tv/<name>           (past broadcasts)
  YouTube   https://www.youtube.com/@<handle>      (its Live tab, then Videos)
  Kick      https://kick.com/<name>                (past streams; best effort - Kick can block automated access)
"""
import json
import os
import re
import threading
import time

from .common import load_config, log

_LOCK = threading.Lock()
MAX_SEEN = 300


def _path():
    d = os.path.join(load_config()["work_root"], "_settings")
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "watches.json")


def load():
    try:
        return json.load(open(_path()))
    except Exception:
        return []


def _save(ws):
    tmp = _path() + ".tmp"
    json.dump(ws, open(tmp, "w"), indent=1)
    os.replace(tmp, _path())


def channel(url):
    """Normalise a channel link -> (platform, canonical channel url, name). Raises ValueError."""
    u = (url or "").strip()
    if not re.match(r"https?://", u):
        u = "https://" + u
    m = re.match(r"https?://(?:www\.|m\.)?twitch\.tv/([A-Za-z0-9_]{2,30})/?(?:videos.*)?$", u)
    if m and m.group(1).lower() not in ("videos", "directory", "settings"):
        return "twitch", "https://www.twitch.tv/%s" % m.group(1).lower(), m.group(1)
    m = re.match(r"https?://(?:www\.)?kick\.com/([A-Za-z0-9_-]{2,40})/?(?:videos/?)?$", u)
    if m:
        return "kick", "https://kick.com/%s" % m.group(1).lower(), m.group(1)
    m = re.match(r"https?://(?:www\.|m\.)?youtube\.com/(@[\w.-]+|channel/[\w-]+|c/[\w.-]+|user/[\w.-]+)", u)
    if m:
        return "youtube", "https://www.youtube.com/%s" % m.group(1), m.group(1).lstrip("@")
    raise ValueError("That isn't a channel link. Use e.g. https://www.twitch.tv/name, https://kick.com/name or "
                     "https://www.youtube.com/@handle (for a single video, use New instead).")


# ------------------------------------------------------------------ listing VODs
def _ytdlp_list(url, n=6, cfg=None):
    from .common import run
    from .fetch import _ytdlp_base
    r = run(_ytdlp_base(cfg or load_config()) + ["--flat-playlist", "--playlist-end", str(n), "-J", url],
            timeout=180, check=False)
    if r.returncode != 0:
        raise RuntimeError((r.stderr or "").strip().splitlines()[-1][:200] if (r.stderr or "").strip() else "listing failed")
    j = json.loads(r.stdout or "{}")
    return j.get("entries") or []


def list_vods(url, n=6, cfg=None, _lister=None):
    """Newest VODs first: [{"id", "url", "title", "duration", "live"}]."""
    plat, ch, name = channel(url)
    lister = _lister or _ytdlp_list
    out = []
    if plat == "twitch":
        for e in lister(ch + "/videos?filter=archives&sort=time", n, cfg):
            vid = str(e.get("id") or "").lstrip("v")
            if vid.isdigit():
                out.append({"id": "tw" + vid, "url": "https://www.twitch.tv/videos/" + vid, "title": e.get("title") or "",
                            "duration": e.get("duration"), "live": False})
    elif plat == "youtube":
        ents = []
        for tab in ("/streams", "/videos"):
            try:
                ents = lister(ch + tab, n, cfg)
            except RuntimeError:
                ents = []
            if ents:
                break
        for e in ents:
            if e.get("id"):
                out.append({"id": "yt" + e["id"], "url": "https://www.youtube.com/watch?v=" + e["id"],
                            "title": e.get("title") or "", "duration": e.get("duration"),
                            "live": e.get("live_status") in ("is_live", "is_upcoming", "post_live")})
    else:
        out = _kick_vods(name, n) if _lister is None else [
            {"id": "kk" + str(e["id"]), "url": e["url"], "title": e.get("title", ""), "duration": e.get("duration"),
             "live": bool(e.get("live"))} for e in lister(ch, n, cfg)]
    return out[:n]


def _kick_vods(slug, n):
    try:
        from curl_cffi import requests as creq            # Kick sits behind Cloudflare; a browser-like client helps
        r = creq.get("https://kick.com/api/v2/channels/%s/videos" % slug, impersonate="chrome", timeout=30)
        if r.status_code != 200:
            raise RuntimeError("Kick answered %s" % r.status_code)
        arr = r.json()
    except ImportError:
        raise RuntimeError("Kick channel watch needs curl_cffi (run the installer again)")
    out = []
    for v in arr if isinstance(arr, list) else []:
        uuid = ((v.get("video") or {}).get("uuid")) or v.get("uuid")
        if not uuid:
            continue
        out.append({"id": "kk" + uuid, "url": "https://kick.com/%s/videos/%s" % (slug, uuid),
                    "title": v.get("session_title") or "", "live": bool(v.get("is_live")),
                    "duration": (v.get("duration") or 0) / 1000.0 if v.get("duration") else None})
    return out[:n]


# ------------------------------------------------------------------ managing
def add(url, streamer=None, clips=6, min_score=6.0, aspect="9:16", latest=False, _lister=None):
    """Start watching. Existing VODs are marked seen (no backlog); latest=True also clips the newest one."""
    plat, ch, name = channel(url)
    with _LOCK:
        ws = load()
        if any(w["url"] == ch for w in ws):
            raise ValueError("already watching %s" % ch)
    vods = list_vods(ch, _lister=_lister)
    w = {"url": ch, "platform": plat, "name": name, "streamer": streamer or None, "clips": int(clips),
         "min_score": float(min_score), "aspect": aspect or "9:16", "added": int(time.time()), "last_check": int(time.time()),
         "seen": [v["id"] for v in vods], "pending": {}, "done": [], "error": None}
    if latest and vods and not vods[0]["live"]:
        w["seen"] = w["seen"][1:]
        d0 = vods[0].get("duration")
        w["pending"][vods[0]["id"]] = d0 if d0 is not None else -1        # finished VOD: clip on the next check
    with _LOCK:
        ws = load()
        ws.append(w)
        _save(ws)
    return w


def remove(url):
    with _LOCK:
        ws = load()
        keep = [w for w in ws if w["url"] != url]
        _save(keep)
        return len(ws) - len(keep)


def check(clipper=None, _lister=None, now=None):
    """One pass over all channels. New settled VODs -> clipper(vod, watch). Returns what was started."""
    if clipper is None:
        clipper = _autoclip
    now = now or time.time()
    started = []
    with _LOCK:
        ws = load()
    for w in ws:
        try:
            vods = list_vods(w["url"], _lister=_lister)
            w["error"] = None
        except Exception as e:
            w["error"] = str(e)[:200]
            w["last_check"] = int(now)
            continue
        for v in reversed(vods):                      # oldest new one first
            if v["id"] in w["seen"] or v["live"]:
                continue
            dur = v.get("duration")
            if v["id"] not in w["pending"]:
                w["pending"][v["id"]] = dur if dur is not None else -1     # first sighting: check again next time
                continue
            prev = w["pending"][v["id"]]
            if dur is not None and prev != -1 and abs(prev - dur) > 1:
                w["pending"][v["id"]] = dur           # still growing (stream still live): wait
                continue
            w["pending"].pop(v["id"], None)
            w["seen"] = (w["seen"] + [v["id"]])[-MAX_SEEN:]
            started.append({"watch": w["url"], "vod": v})
            try:
                res = clipper(v, w)
                w["done"] = (w.get("done", []) + [{"id": v["id"], "title": v["title"][:120], "at": int(now),
                                                    "project": (res or {}).get("project")}])[-30:]
            except Exception as e:
                w["error"] = "clipping %s failed: %s" % (v["title"][:60], str(e)[:160])
        w["last_check"] = int(now)
    with _LOCK:
        cur = {w["url"]: w for w in load()}
        for w in ws:
            if w["url"] in cur:                   # removed meanwhile -> stay removed
                cur[w["url"]] = w
        _save(list(cur.values()))
    return started


def _autoclip(v, w):
    from .autoclip import run, project_name
    name = "%s_%s" % (re.sub(r"\W+", "_", w["name"])[:20], project_name(v["title"] or v["id"])[:30])
    st = run(v["url"], None, name, clips=w.get("clips", 6), min_score=w.get("min_score", 6.0),
             aspect=w.get("aspect", "9:16"), streamer=w.get("streamer"))
    return {"project": st.get("project"), "state": st.get("state")}


class Poller:
    """Background checker for the editor: a check() pass every `minutes` (and on demand). Clips run one at a time."""
    def __init__(self, minutes=None):
        self.minutes = float(minutes or load_config().get("watch_minutes", 30))
        self.stop = threading.Event()
        self.kick = threading.Event()
        self.busy = False
        self.last = None

    def now(self):
        self.kick.set()

    def run(self):
        wait = 60.0
        while not self.stop.is_set():
            self.kick.wait(wait)
            self.kick.clear()
            if self.stop.is_set():
                break
            wait = max(60.0, self.minutes * 60)
            if not load():
                continue
            self.busy = True
            try:
                s = check()
                self.last = {"at": int(time.time()), "started": len(s)}
                if s:
                    log("watch: clipped %d new VOD(s)" % len(s))
            except Exception as e:
                log("watch: %s" % e)
            finally:
                self.busy = False

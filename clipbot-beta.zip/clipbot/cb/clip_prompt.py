"""The prompt box on a clip: type what you want in normal words, get one focused change to THAT clip.

plan(text, spec, words, playhead=None) -> {"patch": {...}, "done": [plain words], "not_done": [plain words]}

`patch` holds only clip-spec fields the manual editor also edits (start/end/segments, headline, words, follow, wide),
so the editor applies it as one ordinary edit: undo/redo cover prompt and manual changes alike. Nothing here renders,
posts or touches other clips. Every part of the request is either done or listed in not_done - never silently dropped.

Understood (any order, several at once with "and" / "," / "then"):
  cut / trim / skip the first N seconds        cut the last N seconds / end N seconds earlier
  start at 0:12 / end at 0:25 (clip time)      start N seconds earlier / later, end N seconds later
  fix the caption that says X, it should say Y   (also: "X should be Y", "replace X with Y")
  make the headline shorter / change the headline to X / remove the headline
  tighten this to the punchline / end on the punchline
  follow the guy on the left / right (person, girl, one ...)   follow whoever is talking (back to automatic)
  widen the frame (here) so both are in it / keep both of them in frame
"""
import re

WORDNUM = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9,
           "ten": 10, "a couple": 2, "a few": 3, "half a": 0.5}
NUM = r"(\d+(?:\.\d+)?|one|two|three|four|five|six|seven|eight|nine|ten|a couple|a few|half a)"
SECS = NUM + r"\s*(?:s\b|secs?\b|seconds?\b)"
FILLER = {"so", "like", "just", "really", "actually", "literally", "basically", "very", "the", "a", "an", "and", "that",
          "um", "uh", "okay", "ok", "yeah", "this", "is", "was", "of"}
BEAT = re.compile(r"haha+|lol|lmao|i'?m dead|no way|oh my god|what the|let'?s go+|bro what|are you serious|wait what|"
                  r"!|\?!|i can'?t (?:believe|breathe)|that'?s insane|clip (?:it|that)", re.I)


def _num(x):
    x = x.lower().strip()
    return float(WORDNUM.get(x, x)) if (x in WORDNUM or re.match(r"^\d+(\.\d+)?$", x)) else None


def _clock(x):
    m = re.match(r"^(?:(\d+):)?(\d{1,2}(?:\.\d+)?)$", x.strip())
    return (int(m.group(1) or 0) * 60 + float(m.group(2))) if m else None


def _segs(spec):
    return [list(map(float, s)) for s in (spec.get("segments") or [[spec["start"], spec["end"]]])]


def _clip_len(segs):
    return sum(b - a for a, b in segs)


def _to_source(segs, t):
    """clip time -> source time"""
    for a, b in segs:
        if t <= b - a:
            return a + max(0.0, t)
        t -= b - a
    return segs[-1][1]


def _set_span(patch, segs, new_a=None, new_b=None):
    """Move the clip's start / end (source time), keeping cuts inside."""
    a0, b0 = segs[0][0], segs[-1][1]
    a, b = (new_a if new_a is not None else a0), (new_b if new_b is not None else b0)
    out = [[max(x, a), min(y, b)] for x, y in segs if min(y, b) - max(x, a) > 0.05]
    if not out:
        out = [[a, b]]
    if new_a is not None and new_a < a0:
        out[0][0] = new_a
    if new_b is not None and new_b > b0:
        out[-1][1] = new_b
    patch["segments"] = [[round(x, 3), round(y, 3)] for x, y in out]
    patch["start"], patch["end"] = patch["segments"][0][0], patch["segments"][-1][1]


def _clip_words(spec, words):
    """Words inside the clip (source time), preferring the clip's own edited captions."""
    if spec.get("words"):
        return [list(w[:3]) for w in spec["words"]]
    segs = _segs(spec)
    return [list(w[:3]) for w in (words or []) if any(a - 0.05 <= w[0] and w[1] <= b + 0.1 for a, b in segs)]


def _split(text):
    parts = re.split(r"\s*(?:;|\.(?:\s|$)|,?\s+(?:and then|then|and also|also|and)\s+|,\s*(?=(?:cut|trim|skip|start|end|"
                     r"make|change|fix|remove|follow|widen|keep|tighten|show|replace)\b))", text.strip(), flags=re.I)
    return [p.strip(" ,.") for p in parts if p and p.strip(" ,.")]


def plan(text, spec, words=None, playhead=None):
    patch, done, not_done = {}, [], []
    text = (text or "").strip()
    if not text:
        return {"patch": {}, "done": [], "not_done": ["Type what you'd like to change about this clip."]}
    if len(text) > 600:
        return {"patch": {}, "done": [], "not_done": ["That's a lot at once. Ask for one or two changes at a time."]}
    # caption fixes first: their quoted text can contain words like "and" that would split the request
    quoted = _caption_fixes(text, spec, words, patch, done, not_done)
    rest = quoted if quoted is not None else text
    for part in _split(rest):
        if not _one(part, spec, words, playhead, patch, done, not_done):
            not_done.append("I didn't understand \"%s\". I can trim the start or end, fix a caption word, shorten or "
                            "change the headline, tighten to the punchline, follow the person on the left or right, or "
                            "widen the frame to show both." % part[:80])
    return {"patch": patch, "done": done, "not_done": not_done}


def _caption_fixes(text, spec, words, patch, done, not_done):
    pats = [r"(?:fix|change|correct)\s+(?:the\s+)?captions?\s+(?:that\s+|where\s+it\s+)?(?:says?|saying|reads?)\s+[\"“']?(.+?)[\"”']?"
            r"\s*(?:,|;)?\s*(?:it\s+)?(?:should\s+(?:say|be|read)|to|into|->|→)\s+[\"“']?(.+?)[\"”']?\s*$",
            r"replace\s+[\"“']?(.+?)[\"”']?\s+with\s+[\"“']?(.+?)[\"”']?\s*$",
            r"^[\"“'](.+?)[\"”']\s+should\s+(?:say|be|read)\s+[\"“'](.+?)[\"”']\s*$"]
    for p in pats:
        m = re.search(p, text, re.I)
        if not m:
            continue
        wrong, right = m.group(1).strip(" \"'“”"), m.group(2).strip(" \"'“”.")
        cw = _clip_words(spec, words)
        toks = [w[2] for w in cw]
        wt = wrong.lower().split()
        norm = lambda s: re.sub(r"[^\w']", "", s.lower())
        hits = [i for i in range(len(toks) - len(wt) + 1) if [norm(t) for t in toks[i:i + len(wt)]] == [norm(x) for x in wt]]
        if not hits:
            not_done.append("I couldn't find a caption that says \"%s\" in this clip. Check the spelling, or fix it in "
                            "the Captions panel." % wrong)
        else:
            new = []
            i = 0
            rt = right.split()
            while i < len(cw):
                if i in hits:
                    a, b = cw[i][0], cw[i + len(wt) - 1][1]
                    step = (b - a) / max(1, len(rt))
                    new += [[round(a + k * step, 3), round(a + (k + 1) * step, 3), r] for k, r in enumerate(rt)]
                    i += len(wt)
                else:
                    new.append(cw[i])
                    i += 1
            patch["words"] = new
            done.append("Changed the caption \"%s\" to \"%s\"%s." % (wrong, right, " (%d places)" % len(hits) if len(hits) > 1 else ""))
        return (text[:m.start()] + text[m.end():]).strip(" ,.;")
    return None


def _one(part, spec, words, playhead, patch, done, not_done):
    p = part.lower().strip()
    segs = _segs(dict(spec, **{k: v for k, v in patch.items() if k in ("segments", "start", "end")}))
    L = _clip_len(segs)
    m = re.search(r"(?:cut|trim|skip|remove|drop|lose)\s+(?:off\s+)?(?:the\s+)?first\s+" + SECS, p) or \
        re.search(r"start\s+" + SECS + r"\s+later", p)
    if m:
        n = _num(m.group(1))
        if n >= L - 3:
            not_done.append("Cutting %gs from the start would leave less than 3 seconds." % n)
        else:
            _set_span(patch, segs, new_a=_to_source(segs, n))
            done.append("Cut the first %g seconds." % n)
        return True
    m = re.search(r"(?:cut|trim|skip|remove|drop|lose)\s+(?:off\s+)?(?:the\s+)?last\s+" + SECS, p) or \
        re.search(r"end\s+" + SECS + r"\s+(?:earlier|sooner)", p)
    if m:
        n = _num(m.group(1))
        if n >= L - 3:
            not_done.append("Cutting %gs from the end would leave less than 3 seconds." % n)
        else:
            _set_span(patch, segs, new_b=_to_source(segs, L - n))
            done.append("Cut the last %g seconds." % n)
        return True
    m = re.search(r"start\s+" + SECS + r"\s+(?:earlier|sooner|before)", p)
    if m:
        n = _num(m.group(1))
        _set_span(patch, segs, new_a=max(0.0, segs[0][0] - n))
        done.append("Started %g seconds earlier." % n)
        return True
    m = re.search(r"end\s+" + SECS + r"\s+later", p) or re.search(r"(?:add|keep|extend(?: it)?(?: by)?)\s+(?:another\s+)?"
                                                                  + SECS + r"\s+(?:at|to)\s+the\s+end", p)
    if m:
        n = _num(m.group(1))
        _set_span(patch, segs, new_b=segs[-1][1] + n)
        done.append("Ended %g seconds later." % n)
        return True
    m = re.search(r"(start|end)\s+(?:it\s+)?at\s+([\d:.]+)", p)
    if m:
        t = _clock(m.group(2))
        if t is None or t > L or (m.group(1) == "end" and t < 3):
            not_done.append("%s isn't a time inside this clip (it's %.0f seconds long)." % (m.group(2), L))
        elif m.group(1) == "start":
            if L - t < 3:
                not_done.append("Starting at %s would leave less than 3 seconds." % m.group(2))
            else:
                _set_span(patch, segs, new_a=_to_source(segs, t))
                done.append("Now starts at %s of the old clip." % m.group(2))
        else:
            _set_span(patch, segs, new_b=_to_source(segs, t))
            done.append("Now ends at %s." % m.group(2))
        return True
    if "headline" in p or "title" in p:
        return _headline(p, part, spec, patch, done, not_done)
    if re.search(r"tighten|punch ?line|payoff|end on the (?:joke|laugh|reaction)|cut (?:the )?(?:tail|ending)", p):
        return _tighten(spec, words, segs, patch, done, not_done)
    m = re.search(r"(?:follow|focus on|stay on|keep (?:the )?(?:camera|crop|frame) on|crop (?:to|on)|show)\s+(?:only\s+)?"
                  r"(?:the\s+)?(?:\w+\s+){0,2}(?:on\s+the\s+|to\s+the\s+)?(left|right)\b", p) or \
        re.search(r"\b(left|right)\s+(?:guy|girl|person|one|dude|man|woman|side)\b", p)
    if m and not re.search(r"\bboth\b|everyone|widen", p):
        side = m.group(1)
        patch["follow"] = side
        patch["crop_x"] = None
        done.append("The frame now follows the person on the %s for the whole clip." % side)
        return True
    if re.search(r"(?:follow|show)\s+(?:whoever|who'?s|the person)\s+(?:is\s+)?talking|automatic(?:ally)? (?:follow|crop)", p):
        patch["follow"] = None
        patch["wide"] = None
        done.append("Back to following whoever is talking.")
        return True
    if re.search(r"widen|zoom out|wider|both (?:of them|people|guys|girls)?\s*(?:are\s+)?in (?:the )?(?:frame|shot)|"
                 r"keep (?:them )?both|show (?:them )?both|show everyone|everyone in (?:the )?frame", p):
        here = re.search(r"\bhere\b|\bthis (?:part|bit|moment)\b|\bright now\b", p)
        if here and playhead is not None:
            t = _clip_time(segs, playhead)
            if t is None:
                not_done.append("The playhead isn't inside this clip, so I don't know where \"here\" is. Move it "
                                "there and ask again, or say \"the whole clip\".")
                return True
            rng = [round(max(0.0, t - 3), 2), round(min(L, t + 3), 2)]
            prev = spec.get("wide") if isinstance(spec.get("wide"), list) else []
            patch["wide"] = prev + [rng]
            done.append("Shows both people from %.0fs to %.0fs of the clip." % tuple(rng))
        else:
            patch["wide"] = True
            done.append("Shows both people for the whole clip (where both are on camera).")
        patch["follow"] = None
        return True
    return False


def _clip_time(segs, src_t):
    acc = 0.0
    for a, b in segs:
        if a <= src_t <= b:
            return acc + src_t - a
        acc += b - a
    return None


def _headline(p, part, spec, patch, done, not_done):
    cur = spec.get("headline") or ""
    if re.search(r"remove|delete|no headline|get rid|without (?:a|the) headline", p):
        patch["headline"] = ""
        done.append("Removed the headline.")
        return True
    m = re.search(r"(?:change|set|make|rename)\s+(?:the\s+)?(?:headline|title)\s+(?:to|into|say|as)\s+[\"“']?(.+?)[\"”']?\s*$", part, re.I)
    if m:
        patch["headline"] = m.group(1).strip()[:120]
        done.append("Headline is now \"%s\"." % patch["headline"])
        return True
    if re.search(r"short|tight|fewer words|punchier|too long", p):
        if not cur:
            not_done.append("This clip has no headline to shorten.")
            return True
        new = shorten_headline(cur)
        if len(new) >= len(cur):
            not_done.append(("The headline is already short (\"%s\"). " % cur if len(cur.split()) <= 6 else
                             "I couldn't make the headline shorter without losing the point. ") +
                            "Type the one you want: \"change the headline to ...\".")
        else:
            patch["headline"] = new
            done.append("Shortened the headline to \"%s\"." % new)
        return True
    if re.search(r"caps|capital|upper", p):
        patch["headline"] = cur.upper()
        done.append("Headline is in capitals.")
        return True
    not_done.append("I can shorten, change or remove the headline. Try \"change the headline to ...\".")
    return True


SOFT = {"literally", "actually", "basically", "really", "just", "like", "totally", "honestly", "kinda", "lowkey", "um", "uh"}
LEAD = {"so", "and", "but", "okay", "ok", "well", "yeah", "then"}
PREP = {"to", "at", "in", "for", "from", "with", "during", "after", "before", "on", "into", "about", "while"}


def shorten_headline(h, target=6):
    """Shorter, same point. Only safe cuts: filler words, a leading "so / and / okay", and one trailing place phrase
    like "to the event" / "at the party". Never cuts mid-phrase; if that isn't enough it returns h unchanged and the
    prompt box asks for the headline instead of guessing a worse one."""
    ws = h.split()
    ws = [w for w in ws if w.lower().strip(".,!?") not in SOFT] or ws
    while len(ws) > 3 and ws[0].lower().strip(".,!?") in LEAD:
        ws = ws[1:]
    if len(ws) > target and len(ws) >= 6:
        tail = " ".join(ws[-3:]).lower().strip(".,!?")
        if re.match(r"^(?:to|at|in|from|during|after)\s+(?:the|a|my|his|her|our|their|this|that)\s+\w+$", tail):
            ws = ws[:-3]
    return " ".join(ws).rstrip(",;:")


def _tighten(spec, words, segs, patch, done, not_done):
    cw = _clip_words(spec, words)
    if not cw:
        not_done.append("This clip has no transcript yet, so I can't find the punchline. Trim it on the timeline.")
        return True
    from .transcribe import sentences_from_words
    sents = sentences_from_words([list(w[:3]) + [1.0] for w in cw])
    beats = [s for s in sents if BEAT.search(s["text"])]
    if not beats:
        not_done.append("I couldn't find a clear punchline or reaction in this clip (no laugh, \"no way\", shout...). "
                        "Tell me where to end it instead, like \"end at 0:18\".")
        return True
    last = beats[-1]
    # keep a short reaction line right after the punchline (it's part of the payoff), then stop
    nxt = [s for s in sents if s["start"] >= last["end"] - 0.01]
    end = last["end"]
    if len(nxt) > 1 and nxt[1]["end"] - last["end"] <= 2.5 and BEAT.search(nxt[1]["text"]):
        end = nxt[1]["end"]
    end = min(end + 0.4, segs[-1][1])
    if segs[-1][1] - end < 0.8:
        done.append("It already ends on the punchline (\"%s\")." % last["text"][:60])
        return True
    cut = segs[-1][1] - end
    _set_span(patch, segs, new_b=end)
    done.append("Ends right after the punchline now (\"%s\"), %.0f seconds shorter." % (last["text"][:60], cut))
    return True

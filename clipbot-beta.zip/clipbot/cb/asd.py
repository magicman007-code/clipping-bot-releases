"""Active-speaker detection with a small neural network (Light-ASD, CVPR 2023, MIT licence).

For every face track it looks at the mouth region over time AND listens to the audio, and scores each frame "is this
person the one talking right now". Unlike mouth-motion heuristics it learned audio-visual sync from real speech, so a
listener who laughs, chews or mouths along isn't mistaken for the speaker.

analyze(clip, w0, h0, workdir, fps=10) -> (samples, active, info)
  samples  [(t, [(cx, cy, w, h, det_score, track_id), ...])] at `fps`, clip pixel coordinates (same as speaker.py)
  active   per sample: track id of the speaker, "both" when two people talk at once or it can't tell who is talking
           while several faces are on screen, or None (nobody visible / silence before anyone spoke)
  info     {"method", "tracks", "confidence": [0..1 per sample], "speech": [bool per sample]}
Model: assets/models/light_asd.onnx (converted from the authors' TalkSet weights; scores match PyTorch to 1e-5).
"""
import os
import wave

import numpy as np

from .common import ROOT, YUNET, ffmpeg

MODEL = os.path.join(ROOT, "assets", "models", "light_asd.onnx")
MARGIN = 1.0                  # how clearly (in model logits) the speaker must beat the next face
VFPS = 25                     # the network was trained on 25 fps video and 100 fps MFCC
_SESS = None


def available():
    if not os.path.exists(MODEL):
        return False
    try:
        import onnxruntime  # noqa: F401
        return True
    except Exception:
        return False


def _session():
    global _SESS
    if _SESS is None:
        import onnxruntime as ort
        so = ort.SessionOptions()
        so.intra_op_num_threads = max(1, min(4, (os.cpu_count() or 2) - 1))
        so.log_severity_level = 3
        _SESS = ort.InferenceSession(MODEL, so, providers=["CPUExecutionProvider"])
    return _SESS


# ------------------------------------------------------------------ audio features (python_speech_features.mfcc port)
def _mel(f):
    return 2595 * np.log10(1 + f / 700.0)


def _imel(m):
    return 700 * (10 ** (m / 2595.0) - 1)


def _dct_ortho(x):
    """DCT-II with orthonormal scaling along the last axis (scipy.fftpack.dct(x, type=2, norm='ortho'))."""
    N = x.shape[-1]
    k = np.arange(N)
    basis = np.cos(np.pi * (2 * k[None, :] + 1) * k[:, None] / (2.0 * N))      # [k, n]
    out = x @ basis.T * np.sqrt(2.0 / N)
    out[..., 0] /= np.sqrt(2.0)
    return out


def mfcc(sig, sr=16000, winlen=0.025, winstep=0.01, numcep=13, nfilt=26, nfft=512, preemph=0.97, ceplifter=22):
    """Same numbers as python_speech_features.mfcc(sig, sr, numcep=13) - what the network was trained on."""
    sig = np.asarray(sig, np.float64)
    sig = np.append(sig[0], sig[1:] - preemph * sig[:-1]) if len(sig) else sig
    flen, fstep = int(round(winlen * sr)), int(round(winstep * sr))
    n = 1 if len(sig) <= flen else 1 + int(np.ceil((len(sig) - flen) / float(fstep)))
    pad = np.concatenate([sig, np.zeros(max(0, (n - 1) * fstep + flen - len(sig)))])
    idx = np.arange(flen)[None, :] + np.arange(n)[:, None] * fstep
    frames = pad[idx]
    mag = np.abs(np.fft.rfft(frames, nfft))
    pspec = mag ** 2 / nfft
    energy = pspec.sum(1)
    energy = np.where(energy == 0, np.finfo(float).eps, energy)
    pts = _imel(np.linspace(_mel(0), _mel(sr / 2), nfilt + 2))
    bins = np.floor((nfft + 1) * pts / sr)
    fb = np.zeros((nfilt, nfft // 2 + 1))
    for j in range(nfilt):
        for i in range(int(bins[j]), int(bins[j + 1])):
            fb[j, i] = (i - bins[j]) / (bins[j + 1] - bins[j])
        for i in range(int(bins[j + 1]), int(bins[j + 2])):
            fb[j, i] = (bins[j + 2] - i) / (bins[j + 2] - bins[j + 1])
    feat = pspec @ fb.T
    feat = np.where(feat == 0, np.finfo(float).eps, feat)
    c = _dct_ortho(np.log(feat))[:, :numcep]
    c = c * (1 + (ceplifter / 2.0) * np.sin(np.pi * np.arange(numcep) / ceplifter))
    c[:, 0] = np.log(energy)
    return c.astype(np.float32)


def _read_audio(clip, workdir):
    wav = os.path.join(workdir, "asd16k.wav")
    ffmpeg(["-i", clip, "-vn", "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", wav])
    with wave.open(wav, "rb") as wf:
        x = np.frombuffer(wf.readframes(wf.getnframes()), dtype=np.int16)
    try:
        os.remove(wav)
    except OSError:
        pass
    return x


def speech_mask(x, n_frames, fps=VFPS):
    """Rough voice activity per video frame (energy in the speech band against the clip's own noise floor)."""
    hop = int(16000 / fps)
    m = min(n_frames, len(x) // hop)
    out = np.zeros(n_frames, bool)
    if m == 0:
        return out
    e = 20 * np.log10(np.sqrt((x[: m * hop].astype(np.float32).reshape(m, hop) ** 2).mean(1)) + 1)
    lo, hi = np.percentile(e, 15), np.percentile(e, 97)
    out[:m] = e > lo + 0.35 * max(3.0, hi - lo)
    return out


# ------------------------------------------------------------------ faces: detect + track at 25 fps
def _detect_tracks(clip, w0, h0, det_every=2, max_frames=VFPS * 60 * 10):
    """Face boxes for every 25 fps frame, linked into tracks, plus the grayscale frames needed for the crops.
    Detection runs on every `det_every`-th frame and is interpolated in between (faces don't teleport in 80 ms)."""
    import cv2
    aw = 640
    ah = int(round(aw * h0 / float(w0)))
    k = w0 / float(aw)
    det = cv2.FaceDetectorYN.create(YUNET, "", (aw, ah), 0.6, 0.3, 5000)
    cap = cv2.VideoCapture(clip)
    sfps = cap.get(cv2.CAP_PROP_FPS) or 30
    gray_w = 640                                   # crops are 112 px: a 640 px wide grayscale copy is plenty
    gk = w0 / float(gray_w)
    gray_h = int(round(h0 / gk))
    frames, dets = [], []
    want, i = 0.0, 0
    while len(frames) < max_frames and cap.grab():
        t = i / sfps
        i += 1
        if t + 1e-6 < want:
            continue
        ok, img = cap.retrieve()
        if not ok:
            break
        want += 1.0 / VFPS
        frames.append(cv2.cvtColor(cv2.resize(img, (gray_w, gray_h), interpolation=cv2.INTER_AREA), cv2.COLOR_BGR2GRAY))
        if (len(frames) - 1) % det_every == 0:
            _, f = det.detect(cv2.resize(img, (aw, ah)))
            dets.append([(r[:4] * k).tolist() + [float(r[14])] for r in (f if f is not None else [])
                         if r[3] * k > 0.045 * h0])
        else:
            dets.append(None)
    cap.release()
    # link detections (x, y, w, h, score) into tracks by overlap, on the detected frames
    tracks = []                                     # {"f": [frame], "b": [box]}
    live = []
    for fi, ds in enumerate(dets):
        if ds is None:
            continue
        used = set()
        nxt = []
        for tr in live:
            lb = tr["b"][-1]
            best, bi = 0.3, None
            for j, d in enumerate(ds):
                if j in used:
                    continue
                o = _iou(lb, d)
                if o > best:
                    best, bi = o, j
            if bi is not None:
                used.add(bi)
                tr["f"].append(fi)
                tr["b"].append(ds[bi])
                nxt.append(tr)
            elif fi - tr["f"][-1] <= 8:            # missed for a moment: keep it alive
                nxt.append(tr)
            else:
                tracks.append(tr)
        for j, d in enumerate(ds):
            if j not in used:
                nxt.append({"f": [fi], "b": [d]})
        live = nxt
    tracks += live
    out = []
    for tr in tracks:
        if tr["f"][-1] - tr["f"][0] < VFPS * 0.8:   # under 0.8 s: a false detection or someone passing by
            continue
        fr = np.arange(tr["f"][0], tr["f"][-1] + 1)
        B = np.array(tr["b"])
        box = np.stack([np.interp(fr, tr["f"], B[:, c]) for c in range(5)], 1)
        out.append({"frames": fr, "box": box})
    return frames, out, gk


def _iou(a, b):
    ax1, ay1, ax2, ay2 = a[0], a[1], a[0] + a[2], a[1] + a[3]
    bx1, by1, bx2, by2 = b[0], b[1], b[0] + b[2], b[1] + b[3]
    iw, ih = max(0, min(ax2, bx2) - max(ax1, bx1)), max(0, min(ay2, by2) - max(ay1, by1))
    inter = iw * ih
    return inter / float(a[2] * a[3] + b[2] * b[3] - inter + 1e-6)


def _medfilt(x, k=13):
    """Median filter with zero padding at the ends (scipy.signal.medfilt)."""
    x = np.asarray(x, np.float64)
    k = min(k, len(x) if len(x) % 2 else len(x) - 1)
    if k < 3:
        return x
    h = k // 2
    p = np.pad(x, h)
    return np.median(np.lib.stride_tricks.sliding_window_view(p, k), axis=1)


def _crops(frames, tr, gk, cs=0.40):
    """112x112 mouth-centred face crops, exactly like the authors' Columbia pipeline (box smoothed, padded, centre crop)."""
    import cv2
    b = tr["box"] / gk                                # into the grayscale frame's pixels
    s = _medfilt(np.maximum(b[:, 2], b[:, 3]) / 2)
    cy = _medfilt(b[:, 1] + b[:, 3] / 2)
    cx = _medfilt(b[:, 0] + b[:, 2] / 2)
    out = np.zeros((len(tr["frames"]), 112, 112), np.float32)
    for j, fi in enumerate(tr["frames"]):
        img = frames[fi]
        bs = s[j]
        bsi = int(bs * (1 + 2 * cs))
        pad = cv2.copyMakeBorder(img, bsi, bsi, bsi, bsi, cv2.BORDER_CONSTANT, value=110)
        my, mx = cy[j] + bsi, cx[j] + bsi
        face = pad[int(my - bs):int(my + bs * (1 + 2 * cs)), int(mx - bs * (1 + cs)):int(mx + bs * (1 + cs))]
        if face.size == 0:
            continue
        face = cv2.resize(face, (224, 224))
        out[j] = face[56:168, 56:168]
    return out


DURATIONS = (2,)           # one 2 s window: same accuracy as the authors (1, 2, 4) ensemble on our tests, half the time


def _score_track(a_feat, v_feat, durations=None):
    """Per-frame speaking score (logit; > 0 means speaking). Averaged over several window lengths, as the authors do."""
    sess = _session()
    durations = durations or DURATIONS
    T = min(len(v_feat), (len(a_feat) - len(a_feat) % 4) // 4)
    if T < 3:
        return np.full(len(v_feat), -5.0, np.float32)
    a_feat, v_feat = a_feat[: T * 4], v_feat[:T]
    allsc = []
    for dsec in durations:
        n = dsec * VFPS
        sc = []
        for s0 in range(0, T, n):
            e = min(T, s0 + n)
            s = max(0, e - 3) if e - s0 < 3 else s0    # a sliver at the end: score it with its neighbours
            r = sess.run(None, {"audio": a_feat[s * 4: e * 4][None], "video": v_feat[s:e][None]})[0]
            sc.append(r[s0 - s:])
        allsc.append(np.concatenate(sc)[:T])
    out = np.mean(allsc, 0)
    if T < len(v_feat):
        out = np.concatenate([out, np.full(len(v_feat) - T, out[-1])])
    return out


def analyze(clip, w0, h0, workdir, fps=10):
    frames, tracks, gk = _detect_tracks(clip, w0, h0)
    nF = len(frames)
    x = _read_audio(clip, workdir)
    feats = mfcc(x, 16000)
    speech = speech_mask(x, nF)
    S = np.full((len(tracks), nF), np.nan, np.float32)        # per track, per 25 fps frame
    for k_, tr in enumerate(tracks):
        v = _crops(frames, tr, gk)
        f0, f1 = int(tr["frames"][0]), int(tr["frames"][-1]) + 1
        a = feats[f0 * 4: f1 * 4]
        sc = _score_track(a, v)
        # smooth over ~0.8 s: decide per phrase, not per frame
        ker = np.ones(21) / 21.0
        sm = np.convolve(np.pad(sc, 10, mode="edge"), ker, mode="valid")
        S[k_, f0:f0 + len(sm)] = sm[: f1 - f0]
    frames = None
    # sample at `fps` for the renderer
    step = VFPS / float(fps)
    samples, active, conf, spk = [], [], [], []
    js = [int(round(q * step)) for q in range(int(nF / step))]
    for j in js:
        t = j / float(VFPS)
        faces = []
        for k_, tr in enumerate(tracks):
            r = j - int(tr["frames"][0])
            if 0 <= r < len(tr["frames"]):
                bx, by, bw, bh, ds = tr["box"][r]
                faces.append((bx + bw / 2, by + bh / 2, bw, bh, ds, k_))
        samples.append((t, faces))
        col = S[:, j] if len(tracks) else np.array([])
        vis = [(float(col[f[5]]), f[5]) for f in faces if not np.isnan(col[f[5]])]
        vis.sort(reverse=True)
        voiced = bool(speech[max(0, j - 5): j + 6].any())
        spk.append(voiced)
        if not vis:
            active.append(None)
            conf.append(0.0)
            continue
        top, tid = vis[0]
        second = vis[1][0] if len(vis) > 1 else -9.0
        c = 1 / (1 + np.exp(-(top - max(second, 0.0))))       # how clearly the top face beats the rest
        conf.append(round(float(c), 3))
        if len(vis) == 1:
            active.append(tid)
        elif not voiced:
            active.append(None)                                # silence: keep whoever was on screen
        elif top - second >= MARGIN:
            active.append(tid)                                 # one face clearly matches the voice
        else:
            active.append("both")                              # two talking at once, or can't tell: show everyone
    active = _hysteresis(active, fps)
    return samples, active, {"method": "light-asd", "tracks": len(tracks), "confidence": conf, "speech": spk}


def _hysteresis(raw, fps, min_turn=0.5):
    """Cut to a new speaker only when they hold the floor for `min_turn` s, and back-date the cut to when they
    started (offline we can look ahead), so the cut lands on the turn and never flickers mid-word."""
    need = max(1, int(min_turn * fps))
    out = list(raw)
    # fill silences with the surrounding speaker (hold the shot through pauses)
    last = None
    for i, r in enumerate(out):
        if r is None:
            out[i] = last
        else:
            last = r
    first = next((r for r in out if r is not None), None)
    out = [r if r is not None else first for r in out]
    # drop runs shorter than `need` (merge into the previous run)
    runs = []
    for r in out:
        if runs and runs[-1][0] == r:
            runs[-1][1] += 1
        else:
            runs.append([r, 1])
    changed = True
    while changed and len(runs) > 1:
        changed = False
        for i, (r, n) in enumerate(runs):
            if n < need:
                j = i - 1 if i > 0 else i + 1
                runs[j][1] += n
                runs.pop(i)
                changed = True
                break
        k = 0
        while k < len(runs) - 1:
            if runs[k][0] == runs[k + 1][0]:
                runs[k][1] += runs[k + 1][1]
                runs.pop(k + 1)
            else:
                k += 1
    res = []
    for r, n in runs:
        res += [r] * n
    return res

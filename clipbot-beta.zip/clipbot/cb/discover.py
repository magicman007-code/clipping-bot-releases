"""Find streams to clip: who is live playing a game (GTA 6, Just Chatting, anything) right now, on Twitch and Kick,
sorted by viewers. One click in the UI starts the live clipper on that channel.

Twitch uses the Helix API with the user's connected Twitch app (same credentials as clip-making). Kick uses its public
API (no login); datacenter IPs are sometimes blocked by Cloudflare, so Kick discovery is best-effort and works most
reliably from the user's own computer.
"""
import json
import re
import urllib.parse
import urllib.request

DEFAULT_GAME = "Grand Theft Auto VI"
KICK_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
           "Chrome/126.0 Safari/537.36")


# ---------------------------------------------------------------- Twitch
def _tw_headers(id_url=None):
    from .social import _tw_access
    c = _tw_access(id_url)
    return {"Client-Id": c["client_id"], "Authorization": "Bearer " + c["access_token"]}


def tw_game_id(name, api=None, headers=None):
    from .social import _req, TW_API
    h = headers or _tw_headers()
    j = _req((api or TW_API) + "/games?" + urllib.parse.urlencode({"name": name}), headers=h)
    data = j.get("data") or []
    return data[0]["id"] if data else None


def twitch_streams(game=DEFAULT_GAME, limit=40, api=None, id_url=None):
    """Live Twitch streams for a game, most viewers first."""
    from .social import _req, TW_API, _err
    h = _tw_headers(id_url)
    gid = tw_game_id(game, api, h)
    if not gid:
        return []
    out = []
    cursor = None
    while len(out) < limit:
        q = {"game_id": gid, "first": min(100, limit - len(out)), "type": "live"}
        if cursor:
            q["after"] = cursor
        j = _req((api or TW_API) + "/streams?" + urllib.parse.urlencode(q), headers=h)
        if _err(j):
            break
        for s in j.get("data") or []:
            thumb = (s.get("thumbnail_url") or "").replace("{width}", "320").replace("{height}", "180")
            out.append({"platform": "twitch", "channel": s.get("user_login"), "name": s.get("user_name"),
                        "title": s.get("title") or "", "viewers": int(s.get("viewer_count") or 0),
                        "url": "https://twitch.tv/" + (s.get("user_login") or ""), "thumbnail": thumb,
                        "game": s.get("game_name") or game})
        cursor = (j.get("pagination") or {}).get("cursor")
        if not cursor:
            break
    return out[:limit]


# ---------------------------------------------------------------- Kick
def _kick_get(path, timeout=20, api=None):
    url = (api or "https://kick.com") + path
    req = urllib.request.Request(url, headers={"User-Agent": KICK_UA, "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read())


def kick_slug(game):
    s = re.sub(r"[^a-z0-9]+", "-", (game or "").lower()).strip("-")
    return {"grand-theft-auto-vi": "grand-theft-auto-vi", "gta-6": "grand-theft-auto-vi",
            "gta-vi": "grand-theft-auto-vi"}.get(s, s)


def kick_streams(game=DEFAULT_GAME, limit=40, api=None):
    """Live Kick streams for a category, most viewers first. Best-effort (Cloudflare may block datacenter IPs)."""
    slug = kick_slug(game)
    out = []
    # Kick's category livestreams listing (web API). Shape varies, so read defensively.
    for path in ("/api/v2/categories/%s/livestreams?sort=desc&page=1&limit=%d" % (slug, limit),
                 "/stream/livestreams/en?category=%s&sort=viewers&limit=%d" % (slug, limit)):
        try:
            data = _kick_get(path, api=api)
        except Exception:
            continue
        rows = data.get("data") if isinstance(data, dict) else data
        if not isinstance(rows, list):
            continue
        for s in rows[:limit]:
            ch = s.get("channel") or s.get("broadcaster") or {}
            user = (ch.get("slug") or ch.get("username") or s.get("slug") or "")
            if not user:
                continue
            thumb = ((s.get("thumbnail") or {}).get("url") if isinstance(s.get("thumbnail"), dict)
                     else s.get("thumbnail")) or ""
            out.append({"platform": "kick", "channel": user, "name": ch.get("username") or user,
                        "title": s.get("session_title") or s.get("title") or "",
                        "viewers": int(s.get("viewer_count") or s.get("viewers") or 0),
                        "url": "https://kick.com/" + user, "thumbnail": thumb, "game": game})
        if out:
            break
    out.sort(key=lambda s: -s["viewers"])
    return out[:limit]


# ---------------------------------------------------------------- YouTube
def _yt_key():
    from .connect import get
    y = get().get("youtube") or {}
    return y.get("api_key") or ""


def youtube_streams(game=DEFAULT_GAME, limit=40, api=None, key=None):
    """Live YouTube streams matching a search term, by viewers. Needs a YouTube Data API key (keyword-based, and uses
    API quota). Returns [] with no key."""
    key = key or _yt_key()
    if not key:
        raise RuntimeError("add a YouTube Data API key in Settings to find YouTube live streams")
    base = api or "https://www.googleapis.com/youtube/v3"
    q = {"part": "snippet", "eventType": "live", "type": "video", "order": "viewCount",
         "maxResults": min(50, limit), "q": game, "key": key}
    try:
        data = json.loads(urllib.request.urlopen(base + "/search?" + urllib.parse.urlencode(q), timeout=20).read())
    except Exception as e:
        raise RuntimeError("YouTube search failed: %s" % str(e)[:120])
    items = data.get("items") or []
    ids = [it["id"]["videoId"] for it in items if (it.get("id") or {}).get("videoId")]
    viewers = {}
    if ids:
        try:
            vd = json.loads(urllib.request.urlopen(
                base + "/videos?" + urllib.parse.urlencode({"part": "liveStreamingDetails,snippet",
                                                            "id": ",".join(ids), "key": key}), timeout=20).read())
            for v in vd.get("items") or []:
                viewers[v["id"]] = int((v.get("liveStreamingDetails") or {}).get("concurrentViewers") or 0)
        except Exception:
            pass
    out = []
    for it in items:
        vid = (it.get("id") or {}).get("videoId")
        sn = it.get("snippet") or {}
        if not vid:
            continue
        out.append({"platform": "youtube", "channel": sn.get("channelTitle") or "", "name": sn.get("channelTitle") or "",
                    "title": sn.get("title") or "", "viewers": viewers.get(vid, 0),
                    "url": "https://www.youtube.com/watch?v=" + vid,
                    "thumbnail": ((sn.get("thumbnails") or {}).get("medium") or {}).get("url") or "", "game": game})
    out.sort(key=lambda s: -s["viewers"])
    return out[:limit]


# ---------------------------------------------------------------- combined
def find_streams(game=DEFAULT_GAME, platforms=("twitch", "kick", "youtube"), limit=40):
    """Live streams for a game across platforms, most viewers first. Each platform fails soft."""
    found, errors = [], {}
    if "twitch" in platforms:
        try:
            found += twitch_streams(game, limit)
        except Exception as e:
            errors["twitch"] = str(e)[:160]
    if "kick" in platforms:
        try:
            found += kick_streams(game, limit)
        except Exception as e:
            errors["kick"] = str(e)[:160]
    if "youtube" in platforms:
        try:
            found += youtube_streams(game, limit)
        except Exception as e:
            errors["youtube"] = str(e)[:160]
    found.sort(key=lambda s: -s["viewers"])
    return {"game": game, "streams": found[:limit], "errors": errors}

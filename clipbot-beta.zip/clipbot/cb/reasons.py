"""Reason codes for the quality gate.

cb/qa.py (render-time) and cb/verify.py (independent, post-render) each produce human-readable
defect strings. This module turns those strings into a small, stable set of machine-readable
reason codes, each with a severity and - where the fix is mechanical - a repair hint, and folds
them into one gate verdict:

    pass    - nothing wrong
    repair  - only mechanically fixable issues (loudness, true peak, faststart, container) remain;
              re-finish the file, the picture and the cut are fine
    block   - something a re-mux can't fix (wrong size, black/frozen video, captions that read
              wrong, letterboxing); needs a re-render or a human look

The codes are the contract: they don't change wording when a message is reworded, so the gate is
testable and other code (auto-repair, dashboards, learning) can act on them. Pure standard library.
"""
import re

# code -> (severity, one-line label, repair hint or None)
CODES = {
    "RES_MISMATCH":     ("block",  "wrong resolution",                 None),
    "FPS_OFF":          ("block",  "wrong frame rate",                 "re-encode at 30fps"),
    "CODEC_WRONG":      ("repair", "wrong codecs",                     "re-encode to H.264/AAC"),
    "NOT_FASTSTART":    ("repair", "moov after mdat (slow to start)",  "remux with +faststart"),
    "NO_AUDIO":         ("block",  "no audio stream",                  None),
    "LOUDNESS_OFF":     ("repair", "loudness off target",             "re-run two-pass loudnorm to -14 LUFS"),
    "TRUE_PEAK_HOT":    ("repair", "true peak too hot",                "apply a -1 dBTP limiter"),
    "BLACK_FRAMES":     ("block",  "black frames",                     None),
    "FROZEN":           ("block",  "frozen picture",                   None),
    "DEAD_AIR":         ("warn",   "long silence",                     "trim the silence or jump-cut"),
    "LETTERBOX":        ("block",  "letterbox/pillarbox bars",         None),
    "CAPTION_WER_HIGH": ("block",  "captions read wrong on screen",    "re-run the caption pass or fix in Captions"),
    "CAPTION_COVERAGE_LOW": ("warn", "speech left uncaptioned",        "check the transcript covers the whole clip"),
    "CAPTION_ON_FACE":  ("warn",   "captions over a face",             "move the caption band off the face"),
    "DUR_DRIFT":        ("warn",   "duration drifted from the cut",    None),
    "TOO_LONG":         ("warn",   "long for a short",                 "jump-cut to <=45s"),
    "NO_CAPTIONS":      ("warn",   "no caption words",                 None),
    "HEADLINE_MISSING": ("warn",   "headline card not visible",        "re-draw the headline card"),
    "NO_FACE_OPEN":     ("warn",   "no subject in the first frame",    "cold-open on the subject"),
    "COLD_OPEN_LATE":   ("warn",   "speech starts late",               "trim to the first word"),
    "SLOW_OPEN":        ("warn",   "slow open (few words in 3s)",      None),
    "OTHER":            ("warn",   "other",                            None),
}

# ordered (pattern -> code); first match wins. Patterns match the strings qa.py / verify.py emit.
_PATTERNS = [
    (r"resolution .*want|output is .*expected",     "RES_MISMATCH"),
    (r"frame rate",                                 "FPS_OFF"),
    (r"codecs ",                                    "CODEC_WRONG"),
    (r"faststart",                                  "NOT_FASTSTART"),
    (r"no audio",                                   "NO_AUDIO"),
    (r"loudness ",                                  "LOUDNESS_OFF"),
    (r"true peak",                                  "TRUE_PEAK_HOT"),
    (r"near-black|black frames",                    "BLACK_FRAMES"),
    (r"frozen",                                     "FROZEN"),
    (r"dead air|silence",                           "DEAD_AIR"),
    (r"letterbox|pillarbox",                        "LETTERBOX"),
    (r"wrong words on screen",                      "CAPTION_WER_HIGH"),
    (r"captioned|coverage",                         "CAPTION_COVERAGE_LOW"),
    (r"captions overlap a face",                    "CAPTION_ON_FACE"),
    (r"duration .*differs",                         "DUR_DRIFT"),
    (r"long for a short",                           "TOO_LONG"),
    (r"no caption words",                           "NO_CAPTIONS"),
    (r"headline card not visible",                  "HEADLINE_MISSING"),
    (r"no face visible|open on the subject",        "NO_FACE_OPEN"),
    (r"speech starts at",                           "COLD_OPEN_LATE"),
    (r"slow open",                                  "SLOW_OPEN"),
]
_RX = [(re.compile(p, re.I), c) for p, c in _PATTERNS]

_RANK = {"block": 3, "repair": 2, "warn": 1}


def classify(text):
    """Map one defect/warning string to a reason code (OTHER if nothing matches)."""
    for rx, code in _RX:
        if rx.search(text or ""):
            return code
    return "OTHER"


def annotate(items):
    """A list of defect/warning strings -> a list of {code, severity, text, repair}, de-duplicated by code
    (the worst-severity, first text of each code kept)."""
    out = {}
    for text in items or []:
        code = classify(text)
        sev, _label, repair = CODES.get(code, CODES["OTHER"])
        if code not in out:
            out[code] = {"code": code, "severity": sev, "text": text, "repair": repair}
    # stable order: block first, then repair, then warn; within a tier, first seen
    return sorted(out.values(), key=lambda r: -_RANK[r["severity"]])


def verdict(reasons):
    """pass / repair / block from a list of annotated reasons (or raw severities)."""
    sevs = [r["severity"] if isinstance(r, dict) else r for r in reasons]
    if "block" in sevs:
        return "block"
    if "repair" in sevs:
        return "repair"
    return "pass"


def gate(defects, warnings=None):
    """Fold defect + warning strings into one structured verdict.

    Returns {verdict, reasons, blocking, repairs, warnings, repair_hints} where the three lists are
    codes at each severity and repair_hints pairs each repairable code with its mechanical fix."""
    reasons = annotate(list(defects or []) + list(warnings or []))
    v = verdict(reasons)
    by = lambda s: [r["code"] for r in reasons if r["severity"] == s]
    return {
        "verdict": v,
        "ok": v == "pass",
        "reasons": reasons,
        "blocking": by("block"),
        "repairs": by("repair"),
        "warnings": by("warn"),
        "repair_hints": [{"code": r["code"], "fix": r["repair"]} for r in reasons if r["repair"]],
    }

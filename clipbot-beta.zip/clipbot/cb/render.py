"""Clip renderer (v3).

One hand-picked moment -> finished 1080x1920 short, in ONE final encode:
  cut (frame-exact, native aspect) -> face analysis -> layout per shot
  (auto-detected facecam+screen / tall follow-crop / stacked split / blur-fit / vertical passthrough)
  -> subtle punch-zoom on the peak line(s) -> headline card -> layout-aware word captions
  -> optional watermark -> voice clean-up + two-pass loudnorm to -14 LUFS -> QA sheet.
"""
import json
import os
import re
import wave

import numpy as np

from .common import FONT_DIR, FPS, YUNET, ffmpeg, fpath, probe, run

W, H = 1080, 1920
BAND = 300                      # headline band on top of landscape sources
BODY_H = H - BAND               # 1620: the 2:3 video body under the band
# output shapes. 9:16 uses the speaker-aware vertical layouts below; the others use frame_body().
ASPECTS = {"9:16": (1080, 1920), "4:5": (1080, 1350), "1:1": (1080, 1080), "16:9": (1920, 1080)}
CAP_SCALE = {"9:16": 1.0, "4:5": 0.92, "1:1": 0.85, "16:9": 0.8}     # caption size relative to the 9:16 default


def aspect_of(spec):
    a = str((spec or {}).get("aspect") or "9:16").replace("x", ":")
    return a if a in ASPECTS else "9:16"


def frame_geometry(w0, h0, OW, OH, layout="auto", have_face=False, fixed=False):
    """How a w0 x h0 source fills an OW x OH frame: ('cover'|'crop_x'|'crop_y'|'fit', crop_w, crop_h).
    Mirrored in editor/index.html (frameGeom) so the preview matches the render."""
    src, tgt = w0 / float(h0), OW / float(OH)
    if layout == "blur_fit":
        return "fit", w0, h0
    if abs(src / tgt - 1) <= 0.03:
        return "cover", w0, h0
    if src > tgt:
        cw = int(round(h0 * tgt)) // 2 * 2
        return ("crop_x", cw, h0) if (have_face or fixed or cw >= 0.75 * w0) else ("fit", w0, h0)
    ch = int(round(w0 / tgt)) // 2 * 2
    return ("crop_y", w0, ch) if ch >= 0.75 * h0 else ("fit", w0, h0)


def frame_head(OH):
    """(headline centre y, max headline block height) on a framed (non 9:16) canvas."""
    mh = int(OH * 0.2)
    return int(mh / 2 + 0.03 * OH), mh


def frame_body(samples, dur, w0, h0, OW, OH, layout, info, fixed_x=None):
    """Body graph for 1:1 / 4:5 / 16:9 outputs: follow-crop on the speaker when the source is wider,
    face-centred vertical crop when it's taller, blurred-fill when the shapes are too different."""
    fs_all = [(t, f) for t, ff in samples for f in _real(ff, h0)]
    mode, cw, ch = frame_geometry(w0, h0, OW, OH, layout, bool(fs_all), fixed_x is not None)
    cap_y = int(OH * 0.82)
    if mode == "fit":
        fc = _fit_blur("0:v", "body", OW, OH, "f")
        fg_h = OW * h0 / float(w0)
        if fg_h < OH * 0.8:      # letterboxed picture: captions just under it if there's room
            cap_y = int(min(OH * 0.86, OH / 2 + fg_h / 2 + 0.06 * OH))
        info.append("%s frame: whole picture on a blurred fill" % (layout if layout == "blur_fit" else "fit"))
        k = min(OW / float(w0), OH / float(h0))
        ymap = (k, (OH - h0 * k) / 2)
    elif mode == "cover":
        fc = "[0:v]scale=%d:%d:force_original_aspect_ratio=increase:flags=lanczos,crop=%d:%d,setsar=1[body]" % (OW, OH, OW, OH)
        info.append("full frame")
        k = max(OW / float(w0), OH / float(h0))
        ymap = (k, (OH - h0 * k) / 2)
    elif mode == "crop_x":
        if fixed_x is not None:
            kf = [(0.0, fixed_x * w0), (dur, fixed_x * w0)]
        else:
            tr = _tracks(samples, 0.0, dur + 1, "tall", h0)
            kf = smooth_track(tr["c"], 0.0, dur, w0) if tr["c"] else [(0.0, w0 / 2.0), (dur, w0 / 2.0)]
        kf = [(t, min(max(x, cw / 2.0), w0 - cw / 2.0) - cw / 2.0) for t, x in kf]
        fc = "[0:v]crop=%d:%d:'%s':0,scale=%d:%d:flags=lanczos,setsar=1[body]" % (cw, ch, lerp_expr(kf), OW, OH)
        ymap = (OH / float(h0), 0.0)
        info.append("follow-crop on the speaker" if fs_all and fixed_x is None else "crop at %.0f%%" % (100 * (fixed_x if fixed_x is not None else 0.5)))
    else:   # crop_y
        fy = float(np.median([f[1] for _, f in fs_all])) if fs_all else 0.45 * h0
        y0 = int(min(max(fy - 0.4 * ch, 0), h0 - ch)) // 2 * 2
        fc = "[0:v]crop=%d:%d:0:%d,scale=%d:%d:flags=lanczos,setsar=1[body]" % (cw, ch, y0, OW, OH)
        info.append("vertical source cropped around the face")
        ymap = (OW / float(w0), -y0 * OW / float(w0))
    faces = []
    if fs_all:     # where faces sit in the output (y band) - the banner placement keeps clear of it
        k, oy = ymap
        faces = [(float(np.percentile([f[1] - f[3] / 2 for _, f in fs_all], 15)) * k + oy,
                  float(np.percentile([f[1] + f[3] / 2 for _, f in fs_all], 85)) * k + oy)]
    return fc, [(0.0, 1e9, "frame", cap_y)], mode, faces
CAP_FONT = "Anton"
YELLOW = "&H003DD9FF&"          # #FFD93D in ASS BGR
STOP = set("""a an the and or but so if then than that this these those is are was were be been being am i you he she it we
they me him her us them my your his its our their to of in on at for with from by as into about just like yeah yes no oh um
uh okay ok its im dont thats what whats do did does have has had not too very really gonna wanna gotta can could would
should will all some any one there here when where who how why get got go going""".split())
EMPH = re.compile(r"\$|\d|%|no way|what|never|million|lost|won|insane|crazy|rug|scam|dead|wow|bro", re.I)
PROFANITY = re.compile(r"\b(fuck\w*|shit\w*|bitch\w*|cunt|nigg\w*|fag\w*|retard\w*)\b", re.I)


# ======================================================================= cutting
def cut_raw(source, pieces, out, max_h=1080):
    """pieces: [(a,b), ...] in source seconds. Frame-exact, keeps native aspect, 30fps.
    Returns list of (src_a, src_b, out_t0) offsets."""
    pieces = [(round(a * FPS) / FPS, round(b * FPS) / FPS) for a, b in pieces]
    if not probe(source)["has_audio"]:        # silent video: give it a silent track so every audio step works
        sil = out + ".withaudio.mp4"
        ffmpeg(["-i", source, "-f", "lavfi", "-i", "anullsrc=r=48000:cl=stereo", "-map", "0:v:0", "-map", "1:a",
                "-c:v", "copy", "-c:a", "aac", "-shortest", sil])
        source = sil
    vf = "fps=%d,scale=-2:'min(%d,ih)':flags=lanczos,setsar=1" % (FPS, max_h)
    if len(pieces) == 1:
        a, b = pieces[0]
        ffmpeg(["-ss", "%.3f" % a, "-i", source, "-t", "%.3f" % (b - a), "-vf", vf,
                "-af", "aresample=48000,afade=t=in:d=0.03", "-c:v", "libx264", "-preset", "veryfast",
                "-crf", "14", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "256k", "-ar", "48000", out])
        return [(a, b, 0.0)]
    ins, fc, cat = [], [], ""
    for i, (a, b) in enumerate(pieces):
        ins += ["-ss", "%.3f" % a, "-t", "%.3f" % (b - a), "-i", source]
        d = b - a
        fc.append("[%d:v]%s[v%d]" % (i, vf, i))
        # tiny fades at every jump cut so there is no click
        fc.append("[%d:a]aresample=48000,afade=t=in:d=0.03,afade=t=out:st=%.3f:d=0.03[a%d]" % (i, max(0, d - 0.03), i))
        cat += "[v%d][a%d]" % (i, i)
    fc.append(cat + "concat=n=%d:v=1:a=1[v][a]" % len(pieces))
    ffmpeg(ins + ["-filter_complex", ";".join(fc), "-map", "[v]", "-map", "[a]", "-c:v", "libx264",
                  "-preset", "veryfast", "-crf", "14", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "256k", out])
    offs, t = [], 0.0
    for a, b in pieces:
        offs.append((a, b, t))
        t += b - a
    return offs


def words_for_pieces(all_words, offs):
    out = []
    for a, b, t0 in offs:
        for w in all_words:
            if w[0] >= a - 0.05 and w[1] <= b + 0.1:
                out.append((max(0.0, w[0] - a + t0), w[1] - a + t0, w[2]))
    return out


# ======================================================================= analysis
def sample_faces(clip, w0, h0, fps=4):
    """[(t, [(cx, cy, w, h, score), ...]), ...] in clip pixel coordinates."""
    import cv2
    aw = 960
    ah = int(round(aw * h0 / float(w0)))
    k = w0 / float(aw)
    det = cv2.FaceDetectorYN.create(YUNET, "", (aw, ah), 0.6, 0.3, 5000)
    cap = cv2.VideoCapture(clip)
    vfps = cap.get(cv2.CAP_PROP_FPS) or FPS
    step = max(1, int(round(vfps / fps)))
    out, i = [], 0
    while cap.grab():
        if i % step == 0:
            ok, img = cap.retrieve()
            if not ok:
                break
            _, f = det.detect(cv2.resize(img, (aw, ah)))
            faces = []
            if f is not None:
                for r in f:
                    x, y, fw, fh = (r[:4] * k).tolist()
                    faces.append((x + fw / 2, y + fh / 2, fw, fh, float(r[14])))
            out.append((i / vfps, faces))
        i += 1
    cap.release()
    return out


def detect_shots(clip, dur, thresh=0.3, min_len=1.0):
    r = run(["ffmpeg", "-hide_banner", "-i", clip, "-vf", "select='gt(scene,%s)',showinfo" % thresh,
             "-an", "-f", "null", "-"], check=False)
    cuts = sorted(set(round(float(m) * FPS) / FPS for m in re.findall(r"pts_time:([\d.]+)", r.stderr)))
    b = [0.0]
    for c in cuts:
        if c - b[-1] >= min_len and dur - c >= min_len:
            b.append(c)
    b.append(dur)
    return [(b[i], b[i + 1]) for i in range(len(b) - 1)]


def _real(faces, h0, min_h=0.055, min_s=0.65):
    return [f for f in faces if f[3] > min_h * h0 and f[4] > min_s]


def detect_facecam(clip, samples, w0, h0):
    """Find a streamer webcam inset (small, stable face off-centre over screen content).
    Returns (x, y, w, h) in clip pixels, or None."""
    n = max(1, len(samples))
    big = sum(1 for _, fs in samples if any(f[3] > 0.24 * h0 for f in _real(fs, h0))) / n
    if big > 0.35:
        return None
    pts = [(f[0], f[1], f[2], f[3]) for _, fs in samples for f in _real(fs, h0, 0.035) if f[3] <= 0.24 * h0]
    if len(pts) < 0.4 * n:
        return None
    P = np.array(pts)
    med = np.median(P[:, :2], axis=0)
    near = P[np.hypot(P[:, 0] - med[0], P[:, 1] - med[1]) < 0.06 * w0]
    if len(near) < 0.4 * n or np.std(near[:, 0]) > 0.035 * w0:
        return None
    cx, cy = np.median(near[:, 0]), np.median(near[:, 1])
    fw, fh = np.median(near[:, 2]), np.median(near[:, 3])
    if abs(cx - w0 / 2) < 0.18 * w0 and abs(cy - h0 / 2) < 0.22 * h0:
        return None  # a small centred face is a wide shot, not an inset
    box = _inset_box_from_edges(clip, cx, cy, fw, fh, w0, h0)
    if box is None:
        bw = min(w0, 3.4 * fw)
        bh = min(h0, bw * 9 / 16.0 * 1.15)
        box = (cx - bw / 2, cy - bh * 0.45, bw, bh)
    x, y, bw, bh = box
    if bw > 0.40 * w0 or bh > 0.62 * h0:
        return None        # too big to be a webcam inset: it's the main shot (e.g. a framed talking head)
    x = min(max(0, x), w0 - bw)
    y = min(max(0, y), h0 - bh)
    return tuple(int(round(v / 2.0) * 2) for v in (x, y, bw, bh))


def _inset_box_from_edges(clip, cx, cy, fw, fh, w0, h0):
    """Webcam insets have hard straight borders that stay put while the screen changes;
    a temporal median frame + edge profile finds them."""
    import cv2
    cap = cv2.VideoCapture(clip)
    nfr = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    frames = []
    for k in range(12):
        cap.set(cv2.CAP_PROP_POS_FRAMES, int(nfr * (k + 0.5) / 12))
        ok, img = cap.read()
        if ok:
            frames.append(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY))
    cap.release()
    if len(frames) < 4:
        return None
    med = np.median(np.stack(frames), axis=0).astype(np.float32)
    gx = np.abs(cv2.Sobel(med, cv2.CV_32F, 1, 0, ksize=3))
    gy = np.abs(cv2.Sobel(med, cv2.CV_32F, 0, 1, ksize=3))
    r0, r1 = int(max(0, cy - 1.2 * fh)), int(min(h0, cy + 1.2 * fh))
    c0, c1 = int(max(0, cx - 1.2 * fw)), int(min(w0, cx + 1.2 * fw))
    colp = gx[r0:r1].mean(0)
    rowp = gy[:, c0:c1].mean(1)

    def find(prof, lo, hi, edge_pos):
        lo, hi = int(max(0, lo)), int(min(len(prof) - 1, hi))
        if hi - lo < 3:
            return edge_pos if edge_pos is not None else None
        seg = prof[lo:hi]
        i = int(np.argmax(seg))
        base = np.median(prof) + 1e-3
        if seg[i] > 4.0 * base and seg[i] > 12:
            return lo + i
        # no line found: the inset probably touches the frame edge
        return edge_pos
    # search starts just outside the face box (an inset border can sit right above a head)
    left = find(colp, cx - 4.5 * fw, cx - 0.55 * fw, 0 if cx - 4.5 * fw <= 0 else None)
    right = find(colp, cx + 0.55 * fw, cx + 4.5 * fw, w0 if cx + 4.5 * fw >= w0 else None)
    top = find(rowp, cy - 3.5 * fh, cy - 0.55 * fh, 0 if cy - 3.5 * fh <= 0 else None)
    bot = find(rowp, cy + 0.55 * fh, cy + 4.0 * fh, h0 if cy + 4.0 * fh >= h0 else None)
    if None in (left, right, top, bot):
        return None
    bw, bh = right - left, bot - top
    if not (1.6 * fw <= bw <= 7 * fw and 1.3 * fh <= bh <= 6 * fh and 0.8 <= bw / float(bh) <= 2.4):
        return None
    return (left, top, bw, bh)


def sample_modes(samples, w0, h0, active=None):
    """per-sample mode: 'tall' (one crop fits everyone), 'tall:<track>' (crop on the active
    speaker when people are too far apart for one crop), 'split' (both talking / unclear)."""
    modes = []
    for j, (_, faces) in enumerate(samples):
        fs = _real(faces, h0)
        if not fs:
            modes.append(None)
            continue
        fs = sorted(sorted(fs, key=lambda f: -f[2] * f[3])[:2], key=lambda f: f[0])
        a0, a1 = fs[0][2] * fs[0][3], fs[-1][2] * fs[-1][3]
        far = len(fs) == 2 and (fs[1][0] - fs[0][0]) > 0.225 * w0 and min(a0, a1) / max(a0, a1) > 0.45
        if not far:
            modes.append("tall")
            continue
        a = active[j] if active else None
        ids = [f[5] for f in fs if len(f) > 5]
        modes.append("tall:%s" % a if (a is not None and a != "both" and a in ids) else "split")
    for rng in (range(len(modes)), range(len(modes) - 1, -1, -1)):   # fill gaps both ways
        last = None
        for i in rng:
            if modes[i]:
                last = modes[i]
            elif last:
                modes[i] = last
    sm = []
    for i in range(len(modes)):                                      # ~1.2s majority vote at 10fps
        win = [m for m in modes[max(0, i - 6): i + 7] if m]
        sm.append(max(set(win), key=win.count) if win else None)
    return sm


def plan_segments(samples, modes, shots, dur, min_len=1.6):
    runs = []
    for (t, _), m in zip(samples, modes):
        if runs and runs[-1][2] == m:
            runs[-1][1] = t
        else:
            runs.append([t, t, m])
    changed = True
    while changed and len(runs) > 1:
        changed = False
        for i, r in enumerate(runs):
            if r[1] - r[0] + 0.25 < min_len:
                j = i - 1 if i > 0 else i + 1
                runs[j][0], runs[j][1] = min(runs[j][0], r[0]), max(runs[j][1], r[1])
                runs.pop(i)
                changed = True
                break
        k = 0
        while k < len(runs) - 1:
            if runs[k][2] == runs[k + 1][2]:
                runs[k][1] = runs[k + 1][1]
                runs.pop(k + 1)
            else:
                k += 1
    bounds = {0.0, round(dur * FPS) / FPS}
    bounds |= {round(runs[i][0] * FPS) / FPS for i in range(1, len(runs))}
    bounds |= {round(a * FPS) / FPS for a, _ in shots if a > 0.01}
    bounds = sorted(bounds)
    segs = []
    for i in range(len(bounds) - 1):
        a, b = bounds[i], bounds[i + 1]
        if b - a < 0.5 and segs:
            segs[-1] = (segs[-1][0], b)
        else:
            segs.append((a, b))
    out = []
    for a, b in segs:
        ms = [m for (t, _), m in zip(samples, modes) if a <= t < b and m]
        out.append((a, b, max(set(ms), key=ms.count) if ms else None))
    return out


def smooth_track(track, t0, t1, w0):
    """(t, x) samples -> keyframes: median filtered, dead-zoned, speed-limited camera."""
    ts = np.array([q[0] for q in track])
    xs = np.array([q[1] for q in track])
    kt = np.arange(t0, t1 + 0.01, 0.5)
    vals = []
    for t in kt:
        m = np.abs(ts - t) <= 1.2
        vals.append(float(np.median(xs[m])) if m.any() else (vals[-1] if vals else float(np.median(xs))))
    dz, step = 0.057 * w0, 0.047 * w0
    cam, out = vals[0], []
    for t, v in zip(kt, vals):
        if abs(v - cam) > dz:
            cam += np.sign(v - cam) * min(abs(v - cam) - dz * 0.55, step)
        out.append((float(t), float(cam)))
    return out


def lerp_expr(kf, var="t"):
    comp = [kf[0]]
    for i in range(1, len(kf) - 1):
        p, c, n = comp[-1], kf[i], kf[i + 1]
        if abs(c[1] - p[1]) < 1.0 and abs(n[1] - c[1]) < 1.0:
            continue
        comp.append(c)
    comp.append(kf[-1])
    kf = comp
    if all(abs(k[1] - kf[0][1]) < 1.0 for k in kf):
        return "%.1f" % kf[0][1]
    expr = "%.1f" % kf[-1][1]
    for i in range(len(kf) - 2, -1, -1):
        (ta, xa), (tb, xb) = kf[i], kf[i + 1]
        expr = "if(lt(%s,%.3f),%.1f+(%.1f)*(%s-%.3f)/%.3f,%s)" % (
            var, tb, xa, xb - xa, var, ta, max(0.001, tb - ta), expr)
    return expr


# ======================================================================= layout graph
def _fit_blur(src, out, w, h, tag, sigma=28):
    return ("[{s}]split=2[b{t}][f{t}];[b{t}]scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h},"
            "gblur=sigma={sg},eq=brightness=-0.10:saturation=0.85,lutyuv=y='max(val,40)'[bb{t}];"
            "[f{t}]scale={w}:{h}:force_original_aspect_ratio=decrease:flags=lanczos[ff{t}];"
            "[bb{t}][ff{t}]overlay=(W-w)/2:(H-h)/2,setsar=1[{o}]").format(s=src, o=out, w=w, h=h, t=tag, sg=sigma)


def build_body(samples, segs, w0, h0, layout, facecam, info, fixed_x=None):
    """Returns (filter_chain producing [body], body_h, per-segment caption plan)."""
    plan = []
    if layout == "vertical":
        fc = _fit_blur("0:v", "body", W, H, "v")
        fb = _face_bottom_frac(samples, h0)
        cap_y = int(min(1560, max(1180, (fb * H if fb else 0) + 150)))
        plan.append((0.0, 1e9, "vertical", cap_y))
        return fc, H, plan
    if layout == "facecam_screen" and facecam:
        fx, fy, fw, fh = facecam
        top_h = int(min(0.46 * BODY_H, round(W * fh / float(fw)))) // 2 * 2
        crop_h = int(round(fw * top_h / float(W))) // 2 * 2         # crop cam vertically if it's very tall
        crop_y = fy + max(0, (fh - crop_h) // 3)
        bot_h = BODY_H - top_h
        # screen pane: whole frame, unless the cam is a tall side column -> drop that column
        sx, sw = 0, w0
        if fh > 0.5 * h0:
            if fx + fw / 2 > w0 / 2:
                sw = fx
            else:
                sx, sw = fx + fw, w0 - fx - fw
        fc = ("[0:v]split=2[cam0][scr0];[cam0]crop=%d:%d:%d:%d,scale=%d:%d:flags=lanczos,setsar=1[cam];"
              "[scr0]crop=%d:%d:%d:0[scr1];" % (fw, crop_h, fx, crop_y, W, top_h, sw, h0, sx)
              + _fit_blur("scr1", "scr", W, bot_h, "s") + ";[cam][scr]vstack=inputs=2[body]")
        info.append("facecam on top (inset %dx%d at %d,%d), full screen below" % (fw, fh, fx, fy))
        plan.append((0.0, 1e9, "facecam_screen", BAND + top_h))
        return fc, BODY_H, plan
    if layout == "blur_fit":
        segs = [(segs[0][0], segs[-1][1], None)]
    tall_h = int(0.917 * h0) // 2 * 2              # drops the bottom ~8% (stream overlays/watermarks)
    tall_w = int(round(tall_h * W / float(BODY_H))) // 2 * 2
    pan_h = int(0.556 * h0) // 2 * 2
    pan_w = int(round(pan_h * W / 810.0)) // 2 * 2
    parts, labels = [], []
    n = len(segs)
    parts.append("[0:v]split=%d%s" % (n, "".join("[in%d]" % i for i in range(n))) if n > 1 else "[0:v]null[in0]")
    for i, (a, b, mode) in enumerate(segs):
        if layout == "split" and mode is not None:
            mode = "split"
        elif layout == "tall" and mode == "split":
            mode = "tall"
        if fixed_x is not None and layout != "split":
            mode = "tall"                          # manual crop from the editor
        trim = "[in%d]trim=start=%.4f:end=%.4f,setpts=PTS-STARTPTS" % (i, a, b)
        tr = _tracks(samples, a, b, mode, h0)
        if mode and mode.startswith("tall") and (tr["c"] or fixed_x is not None):
            kf = smooth_track(tr["c"], a, b, w0) if fixed_x is None else [(a, fixed_x * w0), (b, fixed_x * w0)]
            kf = [(t - a, min(max(x, tall_w / 2), w0 - tall_w / 2) - tall_w / 2) for t, x in kf]
            parts.append("%s,crop=%d:%d:'%s':0,scale=%d:%d:flags=lanczos,setsar=1[s%d]" % (
                trim, tall_w, tall_h, lerp_expr(kf), W, BODY_H, i))
            fb = (np.median([y + fh / 2 for _, y, fh in tr["cy"]]) * BODY_H / tall_h + BAND) if tr["cy"] else 1100
            cap_y = int(min(1700, max(1290, fb + 165)))
            plan.append((a, b, "tall", cap_y))
            info.append("%.1f-%.1f %s" % (a, b, "crop on speaker #" + mode[5:] if ":" in mode else "tall follow-crop"))
        elif mode == "split" and len(tr["L"]) >= 2 and len(tr["R"]) >= 2:
            sub = []
            for k, key in enumerate(("L", "R")):
                t3 = tr[key]
                kf = smooth_track([(t, x) for t, x, _ in t3], a, b, w0)
                kf = [(t - a, min(max(x, pan_w / 2), w0 - pan_w / 2) - pan_w / 2) for t, x in kf]
                cy = float(np.median([y for _, _, y in t3]))
                y0 = int(min(max(cy - 0.36 * pan_h, 0), h0 - pan_h))
                sub.append("[p%d_%d]crop=%d:%d:'%s':%d,scale=%d:810:flags=lanczos,setsar=1[q%d_%d]" % (
                    i, k, pan_w, pan_h, lerp_expr(kf), y0, W, i, k))
            parts.append("%s,split=2[p%d_0][p%d_1];%s;[q%d_0][q%d_1]vstack=inputs=2[s%d]" % (
                trim, i, i, ";".join(sub), i, i, i))
            plan.append((a, b, "split", BAND + 810))
            info.append("%.1f-%.1f stacked split (2 people)" % (a, b))
        else:
            parts.append(trim + "[t%d];" % i + _fit_blur("t%d" % i, "s%d" % i, W, BODY_H, "x%d" % i))
            fg_h = W * h0 / float(w0)
            plan.append((a, b, "blur_fit", int(min(1720, BAND + BODY_H / 2 + fg_h / 2 + 115))))
            info.append("%.1f-%.1f blur-fit (no usable face)" % (a, b))
        labels.append("[s%d]" % i)
    parts.append("".join(labels) + ("concat=n=%d:v=1:a=0[body]" % n if n > 1 else "null[body]"))
    return ";".join(parts), BODY_H, plan


def _tracks(samples, a, b, mode, h0):
    c, cy, L, R = [], [], [], []
    for t, faces in samples:
        if not a <= t < b:
            continue
        fs = _real(faces, h0, 0.055, 0.6)
        if not fs:
            continue
        if mode == "split":
            fs = sorted(sorted(fs, key=lambda f: -f[2] * f[3])[:2], key=lambda f: f[0])
            if len(fs) == 2:
                L.append((t, fs[0][0], fs[0][1]))
                R.append((t, fs[1][0], fs[1][1]))
        else:
            want = mode.split(":", 1)[1] if mode and ":" in mode else None
            mine = [f for f in fs if want is not None and len(f) > 5 and str(f[5]) == want]
            big = mine[0] if mine else max(fs, key=lambda f: f[2] * f[3])
            near = [big] if mine else [f for f in fs if abs(f[0] - big[0]) < 0.115 * h0 * 16 / 9]
            c.append((t, float(np.mean([f[0] for f in near]))))
            cy.append((t, big[1], big[3]))
    return {"c": c, "cy": cy, "L": L, "R": R}


def vertical_head_y(samples, w0, h0, headline):
    """Headline card position for vertical sources: above the face if there's room,
    otherwise high enough to cover only hair/forehead - never eyes or mouth."""
    lines, size = layout_headline(strip_emoji(headline or ""), max_h=330)
    hh = len(lines) * size * 1.12 + 34
    s = min(W / float(w0), H / float(h0))
    oy = (H - h0 * s) / 2
    fs = [f for _, ff in samples for f in _real(ff, h0)]
    if not fs:
        return 300
    big = sorted(fs, key=lambda f: -f[3])[: max(1, len(fs) // 2)]
    top = float(np.median([f[1] - f[3] / 2 for f in big])) * s + oy
    fh = float(np.median([f[3] for f in big])) * s
    y = top - 30 - hh / 2
    if y - hh / 2 >= 150:          # fits above the head, below the platform's top UI
        return int(y)
    below = top + fh + 40 + hh / 2   # no room above: just under the chin, still clear of the captions
    if below + hh / 2 <= 1180:
        return int(below)
    return int(max(150 + hh / 2, top + 0.1 * fh - hh / 2))   # last resort: hair only


def _face_bottom_frac(samples, h0):
    ys = [f[1] + f[3] / 2 for _, fs in samples for f in _real(fs, h0)]
    return float(np.median(ys)) / h0 if ys else None


# ======================================================================= captions
def fmt(t):
    t = max(0.0, t)
    return "%d:%02d:%05.2f" % (int(t // 3600), int((t % 3600) // 60), t % 60)


def esc(s):
    return s.replace("{", "(").replace("}", ")").replace("\\", "")


def strip_emoji(s):
    return re.sub(r"[\U0001F000-\U0001FAFF☀-➿️‍]", "", s).strip()


def chunk_words(words, maxw=3, maxchars=16):
    chunks, cur = [], []
    for w in words:
        if cur:
            gap = w[0] - cur[-1][1]
            ends = re.search(r"[.!?,;:]$", cur[-1][2]) is not None
            if len(cur) >= maxw or gap > 0.35 or ends or len(" ".join(x[2] for x in cur + [w])) > maxchars:
                chunks.append(cur)
                cur = []
        cur.append(w)
    if cur:
        chunks.append(cur)
    return chunks


def key_index(chunk):
    best, bi = -99, 0
    for i, (_, _, t) in enumerate(chunk):
        c = re.sub(r"[^A-Za-z0-9$%']", "", t).lower()
        s = len(c) + (6 if re.search(r"\d|\$|%", c) else 0) - (20 if c in STOP else 0)
        if s > best:
            best, bi = s, i
    return bi


_FONT_CACHE = {}


def _font_file(family):
    from .fonts import find
    return find(family) or os.path.join(FONT_DIR, "Anton-Regular.ttf")


def text_px(text, ass_size, font_file=os.path.join(FONT_DIR, "Anton-Regular.ttf")):
    """Width in output pixels of `text` rendered by libass at Fontsize=ass_size.
    libass scales so ascent+descent == Fontsize, so convert via the font's own metrics."""
    try:
        from PIL import ImageFont
        if font_file not in _FONT_CACHE:
            f = ImageFont.truetype(font_file, 100)
            r = None
            try:      # libass/VSFilter scale: Fontsize == winAscent + winDescent
                from fontTools.ttLib import TTFont
                tt = TTFont(font_file, lazy=True)
                os2 = tt["OS/2"]
                r = (os2.usWinAscent + os2.usWinDescent) / float(tt["head"].unitsPerEm)
                tt.close()
            except Exception:
                a, d = f.getmetrics()
                r = (a + d) / 100.0
            _FONT_CACHE[font_file] = (f, r)
        f, r = _FONT_CACHE[font_file]
        return f.getlength(text) * (ass_size / r) / 100.0
    except Exception:
        return len(text) * ass_size * 0.36   # Anton fallback estimate


def _balanced_wrap(words, n, font_file=None):
    """split words into n lines minimising the widest line (n <= 3, so brute force is fine)."""
    if n == 1 or len(words) < n:
        return [" ".join(words)]
    best, best_w = None, 1e9
    idx = range(1, len(words))
    cuts = [(i,) for i in idx] if n == 2 else [(i, j) for i in idx for j in idx if j > i]
    for c in cuts:
        b = (0,) + c + (len(words),)
        lines = [" ".join(words[b[k]:b[k + 1]]) for k in range(n)]
        w = max(text_px(l, 100, *([font_file] if font_file else [])) for l in lines)
        if w < best_w:
            best, best_w = lines, w
    return best


def layout_headline(h, max_w=960, max_h=250, lo=54, hi=112, font_file=None):
    """-> (lines, ass_size): biggest size that fits; prefer fewer lines unless >12% smaller."""
    words = h.upper().split()
    if not words:
        return [], 0
    opts = []
    for n in (1, 2, 3):
        lines = _balanced_wrap(words, n, font_file)
        wide = max(text_px(l, 100, *([font_file] if font_file else [])) for l in lines) / 100.0
        size = min(hi, max_w / wide, max_h / (n * 1.12))
        opts.append((lines, size))
    best = opts[0]
    for o in opts[1:]:
        if o[1] > best[1] * 1.12:
            best = o
    lines, size = best
    if size < lo:                       # too long even on 3 lines: shrink to floor (never truncate)
        size = lo
    return lines, int(size)


def wrap_headline(h):
    return layout_headline(h)[0]


CAPTION_STYLES = ("pro", "karaoke", "box", "minimal")
HILITE = {"yellow": "&H003DD9FF&", "green": "&H0066FF33&", "pink": "&H00B967FF&", "cyan": "&H00FFE000&"}


def _lower_text(txt, words):
    """captions are upper-cased by default; 'uppercase: false' gives natural sentence case."""
    out = [part if part.startswith("{") else re.sub(r"\bi\b", "I", part.lower())
           for part in re.split(r"(\{[^}]*\})", txt)]
    return "".join(out)


def _clean_word(t, censor):
    t = re.sub(r"\s+", "", t).upper()
    t = re.sub(r"[,.;:]+$", "", t)
    if censor:
        t = PROFANITY.sub(lambda m: m.group(0)[0] + "*" * (len(m.group(0)) - 1), t)
    return esc(t)


def build_ass(words, dur, headline, plan, path, vertical=False, watermark=None, censor=False,
              head_y=None, cap_size=118, style="pro", accent="yellow", progress=False, flashes=(),
              cap_font=CAP_FONT, uppercase=True, extra_events=(), look=None, canvas=None):
    """Caption presets (research: word-synced captions with ONE highlighted word beat block text;
    highlight should land ~50-100ms before the word is spoken):
      pro      1-3 words, white + black stroke, one yellow keyword, snap-pop   (clip-page standard)
      karaoke  up to 4 words on screen, the word being spoken turns yellow + grows
      box      up to 4 words, the spoken word sits in a solid colour box (Hormozi-style)
      minimal  5-6 words, smaller Montserrat, no highlight (talky/educational)"""
    from .effects import _ass_color
    from .fonts import resolve
    lk = look or {}
    no_caps = style == "none"                       # clean version: headline/text/banner only, no captions
    style = style if style in CAPTION_STYLES else "pro"
    hl = HILITE.get(accent) or _ass_color(accent, YELLOW)        # preset name or any #RRGGBB
    CW, CH = canvas or (W, H)
    framed = (CW, CH) != (W, H)
    cx = CW // 2
    max_h = frame_head(CH)[1] if framed else (330 if vertical else BAND - 50)
    head_font = resolve(lk.get("headline_font"), CAP_FONT)
    lines, hsize = layout_headline(esc(strip_emoji(headline)), max_w=CW - 120, max_h=max_h, font_file=_font_file(head_font)) \
        if headline else ([], 72)
    explicit = lk.get("caption_font_set")
    cap_font = resolve(cap_font, CAP_FONT)
    font, size, outline = (("Montserrat Black" if not explicit else cap_font, int(cap_size * 0.62), 6)
                           if style == "minimal" else (cap_font, cap_size, 9))
    try:
        if lk.get("outline") not in (None, ""):
            outline = max(0, min(30, int(float(lk["outline"]))))
    except (TypeError, ValueError):
        pass
    base_c = _ass_color(lk.get("color"), "&H00FFFFFF&")
    out_c = _ass_color(lk.get("outline_color"), "&H00000000&")
    bold = -1 if lk.get("bold") else 0
    ital = -1 if lk.get("italic") else 0
    try:
        spacing = float(lk.get("spacing") if lk.get("spacing") not in (None, "") else 1)
    except (TypeError, ValueError):
        spacing = 1.0
    shadow = 3 if lk.get("shadow", True) else 0
    h_ink = _ass_color(lk.get("headline_color"), "&H00000000&")
    h_bg = _ass_color(lk.get("headline_bg"), "&H00FFFFFF&")
    cap_file = _font_file(font)
    hdr = ("[Script Info]\nScriptType: v4.00+\nPlayResX: {pw}\nPlayResY: {ph}\nWrapStyle: 2\nScaledBorderAndShadow: yes\n"
           "[V4+ Styles]\nFormat: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, "
           "Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, "
           "MarginL, MarginR, MarginV, Encoding\n"
           "Style: Cap,{f},{s},{bc},{bc},{oc},&H90000000,{b},{i},0,0,100,100,{sp},0,1,{o},{sh},5,40,40,0,1\n"
           "Style: Box,{f},{s},&H00000000,&H00000000,{hl},&H00000000,{b},{i},0,0,100,100,{sp},0,3,7,0,5,0,0,0,1\n"
           "Style: Head,{cf},{hs},{hi},{hi},{hb},{hb},0,0,0,0,100,100,1,0,3,16,0,5,50,50,0,1\n"
           "Style: Mark,Montserrat Black,34,&H00FFFFFF,&H00FFFFFF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,2,0,9,30,30,0,1\n"
           "Style: Fx,Arial,20,&H00FFFFFF,&H00FFFFFF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,0,0,7,0,0,0,1\n"
           "[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n").format(
        pw=CW, ph=CH,
        f=font, s=size, o=outline, hl=hl.rstrip("&"), cf=head_font, hs=hsize, bc=base_c.rstrip("&"),
        oc=out_c.rstrip("&"), b=bold, i=ital, sp=("%g" % spacing), sh=shadow, hi=h_ink.rstrip("&"), hb=h_bg.rstrip("&"))
    ev = []
    if lines:
        hy = head_y or (frame_head(CH)[0] if framed else (300 if vertical else BAND // 2 + 4))
        ev.append("Dialogue: 4,%s,%s,Head,,0,0,0,,{\\pos(%d,%d)}%s" % (fmt(0), fmt(dur), cx, hy, "\\N".join(lines)))
    if watermark:
        wy = 40 if framed else (470 if vertical else BAND + 22)
        ev.append("Dialogue: 1,%s,%s,Mark,,0,0,0,,{\\alpha&H70&\\pos(%d,%d)}%s" % (fmt(0), fmt(dur), CW - 30, wy, esc(watermark)))
    if progress:   # thin bar that fills left->right over the clip (animated clip rectangle)
        ms = int(dur * 1000)
        ev.append("Dialogue: 5,%s,%s,Fx,,0,0,0,,{\\an7\\pos(0,%d)\\1c%s\\clip(0,0,0,%d)\\t(0,%d,\\clip(0,0,%d,%d))"
                  "\\p1}m 0 0 l %d 0 %d 10 0 10{\\p0}" % (fmt(0), fmt(dur), CH - 10, hl, CH, ms, CW, CH, CW, CW))
    for t in flashes:   # white flash used at the teaser -> story transition
        ev.append("Dialogue: 6,%s,%s,Fx,,0,0,0,,{\\an7\\pos(0,0)\\1c&HFFFFFF&\\fad(0,140)\\p1}m 0 0 l %d 0 %d %d 0 %d{\\p0}"
                  % (fmt(t), fmt(t + 0.16), CW, CW, CH, CH))
    if no_caps:
        chunks = []
    elif style == "pro":
        chunks = chunk_words(words)
    elif style == "minimal":
        chunks = chunk_words(words, maxw=6, maxchars=30)
    else:
        chunks = chunk_words(words, maxw=4, maxchars=20)
    lead = 0.07   # highlight slightly before the word is heard
    for i, ch in enumerate(chunks):
        st = max(0.0, ch[0][0] - lead)
        en = chunks[i + 1][0][0] - lead if i + 1 < len(chunks) else ch[-1][1] + 0.4
        en = max(min(en, ch[-1][1] + 0.5), st + 0.25)
        y = next((p[3] for p in plan if p[0] - 0.01 <= ch[0][0] < p[1]), plan[-1][3] if plan else 1300)
        toks = [_clean_word(w[2], censor) for w in ch]
        if style == "pro":
            k = key_index(ch)
            parts = [("{\\c%s}%s{\\c%s}" % (hl, t, base_c)) if j == k else t for j, t in enumerate(toks)]
            ev.append("Dialogue: 0,%s,%s,Cap,,0,0,0,,{\\pos(%d,%d)\\fscx88\\fscy88\\t(0,80,\\fscx100\\fscy100)}%s"
                      % (fmt(st), fmt(en), cx, y, " ".join(parts)))
        elif style == "minimal":
            ev.append("Dialogue: 0,%s,%s,Cap,,0,0,0,,{\\pos(%d,%d)}%s" % (fmt(st), fmt(en), cx, y, " ".join(toks)))
        else:
            # one event per spoken word so exactly one word is lit at a time
            widths = [text_px(t, size, cap_file) + spacing * len(t) for t in toks]   # + letter spacing
            gap = "\\h\\h" if style == "box" else " "              # wider gaps so the box never touches neighbours
            sp = text_px("  " if style == "box" else " ", size, cap_file) + spacing * (2 if style == "box" else 1)
            total = sum(widths) + sp * (len(toks) - 1)
            x = cx - total / 2
            centers = []
            for wdt in widths:
                centers.append(x + wdt / 2)
                x += wdt + sp
            for j, w in enumerate(ch):
                ws = st if j == 0 else max(st, w[0] - lead)
                we = en if j == len(ch) - 1 else max(ws + 0.05, ch[j + 1][0] - lead)
                if style == "karaoke":
                    parts = [("{\\c%s\\fscx108\\fscy108}%s{\\c%s\\fscx100\\fscy100}" % (hl, t, base_c)) if q == j else t
                             for q, t in enumerate(toks)]
                    ev.append("Dialogue: 0,%s,%s,Cap,,0,0,0,,{\\pos(%d,%d)}%s" % (fmt(ws), fmt(we), cx, y, " ".join(parts)))
                else:  # box: hide the lit word in the base line, draw it boxed on top
                    base = [("{\\alpha&HFF&}%s{\\alpha&H00&}" % t) if q == j else t for q, t in enumerate(toks)]
                    ev.append("Dialogue: 0,%s,%s,Cap,,0,0,0,,{\\pos(%d,%d)}%s" % (fmt(ws), fmt(we), cx, y, gap.join(base)))
                    ev.append("Dialogue: 1,%s,%s,Box,,0,0,0,,{\\pos(%d,%d)}%s" % (fmt(ws), fmt(we), centers[j], y, toks[j]))
    ev.extend(extra_events)
    if not uppercase:
        ev = [e if ",Cap,," not in e and ",Box,," not in e else e[:e.index(",,0,0,0,,") + 9] +
              _lower_text(e[e.index(",,0,0,0,,") + 9:], words) for e in ev]
    open(path, "w").write(hdr + "\n".join(ev) + "\n")
    return {"headline_lines": len(lines), "headline_size": hsize, "caption_chunks": len(chunks), "caption_style": style}


def caption_cues(words, style="pro", censor=False, speed=1.0):
    """The same lines/timing as the burned captions -> [(start, end, text)] (for .srt export).
    Style 'none' (clean version) still gets readable sentence-sized subtitle lines."""
    if style == "pro":
        chunks = chunk_words(words)
    elif style == "minimal":
        chunks = chunk_words(words, maxw=6, maxchars=30)
    elif style == "none":
        chunks = chunk_words(words, maxw=8, maxchars=42)
    else:
        chunks = chunk_words(words, maxw=4, maxchars=20)
    out, lead, sp = [], 0.07, (speed or 1.0)
    for i, ch in enumerate(chunks):
        st = max(0.0, ch[0][0] - lead)
        en = chunks[i + 1][0][0] - lead if i + 1 < len(chunks) else ch[-1][1] + 0.4
        en = max(min(en, ch[-1][1] + 0.5), st + 0.25)
        out.append((st / sp, en / sp, " ".join(_srt_word(w[2], censor) for w in ch)))
    return out


def _srt_word(t, censor):
    """Subtitle files keep normal sentence case (platforms restyle them); censoring still applies."""
    t = re.sub(r"\s+", "", t)
    if censor:
        t = PROFANITY.sub(lambda m: m.group(0)[0] + "*" * (len(m.group(0)) - 1), t)
    return t


def srt_time(t):
    ms = int(round(max(0.0, t) * 1000))
    return "%02d:%02d:%02d,%03d" % (ms // 3600000, ms // 60000 % 60, ms // 1000 % 60, ms % 1000)


def write_srt(cues, path):
    with open(path, "w", encoding="utf-8") as f:
        for i, (a, b, t) in enumerate(cues, 1):
            f.write("%d\n%s --> %s\n%s\n\n" % (i, srt_time(a), srt_time(b), t))
    return path


# ======================================================================= tightening / teaser
FILLERS = {"um", "uh", "uhh", "umm", "uhm", "erm", "er", "hmm", "mm"}


def tighten_pieces(pieces, all_words, max_gap=0.42, keep_after=0.14, keep_before=0.10):
    """Remove dead air (>max_gap between words) and um/uh fillers inside each piece.
    Returns (new_pieces, seconds_removed)."""
    out = []
    for a, b in pieces:
        ws = [w for w in all_words if w[0] >= a - 0.05 and w[1] <= b + 0.1]
        if not ws:
            out.append([a, b])
            continue
        cur_a = max(a, ws[0][0] - 0.12)
        last_end = None
        for w in ws:
            tok = re.sub(r"[^a-z]", "", w[2].lower())
            if tok in FILLERS:
                if last_end is not None:
                    out.append([cur_a, min(w[0] - 0.02, last_end + keep_after)])
                    cur_a = None
                continue
            if cur_a is None:
                cur_a = max(a, w[0] - keep_before)
            elif last_end is not None and w[0] - last_end > max_gap:
                out.append([cur_a, last_end + keep_after])
                cur_a = w[0] - keep_before
            last_end = w[1]
        if cur_a is not None and last_end is not None:
            out.append([cur_a, min(b, last_end + 0.3)])
    merged = []
    for p in out:
        if p[1] - p[0] < 0.2:
            continue
        if merged and p[0] - merged[-1][1] < 0.08:
            merged[-1][1] = p[1]
        else:
            merged.append(p)
    before = sum(b - a for a, b in pieces)
    after = sum(b - a for a, b in merged)
    if not merged or len(merged) > 60:
        return [list(p) for p in pieces], 0.0
    return merged, round(before - after, 2)


def pick_teaser(all_words, a, b, energy_fn, min_len=1.2, max_len=3.6):
    """Best payoff line in the back 60% of [a,b]: loud + meaningful (stakes/shock/laugh)."""
    from .transcribe import sentences_from_words
    from .moments import LEX, _rx
    ws = [w for w in all_words if w[0] >= a and w[1] <= b]
    if len(ws) < 6:
        return None
    rx = [_rx(LEX[k]) for k in ("humor", "shock", "stakes", "drama")]
    best, bs = None, 0.0
    spans = [dict(x, bonus=0.3) for x in sentences_from_words(ws, max_gap=0.5, max_len=max_len + 1)]
    if True:                             # plus ~2.5s word windows (long/unpunctuated sentences)
        for i in range(len(ws)):
            j = i
            while j + 1 < len(ws) and ws[j + 1][1] - ws[i][0] <= 2.6 and ws[j + 1][0] - ws[j][1] < 0.5:
                j += 1
            spans.append({"start": ws[i][0], "end": ws[j][1], "text": " ".join(w[2] for w in ws[i:j + 1]), "bonus": 0.0})
    for s in spans:
        d = s["end"] - s["start"]
        if not (min_len <= d <= max_len) or s["start"] < a + 0.4 * (b - a):
            continue
        hits = sum(len(r.findall(s["text"])) for r in rx)
        sc = energy_fn(s["start"], s["end"]) + 1.5 * hits + s.get("bonus", 0.0)
        if sc > bs:
            best, bs = (round(s["start"] - 0.1, 2), round(s["end"] + 0.2, 2), s["text"]), sc
    return best if bs > 1.0 else None


def whoosh(path, d=0.4):
    """Synthesised soft whoosh (filtered noise swell) - no external assets."""
    if not os.path.exists(path):
        ffmpeg(["-f", "lavfi", "-i", "anoisesrc=d=%.2f:c=pink:a=0.5:r=48000" % d, "-af",
                "highpass=f=600,lowpass=f=5000,afade=t=in:d=%.2f:curve=exp,afade=t=out:st=%.2f:d=%.2f,volume=0.35"
                % (d * 0.6, d * 0.6, d * 0.4), "-ac", "2", path])
    return path


# ======================================================================= punch zoom
def word_energy(clip, words, workdir):
    wav = os.path.join(workdir, "clip8k.wav")
    ffmpeg(["-i", clip, "-vn", "-ac", "1", "-ar", "8000", "-af", "highpass=f=250,lowpass=f=3400", wav])
    with wave.open(wav, "rb") as wf:
        x = np.frombuffer(wf.readframes(wf.getnframes()), dtype=np.int16).astype(np.float32)
    out = []
    for s, e, _ in words:
        seg = x[int(s * 8000): max(int(s * 8000) + 1, int(e * 8000))]
        out.append(20 * np.log10(np.sqrt((seg ** 2).mean()) + 1) if len(seg) else 0.0)
    return np.array(out)


def pick_punches(words, energy, dur, plan, max_n=None, avoid=()):
    """Up to 1 zoom per ~15s, on loud + meaningful words, never in screen/blur segments."""
    if not words or not len(energy):
        return []
    max_n = max_n if max_n is not None else max(1, int(dur // 15))
    z = (energy - np.median(energy)) / (np.std(energy) + 1e-6)
    cand = []
    for (s, e, t), zz in zip(words, z):
        c = re.sub(r"[^\w$%']", "", t).lower()
        mode = next((p[2] for p in plan if p[0] <= s < p[1]), None)
        if s < 1.5 or s > dur - 1.2 or mode in ("facecam_screen", "blur_fit") or c in STOP:
            continue
        if any(abs(s - v) < 1.0 for v in avoid):
            continue
        cand.append((zz + (1.5 if EMPH.search(t) else 0), s))
    cand.sort(reverse=True)
    out = []
    for sc, s in cand:
        if sc < 1.2:
            break
        if all(abs(s - o) > 5 for o in out):
            out.append(s)
        if len(out) >= max_n:
            break
    return sorted(out)


def zoom_chain(punches, body_h, scale=1.09, hold=0.7, open_punch=False, body_w=W):
    """Snap zoom on peak words + optional opening push-in (a frame-1 pattern interrupt)."""
    if not punches and not open_punch:
        return "[body]null[bodyz]"
    z = "1"
    if punches:
        cond = "+".join("between(t,%.3f,%.3f)" % (p - 0.04, p + hold) for p in punches)
        z = "if(%s,%.3f,1)" % (cond, scale)
    if open_punch:
        z = "if(lt(t,0.45),1.08-0.08*t/0.45,%s)" % z
    return ("[body]scale=w='2*trunc(%d*(%s)/2)':h='2*trunc(%d*(%s)/2)':eval=frame:flags=bicubic,"
            "crop=%d:%d:(iw-ow)/2:(ih-oh)*0.4,setsar=1[bodyz]") % (body_w, z, body_h, z, body_w, body_h)


# ======================================================================= audio
AUDIO_PRE = "highpass=f=70,afftdn=nf=-30,acompressor=threshold=-20dB:ratio=2.5:attack=5:release=150"


def measure_loudness(clip, pre=AUDIO_PRE, target=-14.0):
    r = run(["ffmpeg", "-hide_banner", "-i", clip, "-vn", "-af",
             pre + ",loudnorm=I=%s:TP=-1.5:LRA=9:print_format=json" % target, "-f", "null", "-"], check=False)
    m = re.search(r"\{[^{}]*\"input_i\"[^{}]*\}", r.stderr, re.S)
    return json.loads(m.group(0)) if m else None


def audio_chain(meas, dur, target=-14.0, pre=AUDIO_PRE, src="[0:a]", out="[aout]"):
    if meas and meas.get("input_i") not in (None, "-inf"):
        ln = ("loudnorm=I=%s:TP=-1.5:LRA=9:measured_I=%s:measured_TP=%s:measured_LRA=%s:"
              "measured_thresh=%s:offset=%s:linear=true" % (target, meas["input_i"], meas["input_tp"],
                                                            meas["input_lra"], meas["input_thresh"],
                                                            meas["target_offset"]))
    else:
        ln = "loudnorm=I=%s:TP=-1.5:LRA=9" % target
    return "%s%s,%s,aresample=48000,afade=t=out:st=%.3f:d=0.15%s" % (src, pre, ln, max(0, dur - 0.15), out)


def output_loudness(path):
    """(integrated LUFS, true peak dBTP) of a finished file's audio; (None, None) if silent/no audio."""
    r = run(["ffmpeg", "-hide_banner", "-nostdin", "-i", path, "-vn", "-af", "loudnorm=print_format=json",
             "-f", "null", "-"], check=False)
    m = re.search(r"\{[^{}]*\"input_i\"[^{}]*\}", r.stderr, re.S)
    if not m:
        return None, None
    j = json.loads(m.group(0))
    try:
        i, tp = float(j["input_i"]), float(j["input_tp"])
    except (TypeError, ValueError):
        return None, None
    return (i if i > -70 else None), tp


def fix_loudness(out, target=-14.0, tol=1.0):
    """Loudness safety net. Very peaky audio (shouting, game SFX, TTS) can stop loudnorm's linear mode from
    reaching the target; then: make-up gain + a -1.5 dBTP limiter on the audio only (video is copied).
    Returns the final LUFS (or None if there's no measurable audio)."""
    i, _ = output_loudness(out)
    for _ in range(2):
        if i is None or abs(i - target) <= tol:
            return i
        tmp = out + ".lufs.mp4"
        ffmpeg(["-i", out, "-map", "0", "-c:v", "copy", "-af",
                "volume=%.2fdB,alimiter=limit=0.84:attack=3:release=60:level=false" % (target - i + 0.3),
                "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-movflags", "+faststart", tmp])
        os.replace(tmp, out)
        i, _ = output_loudness(out)
    return i


# ======================================================================= main entry
def make_clip(spec, outdir, workroot, cfg=None, all_words=None):
    """Render a clip in its aspect ratio, plus any extra ratios in spec['also_aspects'] (e.g. ["1:1", "16:9"]).
    Extra versions are named <name>_1x1.mp4 etc.; their list is in res['versions']."""
    res = _make_one(spec, outdir, workroot, cfg, all_words)
    extras = [a for a in (spec.get("also_aspects") or []) if a in ASPECTS and a != aspect_of(spec)]
    if extras and not spec.get("_draft"):
        res["versions"] = []
        for a in extras:
            sub = retarget(spec, a)
            try:
                r = _make_one(sub, outdir, workroot, cfg, all_words)
                res["versions"].append({"aspect": a, "out": r["out"], "qa_ok": r.get("qa", {}).get("ok")})
            except Exception as e:
                res["versions"].append({"aspect": a, "error": str(e)[:200]})
    return res


def retarget(spec, aspect):
    """Copy of a clip spec for another aspect ratio: positions/sizes of text, stickers and captions are
    scaled to the new canvas so nothing falls off the frame."""
    import copy
    sub = copy.deepcopy(spec)
    a0 = aspect_of(spec)
    (w1, h1), (w2, h2) = ASPECTS[a0], ASPECTS[aspect]
    sx, sy, sk = w2 / float(w1), h2 / float(h1), min(w2 / float(w1), h2 / float(h1))
    sub.update(aspect=aspect, name="%s_%s" % (spec["name"], aspect.replace(":", "x")), also_aspects=None)
    sub.pop("caption_y", None)
    sub.pop("headline_y", None)
    for t in sub.get("texts") or []:
        t["x"], t["y"] = int(t.get("x", w1 / 2) * sx), int(t.get("y", h1 / 2) * sy)
        t["size"] = int(float(t.get("size", 90)) * sk)
    for st in sub.get("stickers") or []:
        st["x"], st["y"] = int(st.get("x", w1 / 2) * sx), int(st.get("y", h1 / 2) * sy)
        st["w"] = int(float(st.get("w", 200)) * sk)
    b = sub.get("banner")
    if isinstance(b, dict) and isinstance(b.get("position"), (list, tuple)):
        b["position"] = "auto"
    return sub


def _make_one(spec, outdir, workroot, cfg=None, all_words=None):
    """spec keys: name, source, start/end OR segments, headline, and optional:
    layout, facecam, punch, watermark, censor, model, words_json,
    tighten (bool), teaser ("auto" | [a,b] | null), captions (pro|karaoke|box|minimal),
    accent (yellow|green|pink|cyan), progress (bool), open_punch (bool), title/description/hashtags"""
    from . import qa, speaker
    from .transcribe import get_model
    cfg = cfg or {}
    fx = dict(cfg.get("effects", {}))
    name = spec["name"]
    wd = os.path.join(workroot, name)
    os.makedirs(wd, exist_ok=True)
    os.makedirs(outdir, exist_ok=True)
    out = os.path.join(outdir, name + ".mp4")
    pieces = [list(p) for p in (spec.get("segments") or [[spec["start"], spec["end"]]])]
    wj = spec.get("words_json") or os.path.join(os.path.dirname(os.path.abspath(spec["source"])), "words.json")
    if spec.get("words"):                       # edited in the editor (source-time [s, e, word])
        all_words = [list(w[:3]) + [1.0] for w in spec["words"]]
    elif all_words is None and os.path.exists(wj):
        all_words = json.load(open(wj))
    notes = []

    # ---- tighten: cut dead air + fillers (needs the source transcript)
    removed = 0.0
    if all_words and spec.get("tighten", fx.get("tighten", True)):
        pieces, removed = tighten_pieces(pieces, all_words, max_gap=float(fx.get("max_pause", 0.42)))
        if removed:
            notes.append("tightened: removed %.1fs of pauses/fillers (%d cuts)" % (removed, len(pieces) - 1))

    # ---- teaser: payoff line first, then the story (opt-in; strongest when the payoff is visual/loud)
    teaser = spec.get("teaser", fx.get("teaser"))
    flashes = []
    tz = None
    if teaser:
        if teaser == "auto" and all_words:
            span = (min(p[0] for p in pieces), max(p[1] for p in pieces))
            env_clip = os.path.join(wd, "env.wav")
            ffmpeg(["-ss", "%.3f" % span[0], "-t", "%.3f" % (span[1] - span[0]), "-i", spec["source"], "-vn", "-ac", "1",
                    "-ar", "8000", "-af", "highpass=f=250,lowpass=f=3400", env_clip])
            with wave.open(env_clip, "rb") as wf:
                xx = np.frombuffer(wf.readframes(wf.getnframes()), dtype=np.int16).astype(np.float32)
            base = 20 * np.log10(np.sqrt((xx ** 2).mean()) + 1)

            def efn(s, e):
                seg = xx[int((s - span[0]) * 8000): int((e - span[0]) * 8000)]
                return (20 * np.log10(np.sqrt((seg ** 2).mean()) + 1) - base) / 3.0 if len(seg) else 0.0
            tz = pick_teaser(all_words, span[0], span[1], efn)
        elif isinstance(teaser, (list, tuple)):
            tz = (teaser[0], teaser[1], "")
        if tz:
            pieces = [[tz[0], tz[1]]] + pieces
            flashes.append(round(tz[1] - tz[0], 3))
            notes.append("teaser %.1f-%.1f %s" % (tz[0], tz[1], ('"%s"' % tz[2]) if tz[2] else ""))

    raw = os.path.join(wd, "raw.mp4")
    offs = cut_raw(spec["source"], pieces, raw, cfg.get("max_height", 1080))
    pr = probe(raw)
    w0, h0, dur = pr["width"], pr["height"], pr["duration"]

    # ---- words (reused from the full-video transcript; transcribe the clip only as a fallback)
    words = words_for_pieces(all_words, offs) if all_words else None
    if not words:
        cache = os.path.join(wd, "words.json")
        if os.path.exists(cache):
            words = [tuple(w) for w in json.load(open(cache))]
        else:
            from .transcribe import _transcribe_wav
            wav = os.path.join(wd, "a16k.wav")
            ffmpeg(["-i", raw, "-vn", "-ac", "1", "-ar", "16000", wav])
            size = spec.get("model") or cfg.get("whisper_model", "small")
            try:
                words = [tuple(w[:3]) for w in _transcribe_wav(get_model(size), wav, cfg.get("vocab"), 5)]
                json.dump(words, open(cache, "w"))
            except Exception as e:     # never lose a clip because the speech model is unavailable
                notes.append("NO CAPTIONS: speech model unavailable (%s)" % str(e)[:80])
                words = []

    # ---- faces, speakers, layout
    info = list(notes)
    layout = spec.get("layout") or "auto"
    vertical = h0 / float(w0) >= 1.3
    aspect = aspect_of(spec)
    OW, OH = ASPECTS[aspect]
    framed = aspect != "9:16"
    samples, active = speaker.analyze(raw, w0, h0, wd)
    if framed and layout not in ("auto", "blur_fit", "tall"):
        info.append("%s layout is for 9:16 - using the %s frame instead" % (layout, aspect))
        layout = "auto"
    facecam = spec.get("facecam")
    if facecam and all(v <= 1.0 for v in facecam):
        facecam = [int(facecam[0] * w0), int(facecam[1] * h0), int(facecam[2] * w0), int(facecam[3] * h0)]
    if layout == "gameplay" and not (spec.get("background") and os.path.exists(spec["background"])):
        layout = "auto"
        info.append("gameplay layout needs a 'background' video -> auto")
    if framed:
        pass
    elif layout == "gameplay":
        pass
    elif vertical:
        layout = "vertical"
    elif layout in ("auto", "facecam_screen") and not facecam:
        fc_box = detect_facecam(raw, samples, w0, h0)
        if fc_box:
            facecam, layout = list(fc_box), "facecam_screen"
            info.append("auto-detected facecam inset %s" % (fc_box,))
        elif layout == "facecam_screen":
            layout = "blur_fit"
            info.append("facecam layout requested but no inset found -> blur_fit")
    elif facecam and layout == "auto":
        layout = "facecam_screen"
    from . import effects
    segs = [(0.0, dur, None)]
    fmode, frame_faces = None, []
    if framed:
        body_fc, plan, fmode, frame_faces = frame_body(samples, dur, w0, h0, OW, OH, layout, info, fixed_x=spec.get("crop_x"))
        body_h, layout = OH, "frame"
    elif layout == "gameplay":
        body_fc, top_h = effects.gameplay_body(samples, active, w0, h0, 1, effects.bg_duration(spec["background"]),
                                               dur, seed=name)
        body_h, plan = H, [(0.0, 1e9, "gameplay", top_h)]
        info.append("gameplay layout: clip on top, %s below" % os.path.basename(spec["background"]))
    else:
        if layout in ("auto", "tall", "split"):
            shots = detect_shots(raw, dur)
            modes = sample_modes(samples, w0, h0, active)
            segs = plan_segments(samples, modes, shots, dur)
        body_fc, body_h, plan = build_body(samples, segs, w0, h0, layout, facecam, info, fixed_x=spec.get("crop_x"))
    if spec.get("caption_y"):
        plan = [(p[0], p[1], p[2], int(spec["caption_y"])) for p in plan]

    # ---- zooms
    punches = spec.get("punch")
    if punches is None and fx.get("punch_zoom", True) and words:
        punches = pick_punches(words, word_energy(raw, words, wd), dur, plan, avoid=flashes)
    punches = punches or []
    first_mode = plan[0][2] if plan else None
    open_punch = spec.get("open_punch", fx.get("open_punch", True)) and first_mode not in ("facecam_screen", "blur_fit", "gameplay") \
        and fmode != "fit"

    # ---- captions + headline
    ass = os.path.join(wd, "cap.ass")
    head_y = vertical_head_y(samples, w0, h0, spec.get("headline")) if layout == "vertical" else (
        170 if layout == "gameplay" else frame_head(OH)[0] if framed else None)
    head_y = spec.get("headline_y") or head_y
    cap_info = build_ass(words or [], dur, spec.get("headline", ""), plan, ass, vertical=(layout == "vertical"),
                         watermark=spec.get("watermark", cfg.get("watermark")),
                         censor=spec.get("censor", cfg.get("censor_captions", False)),
                         head_y=head_y, cap_size=int(int(spec.get("caption_size") or cfg.get("caption_size", 118)) * CAP_SCALE[aspect]),
                         style=spec.get("captions", cfg.get("caption_style", "pro")),
                         accent=spec.get("accent", cfg.get("accent", "yellow")),
                         progress=spec.get("progress", fx.get("progress_bar", False)), flashes=flashes,
                         cap_font=spec.get("caption_font", cfg.get("caption_font", CAP_FONT)),
                         uppercase=spec.get("uppercase", True),
                         extra_events=effects.text_layer_events(spec.get("texts"), fmt),
                         look={"bold": spec.get("caption_bold"), "italic": spec.get("caption_italic"),
                               "spacing": spec.get("caption_spacing", 1), "color": spec.get("caption_color"),
                               "outline_color": spec.get("caption_outline_color"),
                               "outline": spec.get("caption_outline"), "shadow": spec.get("caption_shadow", True),
                               "headline_font": spec.get("headline_font"), "headline_color": spec.get("headline_color"),
                               "headline_bg": spec.get("headline_bg"),
                               "caption_font_set": bool(spec.get("caption_font") or cfg.get("caption_font"))},
                         canvas=(OW, OH))
    if spec.get("caption_size"):
        pass
    cap_info["head_y"] = head_y

    # ---- one final encode: body -> zoom -> band -> grade -> captions/text -> stickers -> speed
    draft = bool(spec.get("_draft"))
    fc = [body_fc, zoom_chain(punches, body_h, open_punch=open_punch, body_w=OW)]
    if framed or body_h == H:
        fc.append("[bodyz]null[comp]")
    else:
        fc.append("[bodyz]split=2[bz1][bz2];[bz1]scale=%d:%d:force_original_aspect_ratio=increase,crop=%d:%d,"
                  "gblur=sigma=40,eq=brightness=-0.28:saturation=0.75,lutyuv=y='max(val,36)'[bg];[bg][bz2]overlay=0:%d[comp]" % (W, H, W, H, BAND))
    grade = effects.grade_chain(spec.get("grade"))
    from .fonts import render_dir
    fc.append("[comp]%sass=filename=%s:fontsdir=%s[vass]" % (grade + "," if grade else "", fpath(ass), fpath(render_dir())))
    ins = ["-i", raw]
    if layout == "gameplay":
        ins += ["-stream_loop", "-1", "-i", spec["background"]]
    nxt = len(ins) // 2 if layout != "gameplay" else 2
    sargs, steps, nxt = effects.sticker_inputs(spec.get("stickers"), nxt)
    ins += sargs
    last = "[vass]"
    for k, (prep, ov, idx) in enumerate(steps):
        fc.append(prep)
        fc.append("%s[stk%d]%s[vs%d]" % (last, idx, ov, k))
        last = "[vs%d]" % k
    from .banner import resolve as _resolve_banner
    bnr = _resolve_banner(spec.get("banner", cfg.get("banner")))
    if bnr and (bnr.get("handle") or bnr.get("text") or bnr.get("image")) and bnr.get("enabled", True):
        from .banner import overlay_steps
        faces = frame_faces if framed else []
        if layout == "vertical":       # face band in output coords (fit-scaled source)
            sc_ = min(W / float(w0), H / float(h0))
            oy_ = (H - h0 * sc_) / 2
            fs_ = [f for _, ff in samples for f in _real(ff, h0)]
            if fs_:
                faces = [(float(np.percentile([f[1] - f[3] / 2 for f in fs_], 20)) * sc_ + oy_,
                          float(np.percentile([f[1] + f[3] / 2 for f in fs_], 80)) * sc_ + oy_)]
        bargs, bprep, bov = overlay_steps(bnr, layout, plan, head_y if (spec.get("headline") or not framed) else None,
                                          dur, nxt, faces, W=OW, H=OH)
        ins += bargs
        nxt += 1
        fc.append(bprep)
        fc.append("%s[bnr]%s[vbn]" % (last, bov))
        last = "[vbn]"
        info.append("banner: %s" % (os.path.basename(bnr["image"]) if bnr.get("image") else bnr.get("text") or
                                    "%s/%s" % (bnr.get("platform", "kick"), bnr.get("handle"))))
        if bnr.get("outro"):
            from .banner import outro_card
            oargs, oprep, oov = outro_card(bnr, dur, nxt, W=OW, H=OH)
            ins += oargs
            nxt += 1
            fc.append(oprep)
            fc.append("%s[outro]%s[vot]" % (last, oov))
            last = "[vot]"
    speed = float(spec.get("speed", 1.0) or 1.0)
    tail = []
    if abs(speed - 1.0) > 0.01:
        tail.append("setpts=PTS/%.4f" % speed)
    if draft:
        tail.append("scale=%d:%d" % (OW // 2, OH // 2))
    fc.append("%s%s[vout]" % (last, ",".join(tail) if tail else "null"))
    meas = measure_loudness(raw)
    gain = float(spec.get("volume_db", 0) or 0)
    pre = AUDIO_PRE + (",volume=%.1fdB" % gain if gain else "")
    alabel = "[voice0]"
    rep_ = spec.get("audio_replace") or {}
    if rep_.get("path") and os.path.exists(rep_["path"]) and rep_.get("mode", "replace") == "replace":
        # replace the clip's sound entirely (e.g. a licensed track or a re-recorded voiceover)
        ins += ["-stream_loop", "-1", "-ss", "%.3f" % float(rep_.get("offset", 0)), "-i", rep_["path"]]
        fc.append("[%d:a]aresample=48000,aformat=channel_layouts=stereo,atrim=0:%.3f,volume=%.2f,"
                  "loudnorm=I=-14:TP=-1.5:LRA=11,afade=t=in:d=0.05,afade=t=out:st=%.3f:d=0.3%s"
                  % (nxt, dur, float(rep_.get("volume", 1.0)), max(0, dur - 0.3), alabel))
        nxt += 1
        info.append("audio replaced: %s" % os.path.basename(rep_["path"]))
    elif spec.get("mute_original"):
        fc.append("anullsrc=r=48000:cl=stereo,atrim=0:%.3f%s" % (dur, alabel))
    else:
        fc.append(audio_chain(meas, dur, pre=pre, out=alabel))
    if rep_.get("path") and os.path.exists(rep_["path"]) and rep_.get("mode") == "mix":
        ins += ["-stream_loop", "-1", "-ss", "%.3f" % float(rep_.get("offset", 0)), "-i", rep_["path"]]
        fc.append("[%d:a]aresample=48000,aformat=channel_layouts=stereo,atrim=0:%.3f,volume=%.2f[rmx];"
                  "%s[rmx]amix=inputs=2:duration=first:normalize=0[voicem]" % (nxt, dur, float(rep_.get("volume", 0.5)), alabel))
        nxt += 1
        alabel = "[voicem]"
    mr = []
    for r_ in spec.get("mute_ranges") or []:      # "mute a section": silence the original audio in clip time
        try:
            a_, b_ = max(0.0, float(r_[0])), min(dur, float(r_[1]))
        except (TypeError, ValueError, IndexError):
            continue
        if b_ - a_ > 0.02:
            mr.append((a_, b_))
    if mr:
        fc.append("%svolume=0:enable='%s'[amuted]" % (alabel, "+".join("between(t,%.3f,%.3f)" % r_ for r_ in mr)))
        alabel = "[amuted]"
        info.append("muted %d section(s)" % len(mr))
    if flashes and spec.get("sfx", fx.get("sfx", True)):
        ins += ["-i", whoosh(os.path.join(workroot, "_whoosh.wav"))]
        wi = nxt
        nxt += 1
        fc.append("[%d:a]adelay=%d|%d,apad[wh];%s[wh]amix=inputs=2:duration=first:normalize=0[voice1]"
                  % (wi, max(0, int(flashes[0] * 1000) - 250), max(0, int(flashes[0] * 1000) - 250), alabel))
        alabel = "[voice1]"
    mus = spec.get("music") or {}
    if mus.get("path") and os.path.exists(mus["path"]):
        ins += ["-stream_loop", "-1", "-i", mus["path"]]
        fc.append(effects.music_chain(alabel, nxt, dur, float(mus.get("volume", 0.18)), mus.get("duck", True),
                                      out="[amix]"))
        nxt += 1
        alabel = "[amix]"
    fc.append("%s%s[aout]" % (alabel, ("atempo=%.4f" % speed) if abs(speed - 1.0) > 0.01 else "anull"))
    ffmpeg(ins + ["-filter_complex", ";".join(fc), "-map", "[vout]", "-map", "[aout]",
                  "-c:v", "libx264", "-preset", "ultrafast" if draft else "medium", "-crf", "28" if draft else "18",
                  "-pix_fmt", "yuv420p", "-r", str(FPS), "-c:a", "aac", "-b:a", "192k", "-ar", "48000",
                  "-movflags", "+faststart", "-t", "%.3f" % (dur / speed), out], timeout=3600)
    if not draft:
        try:
            lufs = fix_loudness(out)
            if lufs is not None:
                info.append("loudness %.1f LUFS" % lufs)
        except Exception as e:
            info.append("loudness check skipped: %s" % str(e)[:80])
    first_word = min((w[0] for w in words), default=None) if words else None
    res = {"name": name, "out": out, "dur": round(dur, 2), "source": spec["source"],
           "pieces": [[round(a, 2), round(b, 2)] for a, b in pieces], "source_res": "%dx%d" % (w0, h0),
           "layout": layout, "layout_log": info, "punch_zoom_at": [round(p, 2) for p in punches],
           "open_punch": bool(open_punch), "tightened_s": removed, "teaser": tz[:2] if tz else None,
           "words": len(words or []), "first_word_at": first_word,
           "words_first3s": sum(1 for w in (words or []) if w[0] < 3.0),
           "text": " ".join(w[2] for w in (words or [])),
           "speakers": len({f[5] for _, fs in samples for f in fs if len(f) > 5}),
           "headline": spec.get("headline", ""), "aspect": aspect, "size": "%dx%d" % (OW, OH)}
    for k in ("title", "description", "hashtags"):
        if spec.get(k):
            res[k] = spec[k]
    res.update(cap_info)
    if words:     # subtitles file next to the clip (same lines + timing as the burned captions)
        try:
            write_srt(caption_cues(words, spec.get("captions", cfg.get("caption_style", "pro")),
                                   spec.get("censor", cfg.get("censor_captions", False)), speed),
                      os.path.join(outdir, name + ".srt"))
            res["srt"] = name + ".srt"
        except Exception as e:
            info.append("srt export failed: %s" % e)
    if abs(speed - 1.0) > 0.01:
        res["speed"] = speed
        res["dur"] = round(dur / speed, 2)
    if draft:
        res["qa"] = {"ok": True, "warnings": ["draft preview (%dx%d, fast encode) - not QA'd" % (OW // 2, OH // 2)], "draft": True}
        return res
    qplan = plan if abs(speed - 1.0) < 0.01 else [(p[0] / speed, p[1] / speed, p[2], p[3]) for p in plan]
    res["qa"] = qa.check_clip(out, res, qplan, samples, w0, h0, body_h, outdir, expect=(OW, OH))
    from .verify import qc_register, verify_file
    res["verify"] = verify_file(out, [w[2] for w in (words or [])], check_wer=cfg.get("qc", {}).get("caption_wer", True),
                                expect=(OW, OH))
    if not res["verify"]["ok"]:
        res["qa"]["ok"] = False
        res["qa"]["warnings"] = res["qa"]["warnings"] + ["verifier: " + d for d in res["verify"]["defects"]]
    qc_register(outdir, name, out, res["verify"], source=spec.get("_origin", "render"))
    json.dump(res, open(os.path.join(outdir, name + ".json"), "w"), indent=1)
    return res

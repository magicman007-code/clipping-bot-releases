"""Clip quality score (0-10) with a transparent rubric, and the publish bar (default 6.0).

This is a heuristic, NOT a validated virality predictor. Every point is explained so an editor can
disagree; human ratings in the editor are logged (ledger.jsonl) to recalibrate it against real results.

Rubric (pre-render, from the candidate):
  hook        0-2    first sentence carries stakes / shock / a question / conflict (not filler)
  payoff      0-3    distinct outcomes + numbers in the back half, a laugh/shock beat landing late
  complete    0-2    starts on a sentence, ends on a beat (pause/laugh after), setup->payoff structure
  energy      0-1.5  voice energy peaks vs. this speaker's own baseline
  pacing      0-1.5  little dead air/filler, 15-45s, clean transcript
Post-render adjustments: -0.75 per QA/verifier problem (max -2.25); -1 for a late first word.
"""
import re


def _clamp(x, a, b):
    return max(a, min(b, x))


def score_candidate(c):
    why = []
    tags = c.get("tags", {})
    # hook
    if c.get("hook", 0) >= 1.0:
        hook = 2.0
        why.append("+2 hook: opening line has stakes/shock/question")
    elif tags.get("story"):
        hook = 1.0
        why.append("+1 hook: opens on a story marker")
    else:
        hook = 0.0
        why.append("+0 hook: weak opening line")
    if c.get("dangling"):
        hook = max(0.0, hook - 0.75)
        why.append("-0.75 opens mid-thought (\"and / but / like I said...\"): confusing to a stranger")
    # payoff
    pm = float(c.get("payoff_mag", 0))
    late_beat = c.get("payoff", 0) >= 1.5
    payoff = _clamp(pm / 10 * 2 + (1.0 if late_beat else 0) + (0.5 if c.get("novelty", 0) >= 5 else 0), 0, 3)
    why.append("+%.1f payoff (payoff-mag %.0f/10%s)" % (payoff, pm, ", late laugh/shock beat" if late_beat else ""))
    # completeness
    complete = 1.0 + (0.6 if c.get("tail") else 0) + (0.4 if pm >= 6 else 0) - (0.5 if c.get("cut_end") else 0)
    why.append("+%.1f complete (sentence-snapped%s%s)" % (complete, ", ends on a beat" if c.get("tail") else "",
                                                          ", but ends mid-sentence" if c.get("cut_end") else ""))
    # energy
    energy = _clamp(float(c.get("energy", 0)) / 3.0 * 1.5, 0, 1.5)
    why.append("+%.1f energy" % energy)
    # pacing
    dur = float(c.get("dur", 30))
    pacing = 1.5 - 0.3 * float(c.get("dead_air", 0)) - (0.5 if dur < 15 else 0.04 * max(0.0, dur - 25)) \
        - (0.5 if c.get("asr_conf", 1) < 0.6 else 0) - (0.5 if c.get("filler", 0) > 0.25 else 0) \
        - 0.15 * max(0.0, float(c.get("after_beat", 0)) - 3.0)
    pacing = _clamp(pacing, 0, 1.5)
    why.append("+%.1f pacing (%.0fs, %.1fs dead air%s)" % (pacing, dur, c.get("dead_air", 0),
               ", %.0fs after the payoff" % c["after_beat"] if c.get("after_beat", 0) > 3 else ""))
    # community context: a callback to the streamer's lore or a live stream event is what regular viewers share
    ctx = 0.0
    if tags.get("lore"):
        ctx += min(1.0, 0.5 * tags["lore"])
        why.append("+%.1f lore callback (running joke / known name)" % min(1.0, 0.5 * tags["lore"]))
    if tags.get("events"):
        ctx += 0.5
        why.append("+0.5 stream event (subs / raid / donation / ban)")
    hot = [k for k in ("reaction", "awkward", "rage") if tags.get(k)]
    if hot:          # the moment types that dominate the most-shared stream clips
        ctx += 0.5
        why.append("+0.5 %s moment" % "/".join(hot))
    if tags.get("burst"):
        ctx += 0.3
        why.append("+0.3 big vocal reaction (voice jumps well above the moment before)")
    if tags.get("chat"):     # the audience itself reacted (chat replay, chat.py)
        bonus = round(min(1.2, 0.4 + 0.1 * float(c.get("chat_z") or 3.0)), 1)
        ctx += bonus
        mood = {"laugh": "laughing", "hype": "hyped", "shock": "shocked"}.get(c.get("chat_mood"), "reacting")
        why.append("+%.1f chat exploded right after (%s, spike strength %.0f)" % (bonus, mood, float(c.get("chat_z") or 0)))
    if c.get("chrome"):
        ctx -= 1.0
        why.append("-1.0 stream housekeeping (intro / sponsor / 'hit follow') - means nothing to a stranger")
    if c.get("style_sim") is not None:
        bonus = round(max(-0.5, min(1.0, (c["style_sim"] - 0.35) * 4)), 2)
        ctx += bonus
        why.append("%+.1f how much it resembles this streamer's best clips" % bonus)
    total = round(max(0.0, min(10.0, hook + payoff + complete + energy + pacing + ctx)), 1)
    # payoff first: a moment with no punchline / reaction / reveal inside it is chatter, however lively
    if c.get("has_beat") is False and pm < 4 and not tags.get("chat"):
        if total > 5.0:
            why.append("capped at 5: no payoff inside the clip (no laugh, reaction, reveal or chat spike)")
        total = min(total, 5.0)
    if c.get("talk") is not None and c["talk"] < 0.6:
        total = min(total, 4.0)
        why.append("capped at 4: mostly dead air (only %d%% of it is clear talking)" % round(100 * c["talk"]))
    return {"score": total, "parts": {"hook": hook, "payoff": round(payoff, 2), "complete": complete,
                                      "energy": round(energy, 2), "pacing": round(pacing, 2), "context": ctx},
            "why": why}


def adjust_after_render(base, res):
    """Apply render QA to the candidate score."""
    s = dict(base)
    why = list(base.get("why", []))
    probs, seen = [], set()
    for w in res.get("qa", {}).get("warnings", []):
        if "draft preview" in w:
            continue
        key = re.sub(r"^verifier:\s*", "", w).split()[0].lower()      # 'loudness', 'face', ...
        if key.startswith("captions"):
            # fixable in the Captions panel and gated by human approval - not a weaker moment, so not a lower score
            why.append("captions need a look (fix or approve them): %s" % re.sub(r"^verifier:\s*", "", w)[:120])
            continue
        if key not in seen:
            seen.add(key)
            probs.append(w)
    pen = min(2.25, 0.75 * len(probs))
    if pen:
        why.append("-%.2f render QA: %s" % (pen, "; ".join(probs)[:200]))
    fw = res.get("first_word_at")
    late = 1.0 if fw is not None and fw > 0.8 else 0.0
    if late:
        why.append("-1 first word at %.1fs" % fw)
    s["score"] = round(max(0.0, base["score"] - pen - late), 1)
    s["why"] = why
    return s

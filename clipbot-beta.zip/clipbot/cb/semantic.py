"""Meaning search over transcripts (offline).

all-MiniLM-L6-v2 (Apache-2.0, sentence-transformers) as ONNX, run with onnxruntime + tokenizers (both already
installed for the speech model). Downloaded once (~90 MB) from a pinned Hugging Face revision and verified by
SHA-256, stored in <work_root>/_models/minilm/. If it can't be downloaded, callers fall back to keyword search
(available() returns False) - nothing breaks.
"""
import hashlib
import os
import threading

import numpy as np

from .common import load_config, log

REV = "751bff37182d3f1213fa05d7196b954e230abad9"
FILES = {
    "model.onnx": ("https://huggingface.co/Xenova/all-MiniLM-L6-v2/resolve/%s/onnx/model.onnx" % REV,
                   "759c3cd2b7fe7e93933ad23c4c9181b7396442a2ed746ec7c1d46192c469c46e"),
    "tokenizer.json": ("https://huggingface.co/Xenova/all-MiniLM-L6-v2/resolve/%s/tokenizer.json" % REV,
                       "da0e79933b9ed51798a3ae27893d3c5fa4a201126cef75586296df9b4d2c62a0"),
}
_LOCK = threading.Lock()
_M = {"sess": None, "tok": None, "failed": None}


def model_dir():
    d = os.path.join(load_config()["work_root"], "_models", "minilm")
    os.makedirs(d, exist_ok=True)
    return d


def _sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def _fetch(name):
    import urllib.request
    url, want = FILES[name]
    dst = os.path.join(model_dir(), name)
    if os.path.exists(dst) and _sha(dst) == want:
        return dst
    log("downloading the search model (%s, one time)..." % name)
    tmp = dst + ".part"
    req = urllib.request.Request(url, headers={"User-Agent": "clipbot"})
    with urllib.request.urlopen(req, timeout=60) as r, open(tmp, "wb") as f:
        while True:
            b = r.read(1 << 20)
            if not b:
                break
            f.write(b)
    if _sha(tmp) != want:
        os.remove(tmp)
        raise RuntimeError("search model download was corrupted (checksum mismatch)")
    os.replace(tmp, dst)
    return dst


def _load():
    with _LOCK:
        if _M["sess"] is not None or _M["failed"]:
            return _M["sess"] is not None
        try:
            import onnxruntime as ort
            from tokenizers import Tokenizer
            mp, tp = _fetch("model.onnx"), _fetch("tokenizer.json")
            tok = Tokenizer.from_file(tp)
            tok.enable_truncation(max_length=128)
            tok.enable_padding(pad_id=0, pad_token="[PAD]")
            so = ort.SessionOptions()
            so.intra_op_num_threads = max(1, min(4, os.cpu_count() or 1))
            _M["sess"] = ort.InferenceSession(mp, so, providers=["CPUExecutionProvider"])
            _M["tok"] = tok
            return True
        except Exception as e:
            _M["failed"] = str(e)[:200]
            log("meaning search unavailable (%s) - using keyword search" % _M["failed"])
            return False


def available():
    return _load()


def embed(texts, batch=64):
    """L2-normalised sentence vectors (n, 384). Raises if the model isn't available."""
    if not _load():
        raise RuntimeError("search model unavailable: %s" % _M["failed"])
    out = []
    for i in range(0, len(texts), batch):
        enc = _M["tok"].encode_batch([t or " " for t in texts[i:i + batch]])
        ids = np.array([e.ids for e in enc], np.int64)
        mask = np.array([e.attention_mask for e in enc], np.int64)
        feeds = {"input_ids": ids, "attention_mask": mask, "token_type_ids": np.zeros_like(ids)}
        h = _M["sess"].run(None, feeds)[0]                       # (b, seq, 384)
        m = mask[..., None].astype(np.float32)
        v = (h * m).sum(1) / np.maximum(m.sum(1), 1e-9)           # mean pooling (sentence-transformers)
        out.append(v / np.maximum(np.linalg.norm(v, axis=1, keepdims=True), 1e-9))
    return np.vstack(out) if out else np.zeros((0, 384), np.float32)


def sentence_vectors(sentences, workdir):
    """Cached embeddings for a project's sentences (recomputed when the transcript changes)."""
    texts = [s["text"] for s in sentences]
    key = hashlib.md5("\n".join(texts).encode("utf-8")).hexdigest()[:12]
    p = os.path.join(workdir, "_sent_vec_%s.npy" % key)
    if os.path.exists(p):
        v = np.load(p)
        if len(v) == len(texts):
            return v
    v = embed(texts)
    for f in os.listdir(workdir):
        if f.startswith("_sent_vec_") and f.endswith(".npy"):
            try:
                os.remove(os.path.join(workdir, f))
            except OSError:
                pass
    np.save(p, v.astype(np.float32))
    return v

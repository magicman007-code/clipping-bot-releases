"""Continuous live-stream clipping.

  python3 clipbot.py live-watch <url> [--name Orangie] [--minutes 180] [--chat twitch:<channel> | kick:<slug>]

While the stream runs:
  recorder   ffmpeg pulls the stream (YouTube/Twitch/Kick via yt-dlp, or any .m3u8) into 20s
             MPEG-TS segments; reconnects with backoff when the stream drops; stops when it ends.
  chat       optional Twitch IRC (anonymous, read-only) or Kick (Pusher websocket) reader; message
             rate spikes and hype tokens (KEKW, LUL, W, "clip it"...) are a strong live signal.
  processor  every finished segment is transcribed (whisper, rolling) and its voice energy measured
             against a rolling baseline.
  detector   re-scores the last ~4 minutes each segment with the same candidate finder as VODs,
             plus chat; a moment fires only once it has SETTLED (its end is >= 8s behind the live
             edge, so the payoff has happened) and beats an adaptive threshold (session percentile),
             with a cooldown and an hourly cap. A chat explosion fires on its own.
  clipper    cuts the window (+padding) into its own project folder (source.mp4, words.json,
             specs.json) - so it opens in the editor - renders it, and puts it in the QC inbox
             (pending until a person approves). Optional webhook (Discord-compatible) on each clip.
  status     <session>/live_status.json, events.jsonl; old segments are deleted (ring buffer).
"""
import csv
import glob
import json
import os
import re
import signal
import socket
import subprocess
import threading
import time
import wave
from concurrent.futures import ThreadPoolExecutor

import numpy as np

from .common import concat_path, safe_remove, ffmpeg, load_config, log, run

HYPE = re.compile(r"\b(kekw|lul|lol|lmao+|omegalul|pog\w*|w+|ll+|clip (it|that)|no way|holy|wtf|💀|😂|😭|🔥|"
                  r"icant|aware|monka\w*|pepela|xdd+|kek|bro+|nah+)\b", re.I)


# ---------------------------------------------------------------- chat readers
class Chat:
    """Collects (session_time, text) messages from a background thread."""

    def __init__(self, spec, t0):
        self.msgs, self.t0, self.err = [], t0, None
        self.lock = threading.Lock()
        kind, _, target = (spec or "").partition(":")
        self.kind, self.target = kind, target
        if kind in ("twitch", "kick"):
            threading.Thread(target=getattr(self, "_" + kind), daemon=True).start()

    def add(self, text):
        with self.lock:
            self.msgs.append((time.time() - self.t0, text))

    def _twitch(self):
        chan, _, hp = self.target.partition("@")
        host, port = (hp.split(":") + ["6667"])[:2] if hp else ("irc.chat.twitch.tv", "6667")
        while True:
            try:
                s = socket.create_connection((host, int(port)), timeout=60)
                s.sendall(b"NICK justinfan%d\r\nJOIN #%s\r\n" % (int(time.time()) % 90000 + 10000, chan.lower().encode()))
                buf = b""
                while True:
                    data = s.recv(4096)
                    if not data:
                        break
                    buf += data
                    while b"\r\n" in buf:
                        line, buf = buf.split(b"\r\n", 1)
                        ln = line.decode("utf-8", "ignore")
                        if ln.startswith("PING"):
                            s.sendall(b"PONG :tmi.twitch.tv\r\n")
                        elif " PRIVMSG " in ln:
                            self.add(ln.split(" :", 2)[-1])
            except Exception as e:
                self.err = str(e)
            time.sleep(5)

    def _kick(self):
        try:
            import urllib.request
            import websocket   # pip install websocket-client
            req = urllib.request.Request("https://kick.com/api/v2/channels/%s" % self.target,
                                         headers={"User-Agent": "Mozilla/5.0", "Accept": "application/json"})
            room = json.loads(urllib.request.urlopen(req, timeout=30).read())["chatroom"]["id"]
        except Exception as e:
            self.err = "kick chat unavailable: %s" % e
            return
        url = "wss://ws-us2.pusher.com/app/32cbd69e4b950bf97679?protocol=7&client=js&version=8.4.0&flash=false"
        while True:
            try:
                ws = websocket.create_connection(url, timeout=60)
                ws.send(json.dumps({"event": "pusher:subscribe", "data": {"auth": "", "channel": "chatrooms.%s.v2" % room}}))
                while True:
                    m = json.loads(ws.recv())
                    if m.get("event", "").endswith("ChatMessageEvent"):
                        self.add(json.loads(m["data"]).get("content", ""))
                    elif m.get("event") == "pusher:ping":
                        ws.send(json.dumps({"event": "pusher:pong", "data": {}}))
            except Exception as e:
                self.err = str(e)
            time.sleep(5)

    def series(self, t_end, hop=1.0):
        """per-second message counts and hype counts up to t_end."""
        n = int(t_end / hop) + 1
        rate, hype = np.zeros(n), np.zeros(n)
        with self.lock:
            for t, txt in self.msgs:
                i = int(t / hop)
                if 0 <= i < n:
                    rate[i] += 1
                    hype[i] += 1 if HYPE.search(txt) else 0
        return rate, hype

    def spike(self, a, b, t_end):
        """z-score of chat activity in [a, b] vs the previous 5 minutes (0 if no chat)."""
        rate, hype = self.series(t_end)
        if rate.sum() < 5:
            return 0.0
        act = rate + 2 * hype
        win = act[int(a):int(b) + 1]
        base = act[max(0, int(a) - 300):int(a)]
        if len(win) == 0 or len(base) < 20:
            return 0.0
        k = max(1, min(len(win), 6))
        peak = np.sort(np.convolve(win, np.ones(k) / k, mode="valid"))[-1] if len(win) >= k else win.mean()
        return float((peak - base.mean()) / (base.std() + 0.5))


# ---------------------------------------------------------------- session
class LiveSession:
    def __init__(self, url, name=None, minutes=None, chat=None, render=True, transcriber="whisper", outroot=None,
                 cfg=None, wait_hours=None, min_quality=None, recap=True):
        self.cfg = cfg or load_config()
        L = self.cfg.get("live", {})
        self.url, self.render, self.transcriber = url, render, transcriber
        self.name = name or re.sub(r"\W+", "_", url.rstrip("/").split("/")[-1])[:40] or "stream"
        self.minutes = minutes
        self.seg_s = int(L.get("segment_seconds", 20))
        self.settle = float(L.get("settle_seconds", 8))
        self.window = float(L.get("window_seconds", 240))
        self.cooldown = float(L.get("cooldown_seconds", 45))
        self.max_per_hour = int(L.get("max_clips_per_hour", 20))
        # steady pace: if nothing has been clipped for this long, take the best moment that still passes the
        # quality bar even when it isn't a standout (0 = standouts only)
        self.steady_s = 60.0 * float(L.get("steady_minutes", 8))
        self.t_start = time.time()
        self.min_score = float(L.get("min_score", 14))
        self.keep_min = float(L.get("keep_minutes", 45))
        # whole broadcast is kept so the end-of-stream sweep can clip ALL of it (falls back to a rolling
        # buffer only if the disk gets tight)
        self.keep_full = bool(L.get("keep_full_stream", True))
        self.full_sweep = bool(L.get("full_sweep", True))
        self.model = L.get("whisper_model", "base")
        self.niche = tuple(L.get("niche") or self.cfg.get("niche") or ())
        from . import lore as _lore           # streamer lore: names spelled right in live captions too
        self.lore = _lore.load(L.get("streamer") or self.name)
        if self.lore:
            self.cfg = dict(self.cfg, vocab=list(self.cfg.get("vocab") or []) + _lore.vocab(self.lore))
        root = outroot or os.path.join(self.cfg["work_root"], re.sub(r"\W+", "_", self.name))
        self.dir = os.path.join(root, "live_" + time.strftime("%Y%m%d_%H%M%S"))
        self.chunks_dir = os.path.join(self.dir, "chunks")
        os.makedirs(self.chunks_dir, exist_ok=True)
        self.t0 = time.time()
        self.chat = Chat(chat, self.t0)
        self.segments = []          # {path, a, b}
        self.words = []             # [s, e, w, p] session time
        self.energy = []            # voice dB per 0.5s, session time
        self.fired = []             # (a, b, wall)
        self.fired_text = []        # token sets of fired clips (dedupe)
        self.history = []           # best candidate scores (adaptive threshold)
        self.stop = threading.Event()
        self.pool = ThreadPoolExecutor(1)
        self.clips = []
        self.rec_runs = 0
        self.ended = False
        # whole-stream mode: wait for the stream to go live, clip until it ends, then build the recap
        self.wait_hours = float(wait_hours if wait_hours is not None else L.get("wait_for_live_hours", 0))
        self.min_quality = float(min_quality if min_quality is not None else L.get("min_quality", 6.0))
        self.recap = recap and L.get("recap", True)
        self.went_live = False

    # ------------------------------------------------ recorder
    def _resolve(self):
        if re.search(r"\.m3u8(\?|$)", self.url) or os.path.exists(self.url) or self.url.startswith(("rtmp", "srt")):
            return [self.url]
        from .fetch import _ytdlp_base
        r = run(_ytdlp_base(self.cfg) + ["-g", "-f", "b[height<=720]/bv*[height<=720]+ba/best", self.url],
                timeout=90, check=False)
        return [u for u in r.stdout.split() if u.startswith("http")]

    def _recorder(self):
        fails = 0
        while not self.stop.is_set():
            urls = self._resolve()
            if not urls:
                fails += 1
                waiting = not self.went_live and (time.time() - self.t0) < self.wait_hours * 3600
                log("live: %s (%d)" % ("waiting for the stream to start" if waiting else "stream not reachable", fails))
                if waiting:
                    time.sleep(60)
                    continue
                if fails >= (4 if self.went_live else 6):
                    self.ended = True
                    self.stop.set()
                    return
                time.sleep(10 if self.went_live else min(60, 10 * fails))
                continue
            self.rec_runs += 1
            run_dir = os.path.join(self.chunks_dir, "run%02d" % self.rec_runs)
            os.makedirs(run_dir, exist_ok=True)
            base = time.time() - self.t0
            json.dump({"base": base}, open(os.path.join(run_dir, "base.json"), "w"))
            ins = []
            for u in urls[:2]:
                ins += ["-reconnect", "1", "-reconnect_streamed", "1", "-reconnect_delay_max", "10", "-i", u] \
                    if u.startswith("http") else ["-i", u]
            maps = ["-map", "0:v:0", "-map", "1:a:0" if len(urls) > 1 else "0:a:0?"]
            cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y"] + ins + maps + [
                "-c", "copy", "-f", "segment", "-segment_time", str(self.seg_s), "-segment_format", "mpegts",
                "-reset_timestamps", "1", "-segment_list", os.path.join(run_dir, "list.csv"), "-segment_list_type", "csv",
                os.path.join(run_dir, "seg_%05d.ts")]
            # stderr goes to a file: an unread pipe fills up during a long stream and stalls ffmpeg
            errlog = open(os.path.join(run_dir, "ffmpeg.log"), "wb")
            self.proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=errlog)
            while self.proc.poll() is None and not self.stop.is_set():
                time.sleep(1)
            if self.stop.is_set():
                try:     # 'q' = ffmpeg's own clean quit (finishes the last segment) - works on Mac/Linux/Windows
                    self.proc.stdin.write(b"q")
                    self.proc.stdin.flush()
                except (OSError, ValueError, AttributeError):
                    self.proc.terminate()
                try:
                    self.proc.wait(10)
                except Exception:
                    self.proc.kill()
                return
            errlog.close()
            try:
                err = open(os.path.join(run_dir, "ffmpeg.log"), "rb").read()[-300:].decode("utf-8", "ignore")
            except OSError:
                err = ""
            got = len(glob.glob(os.path.join(run_dir, "seg_*.ts")))
            if got > 1:
                self.went_live = True          # only real footage counts as "live"
                fails = 0
                self._empty_runs = 0
                if self._playlist_ended(urls[0]):
                    log("live: stream ended")
                    self.ended = True
                    self.stop.set()
                    return
                log("live: recorder dropped (%s) - reconnecting" % (err.strip()[-120:] or "connection lost"))
                time.sleep(3)
                continue
            if not self.went_live:             # never got footage: still waiting for the stream to start
                fails += 1
                waiting = (time.time() - self.t0) < max(self.wait_hours * 3600, 240)
                log("live: no footage yet (%d) - %s" % (fails, "waiting" if waiting else "giving up"))
                if not waiting:
                    self.ended = True
                    self.stop.set()
                    return
                time.sleep(min(60, 10 * fails))
                continue
            self._empty_runs = getattr(self, "_empty_runs", 0) + 1
            if self._empty_runs >= 4 or self._playlist_ended(urls[0]):   # ~1-2 min of nothing = stream over
                log("live: stream ended")
                self.ended = True
                self.stop.set()
                return
            log("live: no new footage (%d/4) - reconnecting" % self._empty_runs)
            time.sleep(15)

    def _playlist_ended(self, u):
        """HLS VOD/ended playlists carry #EXT-X-ENDLIST; a live one never does."""
        if ".m3u8" not in u:
            return False
        try:
            import urllib.request
            txt = urllib.request.urlopen(u, timeout=10).read(200000).decode("utf-8", "ignore") if u.startswith("http") \
                else open(u).read()
            return "#EXT-X-ENDLIST" in txt
        except Exception:
            return False

    def _new_segments(self):
        out = []
        for run_dir in sorted(glob.glob(os.path.join(self.chunks_dir, "run*"))):
            lst = os.path.join(run_dir, "list.csv")
            if not os.path.exists(lst):
                continue
            base = json.load(open(os.path.join(run_dir, "base.json")))["base"]
            for row in csv.reader(open(lst)):
                if len(row) < 3:
                    continue
                p = os.path.join(run_dir, row[0])
                if any(s["path"] == p for s in self.segments) or not os.path.exists(p):
                    continue
                out.append({"path": p, "a": base + float(row[1]), "b": base + float(row[2])})
        return sorted(out, key=lambda s: s["a"])

    # ------------------------------------------------ processing
    def _transcribe(self, seg):
        if self.transcriber == "none":
            return []
        if self.transcriber.startswith("fake:"):        # testing: words with session times from a file
            ws = json.load(open(self.transcriber[5:]))
            return [w for w in ws if seg["a"] <= w[0] < seg["b"]]
        from .transcribe import _transcribe_wav, get_model
        wav = seg["path"] + ".wav"
        ffmpeg(["-i", seg["path"], "-vn", "-ac", "1", "-ar", "16000", wav])
        try:
            model = get_model(self.model)
        except Exception as e:      # live model can't load (offline / download blocked): use the main model
            main = self.cfg.get("whisper_model", "small")
            if main == self.model:
                raise
            if not getattr(self, "_model_warned", False):
                log("live: '%s' speech model unavailable (%s) - using '%s' instead" % (self.model, str(e)[:100], main))
                self._model_warned = True
            self.model = main
            model = get_model(main)
        ws = _transcribe_wav(model, wav, self.cfg.get("vocab"), 2)
        safe_remove(wav)
        return [[round(w[0] + seg["a"], 3), round(w[1] + seg["a"], 3), w[2], w[3]] for w in ws]

    def _energy(self, seg):
        wav = seg["path"] + ".8k.wav"
        ffmpeg(["-i", seg["path"], "-vn", "-ac", "1", "-ar", "8000", "-af", "highpass=f=250,lowpass=f=3400", wav])
        with wave.open(wav, "rb") as wf:
            x = np.frombuffer(wf.readframes(wf.getnframes()), dtype=np.int16).astype(np.float32)
        safe_remove(wav)
        n = 4000
        k = len(x) // n
        db = (20 * np.log10(np.sqrt((x[:k * n].reshape(k, n) ** 2).mean(1)) + 1)).tolist() if k else []
        i0 = int(seg["a"] / 0.5)
        if len(self.energy) < i0:
            self.energy += [float(np.median(self.energy)) if self.energy else 0.0] * (i0 - len(self.energy))
        self.energy[i0:i0 + len(db)] = db

    def _energy_z(self):
        e = np.array(self.energy, dtype=np.float32)
        if len(e) < 10:
            return np.zeros(max(1, len(e))), 0.5
        z = np.zeros_like(e)
        for i in range(0, len(e), 20):
            seg = e[max(0, i - 300):i + 300]
            v = seg[seg > np.percentile(seg, 30)]
            med = np.median(v) if len(v) else np.median(seg)
            mad = (np.median(np.abs(v - med)) * 1.4826 + 1.0) if len(v) else 3.0
            z[i:i + 20] = (e[i:i + 20] - med) / mad
        return z, 0.5

    # ------------------------------------------------ detection
    def _detect(self, edge):
        from .moments import find_candidates
        lo = max(0.0, edge - self.window)
        ws = [w for w in self.words if w[0] >= lo]
        last_end = max([f[1] for f in self.fired], default=-1)
        hour = [f for f in self.fired if time.time() - f[2] < 3600]
        if len(hour) >= self.max_per_hour or (self.fired and time.time() - self.fired[-1][2] < self.cooldown):
            return None
        cands = []
        if len(ws) >= 20:
            cands = find_candidates(ws, None, self.dir, niche=self.niche, top_k=6, energy=self._energy_z())
        best = None
        for c in cands:
            if c["end"] > edge - self.settle or c["start"] < last_end + 1:
                continue
            c["chat_z"] = round(self.chat.spike(c["start"], c["end"] + 6, edge), 2)
            c["live_score"] = round(c["score"] + 2.0 * max(0.0, c["chat_z"]), 2)
            if not best or c["live_score"] > best["live_score"]:
                best = c
        # chat explosion with no transcript candidate: clip the 25s before the spike + 6s after
        if self.chat.kind:
            for t in range(int(edge - self.settle) - 30, int(edge - self.settle)):
                if t < last_end + 25 or t < 25:
                    continue
                z = self.chat.spike(t, t + 6, edge)
                if z >= float(self.cfg.get("live", {}).get("chat_explosion_z", 4.0)):
                    if not best or best["start"] > t or best["end"] < t:
                        best = {"start": t - 25.0, "end": t + 6.0, "score": 0.0, "chat_z": round(z, 2),
                                "live_score": 99.0, "tags": {"chat_explosion": 1}, "sentences": []}
                    break
        if not best:
            return None
        if not best.get("tags", {}).get("chat_explosion"):
            from .score import score_candidate
            q = score_candidate(best)
            best["quality"] = q
            if q["score"] < self.min_quality:
                return None                       # below the publish bar: don't make a clip of it
            import re as _re
            tb = set(_re.findall(r"[a-z']{3,}", " ".join(x[1] for x in best.get("sentences", [])).lower()))
            for prev in self.fired_text:
                if len(tb & prev) / float(max(1, len(tb | prev))) > 0.6:
                    return None                   # same story again (streamers repeat themselves)
        self.history.append(best["live_score"])
        thr = max(self.min_score, float(np.percentile(self.history, 70)) if len(self.history) >= 8 else self.min_score)
        if best["live_score"] < thr and best.get("chat_z", 0) < 4:
            last_t = self.fired[-1][2] if self.fired else self.t_start
            if not (self.steady_s and time.time() - last_t >= self.steady_s and best.get("quality")):
                return None
            best["steady"] = True                 # not a standout, but good, and it's been a while
        return best

    # ------------------------------------------------ clipping
    def all_segments(self):
        """Every finished recording chunk: processed ones plus ones still waiting for transcription."""
        seen = {s["path"] for s in self.segments}
        return sorted(list(self.segments) + [s for s in self._new_segments() if s["path"] not in seen],
                      key=lambda s: s["a"])

    def _cut(self, c, k):
        pad_a, pad_b = (0.0, 0.0) if c.get("exact") else (3.0, 2.0)   # hand-marked in/out: exactly as marked
        a, b = max(0.0, c["start"] - pad_a), c["end"] + pad_b
        use = [s for s in self.all_segments() if s["b"] > a and s["a"] < b]
        if not use:
            return None
        cd = os.path.join(self.dir, "clips", "clip_%02d" % k)
        os.makedirs(cd, exist_ok=True)
        lst = os.path.join(cd, "concat.txt")
        open(lst, "w").write("".join("file %s\n" % concat_path(s["path"]) for s in use))
        src = os.path.join(cd, "source.mp4")
        ffmpeg(["-f", "concat", "-safe", "0", "-i", lst, "-c", "copy", "-bsf:a", "aac_adtstoasc", "-movflags",
                "+faststart", src])
        base = use[0]["a"]
        words = [[round(w[0] - base, 3), round(w[1] - base, 3), w[2], w[3]] for w in self.words
                 if use[0]["a"] <= w[0] < use[-1]["b"]]
        json.dump(words, open(os.path.join(cd, "words.json"), "w"))
        from .transcribe import write_readables
        write_readables(words, cd)
        headline = self._draft_headline(c)
        spec = {"name": "clip_%02d" % k, "source": src, "start": round(max(0.0, c["start"] - base), 2),
                "end": round(min(use[-1]["b"] - base, c["end"] - base + 0.4), 2), "headline": headline,
                "headline_draft": True, "captions": self.cfg.get("live", {}).get("captions", "karaoke"),
                "banner": self._banner(),
                "_origin": "live", "live": {"session": self.dir, "stream_time": [round(c["start"], 1), round(c["end"], 1)],
                                            "score": c.get("live_score"), "chat_z": c.get("chat_z"), "tags": c.get("tags")}}
        json.dump([spec], open(os.path.join(cd, "specs.json"), "w"), indent=1)
        return cd, spec

    def _vod_map(self):
        """Kept segments in order -> [(session_a, session_b, vod_t0)] (reconnect gaps are squeezed out)."""
        out, t = [], 0.0
        for sg in sorted(self.segments, key=lambda x: x["a"]):
            if os.path.exists(sg["path"]):
                out.append((sg["a"], sg["b"], t, sg["path"]))
                t += sg["b"] - sg["a"]
        return out

    def _to_vod(self, ts, m):
        for a, b, t0, _ in m:
            if a - 0.01 <= ts <= b + 0.01:
                return t0 + (ts - a)
        return None

    def _from_vod(self, v, m):
        for a, b, t0, _ in m:
            if t0 - 0.01 <= v <= t0 + (b - a) + 0.01:
                return a + (v - t0)
        return m[-1][1] if m else 0.0

    def _full_sweep(self):
        """After the stream: stitch the whole broadcast into one VOD and run the full auto-clipper over ALL of it
        (same 6/10 bar), skipping moments the live detector already clipped. Catches everything the rolling
        live window missed - long stories, slow builds, moments right before a reconnect."""
        from .autoclip import run as autorun
        from .common import ffmpeg
        from .transcribe import write_readables
        m = self._vod_map()
        if not m:
            return None
        vd = os.path.join(self.dir, "full_stream")
        os.makedirs(vd, exist_ok=True)
        lst = os.path.join(vd, "concat.txt")
        open(lst, "w").write("".join("file %s\n" % concat_path(p) for *_, p in m))
        src = os.path.join(vd, "source.mp4")
        self._status("stitching full stream")
        ffmpeg(["-f", "concat", "-safe", "0", "-i", lst, "-c", "copy", "-bsf:a", "aac_adtstoasc", "-movflags",
                "+faststart", src], timeout=7200)
        words = []
        for w in self.words:
            v = self._to_vod(w[0], m)
            if v is not None:
                words.append([round(v, 3), round(v + (w[1] - w[0]), 3), w[2], w[3] if len(w) > 3 else 1.0])
        json.dump(words, open(os.path.join(vd, "words.json"), "w"))
        write_readables(words, vd)
        if not words:
            self._event("sweep_skipped", {"reason": "no transcript (speech model unavailable?)"})
            return None
        excl = []
        for a, b, _ in self.fired:
            va, vb = self._to_vod(a, m), self._to_vod(b, m)
            if va is not None and vb is not None:
                excl.append((va, vb))
        hours = m[-1][2] / 3600.0
        n = int(self.cfg.get("live", {}).get("sweep_clips") or max(6, min(60, round(hours * 10))))
        self._status("clipping the full stream")
        st = autorun(src, self.dir, "full_stream", clips=n, min_score=self.min_quality,
                     captions=self.cfg.get("live", {}).get("captions", "karaoke"), banner=self._banner(), exclude=excl,
                     exclude_texts=[sorted(t) for t in getattr(self, "fired_text", [])],
                     streamer=(self.lore or {}).get("streamer"))
        for c in st.get("clips", []):
            if c.get("file") and c.get("passes", True):
                # stream time back from VOD time (approximate across reconnect gaps: first matching segment)
                self.clips.append({"clip": "sweep_" + c["name"], "dir": vd, "file": c["file"], "score": c.get("score"),
                                   "headline": c.get("headline"), "status": "pending_qc", "source": "full_sweep",
                                   "stream_time": [round(self._from_vod(c.get("start", 0), m), 1),
                                                   round(self._from_vod(c.get("end", 0), m), 1)]})
        self._event("sweep_done", {"clips": len(st.get("clips", [])), "rejected": len(st.get("rejected", []))})
        return st

    def _build_recap(self, max_clips=12):
        """After the stream: best clips (score order, hook first, 2nd-best last) stitched into a highlight
        reel with source tags, plus a recap.md listing every clip with its stream time and score."""
        from .montage import build_montage
        done = [c for c in self.clips if c.get("file") and os.path.exists(c["file"])]
        if not done:
            return None
        ranked = sorted(done, key=lambda c: -(c.get("score") or 0))[:max_clips]
        order = [ranked[0]] + sorted(ranked[2:], key=lambda c: c["stream_time"][0]) + ranked[1:2] if len(ranked) > 2 else ranked
        specs = [{"file": c["file"], "label": "%d:%02d into the stream" % divmod(int(c["stream_time"][0] // 60), 60)}
                 for c in order]
        out = os.path.join(self.dir, "recap_highlights.mp4")
        r = build_montage(specs, out, os.path.join(self.dir, "_recap_work"), labels=True)
        lines = ["# Stream recap - %s" % self.name, "", "Stream: %s  ·  recorded %d min  ·  %d clips" % (
            self.url, round((self.segments[-1]["b"] if self.segments else 0) / 60), len(done)), "",
                 "Highlight reel: `%s` (%.0fs)" % (out, r["duration"]), "", "| # | stream time | score | headline | file |",
                 "|---|---|---|---|---|"]
        for c in sorted(done, key=lambda c: c["stream_time"][0]):
            lines.append("| %s | %d:%02d | %s | %s | `%s` |" % (c["clip"], *divmod(int(c["stream_time"][0]), 60),
                                                               c.get("score"), c.get("headline", ""), c["file"]))
        open(os.path.join(self.dir, "recap.md"), "w").write("\n".join(lines) + "\n")
        self._event("recap_built", {"file": out, "duration": r["duration"], "clips": len(order)})
        log("live: recap %s (%.0fs, %d clips)" % (out, r["duration"], len(order)))
        return out

    def _banner(self):
        """Credit the streamer automatically: their platform icon + handle, parsed from the stream URL."""
        from .banner import from_url
        L = self.cfg.get("live", {})
        if L.get("banner") is False:
            return None
        b = from_url(self.url, L.get("banner_preset", "socials"))
        return b or self.cfg.get("banner")

    def _draft_headline(self, c):
        """A starting point only - flagged for a human to rewrite in QC."""
        from .autoclip import draft_headline
        return draft_headline(c) or "%s LIVE MOMENT" % self.name.upper()

    def _render(self, cd, spec):
        from .render import make_clip
        try:
            res = make_clip(dict(spec), os.path.join(cd, "renders"), os.path.join(cd, "_work"), self.cfg)
            info = {"clip": spec["name"], "dir": cd, "file": res["out"], "dur": res["dur"], "headline": spec["headline"],
                    "qa_ok": res["qa"]["ok"], "warnings": res["qa"]["warnings"], "status": "pending_qc"}
        except Exception as e:
            info = {"clip": spec["name"], "dir": cd, "error": str(e)[-600:], "status": "render_failed"}
        self._event("clip_rendered" if "file" in info else "clip_failed", info)
        self._notify(info)
        for c in self.clips:
            if c["clip"] == spec["name"]:
                c.update(info)

    def _notify(self, info):
        hook = self.cfg.get("live", {}).get("webhook_url")
        if not hook:
            return
        import urllib.request
        msg = ("🎬 New live clip **%s** (%ss) - pending QC\n`%s`" % (info.get("headline"), info.get("dur"), info.get("file"))
               if "file" in info else "⚠️ live clip failed: %s" % info.get("error", "")[:200])
        try:
            urllib.request.urlopen(urllib.request.Request(hook, data=json.dumps({"content": msg}).encode(),
                                                          headers={"Content-Type": "application/json"}), timeout=15)
        except Exception as e:
            log("webhook failed: %s" % e)

    def _event(self, kind, data):
        with open(os.path.join(self.dir, "events.jsonl"), "a") as f:
            f.write(json.dumps({"t": round(time.time() - self.t0, 1), "event": kind, **data}) + "\n")

    def _status(self, state):
        edge = self.segments[-1]["b"] if self.segments else 0
        st = {"state": state, "url": self.url, "name": self.name, "dir": self.dir, "elapsed": round(time.time() - self.t0),
              "live_edge": round(edge, 1), "segments": len(self.segments), "words": len(self.words),
              "chat_msgs": len(self.chat.msgs), "chat_error": self.chat.err, "recorder_runs": self.rec_runs,
              "clips": self.clips}
        tmp = os.path.join(self.dir, "live_status.json.tmp")
        json.dump(st, open(tmp, "w"), indent=1)
        os.replace(tmp, os.path.join(self.dir, "live_status.json"))
        return st

    def _cleanup(self):
        import shutil as _sh
        if self.keep_full:
            free = _sh.disk_usage(self.dir).free / 1e9
            if free > float(self.cfg.get("live", {}).get("min_free_gb", 5)):
                return
            if not getattr(self, "_disk_warned", False):
                self._disk_warned = True
                log("live: disk low (%.1f GB) - keeping only the last %d min from now on" % (free, self.keep_min))
                self._event("disk_low", {"free_gb": round(free, 1)})
        cutoff = (self.segments[-1]["b"] if self.segments else 0) - self.keep_min * 60
        for s in self.segments:
            if s["b"] < cutoff and os.path.exists(s["path"]):
                safe_remove(s["path"])

    # ------------------------------------------------ main loop
    def run(self):
        log("live: session %s" % self.dir)
        try:    # only possible from the main thread (CLI); the editor stops sessions via self.stop
            signal.signal(signal.SIGINT, lambda *a: self.stop.set())
            signal.signal(signal.SIGTERM, lambda *a: self.stop.set())
        except ValueError:
            pass
        rec = threading.Thread(target=self._recorder, daemon=True)
        rec.start()
        k = 0
        deadline = self.t0 + self.minutes * 60 if self.minutes else None
        while True:
            if deadline and time.time() > deadline:
                self.stop.set()
            new = self._new_segments()
            for seg in new:
                if time.time() - os.path.getmtime(seg["path"]) < 0.5 and not self.stop.is_set():
                    continue
                self.segments.append(seg)
                self.segments.sort(key=lambda s: s["a"])
                try:
                    self._energy(seg)
                    self.words += self._transcribe(seg)
                    self.words.sort(key=lambda w: w[0])
                except Exception as e:
                    log("live: processing failed for %s: %s" % (seg["path"], e))
                edge = seg["b"]
                c = self._detect(edge)
                if c:
                    k += 1
                    self.fired.append((c["start"], c["end"], time.time()))
                    import re as _re
                    self.fired_text.append(set(_re.findall(r"[a-z']{3,}", " ".join(x[1] for x in c.get("sentences", [])).lower())))
                    cut = self._cut(c, k)
                    if cut:
                        cd, spec = cut
                        info = {"clip": spec["name"], "dir": cd, "stream_time": spec["live"]["stream_time"],
                                "score": (c.get("quality") or {}).get("score"), "live_score": c.get("live_score"),
                                "chat_z": c.get("chat_z"), "headline": spec["headline"],
                                "status": "rendering" if self.render else "cut"}
                        self.clips.append(info)
                        self._event("clip_cut", info)
                        log("live: CLIP %s at %.0f-%.0fs score %s chat_z %s" % (spec["name"], c["start"], c["end"],
                                                                               c.get("live_score"), c.get("chat_z")))
                        if self.render:
                            self.pool.submit(self._render, cd, spec)
                self._cleanup()
            self._status("ended" if self.ended else ("stopping" if self.stop.is_set() else "live"))
            if self.stop.is_set() and not rec.is_alive():
                if not self._new_segments():
                    break
            time.sleep(1)
        self.pool.shutdown(wait=True)
        if self.full_sweep:
            try:
                self._full_sweep()
            except Exception as e:
                log("live: full-stream sweep failed: %s" % e)
                self._event("sweep_failed", {"error": str(e)[-400:]})
        if self.recap:
            try:
                self._status("building recap")
                self._build_recap()
            except Exception as e:
                log("live: recap failed: %s" % e)
                self._event("recap_failed", {"error": str(e)[-400:]})
        st = self._status("finished")
        log("live: finished - %d segment(s), %d clip(s) in %s" % (len(self.segments), len(self.clips), self.dir))
        print(json.dumps({"dir": self.dir, "clips": self.clips}, indent=1))
        return st

"""Results: how your posted clips are doing, and what the numbers say works for YOU.

summary(now) -> {"totals": {...}, "posts": [...], "patterns": [...], "note": str}
Views come from the tracked posts (Post it / Track a link). Posts of different ages aren't compared on raw views:
each post is measured by views per day over its first week ("pace"), so a 3-day-old clip and a 3-week-old clip
compare fairly. Patterns only appear with enough posts on both sides, and say how many posts they rest on.
"""
import statistics
import time

from .learn import features
from .post import _spec, posts

MIN_GROUP = 3          # posts needed on each side before a pattern is shown


def _pace(p, now):
    v = p.get("views")
    if v is None:
        return None
    age_d = max(1.0, (now - p.get("added", now)) / 86400.0)
    hist = p.get("history") or []
    if age_d > 7 and hist:                         # use the count closest to day 7 when we have one
        day7 = p.get("added", now) + 7 * 86400
        best = min(hist, key=lambda h: abs(h[0] - day7))
        if abs(best[0] - day7) < 2 * 86400:
            return best[1] / 7.0
    return v / min(age_d, 7.0)


def _growth(p, now, hours=24):
    hist = p.get("history") or []
    if len(hist) < 2:
        return None
    then = now - hours * 3600
    older = [h for h in hist if h[0] <= then + 3 * 3600]
    base = older[-1][1] if older else hist[0][1]
    return max(0, hist[-1][1] - base)


def _len_bucket(d):
    return "under 20 s" if d < 20 else "20-40 s" if d < 40 else "40-60 s" if d < 60 else "over 60 s"


def _hour_bucket(t):
    h = time.localtime(t).tm_hour
    return "morning (6-12)" if 6 <= h < 12 else "afternoon (12-17)" if 12 <= h < 17 else "evening (17-22)" if 17 <= h < 22 else "night (22-6)"


TAG_NAMES = {"reaction": "big reactions", "rage": "rage", "awkward": "awkward moments", "humor": "jokes", "drama": "drama",
             "shock": "shock moments", "story": "stories", "stakes": "money/stakes", "events": "subs & donations",
             "lore": "lore callbacks", "burst": "loud outbursts", "niche": "niche talk", "chat": "chat explosions"}
CAPTION_NAMES = {"karaoke": "word-by-word captions", "box": "boxed captions", "pro": "classic captions", "none": "no captions"}


def _patterns(rows):
    """[(text, ratio, n_a, n_b)] best first."""
    out = []

    def compare(label_of, describe):
        groups = {}
        for r in rows:
            k = label_of(r)
            if k is not None:
                groups.setdefault(k, []).append(r["pace"])
        good = {k: v for k, v in groups.items() if len(v) >= MIN_GROUP}
        if len(good) < 2:
            return
        med = {k: statistics.median(v) for k, v in good.items()}
        best = max(med, key=med.get)
        rest = [x for k, v in good.items() if k != best for x in v]
        rest_med = statistics.median(rest) if rest else 0
        if rest_med <= 0:
            return
        ratio = med[best] / rest_med
        if ratio >= 1.3:
            out.append((describe(best, ratio, len(good[best]), len(rest)), ratio, len(good[best]), len(rest)))

    compare(lambda r: _len_bucket(r["dur"]) if r["dur"] else None,
            lambda b, x, n, m: "Clips %s get %.1f× the views of your other lengths (%d vs %d posts)." % (b, x, n, m))
    compare(lambda r: r["platform"],
            lambda b, x, n, m: "Your clips do %.1f× better on %s than elsewhere (%d vs %d posts)." % (x, b, n, m))
    compare(lambda r: CAPTION_NAMES.get(r["captions"], r["captions"]) if r["captions"] else None,
            lambda b, x, n, m: "Clips with %s get %.1f× the views (%d vs %d posts)." % (b, x, n, m))
    compare(lambda r: ("with a headline" if r["headline"] else "without a headline") if r["headline"] is not None else None,
            lambda b, x, n, m: "Clips %s get %.1f× the views (%d vs %d posts)." % (b, x, n, m))
    compare(lambda r: _hour_bucket(r["added"]),
            lambda b, x, n, m: "Posting in the %s gets %.1f× the views (%d vs %d posts)." % (b, x, n, m))
    for tag in TAG_NAMES:
        compare(lambda r, tag=tag: ("y" if tag in r["tags"] else "n") if r["tags"] is not None else None,
                lambda b, x, n, m, tag=tag: (("Clips with %s get %.1f× the views of the rest (%d vs %d posts)."
                                              % (TAG_NAMES[tag], x, n, m)) if b == "y" else
                                             ("Clips without %s do %.1f× better (%d vs %d posts)."
                                              % (TAG_NAMES[tag], x, n, m))))
    out.sort(key=lambda o: -o[1])
    return out


def summary(now=None, plist=None, spec_of=None):
    now = now or time.time()
    plist = posts() if plist is None else plist
    spec_of = spec_of or _spec
    rows = []
    for p in plist:
        sp = spec_of(p["project"], p["clip"]) or {}
        f = features(sp) if sp else {}
        rows.append({"url": p["url"], "platform": p.get("platform") or "Other", "project": p["project"], "clip": p["clip"],
                     "title": sp.get("headline") or sp.get("title") or p["clip"], "added": p.get("added", now),
                     "views": p.get("views"), "history": (p.get("history") or [])[-20:], "error": p.get("error"),
                     "growth24": _growth(p, now), "pace": _pace(p, now),
                     "dur": f.get("dur"), "captions": f.get("captions") if sp else None,
                     "headline": f.get("headline") if sp else None, "tags": f.get("tags") if sp else None})
    counted = [r for r in rows if r["views"] is not None]
    total = sum(r["views"] for r in counted)
    g24 = [r["growth24"] for r in rows if r["growth24"] is not None]
    best = max(counted, key=lambda r: r["views"]) if counted else None
    paced = [r for r in counted if r["pace"] is not None]
    pats = _patterns(paced)
    if len(paced) < 2 * MIN_GROUP:
        note = ("Patterns appear once %d posts have view counts (you have %d). Track every post: Post it does it "
                "automatically, or paste a link." % (2 * MIN_GROUP, len(paced)))
    elif not pats:
        note = "No clear pattern yet: your clips perform about the same whatever their length, style or timing."
    else:
        note = ("Early patterns from a small number of posts. They get more reliable as you post more."
                if len(paced) < 20 else "Based on %d posts, measured by views per day over each post's first week." % len(paced))
    rows.sort(key=lambda r: -(r["added"] or 0))
    return {"totals": {"posts": len(rows), "with_views": len(counted), "views": total,
                       "last24": sum(g24) if g24 else None,
                       "best": {"title": best["title"], "views": best["views"], "url": best["url"]} if best else None},
            "posts": rows, "patterns": [p[0] for p in pats[:6]], "note": note}

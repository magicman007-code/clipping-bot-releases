"""Subtitles in other languages: translate a rendered clip's .srt with the user's own AI (Settings -> Your AI).

The timing is kept exactly; only the text of each cue changes. The AI gets numbered lines and must return the same
number of lines - if it doesn't, Clipbot retries in smaller batches, and never writes a file with missing lines.
Output: <clip>.<lang>.srt next to the original, ready to upload to YouTube / TikTok as a caption track.
"""
import json
import os
import re

LANGS = {"es": "Spanish", "pt": "Portuguese (Brazil)", "fr": "French", "de": "German", "it": "Italian", "nl": "Dutch",
         "tr": "Turkish", "ru": "Russian", "ar": "Arabic", "hi": "Hindi", "id": "Indonesian", "ja": "Japanese",
         "ko": "Korean", "zh": "Chinese (Simplified)", "vi": "Vietnamese", "pl": "Polish", "tl": "Filipino"}


def parse_srt(text):
    cues = []
    for block in re.split(r"\r?\n\s*\r?\n", text.strip()):
        lines = [l for l in block.splitlines() if l.strip() != ""]
        if len(lines) >= 2 and "-->" in lines[1]:
            cues.append([lines[0].strip(), lines[1].strip(), "\n".join(lines[2:])])
        elif len(lines) >= 1 and "-->" in lines[0]:
            cues.append([str(len(cues) + 1), lines[0].strip(), "\n".join(lines[1:])])
    if not cues:
        raise ValueError("that subtitle file is empty")
    return cues


def _ask(lines, lang, complete):
    numbered = "\n".join("%d\t%s" % (i + 1, l.replace("\n", " / ")) for i, l in enumerate(lines))
    system = ("You translate short-video subtitles. Keep the meaning, slang and energy; keep names, numbers and "
              "hashtags as they are; keep each line about as short as the original. Return ONLY a JSON array of "
              "strings, one per input line, same order, same count.")
    out = complete("Translate these %d subtitle lines into %s:\n%s" % (len(lines), LANGS.get(lang, lang), numbered),
                   system=system, max_tokens=4000)
    m = re.search(r"\[.*\]", out or "", re.S)
    try:
        arr = json.loads(m.group(0)) if m else None
    except ValueError:
        arr = None
    if not isinstance(arr, list) or len(arr) != len(lines):
        return None
    return [str(x).replace(" / ", "\n").strip() or lines[i] for i, x in enumerate(arr)]


def translate_srt(path, lang, complete=None, batch=40):
    if lang not in LANGS:
        raise ValueError("pick a language")
    if not os.path.isfile(path):
        raise ValueError("render the clip first (the .srt is made with the final render)")
    if complete is None:
        from .connect import ai_complete, ai_ready
        if not ai_ready():
            raise ValueError("connect your AI in Settings first - it does the translating")
        complete = ai_complete
    cues = parse_srt(open(path, encoding="utf-8").read())
    texts = [c[2] for c in cues]
    done = []
    i = 0
    while i < len(texts):
        chunk = texts[i:i + batch]
        res = _ask(chunk, lang, complete)
        if res is None and len(chunk) > 5:         # the AI dropped or merged lines: smaller batches
            batch = max(5, batch // 3)
            continue
        if res is None:
            raise RuntimeError("the AI didn't return every line - try again")
        done += res
        i += len(chunk)
    out = re.sub(r"\.srt$", "", path) + ".%s.srt" % lang
    with open(out, "w", encoding="utf-8") as f:
        for n, (c, t) in enumerate(zip(cues, done), 1):
            f.write("%d\n%s\n%s\n\n" % (n, c[1], t))
    return {"file": out, "lines": len(done), "language": LANGS[lang]}

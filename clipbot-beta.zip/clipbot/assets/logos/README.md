Put official platform logos here to use them in the handle banner (logo + /handle):
  kick.png    - from Kick's brand/press assets
  twitch.png  - Twitch "glitch" from https://brand.twitch.com
  youtube.png, tiktok.png, x.png also work.
Transparent PNG, tightly cropped. Clipbot never ships or redraws platform logos; follow each
platform's brand guidelines. Without a file the banner uses a generic live badge + "kick.com/handle".

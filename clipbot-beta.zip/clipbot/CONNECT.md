# Connect your own AI and software

Everything here is optional, set in **Settings**, and stored only on your computer
(`<work folder>/_settings/connections.json`). Keys are only ever sent to the service they belong to.

## Your AI (titles + a second opinion on picks)

| Provider | What to enter |
|---|---|
| Anthropic (Claude) | your API key; model `claude-haiku-5-5` (cheap, fast) or `claude-sonnet-5-5` (sharper) |
| OpenAI | your API key and a model name from OpenAI |
| OpenRouter | one key for hundreds of models; model name as OpenRouter lists it |
| Google Gemini, Groq, xAI, DeepSeek, Mistral | your key for that service and a model name from its list |
| Ollama | free and runs on your computer: install Ollama, pull a model, type its name. No key. |
| Other | any OpenAI-compatible server: its base URL (`https://…/v1`), key and model |

With **Let my AI re-rank auto-clip picks** on, the top ~15 moments' transcripts go to your AI together with what
Clipbot has learned about your taste (clips you liked or rejected and why, the streamer's lore, their studied
clips). It scores each moment 1-10 with a reason; that's blended into the ranking. It can only reorder moments that
already passed the quality bar. Clipbot checks whether the AI's favourites are the ones you keep and gives it more or
less weight over time.

## Your own scorer (any software)

Point Clipbot at any URL that can take a POST: your own model, a script on your computer
(`http://localhost:...`), or an automation flow (n8n, Make, Zapier webhooks). Clipbot sends:

```json
{"app": "clipbot", "version": 1, "candidates": [
  {"id": 0, "start": 812.4, "end": 851.0, "text": "transcript of the moment", "score": 7.2,
   "tags": ["reaction", "chat"], "chat_z": 6.1}
]}
```

and expects back (within 60 s):

```json
[{"id": 0, "score": 8.5, "why": "huge payoff"}]
```

(or `{"scores": [...]}`). Scores are 0-10. Unknown ids and out-of-range scores are ignored; if the scorer is down,
auto-clip carries on without it. A token, if set, is sent as `Authorization: Bearer <token>`. The starting weight
(default 0.4) is how much your scorer counts; after 8 rated clips Clipbot learns the weight from what you keep.

Minimal example (Python, run with `python3 scorer.py`, then use `http://localhost:8000`):

```python
import json, http.server
class H(http.server.BaseHTTPRequestHandler):
    def do_POST(self):
        req = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        out = [{"id": c["id"], "score": 9 if "chat" in c["tags"] else 5, "why": "chat reacted" if "chat" in c["tags"] else ""}
               for c in req["candidates"]]
        self.send_response(200); self.send_header("Content-Type", "application/json"); self.end_headers()
        self.wfile.write(json.dumps(out).encode())
http.server.HTTPServer(("127.0.0.1", 8000), H).serve_forever()
```

## Webhook (when clips are done)

Clipbot POSTs JSON when a clip renders or an auto-clip run finishes: send it to Discord, Zapier, Make, n8n or your
own server to post, upload or notify.

## Chat replay

YouTube and Twitch VOD chat is fetched automatically (Twitch can refuse; then export it with TwitchDownloader).
For Kick, drop a chat file on the New screen. Accepted: TwitchDownloader `.json`, YouTube `live_chat.json`,
`[{"t": seconds, "text": "..."}]`, or text lines like `0:01:23, message`.

## Subscriber-only VODs

Pick your browser under Settings so downloads use your logins (close that browser first if downloads fail).

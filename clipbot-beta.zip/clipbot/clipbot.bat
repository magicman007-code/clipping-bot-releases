@echo off
rem Run any clipbot command:  clipbot autoclip "C:\path\video.mp4"
if not exist "%~dp0.venv\Scripts\python.exe" ( echo Run install.ps1 first. & exit /b 1 )
"%~dp0.venv\Scripts\python.exe" "%~dp0clipbot.py" %*

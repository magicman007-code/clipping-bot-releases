# ▶ Pick up next week

Everything below is parked by Trevor's call (late Tue 11-18). The app is shipped,
tested and in a solid state — these are the deliberate items that each need a
decision or your key, not loose ends.

## Parked for next week (each needs one input)
1. **Max the in-app AI quality** — add an OpenAI/Anthropic key in Settings → Your AI.
   The free AI is already on (rerank + titles); the key just upgrades quality.
   Nothing to build — it's a one-field change on Trevor's side.
2. **Tighter face framing (before/after)** — face detection is on a strong model
   (YuNet @ 0.6). Changing its settings re-frames existing clips, so do it as a
   tested before/after on a sample clip and let Trevor pick. Don't blind-change.
3. **Style skill** — only add one if Trevor has a specific look to lock in
   (learn from 2-3 example videos → one-click style). Hold otherwise.
4. **MCP** — expose Clipbot's actions (discover/clip/render/list) as an MCP
   server so AI assistants can drive it. A few focused hours; needs testing
   against a real MCP client. Build it as its own session, not a rushed add.

## Shipped Tue 11-18 (3.3.1 → 3.4.14, 18 releases) — all tested, both repos synced
- 3.3.1  live-session bug fixes (stuck "live clipping", false update-block, batch hangs)
- 3.4.0-3.4.3  de-clunk: plain messages, Home dedupe, tidier Settings, one-click
  Twitch connect, clearer Export
- 3.4.4-3.4.6  "Find all my clips" button → full gallery → in the sidebar
- 3.4.7  Home hero ("Turn any stream into clips")
- 3.4.8  tidier Clips panel
- 3.4.9  Category Watch: one-time "I have the rights" acknowledgement
- 3.4.10 auto-clip shows a clean building state, not the previous clips
- 3.4.11 "Watch" previews the clicked moment (preview-range override)
- 3.4.12 fixed hidden Schedule messages (duplicate id) + dup-id build guard
- 3.4.13 Framing is discoverable (explainer + clear label)
- 3.4.14 "Start another project" heading when a project is open

## Permanent test guards now in place (so these classes can't return)
- tests/test_no_dup_ids.py       — no duplicate element ids
- tests/test_endpoint_robustness.py — no endpoint 500s on bad input
- tests/test_ui_smoke.py         — every pane opens, no JS errors
- tests/test_tour.py             — all 29 tour steps / features reachable
- tests/test_live_lifecycle.py   — live sessions end cleanly
- tests/test_clip_ack.py         — clip-rights ack persists

# Clipbot — bug sweep & punch-list

Started 2026-11-18 (GTA 6 launch night). Running list of bugs, friction, and
work to do. Sorted by priority. Check items off as shipped.

## ✅ Fixed this pass (staged in 3.3.1, not yet published)

- **Zombie "live clipping" after a stream ends.** Root cause: the capture loop
  set `self.ended=True` when a stream went offline, but never set `self.stop`,
  so `run()` never broke out, never reached `"finished"`, and sat in state
  `"ended"` forever. `busy()` then reported "live clipping" indefinitely, which
  also **blocked updates**. Fix: `run()` now calls `self.stop.set()` when
  `self.ended` is true, so an offline stream winds down to `"finished"`.
  (cb/live.py)
- **Ended/stopped sessions counted as "busy" / blocked updates.** `busy()` now
  skips sessions that are `ended`, stopped, or in a terminal state
  (`finished`/`ended`/`error`). (cb/editor_server.py)
- **Stopped sessions lingered in the Live list.** `/api/live/sessions` now
  prunes dead (finished/errored/stopped, non-always-on) sessions and reports
  `running:false` + `ended:true` honestly so the UI stops showing them as live.
  (cb/editor_server.py)

## 🔜 Next session — verify before shipping 3.3.1

- Run `python3 tests/run_all.py` + the live/update tests (needs a Whisper model;
  set `MANGO_MODEL_OVERRIDE`/`MODEL_OVERRIDE` to a local model folder in sandbox).
- Add a regression test: start a session, force `ended=True`, assert it reaches
  `finished`, drops out of `busy()`, and disappears from `/api/live/sessions`.
- Then `clipbot publish 3.3.1 --repo magicman007-code/clipping-bot-releases`.

## 🐞 Bug-sweep targets (same class of "stuck state") — AUDITED 11-18

- [x] Category Watch (`/api/category/start`): spawned sessions reuse the same
      `run()`/loop and aren't always-on, so they inherit ended→finished→prune.
      Confirmed clean.
- [x] `edit`/`batch` jobs terminal status: generic runners already set
      done/error. **Batch `go()` outer path was unguarded → FIXED** (always ends
      done or error now).
- [x] Single-live + always-on `loop()` catch `run()` exceptions; always-on
      respawn breaks on `not always or LIVE_STOPPED`. Can always terminate.
- [x] `JOBS` prune keeps last N. Confirmed OK.
- [ ] Update flow: re-run tests/test_update_button.py on a machine with a Whisper
      model to confirm busy() no longer false-blocks (couldn't run in sandbox).
- [ ] Twitch/YouTube token refresh: handle expiry mid-session without a silent
      stall (surface a clear "reconnect" state). Deferred to Phase 3/5 — UI work.
- [ ] Recorder reconnect limits / `_empty_runs` / deadline: spot-checked, look
      bounded; add an explicit test next pass.

## ✨ Features / polish requested

- [ ] **Scheduled clipping when a streamer returns live.** Always-on already
      respawns on return; expose it as a first-class "Watch & auto-resume"
      toggle with a visible "waiting for <channel> to go live" state, and let
      users queue channels to watch.
- [ ] **Category Watch one-click** needs the permission model sorted: clipping
      channels you don't own is gated ("confirm you own this channel…"). Decide
      the product/legal stance and make the UI state it plainly instead of a
      raw error.
- [ ] AI dubbing (only real gap vs competitors).

## 🧭 Interface friction (experienced first-hand driving the app)

These are the "clunky" issues to fix in the de-clunk / redesign roll-in:

- [ ] **Settings is hidden** behind the vague rail label "Connections, learning
      and updates." Rename to **Settings** (or add a plain gear) — new users
      can't find it.
- [ ] **Rail buttons don't give feedback** on click; the active pane isn't
      obviously highlighted. Add clear active/hover states.
- [ ] **Twitch Client ID field has no visible label** until you expand the
      section, and setup is a multi-step hunt (paste ID → Save → Connect →
      authorize). Build a single **"Connect Twitch" wizard** that walks it.
- [ ] **Too many options on one screen** (Clip settings, Brand kit, Export all
      at once) — group and progressively disclose; keep every feature but hide
      advanced ones behind "Show all options" by default.
- [ ] **Plain language pass** on every label and every error (e.g. the Twitch
      permission error should read like a sentence, not an API string).
- [ ] **Find finished clips easily** — a single "All clips / renders" view or
      folder, surfaced prominently.
- [ ] First-run demo/tour should cover: connecting a platform, Category Watch,
      where clips land, and Pro mode.

## 📋 The big list — carried over from the whole build (done + open)

**Already shipped / done this build:**
- [x] Reason-coded quality gate + auto-repair + status chips (cb/reasons.py,
      cb/repair.py) — inspired by clip-engine-core's rigor.
- [x] Second verification pass after live clipping (independent re-verify).
- [x] One-click "Find more moments" — rescans with no prompt required.
- [x] Auto-clip runs start→finish; stays on progress view, only opens Clips
      when fully done (unless live/manual).
- [x] Cropping/frame-geometry reviewed + invariant tests (no black bars / off-edge).
- [x] Filler-word + dead-air removal — confirmed already on by default
      (tighten_pieces: >0.42s gaps + um/uh).
- [x] LLM connections (Claude/OpenAI/Gemini/Ollama) + subtitle translation +
      split-screen — confirmed present (matches competitors).
- [x] Trailer (horizontal + vertical) built.
- [x] Landing page + privacy/terms pages built (for app-store reviews).
- [x] Category Watch feature built (3.3.0) — "clip all top streams at once."

**De-clunk pass SHIPPED 11-18 (3.4.0–3.4.3):**
- [x] Plain-language error messages (live-session / segment / Twitch permission).
- [x] Removed Home duplicates: "YouTube video" chip, "AI live clipper" chip,
      second "Open editor" — Home shortcut row is now all distinct tools.
- [x] Settings opens tidier (empty "What Clipbot has learned" collapsed by default).
- [x] One-click Twitch connect (Connect saves the Client ID; labelled field) —
      fixes the exact friction hit during setup.
- [x] Export tab: renamed confusing "Post" → "Title & caption"; opens 2 sections
      not 3.
- [x] Automated UI smoke test (tests/test_ui_smoke.py): opens every pane, fails
      on any JS error, asserts each cleanup stuck. Runs on every change.

**Still open (priority order):**
- [ ] **UI redesign roll-in** — the refined editor prototype (kept your
      blue-slate + coral theme, cinematic preview/filmstrip, plain terminology).
      The bigger look change; its own focused effort with visual review.
- [ ] **Beginner-first layout audit** — reorganize so someone who's never
      clipped can find everything; group options, progressive disclosure.
- [ ] **Better first-run demo/tour** — cover every feature + Pro mode +
      Category Watch + where clips land.
- [ ] **Easy "all finished clips" view/folder** — surface every render in one
      place (reveal-folder button exists; needs a proper gallery view).
- [ ] **AI dubbing** — the one real feature gap vs the 5 competitors.
- [ ] **Permission model for Category Watch** — clipping channels you don't own
      is gated; decide the stance + make the UI say it plainly.
- [ ] **Optional MCP support** — competitors expose MCP/LLM hooks. Clipbot
      already has LLM connections; MCP is a nice-to-have, not required. Decide.
- [ ] Scheduled clipping / auto-resume when a watched channel returns live
      (always-on respawn already does this — needs a clean first-class UI).

## Notes / state captured tonight

- Twitch connected as `memegoddzs` (Client ID saved server-side; survives
  restart).
- GTA 6 discovery works: 40 live streams found (alanzoka 227K, honeymad 165K,
  magamedtv05 117K, djmariio 107K, xqc 99K, montanablack88 93K…).
- Live-clipping other creators' channels is blocked by the ownership/permission
  gate — a deliberate guard, not a bug. Needs a product decision + clearer UI.

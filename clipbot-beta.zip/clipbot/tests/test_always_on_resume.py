"""Always-on resume UX (3.4.17): when an always-on live session's stream ends, the engine keeps
the same id and respawns to watch for the next stream. The Live panel must NOT declare it finished
and reset — it must keep polling and show a clear "waiting for <channel> to go live again" state.

Server half is covered by test_live_lifecycle.test_prune_keeps_always_on. These are static guards on
the two wiring points that are easy to regress: the sessions payload and pollLive()."""
import os
import re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _read(p):
    with open(os.path.join(ROOT, p), encoding="utf-8") as f:
        return f.read()


def test_sessions_payload_exposes_always_flag():
    src = _read("cb/editor_server.py")
    # the /api/live/sessions payload must tell the UI which sessions keep watching for the next stream
    assert '"always": k in LIVE_ALWAYS' in src, "sessions payload must expose the always-on flag"


def test_pollLive_does_not_reset_always_on_sessions():
    html = _read("editor/index.html")
    m = re.search(r'if\(s&&\(s\.state==="finished"\|\|s\.ended\)([^)]*)\)\{[^}]*LIVEID=null', html)
    assert m, "pollLive finished-reset branch not found"
    assert "!s.always" in m.group(1), "pollLive must NOT reset/stop an always-on session when a stream ends"


def test_pollLive_shows_waiting_for_next_stream():
    html = _read("editor/index.html")
    assert "to go live again" in html, "always-on between-streams label missing"
    assert "s.always&&(s.state===\"finished\"||s.ended)" in html, "waiting state must key off always + terminal"


if __name__ == "__main__":
    import sys, traceback
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    fails = 0
    for fn in fns:
        try:
            fn(); print("ok  ", fn.__name__)
        except Exception:
            fails += 1; print("FAIL", fn.__name__); traceback.print_exc()
    print("%d/%d passed" % (len(fns) - fails, len(fns)))
    sys.exit(1 if fails else 0)

"""Quality-gate reason codes: the free-text defects qa.py / verify.py emit must map to stable
machine-readable codes, and fold into one pass/repair/block verdict."""
from cb import reasons as R


def test_every_pattern_code_is_defined():
    for _rx, code in R._RX:
        assert code in R.CODES, "pattern maps to undefined code %r" % code
    for code, (sev, _label, _repair) in R.CODES.items():
        assert sev in ("block", "repair", "warn"), (code, sev)


def test_classify_known_defects():
    cases = {
        "resolution 1080x1080 (want 1080x1920)": "RES_MISMATCH",
        "output is 720x1280, expected 1080x1920": "RES_MISMATCH",
        "frame rate 24.00 (want 30)": "FPS_OFF",
        "codecs video=['hevc'] audio=['aac'] (want h264/aac)": "CODEC_WRONG",
        "not faststart (moov after mdat) - slow to start on phones": "NOT_FASTSTART",
        "no audio stream": "NO_AUDIO",
        "loudness -19.3 LUFS (want -14 +/-1.5)": "LOUDNESS_OFF",
        "true peak 0.40 dBTP (want <= -1.0; risk of clipping after platform transcode)": "TRUE_PEAK_HOT",
        "black frames: 0.0-0.6s": "BLACK_FRAMES",
        "2/8 sampled frames are near-black": "BLACK_FRAMES",
        "frozen picture for 4.2s": "FROZEN",
        "dead air: 2 silence(s), longest 1.8s": "DEAD_AIR",
        "letterbox/pillarbox: active picture 1080x1400 of 1080x1920": "LETTERBOX",
        "captions: 22% wrong words on screen (bar is 8%) - check them in Captions": "CAPTION_WER_HIGH",
        "captions overlap a face in 3/8 sampled frames": "CAPTION_ON_FACE",
        "duration 45.20s differs from cut 42.00s": "DUR_DRIFT",
        "70s is long for a short; consider jump-cutting to <=45s": "TOO_LONG",
        "no caption words": "NO_CAPTIONS",
        "headline card not visible (white fraction 0.03)": "HEADLINE_MISSING",
        "no face visible in the first frame - open on the subject": "NO_FACE_OPEN",
        "speech starts at 1.6s - cold-open closer to the first word": "COLD_OPEN_LATE",
        "slow open: only 2 words in the first 3s": "SLOW_OPEN",
    }
    for text, code in cases.items():
        assert R.classify(text) == code, "%r -> %s (got %s)" % (text, code, R.classify(text))


def test_unknown_defect_is_other_not_crash():
    assert R.classify("something totally new") == "OTHER"
    assert R.classify("") == "OTHER"
    assert R.classify(None) == "OTHER"


def test_annotate_dedupes_and_orders_block_first():
    items = ["dead air: longest 2.0s", "black frames: 0.0-0.5s", "loudness -18 LUFS",
             "1/8 sampled frames are near-black"]       # two map to BLACK_FRAMES
    ann = R.annotate(items)
    codes = [r["code"] for r in ann]
    assert codes.count("BLACK_FRAMES") == 1             # de-duplicated
    assert codes[0] == "BLACK_FRAMES"                   # block sorts first
    assert "LOUDNESS_OFF" in codes and "DEAD_AIR" in codes


def test_verdict_levels():
    assert R.verdict([]) == "pass"
    assert R.verdict(["warn", "warn"]) == "pass"
    assert R.verdict(["warn", "repair"]) == "repair"
    assert R.verdict(["repair", "block"]) == "block"


def test_gate_clean_passes():
    g = R.gate([])
    assert g["verdict"] == "pass" and g["ok"] and g["reasons"] == []


def test_gate_repair_only():
    g = R.gate(["loudness -19 LUFS (want -14)", "true peak 0.2 dBTP", "not faststart"])
    assert g["verdict"] == "repair" and not g["ok"]
    assert set(g["repairs"]) == {"LOUDNESS_OFF", "TRUE_PEAK_HOT", "NOT_FASTSTART"}
    assert g["blocking"] == []
    # every repair carries a mechanical fix hint
    assert {h["code"] for h in g["repair_hints"]} == {"LOUDNESS_OFF", "TRUE_PEAK_HOT", "NOT_FASTSTART"}
    assert all(h["fix"] for h in g["repair_hints"])


def test_gate_block_wins_over_repair():
    g = R.gate(["loudness -19 LUFS", "captions: 20% wrong words on screen"])
    assert g["verdict"] == "block"
    assert "CAPTION_WER_HIGH" in g["blocking"]
    assert "LOUDNESS_OFF" in g["repairs"]               # still reported, just not the verdict


def test_gate_warnings_do_not_block():
    g = R.gate(["70s is long for a short", "slow open: only 1 words in the first 3s"])
    assert g["verdict"] == "pass" and g["ok"]           # advisory only
    assert set(g["warnings"]) == {"TOO_LONG", "SLOW_OPEN"}


def test_gate_accepts_separate_warnings_arg():
    g = R.gate(["black frames: 0-0.5s"], warnings=["no caption words"])
    assert g["verdict"] == "block"
    assert "BLACK_FRAMES" in g["blocking"] and "NO_CAPTIONS" in g["warnings"]


if __name__ == "__main__":
    import sys
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    for fn in fns:
        fn()
        print("ok", fn.__name__)
    print("PASS (%d tests)" % len(fns))

"""Combine clips (3.5.4): a manual "join these clips (and other videos) into one" mode in the Edits
tab, reusing the montage engine. Guards the wiring and the actual stitch."""
import os, sys, subprocess, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)


def test_endpoint_and_ui_wired():
    srv = open(os.path.join(ROOT, "cb/editor_server.py"), encoding="utf-8").read()
    assert '"/api/edits/combine"' in srv, "combine endpoint route missing"
    assert "build_montage(specs" in srv, "combine must call the montage engine"
    html = open(os.path.join(ROOT, "editor/index.html"), encoding="utf-8").read()
    assert 'value="combine"' in html, "Combine radio missing from the Edits tab"
    assert "/api/edits/combine" in html, "edGo not wired to the combine endpoint"
    assert "buildCombineList" in html, "combine pick-list builder missing"


def _mkclip(path, secs):
    subprocess.run(["ffmpeg", "-y", "-f", "lavfi", "-i", "testsrc=size=640x360:rate=30:duration=%d" % secs,
                    "-f", "lavfi", "-i", "sine=frequency=440:duration=%d" % secs,
                    "-shortest", "-pix_fmt", "yuv420p", path], capture_output=True)


def test_build_montage_joins_two_clips():
    from cb import montage
    from cb.common import probe
    d = tempfile.mkdtemp()
    rd = os.path.join(d, "renders"); os.makedirs(rd)
    a, b = os.path.join(rd, "01_clip.mp4"), os.path.join(rd, "02_clip.mp4")
    _mkclip(a, 2); _mkclip(b, 3)
    out = os.path.join(d, "edits", "combine_test.mp4")
    montage.build_montage([{"file": a, "label": "First"}, {"file": b, "label": "Second"}],
                          out, os.path.join(d, "edits", "_t"), labels=True)
    assert os.path.exists(out), "combined file not produced"
    dur = probe(out)["duration"]
    assert 4.3 <= dur <= 5.8, "combined duration %.1f not ~5s (2+3)" % dur


if __name__ == "__main__":
    import traceback
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    fails = 0
    for fn in fns:
        try:
            fn(); print("ok  ", fn.__name__)
        except Exception:
            fails += 1; print("FAIL", fn.__name__); traceback.print_exc()
    print("%d/%d passed" % (len(fns) - fails, len(fns)))
    sys.exit(1 if fails else 0)

"""Category Watch: plan() picks the top N distinct live streams for a game, de-dupes, caps, and passes
through per-platform errors. Uses a fake discovery so it needs no network."""
from cb import category


def fake_find(streams, errors=None):
    def _f(game, platforms=("twitch", "kick"), limit=40):
        return {"game": game, "streams": list(streams), "errors": errors or {}}
    return _f


S = [
    {"platform": "twitch", "name": "APEX_Andy", "url": "https://twitch.tv/apex_andy", "viewers": 48000},
    {"platform": "kick", "name": "QueenZara", "url": "https://kick.com/queenzara", "viewers": 31000},
    {"platform": "twitch", "name": "SoloSavage", "url": "https://twitch.tv/solosavage", "viewers": 22000},
    {"platform": "twitch", "name": "dup", "url": "https://twitch.tv/apex_andy", "viewers": 9000},   # dup url
    {"platform": "youtube", "name": "NoUrl", "url": "", "viewers": 15000},                          # no url
]


def test_plan_caps_and_dedupes():
    pl = category.plan("Grand Theft Auto VI", find=fake_find(S), limit=3)
    urls = [s["url"] for s in pl["streams"]]
    assert urls == ["https://twitch.tv/apex_andy", "https://kick.com/queenzara", "https://twitch.tv/solosavage"]
    assert len(pl["streams"]) == 3                 # capped
    assert len(urls) == len(set(urls))             # de-duplicated
    assert all(s["url"] for s in pl["streams"])    # no url-less streams


def test_plan_limit_bounds():
    assert len(category.plan("x", find=fake_find(S), limit=99)["streams"]) <= 20
    assert len(category.plan("x", find=fake_find(S), limit=0)["streams"]) >= 1


def test_plan_passes_errors_through():
    pl = category.plan("x", find=fake_find([], {"twitch": "no key"}), limit=5)
    assert pl["streams"] == [] and pl["errors"] == {"twitch": "no key"}


def test_plan_default_game():
    pl = category.plan(find=fake_find(S), limit=2)
    assert pl["game"] == category.discover.DEFAULT_GAME
    assert len(pl["streams"]) == 2


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    for fn in fns:
        fn(); print("ok", fn.__name__)
    print("PASS (%d tests)" % len(fns))

"""Stream-finder: Twitch live streams by game (fake Helix), plus soft-fail behaviour."""
import http.server
import json
import threading
import urllib.parse as up


class H(http.server.BaseHTTPRequestHandler):
    def _send(self, obj):
        b = json.dumps(obj).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def do_GET(self):
        u = up.urlparse(self.path)
        q = up.parse_qs(u.query)
        assert self.headers.get("Client-Id") == "CID" and self.headers.get("Authorization") == "Bearer TOK"
        if u.path.endswith("/games"):
            assert q["name"][0] == "Grand Theft Auto VI"
            return self._send({"data": [{"id": "999", "name": "Grand Theft Auto VI"}]})
        if u.path.endswith("/streams"):
            assert q["game_id"][0] == "999"
            return self._send({"data": [
                {"user_login": "big", "user_name": "Big", "title": "GTA6 DAY ONE", "viewer_count": 50000,
                 "thumbnail_url": "http://x/{width}x{height}.jpg", "game_name": "Grand Theft Auto VI"},
                {"user_login": "mid", "user_name": "Mid", "title": "chilling", "viewer_count": 1200,
                 "thumbnail_url": "http://x/{width}x{height}.jpg", "game_name": "Grand Theft Auto VI"}],
                "pagination": {}})
        self._send({"data": []})

    def log_message(self, *a):
        pass


def test_twitch_streams_by_game(monkeypatch):
    from cb import discover, social
    monkeypatch.setattr(social, "_tw_access", lambda id_url=None: {"client_id": "CID", "access_token": "TOK"})
    httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), H)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    base = "http://127.0.0.1:%d" % httpd.server_address[1]
    s = discover.twitch_streams("Grand Theft Auto VI", limit=40, api=base)
    assert [x["channel"] for x in s] == ["big", "mid"]        # sorted by viewers already (Helix order)
    assert s[0]["viewers"] == 50000 and s[0]["url"] == "https://twitch.tv/big"
    assert s[0]["thumbnail"] == "http://x/320x180.jpg" and s[0]["platform"] == "twitch"
    httpd.shutdown()


def test_find_streams_soft_fails_per_platform(monkeypatch):
    from cb import discover
    monkeypatch.setattr(discover, "twitch_streams", lambda *a, **k: (_ for _ in ()).throw(RuntimeError("not connected")))
    monkeypatch.setattr(discover, "kick_streams", lambda *a, **k: [{"platform": "kick", "channel": "k1", "viewers": 10,
                                                                   "url": "https://kick.com/k1", "title": "", "name": "k1",
                                                                   "thumbnail": "", "game": "x"}])
    monkeypatch.setattr(discover, "youtube_streams", lambda *a, **k: (_ for _ in ()).throw(RuntimeError("no key")))
    r = discover.find_streams("GTA 6", ("twitch", "kick", "youtube"), 40)
    assert [s["channel"] for s in r["streams"]] == ["k1"]      # kick still returns even though twitch/youtube failed
    assert "twitch" in r["errors"] and "youtube" in r["errors"]


def test_kick_slug():
    from cb import discover
    assert discover.kick_slug("GTA 6") == "grand-theft-auto-vi"
    assert discover.kick_slug("Just Chatting") == "just-chatting"

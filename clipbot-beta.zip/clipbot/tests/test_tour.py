"""Tour audit: the guided tour navigates to nearly every feature, so it doubles as a navigation test.
Runs each step's go() (which switches tabs / opens the right section) in Pro mode and checks the
step's target element actually resolves — catching any feature the tour (and a new user) can't find,
plus any JS error thrown while navigating. Needs Playwright + chromium; skips if unavailable."""
import os
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _free_port():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p


def run():
    try:
        from playwright.sync_api import sync_playwright
    except Exception as e:
        print("SKIP: playwright not available (%s)" % e); return 0

    workdir = tempfile.mkdtemp(prefix="cbtour_")
    port = _free_port()
    srv = subprocess.Popen([sys.executable, "clipbot.py", "editor", "--root", workdir, "--port", str(port)],
                           cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    base = "http://127.0.0.1:%d" % port
    try:
        for _ in range(40):
            try:
                urllib.request.urlopen(base, timeout=1).read(1); break
            except Exception:
                time.sleep(0.25)

        errors = []
        with sync_playwright() as p:
            b = p.chromium.launch()
            pg = b.new_page(viewport={"width": 1400, "height": 1000})
            pg.on("console", lambda m: errors.append("console: " + m.text) if m.type == "error" else None)
            pg.on("pageerror", lambda e: errors.append("pageerror: " + str(e)))
            pg.goto(base, wait_until="networkidle"); pg.wait_for_timeout(600)
            try:
                pg.get_by_text("I've read this").click(timeout=2000)
                pg.get_by_text("Accept and continue").click(timeout=2000); pg.wait_for_timeout(400)
            except Exception:
                pass

            if pg.evaluate("typeof TOUR_ALL") != "object":
                print("SKIP: TOUR_ALL not in page scope (can't audit from here)"); b.close(); return 0

            # Pro mode so every (pro) step and section exists, then run each step's navigation.
            pg.evaluate("setMode('pro')"); pg.wait_for_timeout(200)
            report = pg.evaluate("""() => {
                const out = [];
                for (let i = 0; i < TOUR_ALL.length; i++) {
                    const st = TOUR_ALL[i]; let err = null;
                    try { st.go && st.go(); } catch (e) { err = 'go() threw: ' + e.message; }
                    out.push({ i: i, t: st.t, sel: st.sel, found: !!document.querySelector(st.sel), err: err });
                }
                return out;
            }""")

            missing = [r for r in report if not r["found"]]
            threw = [r for r in report if r["err"]]
            b.close()

        bad = False
        for r in threw:
            bad = True; print("STEP %2d '%s' -> %s" % (r["i"] + 1, r["t"], r["err"]))
        for r in missing:
            bad = True; print("STEP %2d '%s' -> target not found: %s" % (r["i"] + 1, r["t"], r["sel"]))
        if errors:
            bad = True
            print("JS errors during tour:")
            for e in errors[:15]:
                print("  -", e)
        if bad:
            return 1
        print("ok   tour audit: all %d steps navigate and resolve, no JS errors" % len(report))
        return 0
    finally:
        srv.terminate()
        try:
            srv.wait(timeout=5)
        except Exception:
            srv.kill()


if __name__ == "__main__":
    sys.exit(run())

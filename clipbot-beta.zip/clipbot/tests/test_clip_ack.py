"""Clip-rights acknowledgement persists. Regression test: the ack is stored as a dict section
('clips': {'rights_ack': True}) so it survives connect.get()'s 'drop non-dict sections' cleanup and
connect.save()'s section whitelist — the exact two things that silently dropped a bare boolean."""
import os
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)


def run():
    tmp = tempfile.mkdtemp(prefix="cback_")
    os.environ["CLIPBOT_WORK_ROOT"] = tmp
    from cb import connect

    assert not connect.get().get("clips", {}).get("rights_ack"), "should start unacknowledged"
    connect.save({"clips": {"rights_ack": True}})
    assert connect.get().get("clips", {}).get("rights_ack") is True, "ack must persist across save/get"
    r = connect.redacted()
    assert r.get("clips", {}).get("rights_ack") is True, "ack must be exposed via the connections API (not a secret)"
    # a later unrelated save must not wipe it
    connect.save({"twitch": {"client_id": "abc"}})
    assert connect.get().get("clips", {}).get("rights_ack") is True, "ack must survive other saves"
    print("ok   clip-rights acknowledgement persists and is readable")
    return 0


if __name__ == "__main__":
    sys.exit(run())

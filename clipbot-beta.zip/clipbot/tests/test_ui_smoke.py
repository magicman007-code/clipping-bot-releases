"""UI smoke test: load the editor, accept the terms gate, then click through every rail pane and
editor tab, failing if any JavaScript console error or uncaught page error fires. Catches the class
of bug where a removed element leaves a dangling handler, or a pane throws on open. Needs Playwright
+ chromium; skips cleanly if they're unavailable. Run: PYTHONPATH=. python3 tests/test_ui_smoke.py"""
import os
import socket
import subprocess
import sys
import tempfile
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


def run():
    try:
        from playwright.sync_api import sync_playwright
    except Exception as e:
        print("SKIP: playwright not available (%s)" % e)
        return 0

    workdir = tempfile.mkdtemp(prefix="cbui_")
    port = _free_port()
    srv = subprocess.Popen([sys.executable, "clipbot.py", "editor", "--root", workdir, "--port", str(port)],
                           cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    base = "http://127.0.0.1:%d" % port
    try:
        # wait for the server
        import urllib.request
        for _ in range(40):
            try:
                urllib.request.urlopen(base, timeout=1).read(1)
                break
            except Exception:
                time.sleep(0.25)

        errors = []
        with sync_playwright() as p:
            b = p.chromium.launch()
            pg = b.new_page(viewport={"width": 1280, "height": 900})
            pg.on("console", lambda m: errors.append("console.%s: %s" % (m.type, m.text))
                  if m.type == "error" else None)
            pg.on("pageerror", lambda e: errors.append("pageerror: %s" % e))
            pg.goto(base, wait_until="networkidle")
            pg.wait_for_timeout(600)

            # accept the first-run terms gate if present
            try:
                pg.get_by_text("I've read this").click(timeout=2000)
                pg.get_by_text("Accept and continue").click(timeout=2000)
                pg.wait_for_timeout(400)
            except Exception:
                pass

            # the duplicate YouTube chip must be gone, the top YouTube tab must remain
            assert pg.query_selector("#hYt") is None, "duplicate #hYt chip should be removed"
            assert pg.query_selector('[data-m="youtube"]') is not None, "YouTube top tab must remain"

            def safe_click(sel):
                el = pg.query_selector(sel)
                if el and el.is_visible():
                    try:
                        el.click(timeout=2500)
                        pg.wait_for_timeout(250)
                        return True
                    except Exception as ex:
                        errors.append("click %s: %s" % (sel, str(ex)[:80]))
                return False

            # click every rail pane that is visible
            for p_ in ["home", "projects", "procs", "live", "edits", "lore", "settings", "results"]:
                safe_click('[data-p="%s"]' % p_) or safe_click('[data-page="%s"]' % p_)

            # back home, then exercise the visible mode tabs
            safe_click('[data-page="home"]')
            for mid in ("manual", "youtube", "live"):
                safe_click('[data-m="%s"]' % mid)

            b.close()

        if errors:
            print("FAIL: %d UI error(s):" % len(errors))
            for e in errors[:20]:
                print("  -", e)
            return 1
        print("ok   UI smoke: all panes opened, no JS errors, duplicate chip removed")
        return 0
    finally:
        srv.terminate()
        try:
            srv.wait(timeout=5)
        except Exception:
            srv.kill()


if __name__ == "__main__":
    sys.exit(run())

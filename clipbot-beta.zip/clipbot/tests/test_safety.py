"""Brand-safety review flags (3.5.3): advisory flags on a clip's transcript, borrowed from the way
good clip pickers warn before posting. Flags must be advisory only — never empty-flag clean text,
never crash, and catch the obvious profanity/sexual cases a brand campaign cares about."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from cb import safety


def test_clean_text_has_no_flags():
    for t in ("that was an insane triple kill", "welcome back to the stream everyone", "", None,
              "he grabbed the assault rifle and ran"):   # 'assault rifle' must not trip the profanity 'ass' guard
        assert safety.review_flags(t) == [], "clean text should not be flagged: %r" % (t,)


def test_profanity_flagged_as_language():
    fl = safety.review_flags("what the fuck was that bro")
    assert any(f["flag"] == "language" for f in fl), "profanity should raise the language flag"
    assert all("label" in f and "hint" in f for f in fl), "each flag needs a label + hint for the UI"


def test_sexual_flagged_as_sensitive():
    fl = safety.review_flags("we went to the strip club after")
    assert any(f["flag"] == "sensitive" for f in fl)


def test_flags_are_advisory_shape():
    # a list of dicts with flag/label/hint — nothing that could be mistaken for a score change
    fl = safety.review_flags("fuck that was close")
    assert isinstance(fl, list) and all(set(f) == {"flag", "label", "hint"} for f in fl)
    assert safety.flag_labels(fl) == [f["label"] for f in fl]


if __name__ == "__main__":
    import traceback
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    fails = 0
    for fn in fns:
        try:
            fn(); print("ok  ", fn.__name__)
        except Exception:
            fails += 1; print("FAIL", fn.__name__); traceback.print_exc()
    print("%d/%d passed" % (len(fns) - fails, len(fns)))
    sys.exit(1 if fails else 0)

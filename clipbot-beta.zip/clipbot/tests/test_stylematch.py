"""Learn-my-style: measured look -> Clipbot grade, and caption summary -> brand kit."""
from cb import stylematch as SM


def test_look_maps_to_grade():
    # a warm, punchy, vivid, vignetted look
    g = SM.to_grade({"brightness": 150, "contrast": 80, "saturation": 120, "warmth": 36, "vignette": 0.6, "black": 8})
    assert g["brightness"] > 0 and g["contrast"] > 1 and g["saturation"] > 1 and g["warmth"] > 0
    assert g["vignette"] is True and g["look"] == "punchy"
    # a neutral look makes an (almost) empty grade
    assert SM.to_grade({"brightness": 128, "contrast": 55, "saturation": 60, "warmth": 0, "vignette": 1.0, "black": 8}) == {}
    assert SM.to_grade({"saturation": 5, "brightness": 128, "contrast": 55, "warmth": 0, "vignette": 1}).get("look") == "bw"


def test_caption_summary_and_brand_mapping():
    # OCR-style lines: boxed white ALL CAPS captions at the bottom, changing over time
    lines = []
    for i, txt in enumerate(["THIS IS INSANE", "WATCH THIS", "NO WAY"]):
        lines.append({"t": i * 1.0, "text": txt, "y": 0.8, "height": 0.05,
                      "fill": [255, 255, 255], "kind": "boxed", "box": [0, 0, 0], "accent": None})
    c = SM.caption_summary(lines, dur=4)
    assert c["present"] and c["kind"] == "boxed" and c["all_caps"] and c["position"] == "bottom"
    assert c["fill"] == "#FFFFFF" and c["box"] == "#000000"
    b = SM.captions_to_brand(c)
    assert b["caption_style"] == "box" and b["color"] == "#FFFFFF" and b["uppercase"] is True


def test_static_watermark_is_ignored():
    # a handle shown the whole video shouldn't be treated as a caption
    lines = [{"t": t / 3, "text": "@MYHANDLE", "y": 0.95, "height": 0.02, "fill": [200, 200, 200],
              "kind": "plain", "box": None, "accent": None} for t in range(0, 180)]
    lines += [{"t": i, "text": w, "y": 0.8, "height": 0.05, "fill": [255, 230, 0], "kind": "outline",
               "box": None, "accent": None} for i, w in enumerate(["BIG", "W", "GG"])]
    c = SM.caption_summary(lines, dur=60)
    assert c["present"] and c["fill_name"] == "yellow"      # the real captions, not the grey watermark


def test_summarise_and_describe():
    vids = [{"w": 1080, "h": 1920, "duration": 30, "framing": "fill",
             "look": {"brightness": 140, "contrast": 75, "saturation": 115, "warmth": 20,
                      "vignette": 0.9, "black": 8, "white": 240},
             "motion": {"seconds": 30, "cuts": 10, "punches": 3, "push_share": 0.1, "push_rate": 0.0,
                        "black_dips": 0, "flashes": 3},
             "sound": {"silent": False, "bed": True, "silence_share": 0.2}}]
    s = SM.summarise(vids)
    assert s["framing"] == "fill" and s["transition"] in ("flash", "cut")
    assert s["format"]["shape"] == "vertical"
    card = SM.describe(s)
    assert any("Look" in l for l in card) and any("Framing" in l for l in card)
    assert SM.to_brand(s)["grade"]        # non-empty grade from a punchy look

"""Server robustness: no endpoint should 500 on empty / malformed / bad-path input — it should
reject cleanly (400/403/404) instead of crashing. Guards the 'unhandled exception in a handler'
class of bug. Starts the editor server on an empty temp root; no Playwright, no model needed."""
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HEADER = {"Content-Type": "application/json", "X-Clipbot": "1"}

# (method, path, body) — bodies are intentionally empty/bad; none should cause a 500.
CASES = [
    ("POST", "/api/candidates", {}),
    ("POST", "/api/candidates", {"dir": "/no/such/dir"}),
    ("POST", "/api/clip/prompt", {}),
    ("POST", "/api/autoclip", {}),
    ("POST", "/api/autoclip", {"source": ""}),
    ("POST", "/api/render", {}),
    ("POST", "/api/live/start", {}),
    ("POST", "/api/category/start", {}),
    ("POST", "/api/connections", {"patch": {"bogus": {"x": 1}}}),
    ("POST", "/api/schedule/plan", {}),
    ("POST", "/api/schedule/add", {}),
    ("POST", "/api/schedule/cancel", {}),
    ("POST", "/api/post/folder", {}),
    ("POST", "/api/post/youtube", {}),
    ("POST", "/api/post/everywhere", {}),
    ("POST", "/api/post/x", {}),
    ("POST", "/api/twitch/device", {}),
    ("POST", "/api/clip/reveal", {"dir": "/no/such"}),
    ("GET", "/api/renders?dir=/no/such", None),
    ("GET", "/api/all_renders", None),
    ("GET", "/api/live/sessions", None),
    ("GET", "/api/schedule", None),
    ("GET", "/api/discover?game=&platforms=", None),
]


def _status(base, method, path, body):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(base + path, data=data, headers=HEADER, method=method)
    try:
        return urllib.request.urlopen(req, timeout=10).status
    except urllib.error.HTTPError as e:
        return e.code
    except Exception as e:
        return "ERR:" + str(e)[:40]


def run():
    port = socket.socket(); port.bind(("127.0.0.1", 0)); p = port.getsockname()[1]; port.close()
    workdir = tempfile.mkdtemp(prefix="cbrob_")
    srv = subprocess.Popen([sys.executable, "clipbot.py", "editor", "--root", workdir, "--port", str(p)],
                           cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    base = "http://127.0.0.1:%d" % p
    try:
        for _ in range(40):
            try:
                urllib.request.urlopen(base, timeout=1).read(1); break
            except Exception:
                time.sleep(0.25)
        crashes = []
        for method, path, body in CASES:
            st = _status(base, method, path, body)
            if st == 500:
                crashes.append("%s %s -> 500" % (method, path.split("?")[0]))
        if crashes:
            print("FAIL: endpoint(s) crashed with 500:")
            for c in crashes:
                print("  -", c)
            return 1
        print("ok   endpoint robustness: %d edge-case requests, no 500s" % len(CASES))
        return 0
    finally:
        srv.terminate()
        try:
            srv.wait(timeout=5)
        except Exception:
            srv.kill()


if __name__ == "__main__":
    sys.exit(run())

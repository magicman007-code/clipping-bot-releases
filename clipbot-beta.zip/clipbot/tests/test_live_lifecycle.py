"""Live-session lifecycle: a stream that ends or is stopped must stop counting as "live clipping"
and must get pruned from the registry, so it never blocks an update or lingers in the Live list.
Regression test for the 2026-11-18 "stuck live clipping" bug. Uses fake sessions; no network/ASR."""
import os
import threading

from cb import editor_server as es


class FakeSession:
    def __init__(self, tmpdir, state=None, ended=False):
        self.dir = str(tmpdir)
        self.stop = threading.Event()
        self.ended = ended
        if state is not None:
            with open(os.path.join(self.dir, "live_status.json"), "w") as f:
                f.write('{"state": "%s"}' % state)


def _reset():
    es.JOBS.clear(); es.LIVE.clear(); es.LIVE_STOPPED.clear(); es.LIVE_ALWAYS.clear()


def test_live_session_is_busy(tmp_path):
    _reset()
    es.LIVE["a"] = FakeSession(tmp_path, state="live")
    assert "live clipping" in es.busy()               # a genuinely-live stream blocks updates


def test_ended_stream_is_not_busy(tmp_path):
    _reset()
    es.LIVE["a"] = FakeSession(tmp_path, state="ended", ended=True)   # streamer went offline
    assert es.busy() == []                             # the exact bug: must NOT read as busy


def test_stopped_session_is_not_busy(tmp_path):
    _reset()
    s = FakeSession(tmp_path, state="live")
    s.stop.set()
    es.LIVE["a"] = s
    es.LIVE_STOPPED["a"] = True
    assert es.busy() == []


def test_terminal_states_are_not_busy(tmp_path):
    for st in ("finished", "ended", "error"):
        _reset()
        es.LIVE["a"] = FakeSession(tmp_path, state=st)
        assert es.busy() == [], "state %s should not block updates" % st


def test_always_on_still_busy_until_it_ends(tmp_path):
    _reset()
    es.LIVE["a"] = FakeSession(tmp_path, state="live")
    es.LIVE_ALWAYS.add("a")
    assert "live clipping" in es.busy()                # always-on waiting/clipping still counts
    es.LIVE["a"].ended = True                          # but once the stream really ends, it frees up
    assert es.busy() == []


def test_prune_drops_dead_but_keeps_live(tmp_path):
    _reset()
    d_live = tmp_path / "live"; d_live.mkdir()
    d_done = tmp_path / "done"; d_done.mkdir()
    d_recap = tmp_path / "recap"; d_recap.mkdir()
    es.LIVE["live"] = FakeSession(d_live, state="live")
    es.LIVE["done"] = FakeSession(d_done, state="finished")
    es.LIVE["recap"] = FakeSession(d_recap, state="building recap")   # still finalizing
    pruned = es.prune_dead_sessions()
    assert "done" in pruned
    assert "live" in es.LIVE and "recap" in es.LIVE     # live + finalizing are kept
    assert "done" not in es.LIVE                        # finished is dropped


def test_prune_keeps_always_on(tmp_path):
    _reset()
    es.LIVE["a"] = FakeSession(tmp_path, state="finished")
    es.LIVE_ALWAYS.add("a")
    es.prune_dead_sessions()
    assert "a" in es.LIVE                               # always-on respawns; never pruned


if __name__ == "__main__":
    import sys, tempfile, traceback
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    fails = 0
    for fn in fns:
        with tempfile.TemporaryDirectory() as td:
            try:
                import pathlib
                fn(pathlib.Path(td))
                print("ok  ", fn.__name__)
            except Exception:
                fails += 1
                print("FAIL", fn.__name__); traceback.print_exc()
    print("%d/%d passed" % (len(fns) - fails, len(fns)))
    sys.exit(1 if fails else 0)

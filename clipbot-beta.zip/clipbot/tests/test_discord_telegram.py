"""Discord webhook + Telegram bot posting, against a fake server (no real credentials)."""
import http.server
import json
import threading


class _H(http.server.BaseHTTPRequestHandler):
    seen = {}

    def _send(self, obj, code=200):
        b = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def do_POST(self):
        ln = int(self.headers.get("Content-Length") or 0)
        ctype = self.headers.get("Content-Type", "")
        raw = self.rfile.read(ln)
        _H.seen["ctype"] = ctype
        _H.seen["raw"] = raw
        if "/webhooks/" in self.path:
            return self._send({"id": "msg1", "channel_id": "chan1"})
        if "/sendVideo" in self.path:
            return self._send({"ok": True, "result": {"message_id": 77}})
        self._send({}, 404)

    def log_message(self, *a):
        pass


def _server():
    httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), _H)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    return httpd, httpd.server_address[1]


def _clip(tmp_path):
    import subprocess
    p = tmp_path / "clip.mp4"
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "color=c=blue:s=320x568:d=1:r=10",
                    "-pix_fmt", "yuv420p", str(p)], check=True)
    return str(p)


def test_discord_webhook_post(tmp_path, monkeypatch):
    from cb import connect, publish
    monkeypatch.setattr(connect, "_path", lambda: str(tmp_path / "c.json"))
    httpd, port = _server()
    hook = "http://127.0.0.1:%d/api/webhooks/1/abc" % port
    _H.seen = {}
    r = publish.discord_post(_clip(tmp_path), "big W clip \U0001F525", webhook=hook)
    assert r["ok"] and r["id"] == "msg1" and r["url"]
    raw = _H.seen["raw"]
    assert b'name="files[0]"; filename=' in raw and b"video/mp4" in raw and len(raw) > 1000
    assert b"big W clip" in raw
    httpd.shutdown()


def test_telegram_bot_post(tmp_path, monkeypatch):
    from cb import connect, publish
    monkeypatch.setattr(connect, "_path", lambda: str(tmp_path / "c.json"))
    httpd, port = _server()
    connect.save({"telegram": {"bot_token": "123456:ABCDEFGHIJKLMNOPQRSTUVWXYZ012345678", "chat_id": "@mychan"}})
    _H.seen = {}
    r = publish.telegram_post(_clip(tmp_path), "watch this", api="http://127.0.0.1:%d" % port)
    assert r["ok"] and r["message_id"] == 77
    raw = _H.seen["raw"]
    assert b'name="video"; filename=' in raw and b"@mychan" in raw and b"watch this" in raw
    httpd.shutdown()


def test_missing_credentials(tmp_path, monkeypatch):
    from cb import connect, publish
    monkeypatch.setattr(connect, "_path", lambda: str(tmp_path / "c.json"))
    for fn in (publish.discord_post, publish.telegram_post):
        try:
            fn(_clip(tmp_path), "x")
            assert False, "should require credentials"
        except ValueError as e:
            assert "Settings" in str(e)

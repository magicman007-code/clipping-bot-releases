"""No duplicate element IDs in the editor. Duplicate ids are a silent-bug factory: document
.getElementById / $() returns only the first match, so a handler updates or reads the wrong
element (e.g. a status message written to a hidden twin). Static check, no browser needed."""
import os
import re
from collections import Counter

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def run():
    html = open(os.path.join(ROOT, "editor", "index.html"), encoding="utf-8").read()
    # ignore ids inside inline <template> content is overkill here; the editor has none.
    ids = re.findall(r'\bid="([A-Za-z0-9_]+)"', html)
    dups = [k for k, v in Counter(ids).items() if v > 1]
    if dups:
        print("FAIL: duplicate element id(s):", ", ".join(sorted(dups)))
        return 1
    print("ok   no duplicate element ids (%d unique)" % len(set(ids)))
    return 0


if __name__ == "__main__":
    import sys
    sys.exit(run())

"""Brand kit defaults + logo overlay, and the music-safety detector."""
import numpy as np

from cb import brand, musicsafe


def test_brand_active_and_look_defaults():
    assert brand.active({}) == {}
    assert brand.active({"brand": {"enabled": False, "accent": "#f00"}}) == {}
    b = {"enabled": True, "accent": "#ff0055", "color": "#ffffff", "headline_bg": "#000000", "caption_font": "Anton"}
    assert brand.active({"brand": b}) == b
    look = brand.look_defaults(b)
    assert look["color"] == "#ffffff" and look["headline_bg"] == "#000000"
    assert "caption_font" not in look and "accent" not in look          # those aren't look keys


def test_logo_overlay_corners_and_bounds(tmp_path):
    png = tmp_path / "logo.png"
    png.write_bytes(b"x")
    assert brand.logo_overlay({"enabled": True}, 1, 1080, 1920) is None    # no logo set
    got = brand.logo_overlay({"enabled": True, "logo": str(png), "logo_pos": "tl", "logo_size": 500, "logo_opacity": 5}, 2, 1080, 1920)
    args, prep, ov = got
    assert args[:3] == ["-loop", "1", "-i"] and args[3] == str(png)
    assert "colorchannelmixer=aa=0.10" in prep            # opacity clamped up to 0.1 minimum
    assert ov.startswith("overlay=") and ov.split(":")[0].endswith(str(max(12, int(1080 * 0.03))))  # tl -> left margin
    br = brand.logo_overlay({"enabled": True, "logo": str(png)}, 2, 1080, 1920)[2]
    assert "W-w-" in br                                   # default corner is bottom-right


def _music(dur=12, sr=16000):
    t = np.arange(int(sr * dur)) / sr
    chord = sum(np.sin(2 * np.pi * f * t) for f in (261.6, 329.6, 392.0)) / 3
    beat = (0.5 + 0.5 * np.sign(np.sin(2 * np.pi * 2 * t))) * np.sin(2 * np.pi * 60 * t)
    return (0.7 * chord + 0.3 * beat) * 0.3


def _speech(dur=12, sr=16000):
    # voiced harmonics + consonant hiss + syllable envelope + word gaps -> realistic speech, not a held tone
    t = np.arange(int(sr * dur)) / sr
    f0 = 120 * (1 + 0.05 * np.sin(2 * np.pi * 0.3 * t))
    ph = 2 * np.pi * np.cumsum(f0) / sr
    voice = sum(np.sin(h * ph) / h for h in range(1, 12))
    syl = np.clip(np.sin(2 * np.pi * 4.5 * t), 0, 1) ** 2
    word = (np.sin(2 * np.pi * 0.5 * t) > -0.2).astype(float)
    hiss = np.random.default_rng(2).standard_normal(len(t)) * 0.15 * (syl > 0.3)   # consonants
    return ((voice * syl + hiss) * word) * 0.3


def test_music_flagged_speech_is_not():
    m = musicsafe.scan_wav(_music(), 16000)
    assert m["music_frac"] > 0.6 and m["music"] and m["note"]
    s = musicsafe.scan_wav(_speech(), 16000)
    assert s["music_frac"] == 0.0 and not s["music"] and s["note"] is None
    assert musicsafe.scan_wav(np.zeros(16000 * 5, np.float32), 16000)["music"] == []


def test_music_finds_only_the_music_half():
    mixed = np.concatenate([_speech(6), _music(8)])
    r = musicsafe.scan_wav(mixed, 16000)
    assert r["music"], "should flag the music section"
    a, b = r["music"][0]
    assert a >= 4.0 and b >= 12.0          # music starts in the back half, not during the speech

"""Home dashboard project cards, GIPHY stickers and the app refresh after an update."""
import json
import os

from cb import effects, giphy


def test_gif_sticker_loops_and_starts_at_its_window(tmp_path):
    g = tmp_path / "a.gif"
    g.write_bytes(b"GIF89a" + b"\0" * 20)
    args, steps, _ = effects.sticker_inputs([{"path": str(g), "start": 2, "end": 5, "w": 300}], 1)
    assert args[:3] == ["-ignore_loop", "0", "-i"]
    assert "setpts=PTS-STARTPTS+2.000/TB" in steps[0][0]
    p = tmp_path / "b.png"
    p.write_bytes(b"x")
    args, steps, _ = effects.sticker_inputs([{"path": str(p)}], 1)
    assert args[:2] == ["-loop", "1"] and "setpts" not in steps[0][0]


def test_giphy_needs_a_key_and_rejects_bad_ids(monkeypatch, tmp_path):
    monkeypatch.setattr(giphy, "key", lambda: "")
    try:
        giphy.search("cat")
        assert False, "should ask for a key"
    except RuntimeError as e:
        assert "GIPHY API key" in str(e)
    for bad in ("../etc", "a b", "", "x" * 60):
        try:
            giphy.fetch(bad, str(tmp_path))
            assert False
        except ValueError:
            pass


def test_giphy_emoji_uses_the_emoji_library(monkeypatch):
    seen = []
    monkeypatch.setattr(giphy, "_get", lambda path, params: seen.append(path) or {"data": [], "pagination": {}})
    giphy.search("", "emoji")
    giphy.search("laugh", "emoji")
    giphy.search("", "stickers")
    assert seen == ["v2/emoji", "stickers/search", "stickers/trending"]


def test_project_card_reads_status_and_counts(tmp_path, monkeypatch):
    from cb import editor_server as es
    monkeypatch.setattr(es.Ctx, "root", str(tmp_path), raising=False)
    d = tmp_path / "p1"
    (d / "renders").mkdir(parents=True)
    (d / "source.mp4").write_bytes(b"x")
    (d / "renders" / "c1.mp4").write_bytes(b"x")
    (d / "renders" / "c1_draft.mp4").write_bytes(b"x")
    (d / "candidates.json").write_text(json.dumps([{}, {}, {}]))
    (d / "autoclip_status.json").write_text(json.dumps({"source": "https://kick.com/x/videos/1", "state": "transcribing",
                                                        "duration": 600}))
    c = es.project_card(str(d), str(d / "source.mp4"))
    assert c["kind"] == "kick" and c["clips"] == 1 and c["moments"] == 3 and c["busy"] and c["duration"] == 600
    (d / "autoclip_status.json").write_text(json.dumps({"state": "done"}))
    c = es.project_card(str(d), str(d / "source.mp4"))
    assert not c["busy"] and c["kind"] == "file" and c["origin"] == ""


def test_dock_pin_only_once(monkeypatch, tmp_path):
    from cb import appshell
    monkeypatch.setattr(appshell.sys, "platform", "darwin")
    monkeypatch.setattr(appshell, "DOCK_MARK", str(tmp_path / "mark"))
    calls = []

    class R:
        stdout = ""
    monkeypatch.setattr(appshell.subprocess, "run", lambda a, **k: calls.append(a[0]) or R())
    assert appshell.add_to_dock("/Applications/Clipbot.app")
    assert "defaults" in calls and "killall" in calls
    calls.clear()
    assert not appshell.add_to_dock("/Applications/Clipbot.app")      # removed from the Dock later? leave it removed
    assert calls == []
    assert os.path.exists(str(tmp_path / "mark"))

"""First-run simple path (3.5.2): with no projects yet, Home shows one clear action and tucks the
secondary tools behind "More tools". Returning users (any projects) must see the full Home, so the
simplification is gated on an empty project list only. Static guards on the three wiring points."""
import os, re
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
H = open(os.path.join(ROOT, "editor/index.html"), encoding="utf-8").read()


def test_firstrun_toggled_only_when_no_projects():
    # fillRecent flips the class on/off from the project count, so returning users never get it
    assert 'classList.toggle("firstrun",!S.pj.length)' in H, "firstrun must be gated on an empty project list"


def test_firstrun_css_tucks_secondary_tools():
    assert "#home.firstrun .qChips{display:none}" in H, "first run must hide the secondary chips row"
    assert "#home.firstrun .moreRow{display:flex}" in H, "first run must reveal the More tools control"


def test_more_tools_reveals_everything():
    m = re.search(r'\$\("hMoreTools"\)\.onclick=\(\)=>\{([^}]*)\}', H)
    assert m, "hMoreTools handler missing"
    assert 'classList.remove("firstrun")' in m.group(1), "More tools must drop the firstrun state (reveal the tools)"


if __name__ == "__main__":
    import sys, traceback
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    fails = 0
    for fn in fns:
        try:
            fn(); print("ok  ", fn.__name__)
        except Exception:
            fails += 1; print("FAIL", fn.__name__); traceback.print_exc()
    print("%d/%d passed" % (len(fns) - fails, len(fns)))
    sys.exit(1 if fails else 0)

"""End-to-end + unit tests.  Run:  python -m pytest -q tests   (about 3-4 minutes, fully offline)."""
import json
import os
import socket
import sys
import threading
import time
import urllib.request
import wave

import numpy as np
import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))

from cb import banner, moments, packaging, score  # noqa: E402
from cb.common import ffmpeg, probe  # noqa: E402


@pytest.fixture(scope="session")
def demo(tmp_path_factory):
    root = tmp_path_factory.mktemp("work")
    os.environ["CLIPBOT_WORK_ROOT"] = str(root)
    from cb.tools import demo as mk
    d = mk(str(root / "demo"))
    return {"root": str(root), "dir": d, "src": os.path.join(d, "source.mp4"),
            "words": json.load(open(os.path.join(d, "words.json")))}


# ---------------------------------------------------------------- moment finding
def test_lexicon_whole_words():
    rx = moments._rx(moments.LEX["humor"])
    assert not rx.findall("the market cap is two million you know")        # not "no cap"
    assert rx.findall("no cap that was hilarious")
    assert not moments._rx(moments.LEX["drama"]).findall("she applied for it")  # not "lied"


def test_candidates_snap_to_sentences_and_skip_filler(demo):
    cs = moments.find_candidates(demo["words"], demo["src"], demo["dir"], niche=("crypto",), top_k=4)
    assert cs, "no candidates"
    best = cs[0]
    assert best["sentences"][0][1].startswith(("So one time", "Wait")), best["sentences"][0]
    for c in cs:
        first = c["sentences"][0][1].lower()
        assert not first.startswith(("so um", "okay so um", "um")), first


def test_quality_bar(demo):
    cs = moments.find_candidates(demo["words"], demo["src"], demo["dir"], niche=("crypto",), top_k=6)
    scores = [score.score_candidate(c)["score"] for c in cs]
    assert max(scores) >= 6.0
    filler = {"tags": {}, "hook": -2, "payoff": 0, "payoff_mag": 0, "novelty": 0, "energy": 0, "dur": 30,
              "dead_air": 4, "asr_conf": 0.5, "filler": 0.5, "tail": False}
    assert score.score_candidate(filler)["score"] < 6.0


# ---------------------------------------------------------------- titles
def test_titles_never_splice_claims_across_sentences():
    ok, miss = packaging._supported("He lost ten million", "I lost eleven grand. Did that hit ten million?")
    assert not ok and miss
    ts = packaging.titles("Orangie bought this coin at 200K. Then Brez sold it. He lost 40K in ten minutes.")
    spec = [t for t in ts if t["style"] == "specific"][0]
    assert spec["title"].startswith("Orangie bought 200K") and spec["supported"]
    assert all("He's" not in t["title"] for t in ts)


# ---------------------------------------------------------------- banners
def test_banner_from_url_and_render():
    assert banner.from_url("https://kick.com/n3on") == {"platform": "kick", "handle": "n3on"}
    assert banner.from_url("https://www.twitch.tv/kaicenat", "socials")["platform"] == "twitch"
    assert banner.from_url("https://kick.com/videos") is None
    for b in ({"preset": "socials", "platform": "kick", "handle": "orangie"},
              {"preset": "kick_campaign", "handle": "orangie"}, {"preset": "twitch_tag", "handle": "xqc"}):
        p, w, h = banner.render_png(banner.resolve(b))
        assert os.path.exists(p) and 80 < w <= 1080 and 40 < h < 400


def test_banner_stays_in_safe_band():
    for layout, cap in (("auto", 1350), ("vertical", 1300), ("gameplay", 960), ("facecam_screen", 900)):
        x, y = banner.placement({"position": "auto"}, layout, [(0, 99, "tall", cap)], 300)
        assert banner.SAFE_TOP <= y <= banner.SAFE_BOTTOM, (layout, y)
        assert abs(y - cap) > 100, (layout, y, cap)


# ---------------------------------------------------------------- editing primitives
def test_tighten_removes_dead_air():
    from cb.render import tighten_pieces
    words = [[0.2, 0.5, "so", 1], [0.6, 0.9, "one", 1], [3.0, 3.3, "time", 1], [3.4, 3.6, "um", 1],
             [5.0, 5.3, "bro", 1]]
    pieces, removed = tighten_pieces([[0, 6]], words)
    assert removed > 2.5 and len(pieces) >= 2


def test_beat_tracker_on_click_track(tmp_path):
    from cb.montage_engine import analyze_music
    sr = 44100
    y = np.zeros(20 * sr)
    for k in range(40):
        i = int(k * 0.5 * sr)
        y[i:i + 200] += np.random.RandomState(k).randn(200) * 0.8
    p = str(tmp_path / "click.wav")
    w = wave.open(p, "wb")
    w.setnchannels(1)
    w.setsampwidth(2)
    w.setframerate(sr)
    w.writeframes((np.clip(y, -1, 1) * 32767).astype(np.int16).tobytes())
    w.close()
    g = analyze_music(p, str(tmp_path))
    assert abs(g["bpm"] - 120) < 1.5
    err = [min(abs(b - k * 0.5) for k in range(40)) for b in g["beats"]]
    assert np.median(err) < 0.03


# ---------------------------------------------------------------- render + verify + QC
def test_render_banner_audio_replace_and_qc(demo, tmp_path):
    from cb.render import make_clip
    from cb.verify import qc_load, qc_set
    tone = str(tmp_path / "tone.wav")
    os.system("ffmpeg -loglevel error -y -f lavfi -i sine=f=1000:d=30 %s" % tone)
    spec = {"name": "t1", "source": demo["src"], "start": 44.0, "end": 58.0, "headline": "He bought at $200K and it hit $10M",
            "captions": "box", "banner": {"preset": "socials", "platform": "kick", "handle": "orangie"},
            "audio_replace": {"path": tone, "mode": "replace", "volume": 1.0}}
    out = str(tmp_path / "out")
    res = make_clip(spec, out, str(tmp_path / "work"), {})
    pr = probe(res["out"])
    assert (pr["width"], pr["height"]) == (1080, 1920) and pr["has_audio"]
    assert res["verify"]["ok"], res["verify"]["defects"]
    assert any("banner" in x for x in res["layout_log"]) and any("audio replaced" in x for x in res["layout_log"])
    # the output's audio really is the 1 kHz replacement
    wav = str(tmp_path / "o.wav")
    os.system("ffmpeg -loglevel error -y -i %s -ac 1 -ar 16000 %s" % (res["out"], wav))
    w = wave.open(wav)
    x = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(float)
    f = np.argmax(np.abs(np.fft.rfft(x[16000:48000]))) * 16000 / 32000.0
    assert abs(f - 1000) < 20
    # human QC gate
    assert qc_load(out)["t1"]["status"] == "pending"
    with pytest.raises(ValueError):
        qc_set(out, "t1", "approved", watched=False)
    assert qc_set(out, "t1", "approved", watched=True)["status"] == "approved"


def test_autoclip_respects_bar(demo):
    from cb.autoclip import run
    st = run(demo["src"], demo["root"], "demo", clips=2, min_score=6.0, draft=True)
    assert st["state"] == "done", st
    assert st["clips"] and all(c.get("score", 0) >= 6.0 for c in st["clips"] if "score" in c)
    specs = json.load(open(os.path.join(demo["dir"], "specs.json")))
    assert any(s["name"].endswith("_clip") for s in specs)


# ---------------------------------------------------------------- editor server
def test_editor_api(demo):
    from cb import editor_server
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    threading.Thread(target=editor_server.serve, args=(demo["root"], port), daemon=True).start()
    time.sleep(1.0)
    base = "http://127.0.0.1:%d" % port
    j = json.load(urllib.request.urlopen(base + "/api/projects"))
    assert any(p["dir"] == demo["dir"] for p in j["projects"])
    html = urllib.request.urlopen(base + "/").read().decode()
    assert "Clipbot Studio" in html and "Auto-clip it" in html and "tourNext" in html
    req = urllib.request.Request(base + "/media?path=" + demo["src"], headers={"Range": "bytes=0-99"})
    r = urllib.request.urlopen(req)
    assert r.status == 206 and len(r.read()) == 100
    with pytest.raises(urllib.error.HTTPError) as e:
        urllib.request.urlopen(base + "/media?path=/etc/passwd")
    assert e.value.code == 403
    body = json.dumps({"text": "Orangie bought this coin at 200K.", "headline": ""}).encode()
    t = json.load(urllib.request.urlopen(urllib.request.Request(base + "/api/titles", data=body,
                                                                headers={"Content-Type": "application/json"})))
    assert t["titles"]


def test_filter_paths_and_icons(tmp_path):
    """Paths with spaces/quotes/drive colons survive ffmpeg filter args; icons work offline from the bundle."""
    from cb.common import fpath
    assert "\\\\\\'s PC" in fpath("/Users/Bob's PC/a.ass")
    d = tmp_path / "it's a dir"
    d.mkdir()
    ass = d / "t.ass"
    ass.write_text("[Script Info]\nScriptType: v4.00+\nPlayResX: 64\nPlayResY: 64\n[V4+ Styles]\nFormat: Name, Fontname, "
                   "Fontsize\nStyle: Default,Anton,20\n[Events]\nFormat: Layer, Start, End, Style, Text\n")
    from cb.common import ffmpeg, FONT_DIR
    ffmpeg(["-f", "lavfi", "-i", "color=c=black:s=64x64:d=0.2", "-vf",
            "ass=filename=%s:fontsdir=%s" % (fpath(str(ass)), fpath(FONT_DIR)), str(d / "o.mp4")])
    assert (d / "o.mp4").exists()
    from cb.banner import brand_icon
    for p in ("kick", "twitch", "youtube"):
        assert brand_icon(p, 64, "#000000")


def test_editor_port_fallback():
    import socket
    import threading
    from cb import editor_server
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    busy = s.getsockname()[1]
    s.listen(1)
    got = {}
    orig = editor_server.ThreadingHTTPServer

    class Spy(orig):
        def serve_forever(self, *a, **k):
            got["port"] = self.server_address[1]
            self.server_close()
    editor_server.ThreadingHTTPServer = Spy
    try:
        t = threading.Thread(target=editor_server.serve, args=(os.path.dirname(__file__), busy))
        t.start()
        t.join(10)
    finally:
        editor_server.ThreadingHTTPServer = orig
        s.close()
    assert got["port"] != busy


def test_share_links_normalised():
    from cb.fetch import LinkError, direct_link
    d = direct_link("https://www.dropbox.com/scl/fi/abc123/stream.mp4?rlkey=xyz&e=1&dl=0")
    assert d.startswith("https://www.dropbox.com/scl/fi/abc123/stream.mp4?") and "dl=1" in d and "rlkey=xyz" in d
    assert "dl=1" in direct_link("https://dropbox.com/s/k3y/clip.mov?dl=0")
    with pytest.raises(LinkError):
        direct_link("https://www.dropbox.com/scl/fo/folderid/h?rlkey=1&dl=0")
    g = direct_link("https://drive.google.com/file/d/1AbCdEfGhIjKlMnOp/view?usp=sharing")
    assert g == "https://drive.usercontent.google.com/download?id=1AbCdEfGhIjKlMnOp&export=download&confirm=t"
    assert "id=1AbCdEfGhIjKlMnOp" in direct_link("https://drive.google.com/open?id=1AbCdEfGhIjKlMnOp")
    with pytest.raises(LinkError):
        direct_link("https://drive.google.com/drive/folders/1AbCdEfGhIjKlMnOp")
    assert direct_link("https://cdn.example.com/v/raw.MP4") == "https://cdn.example.com/v/raw.MP4"
    assert direct_link("https://www.youtube.com/watch?v=abc") is None and direct_link("https://kick.com/x") is None


def test_direct_download_from_http_server(demo, tmp_path):
    """A 'cloud' link served over HTTP downloads + validates; an HTML page is rejected with a clear reason."""
    import http.server
    import shutil
    from cb.fetch import download
    srv_dir = tmp_path / "srv"
    srv_dir.mkdir()
    shutil.copy(demo["src"], srv_dir / "video.mp4")
    (srv_dir / "page.mp4").write_text("<!DOCTYPE html><html>sign in</html>")
    h = lambda *a, **k: http.server.SimpleHTTPRequestHandler(*a, directory=str(srv_dir), **k)  # noqa: E731
    httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), h)
    httpd.RequestHandlerClass.log_message = lambda *a: None
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    base = "http://127.0.0.1:%d/" % httpd.server_address[1]
    try:
        p, kind, _ = download(base + "video.mp4", str(tmp_path / "a"))
        assert p and kind is None and probe(p)["duration"] > 60
        p, kind, msg = download(base + "page.mp4", str(tmp_path / "b"))
        assert p is None and kind == "bad_link" and "web page" in msg
    finally:
        httpd.shutdown()


def test_fonts_pack_and_upload(tmp_path):
    from cb import fonts
    fams = {f["family"] for f in fonts.list_fonts()}
    assert {"Anton", "Montserrat Black", "Bebas Neue", "Poppins ExtraBold"} <= fams and len(fams) >= 20
    assert fonts.resolve("montserrat") == "Montserrat Black" and fonts.resolve("bebas neue") == "Bebas Neue" and fonts.resolve("Nope Sans") == "Anton"
    from fontTools.ttLib import TTFont
    tt = TTFont(fonts.find("Bangers"))
    for r in tt["name"].names:
        if r.nameID in (1, 4):
            r.string = "My Brand Font"
    src = str(tmp_path / "brand.ttf")
    tt.save(src)
    got = fonts.add(src)
    assert got["family"] == "My Brand Font"
    assert any(f["family"] == "My Brand Font" and f["user"] for f in fonts.list_fonts())
    assert any(n.startswith("u_") for n in os.listdir(fonts.render_dir()))
    bad = str(tmp_path / "bad.ttf")
    open(bad, "wb").write(b"not a font")
    with pytest.raises(ValueError):
        fonts.add(bad)


def test_formatting_and_srt_match_captions(demo, tmp_path):
    from cb.render import build_ass, caption_cues, make_clip
    ws = [w for w in demo["words"] if 44.0 <= w[0] < 58.0]
    ws = [[w[0] - 44.0, w[1] - 44.0, w[2]] for w in ws]
    ass = str(tmp_path / "c.ass")
    look = {"bold": True, "italic": True, "spacing": 3, "color": "#00ff00", "outline_color": "#ff0000",
            "outline": "", "headline_font": "Bebas Neue", "caption_font_set": True}
    info = build_ass(ws, 14, "Test headline", [(0, 99, "x", 1300)], ass, cap_font="Poppins ExtraBold",
                     style="minimal", accent="#12abef", look=look)
    txt = open(ass).read()
    assert "Style: Cap,Poppins ExtraBold," in txt and ",-1,-1,0,0,100,100,3," in txt
    assert "&H0000FF00" in txt and "&H000000FF" in txt and "Style: Head,Bebas Neue," in txt
    assert len(caption_cues(ws, "minimal")) == info["caption_chunks"]
    info = build_ass(ws, 14, "", [(0, 99, "x", 1300)], ass, style="none")
    assert info["caption_chunks"] == 0 and ",Cap,," not in open(ass).read()
    spec = {"name": "s1", "source": demo["src"], "start": 44.0, "end": 58.0, "captions": "pro", "speed": 1.25,
            "caption_font": "Bebas Neue", "caption_bold": True}
    out = str(tmp_path / "out")
    res = make_clip(spec, out, str(tmp_path / "work"), {})
    srt = open(os.path.join(out, "s1.srt"), encoding="utf-8").read()
    cues = [b for b in srt.strip().split("\n\n") if "-->" in b]
    assert len(cues) == res["caption_chunks"] > 3
    last_end = cues[-1].split("\n")[1].split(" --> ")[1]
    h, m, rest = last_end.split(":")
    assert float(rest.replace(",", ".")) <= res["dur"] + 0.6


def test_aspect_ratios_and_extra_versions(demo, tmp_path):
    from cb.render import frame_geometry, make_clip, retarget
    assert frame_geometry(1920, 1080, 1080, 1080, have_face=True)[0] == "crop_x"
    assert frame_geometry(1920, 1080, 1080, 1080, have_face=False)[0] == "fit"
    assert frame_geometry(1920, 1080, 1920, 1080)[0] == "cover"
    assert frame_geometry(1080, 1920, 1920, 1080)[0] == "fit"
    assert frame_geometry(1080, 1350, 1080, 1080)[0] == "crop_y"
    sub = retarget({"name": "x", "aspect": "9:16", "caption_y": 1500, "texts": [{"x": 540, "y": 1600, "size": 100}],
                    "stickers": [{"x": 1000, "y": 1800, "w": 200}]}, "16:9")
    assert sub["name"] == "x_16x9" and "caption_y" not in sub
    assert sub["texts"][0]["x"] == 960 and sub["texts"][0]["y"] == 900 and sub["texts"][0]["size"] == 56
    assert sub["stickers"][0]["x"] <= 1920 and sub["stickers"][0]["y"] <= 1080
    spec = {"name": "sq", "source": demo["src"], "start": 44.0, "end": 52.0, "headline": "He bought at $200K",
            "banner": {"preset": "socials", "platform": "kick", "handle": "orangie"}, "aspect": "1:1",
            "also_aspects": ["16:9", "4:5"]}
    out = str(tmp_path / "out")
    res = make_clip(spec, out, str(tmp_path / "work"), {})
    assert res["size"] == "1080x1080" and res["verify"]["ok"], res["verify"]["defects"]
    sizes = {v["aspect"]: probe(v["out"]) for v in res["versions"]}
    assert (sizes["16:9"]["width"], sizes["16:9"]["height"]) == (1920, 1080)
    assert (sizes["4:5"]["width"], sizes["4:5"]["height"]) == (1080, 1350)
    assert os.path.exists(os.path.join(out, "sq_16x9.srt"))


def test_manual_import_mode(demo, tmp_path):
    """'Just import' opens a hand-editable project without auto-rendering anything; no banner/headline when off."""
    import shutil
    from cb.autoclip import run
    src = tmp_path / "mine.mp4"
    shutil.copy(demo["src"], src)
    shutil.copy(os.path.join(demo["dir"], "words.json"), tmp_path / "words.json")
    st = run(str(src), str(tmp_path / "root"), "mine", manual=True, banner=False, aspect="16:9")
    assert st["state"] == "done" and st["manual"] and st["clips"] == []
    specs = json.load(open(os.path.join(str(tmp_path / "root"), "mine", "specs.json")))
    assert len(specs) == 1 and specs[0]["aspect"] == "16:9" and specs[0]["banner"] is None and not specs[0]["headline"]
    assert not os.path.exists(os.path.join(str(tmp_path / "root"), "mine", "renders", "01_my_clip.mp4"))


def test_hardening_helpers(tmp_path, demo):
    from cb.autoclip import check_source, draft_headline
    from cb.transcribe import merge_number_tokens
    bad = tmp_path / "x.mp4"
    bad.write_text("nope")
    with pytest.raises(RuntimeError, match="Can't read this file"):
        check_source(str(bad))
    sil = str(tmp_path / "silent.mp4")
    ffmpeg(["-i", demo["src"], "-t", "8", "-an", "-c:v", "copy", sil])
    with pytest.raises(RuntimeError, match="no sound"):
        check_source(sil)
    assert check_source(sil, need_audio=False)["duration"] > 7
    assert [w[2] for w in merge_number_tokens([[0, 1, "$100", .9], [1, 1.2, ",000", .8], [2, 2.2, "40", .9],
                                                [2.2, 2.3, "%", .9]])] == ["$100,000", "40%"]
    assert draft_headline({"sentences": [(0, "thing completely insane."), (1, "So last week i bought it.")]}) \
        == "So last week I bought it"


def test_silent_video_render_mute_and_loudness(demo, tmp_path):
    """A video with no audio track still renders; mute ranges silence the voice; loudness lands on target."""
    from cb.render import make_clip, output_loudness
    sil = str(tmp_path / "silent.mp4")
    ffmpeg(["-i", demo["src"], "-t", "20", "-an", "-c:v", "copy", sil])
    res = make_clip({"name": "s", "source": sil, "start": 2, "end": 10, "captions": "none"}, str(tmp_path / "o"),
                    str(tmp_path / "w"), {})
    assert probe(res["out"])["has_audio"]
    res = make_clip({"name": "m", "source": demo["src"], "start": 44, "end": 54, "mute_ranges": [[0, 9.9]]},
                    str(tmp_path / "o"), str(tmp_path / "w"), {})
    i, _ = output_loudness(res["out"])
    assert i is None or i < -40          # (almost) everything muted
    res = make_clip({"name": "n", "source": demo["src"], "start": 44, "end": 54}, str(tmp_path / "o"),
                    str(tmp_path / "w"), {})
    i, _ = output_loudness(res["out"])
    assert abs(i + 14) <= 1.2, i


def test_prompt_clipping_keywords_and_meaning(demo, monkeypatch):
    """Prompt search finds the right line; works by keywords even when the meaning model is unavailable."""
    from cb import semantic
    from cb.prompt_clip import find, plan
    words = demo["words"]
    p = plan("every time he talks about the $10M coin, funny moments")
    assert p["all"] and "humor" in p["intents"] and "coin" in p["keywords"]
    monkeypatch.setattr(semantic, "available", lambda: False)
    c, info = find("when he says the market cap", words, demo["src"], demo["dir"], n=3)
    assert c and info["method"][0] == "keywords"
    assert "market cap" in c[0]["match"].lower() and c[0]["relevance"] >= 0.5
    assert c[0]["start"] <= c[0]["match_at"] <= c[0]["end"] and c[0]["rank"] == 1 and "quality" in c[0]
    c, info = find("basketball tournament", words, demo["src"], demo["dir"], n=3)
    assert c == []


def test_lore_learn_save_and_scoring(demo, tmp_path):
    import json as _j
    import random
    from cb import lore
    from cb.moments import find_candidates
    random.seed(3)
    filler = "so anyway I was thinking about the market today and honestly it looks pretty good".split()
    dirs = []
    for k in range(3):
        d = tmp_path / ("s%d" % k)
        d.mkdir()
        ws, t = [], 0.0
        for r in range(50):
            sent = random.sample(filler, 7)
            if r % 6 == 0:
                sent += ["and", "Cupsey", "is", "here", "again."]
            elif r % 8 == 0:
                sent += ["dev", "sold", "chat."]
            else:
                sent[-1] += "."
            for w in sent:
                ws.append([t, t + 0.3, w, 0.9])
                t += 0.35
        _j.dump(ws, open(d / "words.json", "w"))
        dirs.append(str(d))
    r = lore.learn(dirs)
    assert [n["text"] for n in r["names"]] == ["Cupsey"]
    assert any(p["text"].startswith("dev sold") for p in r["phrases"])
    assert not any(p["text"] in ("market today", "thinking about") for p in r["phrases"])
    prof = lore.save({"streamer": "Test Guy", "names": ["Cupsey", "Cupsey"], "aliases": {"Cupsey": ["cups"]},
                      "phrases": ["dev sold"]})
    assert prof["names"] == ["Cupsey"] and lore.load("test guy")["streamer"] == "Test Guy"
    assert "Cupsey" in lore.vocab(prof) and lore.aliases(prof)["cups"] == ["Cupsey"]
    plain = find_candidates(demo["words"], demo["src"], demo["dir"], top_k=3)
    boosted = find_candidates(demo["words"], demo["src"], demo["dir"], top_k=3, lore=[r"market\s+cap"])
    assert any(c["tags"].get("lore") for c in boosted) and not any(c["tags"].get("lore") for c in plain)


def test_updater_versions_and_release(tmp_path):
    import zipfile
    from cb import updater
    assert updater._v("1.10.0") > updater._v("1.9.9") > updater._v("v1.2") == (1, 2, 0)
    assert updater.check(url="http://127.0.0.1:9/none.json")["available"] is False
    cur = updater.current_version()
    try:
        r = updater.release(str(tmp_path), "9.9.9", url="https://example.com/latest.json", notes="x")
    finally:
        open(updater.VERSION_FILE, "w").write(cur + "\n")
    z = zipfile.ZipFile(r["zip"])
    names = z.namelist()
    assert "clipbot/clipbot.py" in names and "clipbot/VERSION" in names
    assert not any(n.startswith("clipbot/.venv/") or "__pycache__" in n or n.endswith("ledger.jsonl") for n in names)
    assert json.loads(z.read("clipbot/config.json"))["update_url"] == "https://example.com/latest.json"
    m = json.load(open(r["manifest"]))
    assert m["version"] == "9.9.9" and len(m["sha256"]) == 64


def test_wetransfer_link_and_zip(demo, tmp_path, monkeypatch):
    """WeTransfer: short link -> /downloads/<id>/<hash> -> CSRF + POST -> direct link -> zip with the video."""
    import http.server
    import zipfile
    from cb import fetch
    real_is_wt = fetch.is_wetransfer
    z = tmp_path / "transfer.zip"
    with zipfile.ZipFile(z, "w") as zf:
        zf.writestr("notes.txt", "hi")
        zf.write(demo["src"], "folder/stream vod.mp4")
    seen = {}

    class H(http.server.BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def do_GET(self):
            if self.path.startswith("/t-short"):
                self.send_response(302)
                self.send_header("Location", base + "/downloads/abc123/sechash99")
                self.end_headers()
            elif self.path in ("/", "/downloads/abc123/sechash99"):
                b = b'<html><meta name="csrf-token" content="tok42"></html>'
                self.send_response(200)
                self.send_header("Set-Cookie", "wt_session=1")
                self.send_header("Content-Length", str(len(b)))
                self.end_headers()
                self.wfile.write(b)
            elif self.path == "/files/transfer.zip":
                data = z.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", "application/zip")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
            else:
                self.send_response(404)
                self.end_headers()

        def do_POST(self):
            body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
            seen.update(body=body, csrf=self.headers.get("X-CSRF-Token"), cookie=self.headers.get("Cookie"),
                        path=self.path)
            ok = body.get("security_hash") == "sechash99"
            out = json.dumps({"direct_link": base + "/files/transfer.zip"} if ok else {"message": "expired"}).encode()
            self.send_response(200)
            self.send_header("Content-Length", str(len(out)))
            self.end_headers()
            self.wfile.write(out)
    httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), H)
    base = "http://127.0.0.1:%d" % httpd.server_address[1]
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    monkeypatch.setattr(fetch, "WT_BASE", base)
    monkeypatch.setattr(fetch, "is_wetransfer", lambda u: u.startswith(base))
    try:
        p, kind, msg = fetch.download_direct(base + "/t-short", str(tmp_path / "w"))
        assert kind is None and p and probe(p)["duration"] > 60, msg
        assert seen["path"] == "/api/v4/transfers/abc123/download" and seen["csrf"] == "tok42"
        assert seen["body"] == {"intent": "entire_transfer", "security_hash": "sechash99"} and "wt_session" in seen["cookie"]
        p, kind, msg = fetch.download_direct(base + "/downloads/abc123/rcpt/badhash", str(tmp_path / "w2"))
        assert p is None and kind == "bad_link" and "WeTransfer" in msg and "expired" in msg
    finally:
        httpd.shutdown()
    assert real_is_wt("https://we.tl/t-abc") and real_is_wt("https://wetransfer.com/downloads/a/b")
    assert not real_is_wt("https://www.dropbox.com/s/x/y.mp4")


def test_publish_github_with_fake_gh(tmp_path):
    from cb import updater
    log = tmp_path / "gh_args.json"
    fake = tmp_path / "gh"
    fake.write_text("#!/usr/bin/env python3\nimport json,sys\njson.dump(sys.argv[1:], open(%r,'w'))\n" % str(log))
    fake.chmod(0o755)
    cur = updater.current_version()
    try:
        r = updater.publish_github("7.0.1", "me/clipbot-releases", notes="hello", gh=str(fake))
    finally:
        open(updater.VERSION_FILE, "w").write(cur + "\n")
    args = json.load(open(log))
    assert args[:3] == ["release", "create", "v7.0.1"] and "--latest" in args and "me/clipbot-releases" in args
    manifest = json.load(open([a for a in args if a.endswith("latest.json")][0]))
    assert manifest["zip"] == "https://github.com/me/clipbot-releases/releases/download/v7.0.1/clipbot-beta.zip"
    assert r["update_url"] == "https://github.com/me/clipbot-releases/releases/latest/download/latest.json"
    with pytest.raises(ValueError):
        updater.publish_github("1.0.0", "not a repo", gh=str(fake))


def test_streamer_signals_rank_reactions_over_housekeeping(demo, tmp_path):
    """Research-driven signals: 'chat clip that' reactions / awkward moments beat intros and 'hit follow'."""
    from cb.moments import find_candidates
    from cb.score import score_candidate
    lines = ["What's up chat, welcome back to the stream, make sure you hit follow.",
             "Let me know in the chat what we should play today, turn on notifications.",
             "Today's sponsor is a great energy drink, use my code at checkout.",
             "Okay so I queue up and the first guy I see is just standing there.",
             "And then he turns around and hits me with the craziest shot from across the map.",
             "Bro what, ain't no way, chat did you see that, somebody clip that right now.",
             "I'm actually crying, that is the most embarrassing thing that has ever happened to me.",
             "Are you kidding me, this game is rigged, I hate this so much.",
             "Anyway that's it for today, see you guys tomorrow, hit follow."]
    ws, t = [], 0.0
    for ln in lines:
        for w in ln.split():
            ws.append([round(t, 2), round(t + 0.3, 2), w, 0.95])
            t += 0.34
        t += 0.8
    z = np.zeros(int(t / 0.5) + 10)
    cands = find_candidates(ws, demo["src"], str(tmp_path), top_k=3, energy=(z, 0.5), min_len=8, max_len=25)
    best = cands[0]
    text = " ".join(s for _, s in best["sentences"]).lower()
    assert "clip that" in text and "welcome back" not in text
    assert best["tags"].get("reaction") and best["chrome"] == 0
    q = score_candidate(best)
    assert any("reaction" in w for w in q["why"])
    intro = find_candidates(ws[:40], demo["src"], str(tmp_path), top_k=1, energy=(z, 0.5), min_len=5, max_len=20)
    if intro:
        assert intro[0]["chrome"] >= 1 and score_candidate(intro[0])["score"] < q["score"]


def test_style_weights_and_similarity():
    from cb import style
    st = {"clips": 10, "dur": [20.0, 28.0, 40.0], "wps": 3.0,
          "share": {"reaction": 0.8, "rage": 0.0, "awkward": 0.1, "humor": 0.5, "drama": 0.0, "shock": 0.4,
                    "story": 0.2, "stakes": 0.3, "events": 0.0, "burst": 0.6}, "openers": {"reaction": 6, "plain": 4}}
    w = style.kind_weights(st)
    assert w["reaction"] == 1.6 and w["rage"] == 0.75 and 0.75 <= w["story"] <= 1.6
    assert style.kind_weights(dict(st, clips=3))["reaction"] < 1.6          # few examples -> gentler
    assert style.length_range(st) == (16.0, 50.0) and style.length_range(dict(st, clips=2)) is None
    assert "Learned from 10 clips" in style.describe(st) and "big reactions" in style.describe(st)

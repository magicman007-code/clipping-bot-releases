"""End-to-end + unit tests.  Run:  python -m pytest -q tests   (about 3-4 minutes, fully offline)."""
import io
import hashlib
import json
import os
import socket
import sys
import threading
import time
import urllib.request
import wave

import numpy as np
import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))

from cb import banner, moments, packaging, score  # noqa: E402
from cb.common import ffmpeg, probe  # noqa: E402


@pytest.fixture(scope="session")
def demo(tmp_path_factory):
    root = tmp_path_factory.mktemp("work")
    os.environ["CLIPBOT_WORK_ROOT"] = str(root)
    from cb.tools import demo as mk
    d = mk(str(root / "demo"))
    return {"root": str(root), "dir": d, "src": os.path.join(d, "source.mp4"),
            "words": json.load(open(os.path.join(d, "words.json")))}


# ---------------------------------------------------------------- moment finding
def test_lexicon_whole_words():
    rx = moments._rx(moments.LEX["humor"])
    assert not rx.findall("the market cap is two million you know")        # not "no cap"
    assert rx.findall("no cap that was hilarious")
    assert not moments._rx(moments.LEX["drama"]).findall("she applied for it")  # not "lied"


def test_candidates_snap_to_sentences_and_skip_filler(demo):
    cs = moments.find_candidates(demo["words"], demo["src"], demo["dir"], niche=("crypto",), top_k=4)
    assert cs, "no candidates"
    best = cs[0]
    assert best["sentences"][0][1].startswith(("So one time", "Wait")), best["sentences"][0]
    for c in cs:
        first = c["sentences"][0][1].lower()
        assert not first.startswith(("so um", "okay so um", "um")), first


def test_quality_bar(demo):
    cs = moments.find_candidates(demo["words"], demo["src"], demo["dir"], niche=("crypto",), top_k=6)
    scores = [score.score_candidate(c)["score"] for c in cs]
    assert max(scores) >= 6.0
    filler = {"tags": {}, "hook": -2, "payoff": 0, "payoff_mag": 0, "novelty": 0, "energy": 0, "dur": 30,
              "dead_air": 4, "asr_conf": 0.5, "filler": 0.5, "tail": False}
    assert score.score_candidate(filler)["score"] < 6.0


# ---------------------------------------------------------------- titles
def test_titles_never_splice_claims_across_sentences():
    ok, miss = packaging._supported("He lost ten million", "I lost eleven grand. Did that hit ten million?")
    assert not ok and miss
    ts = packaging.titles("Orangie bought this coin at 200K. Then Brez sold it. He lost 40K in ten minutes.")
    spec = [t for t in ts if t["style"] == "specific"][0]
    assert spec["title"].startswith("Orangie bought 200K") and spec["supported"]
    assert all("He's" not in t["title"] for t in ts)


# ---------------------------------------------------------------- banners
def test_banner_from_url_and_render():
    assert banner.from_url("https://kick.com/n3on") == {"platform": "kick", "handle": "n3on"}
    assert banner.from_url("https://www.twitch.tv/kaicenat", "socials")["platform"] == "twitch"
    assert banner.from_url("https://kick.com/videos") is None
    for b in ({"preset": "socials", "platform": "kick", "handle": "orangie"},
              {"preset": "kick_campaign", "handle": "orangie"}, {"preset": "twitch_tag", "handle": "xqc"}):
        p, w, h = banner.render_png(banner.resolve(b))
        assert os.path.exists(p) and 80 < w <= 1080 and 40 < h < 400


def test_banner_stays_in_safe_band():
    for layout, cap in (("auto", 1350), ("vertical", 1300), ("gameplay", 960), ("facecam_screen", 900)):
        x, y = banner.placement({"position": "auto"}, layout, [(0, 99, "tall", cap)], 300)
        assert banner.SAFE_TOP <= y <= banner.SAFE_BOTTOM, (layout, y)
        assert abs(y - cap) > 100, (layout, y, cap)


# ---------------------------------------------------------------- editing primitives
def test_tighten_removes_dead_air():
    from cb.render import tighten_pieces
    words = [[0.2, 0.5, "so", 1], [0.6, 0.9, "one", 1], [3.0, 3.3, "time", 1], [3.4, 3.6, "um", 1],
             [5.0, 5.3, "bro", 1]]
    pieces, removed = tighten_pieces([[0, 6]], words)
    assert removed > 2.5 and len(pieces) >= 2


def test_beat_tracker_on_click_track(tmp_path):
    from cb.montage_engine import analyze_music
    sr = 44100
    y = np.zeros(20 * sr)
    for k in range(40):
        i = int(k * 0.5 * sr)
        y[i:i + 200] += np.random.RandomState(k).randn(200) * 0.8
    p = str(tmp_path / "click.wav")
    w = wave.open(p, "wb")
    w.setnchannels(1)
    w.setsampwidth(2)
    w.setframerate(sr)
    w.writeframes((np.clip(y, -1, 1) * 32767).astype(np.int16).tobytes())
    w.close()
    g = analyze_music(p, str(tmp_path))
    assert abs(g["bpm"] - 120) < 1.5
    err = [min(abs(b - k * 0.5) for k in range(40)) for b in g["beats"]]
    assert np.median(err) < 0.03


# ---------------------------------------------------------------- render + verify + QC
def test_render_banner_audio_replace_and_qc(demo, tmp_path):
    from cb.render import make_clip
    from cb.verify import qc_load, qc_set
    tone = str(tmp_path / "tone.wav")
    os.system("ffmpeg -loglevel error -y -f lavfi -i sine=f=1000:d=30 %s" % tone)
    spec = {"name": "t1", "source": demo["src"], "start": 44.0, "end": 58.0, "headline": "He bought at $200K and it hit $10M",
            "captions": "box", "banner": {"preset": "socials", "platform": "kick", "handle": "orangie"},
            "audio_replace": {"path": tone, "mode": "replace", "volume": 1.0}}
    out = str(tmp_path / "out")
    res = make_clip(spec, out, str(tmp_path / "work"), {})
    pr = probe(res["out"])
    assert (pr["width"], pr["height"]) == (1080, 1920) and pr["has_audio"]
    assert res["verify"]["ok"], res["verify"]["defects"]
    assert any("banner" in x for x in res["layout_log"]) and any("audio replaced" in x for x in res["layout_log"])
    # the output's audio really is the 1 kHz replacement
    wav = str(tmp_path / "o.wav")
    os.system("ffmpeg -loglevel error -y -i %s -ac 1 -ar 16000 %s" % (res["out"], wav))
    w = wave.open(wav)
    x = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(float)
    f = np.argmax(np.abs(np.fft.rfft(x[16000:48000]))) * 16000 / 32000.0
    assert abs(f - 1000) < 20
    # human QC gate
    assert qc_load(out)["t1"]["status"] == "pending"
    with pytest.raises(ValueError):
        qc_set(out, "t1", "approved", watched=False)
    assert qc_set(out, "t1", "approved", watched=True)["status"] == "approved"


def test_autoclip_respects_bar(demo):
    from cb.autoclip import run
    st = run(demo["src"], demo["root"], "demo", clips=2, min_score=6.0, draft=True)
    assert st["state"] == "done", st
    assert st["clips"] and all(c.get("score", 0) >= 6.0 for c in st["clips"] if "score" in c)
    specs = json.load(open(os.path.join(demo["dir"], "specs.json")))
    assert any(s["name"].endswith("_clip") for s in specs)


# ---------------------------------------------------------------- editor server
def test_editor_api(demo):
    from cb import editor_server
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    threading.Thread(target=editor_server.serve, args=(demo["root"], port), daemon=True).start()
    time.sleep(1.0)
    base = "http://127.0.0.1:%d" % port
    j = json.load(urllib.request.urlopen(base + "/api/projects"))
    assert any(p["dir"] == demo["dir"] for p in j["projects"])
    html = urllib.request.urlopen(base + "/").read().decode()
    assert "Clipbot Studio" in html and "Auto-clip" in html and "acGo" in html and "tourNext" in html
    req = urllib.request.Request(base + "/media?path=" + demo["src"], headers={"Range": "bytes=0-99"})
    r = urllib.request.urlopen(req)
    assert r.status == 206 and len(r.read()) == 100
    with pytest.raises(urllib.error.HTTPError) as e:
        urllib.request.urlopen(base + "/media?path=/etc/passwd")
    assert e.value.code == 403
    body = json.dumps({"text": "Orangie bought this coin at 200K.", "headline": ""}).encode()
    t = json.load(urllib.request.urlopen(urllib.request.Request(base + "/api/titles", data=body,
                                                                headers={"Content-Type": "application/json", "X-Clipbot": "1"})))
    assert t["titles"]
    # hardening: other websites can't drive the editor
    for hdrs in ({"Content-Type": "text/plain"},                                  # classic CSRF form/fetch: no header
                 {"X-Clipbot": "1", "Origin": "https://evil.example"},            # wrong origin
                 {"X-Clipbot": "1", "Host": "evil.example:%s" % base.rsplit(":", 1)[1]}):   # DNS rebinding
        with pytest.raises(urllib.error.HTTPError) as e:
            urllib.request.urlopen(urllib.request.Request(base + "/api/titles", data=body, headers=hdrs))
        assert e.value.code == 403
    with pytest.raises(urllib.error.HTTPError) as e:
        urllib.request.urlopen(urllib.request.Request(base + "/api/projects", headers={"Host": "attacker.example"}))
    assert e.value.code == 403
    with pytest.raises(urllib.error.HTTPError) as e:
        urllib.request.urlopen(urllib.request.Request(base + "/api/titles", method="OPTIONS"))
    assert e.value.code == 405


def test_filter_paths_and_icons(tmp_path):
    """Paths with spaces/quotes/drive colons survive ffmpeg filter args; icons work offline from the bundle."""
    from cb.common import fpath
    assert "\\\\\\'s PC" in fpath("/Users/Bob's PC/a.ass")
    d = tmp_path / "it's a dir"
    d.mkdir()
    ass = d / "t.ass"
    ass.write_text("[Script Info]\nScriptType: v4.00+\nPlayResX: 64\nPlayResY: 64\n[V4+ Styles]\nFormat: Name, Fontname, "
                   "Fontsize\nStyle: Default,Anton,20\n[Events]\nFormat: Layer, Start, End, Style, Text\n")
    from cb.common import ffmpeg, FONT_DIR
    ffmpeg(["-f", "lavfi", "-i", "color=c=black:s=64x64:d=0.2", "-vf",
            "ass=filename=%s:fontsdir=%s" % (fpath(str(ass)), fpath(FONT_DIR)), str(d / "o.mp4")])
    assert (d / "o.mp4").exists()
    from cb.banner import brand_icon
    for p in ("kick", "twitch", "youtube"):
        assert brand_icon(p, 64, "#000000")


def test_editor_port_fallback():
    import socket
    import threading
    from cb import editor_server
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    busy = s.getsockname()[1]
    s.listen(1)
    got = {}
    orig = editor_server.ThreadingHTTPServer

    class Spy(orig):
        def serve_forever(self, *a, **k):
            got["port"] = self.server_address[1]
            self.server_close()
    editor_server.ThreadingHTTPServer = Spy
    try:
        t = threading.Thread(target=editor_server.serve, args=(os.path.dirname(__file__), busy))
        t.start()
        t.join(10)
    finally:
        editor_server.ThreadingHTTPServer = orig
        s.close()
    assert got["port"] != busy


def test_share_links_normalised():
    from cb.fetch import LinkError, direct_link
    d = direct_link("https://www.dropbox.com/scl/fi/abc123/stream.mp4?rlkey=xyz&e=1&dl=0")
    assert d.startswith("https://www.dropbox.com/scl/fi/abc123/stream.mp4?") and "dl=1" in d and "rlkey=xyz" in d
    assert "dl=1" in direct_link("https://dropbox.com/s/k3y/clip.mov?dl=0")
    with pytest.raises(LinkError):
        direct_link("https://www.dropbox.com/scl/fo/folderid/h?rlkey=1&dl=0")
    g = direct_link("https://drive.google.com/file/d/1AbCdEfGhIjKlMnOp/view?usp=sharing")
    assert g == "https://drive.usercontent.google.com/download?id=1AbCdEfGhIjKlMnOp&export=download&confirm=t"
    assert "id=1AbCdEfGhIjKlMnOp" in direct_link("https://drive.google.com/open?id=1AbCdEfGhIjKlMnOp")
    with pytest.raises(LinkError):
        direct_link("https://drive.google.com/drive/folders/1AbCdEfGhIjKlMnOp")
    assert direct_link("https://cdn.example.com/v/raw.MP4") == "https://cdn.example.com/v/raw.MP4"
    assert direct_link("https://www.youtube.com/watch?v=abc") is None and direct_link("https://kick.com/x") is None


def test_direct_download_from_http_server(demo, tmp_path):
    """A 'cloud' link served over HTTP downloads + validates; an HTML page is rejected with a clear reason."""
    import http.server
    import shutil
    from cb.fetch import download
    srv_dir = tmp_path / "srv"
    srv_dir.mkdir()
    shutil.copy(demo["src"], srv_dir / "video.mp4")
    (srv_dir / "page.mp4").write_text("<!DOCTYPE html><html>sign in</html>")
    h = lambda *a, **k: http.server.SimpleHTTPRequestHandler(*a, directory=str(srv_dir), **k)  # noqa: E731
    httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), h)
    httpd.RequestHandlerClass.log_message = lambda *a: None
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    base = "http://127.0.0.1:%d/" % httpd.server_address[1]
    try:
        p, kind, _ = download(base + "video.mp4", str(tmp_path / "a"))
        assert p and kind is None and probe(p)["duration"] > 60
        p, kind, msg = download(base + "page.mp4", str(tmp_path / "b"))
        assert p is None and kind == "bad_link" and "web page" in msg
    finally:
        httpd.shutdown()


def test_fonts_pack_and_upload(tmp_path):
    from cb import fonts
    fams = {f["family"] for f in fonts.list_fonts()}
    assert {"Anton", "Montserrat Black", "Bebas Neue", "Poppins ExtraBold"} <= fams and len(fams) >= 20
    assert fonts.resolve("montserrat") == "Montserrat Black" and fonts.resolve("bebas neue") == "Bebas Neue" and fonts.resolve("Nope Sans") == "Anton"
    from fontTools.ttLib import TTFont
    tt = TTFont(fonts.find("Bangers"))
    for r in tt["name"].names:
        if r.nameID in (1, 4):
            r.string = "My Brand Font"
    src = str(tmp_path / "brand.ttf")
    tt.save(src)
    got = fonts.add(src)
    assert got["family"] == "My Brand Font"
    assert any(f["family"] == "My Brand Font" and f["user"] for f in fonts.list_fonts())
    assert any(n.startswith("u_") for n in os.listdir(fonts.render_dir()))
    bad = str(tmp_path / "bad.ttf")
    open(bad, "wb").write(b"not a font")
    with pytest.raises(ValueError):
        fonts.add(bad)


def test_formatting_and_srt_match_captions(demo, tmp_path):
    from cb.render import build_ass, caption_cues, make_clip
    ws = [w for w in demo["words"] if 44.0 <= w[0] < 58.0]
    ws = [[w[0] - 44.0, w[1] - 44.0, w[2]] for w in ws]
    ass = str(tmp_path / "c.ass")
    look = {"bold": True, "italic": True, "spacing": 3, "color": "#00ff00", "outline_color": "#ff0000",
            "outline": "", "headline_font": "Bebas Neue", "caption_font_set": True}
    info = build_ass(ws, 14, "Test headline", [(0, 99, "x", 1300)], ass, cap_font="Poppins ExtraBold",
                     style="minimal", accent="#12abef", look=look)
    txt = open(ass).read()
    assert "Style: Cap,Poppins ExtraBold," in txt and ",-1,-1,0,0,100,100,3," in txt
    assert "&H0000FF00" in txt and "&H000000FF" in txt and "Style: Head,Bebas Neue," in txt
    assert len(caption_cues(ws, "minimal")) == info["caption_chunks"]
    info = build_ass(ws, 14, "", [(0, 99, "x", 1300)], ass, style="none")
    assert info["caption_chunks"] == 0 and ",Cap,," not in open(ass).read()
    spec = {"name": "s1", "source": demo["src"], "start": 44.0, "end": 58.0, "captions": "pro", "speed": 1.25,
            "caption_font": "Bebas Neue", "caption_bold": True}
    out = str(tmp_path / "out")
    res = make_clip(spec, out, str(tmp_path / "work"), {})
    srt = open(os.path.join(out, "s1.srt"), encoding="utf-8").read()
    cues = [b for b in srt.strip().split("\n\n") if "-->" in b]
    assert len(cues) == res["caption_chunks"] > 3
    last_end = cues[-1].split("\n")[1].split(" --> ")[1]
    h, m, rest = last_end.split(":")
    assert float(rest.replace(",", ".")) <= res["dur"] + 0.6


def test_aspect_ratios_and_extra_versions(demo, tmp_path):
    from cb.render import frame_geometry, make_clip, retarget
    assert frame_geometry(1920, 1080, 1080, 1080, have_face=True)[0] == "crop_x"
    assert frame_geometry(1920, 1080, 1080, 1080, have_face=False)[0] == "fit"
    assert frame_geometry(1920, 1080, 1920, 1080)[0] == "cover"
    assert frame_geometry(1080, 1920, 1920, 1080)[0] == "fit"
    assert frame_geometry(1080, 1350, 1080, 1080)[0] == "crop_y"
    sub = retarget({"name": "x", "aspect": "9:16", "caption_y": 1500, "texts": [{"x": 540, "y": 1600, "size": 100}],
                    "stickers": [{"x": 1000, "y": 1800, "w": 200}]}, "16:9")
    assert sub["name"] == "x_16x9" and "caption_y" not in sub
    assert sub["texts"][0]["x"] == 960 and sub["texts"][0]["y"] == 900 and sub["texts"][0]["size"] == 56
    assert sub["stickers"][0]["x"] <= 1920 and sub["stickers"][0]["y"] <= 1080
    spec = {"name": "sq", "source": demo["src"], "start": 44.0, "end": 52.0, "headline": "He bought at $200K",
            "banner": {"preset": "socials", "platform": "kick", "handle": "orangie"}, "aspect": "1:1",
            "also_aspects": ["16:9", "4:5"]}
    out = str(tmp_path / "out")
    res = make_clip(spec, out, str(tmp_path / "work"), {})
    assert res["size"] == "1080x1080" and res["verify"]["ok"], res["verify"]["defects"]
    sizes = {v["aspect"]: probe(v["out"]) for v in res["versions"]}
    assert (sizes["16:9"]["width"], sizes["16:9"]["height"]) == (1920, 1080)
    assert (sizes["4:5"]["width"], sizes["4:5"]["height"]) == (1080, 1350)
    assert os.path.exists(os.path.join(out, "sq_16x9.srt"))


def test_manual_import_mode(demo, tmp_path):
    """'Just import' opens a hand-editable project without auto-rendering anything; no banner/headline when off."""
    import shutil
    from cb.autoclip import run
    src = tmp_path / "mine.mp4"
    shutil.copy(demo["src"], src)
    shutil.copy(os.path.join(demo["dir"], "words.json"), tmp_path / "words.json")
    st = run(str(src), str(tmp_path / "root"), "mine", manual=True, banner=False, aspect="16:9")
    assert st["state"] == "done" and st["manual"] and st["clips"] == []
    specs = json.load(open(os.path.join(str(tmp_path / "root"), "mine", "specs.json")))
    assert len(specs) == 1 and specs[0]["aspect"] == "16:9" and specs[0]["banner"] is None and not specs[0]["headline"]
    assert not os.path.exists(os.path.join(str(tmp_path / "root"), "mine", "renders", "01_my_clip.mp4"))


def test_hardening_helpers(tmp_path, demo):
    from cb.autoclip import check_source, draft_headline
    from cb.transcribe import merge_number_tokens
    bad = tmp_path / "x.mp4"
    bad.write_text("nope")
    with pytest.raises(RuntimeError, match="Can't read this file"):
        check_source(str(bad))
    sil = str(tmp_path / "silent.mp4")
    ffmpeg(["-i", demo["src"], "-t", "8", "-an", "-c:v", "copy", sil])
    with pytest.raises(RuntimeError, match="no sound"):
        check_source(sil)
    assert check_source(sil, need_audio=False)["duration"] > 7
    assert [w[2] for w in merge_number_tokens([[0, 1, "$100", .9], [1, 1.2, ",000", .8], [2, 2.2, "40", .9],
                                                [2.2, 2.3, "%", .9]])] == ["$100,000", "40%"]
    assert draft_headline({"sentences": [(0, "thing completely insane."), (1, "So last week i bought it.")]}) \
        == "So last week I bought it"


def test_silent_video_render_mute_and_loudness(demo, tmp_path):
    """A video with no audio track still renders; mute ranges silence the voice; loudness lands on target."""
    from cb.render import make_clip, output_loudness
    sil = str(tmp_path / "silent.mp4")
    ffmpeg(["-i", demo["src"], "-t", "20", "-an", "-c:v", "copy", sil])
    res = make_clip({"name": "s", "source": sil, "start": 2, "end": 10, "captions": "none"}, str(tmp_path / "o"),
                    str(tmp_path / "w"), {})
    assert probe(res["out"])["has_audio"]
    res = make_clip({"name": "m", "source": demo["src"], "start": 44, "end": 54, "mute_ranges": [[0, 9.9]]},
                    str(tmp_path / "o"), str(tmp_path / "w"), {})
    i, _ = output_loudness(res["out"])
    assert i is None or i < -40          # (almost) everything muted
    res = make_clip({"name": "n", "source": demo["src"], "start": 44, "end": 54}, str(tmp_path / "o"),
                    str(tmp_path / "w"), {})
    i, _ = output_loudness(res["out"])
    assert abs(i + 14) <= 1.2, i


def test_prompt_clipping_keywords_and_meaning(demo, monkeypatch):
    """Prompt search finds the right line; works by keywords even when the meaning model is unavailable."""
    from cb import semantic
    from cb.prompt_clip import find, plan
    words = demo["words"]
    p = plan("every time he talks about the $10M coin, funny moments")
    assert p["all"] and "humor" in p["intents"] and "coin" in p["keywords"]
    monkeypatch.setattr(semantic, "available", lambda: False)
    c, info = find("when he says the market cap", words, demo["src"], demo["dir"], n=3)
    assert c and info["method"][0] == "keywords"
    assert "market cap" in c[0]["match"].lower() and c[0]["relevance"] >= 0.5
    assert c[0]["start"] <= c[0]["match_at"] <= c[0]["end"] and c[0]["rank"] == 1 and "quality" in c[0]
    c, info = find("basketball tournament", words, demo["src"], demo["dir"], n=3)
    assert c == []


def test_lore_learn_save_and_scoring(demo, tmp_path):
    import json as _j
    import random
    from cb import lore
    from cb.moments import find_candidates
    random.seed(3)
    filler = "so anyway I was thinking about the market today and honestly it looks pretty good".split()
    dirs = []
    for k in range(3):
        d = tmp_path / ("s%d" % k)
        d.mkdir()
        ws, t = [], 0.0
        for r in range(50):
            sent = random.sample(filler, 7)
            if r % 6 == 0:
                sent += ["and", "Cupsey", "is", "here", "again."]
            elif r % 8 == 0:
                sent += ["dev", "sold", "chat."]
            else:
                sent[-1] += "."
            for w in sent:
                ws.append([t, t + 0.3, w, 0.9])
                t += 0.35
        _j.dump(ws, open(d / "words.json", "w"))
        dirs.append(str(d))
    r = lore.learn(dirs)
    assert [n["text"] for n in r["names"]] == ["Cupsey"]
    assert any(p["text"].startswith("dev sold") for p in r["phrases"])
    assert not any(p["text"] in ("market today", "thinking about") for p in r["phrases"])
    prof = lore.save({"streamer": "Test Guy", "names": ["Cupsey", "Cupsey"], "aliases": {"Cupsey": ["cups"]},
                      "phrases": ["dev sold"]})
    assert prof["names"] == ["Cupsey"] and lore.load("test guy")["streamer"] == "Test Guy"
    assert "Cupsey" in lore.vocab(prof) and lore.aliases(prof)["cups"] == ["Cupsey"]
    plain = find_candidates(demo["words"], demo["src"], demo["dir"], top_k=3)
    boosted = find_candidates(demo["words"], demo["src"], demo["dir"], top_k=3, lore=[r"market\s+cap"])
    assert any(c["tags"].get("lore") for c in boosted) and not any(c["tags"].get("lore") for c in plain)


def test_updater_versions_and_release(tmp_path):
    import zipfile
    from cb import updater
    assert updater._v("1.10.0") > updater._v("1.9.9") > updater._v("v1.2") == (1, 2, 0)
    assert updater.check(url="http://127.0.0.1:9/none.json")["available"] is False
    cur = updater.current_version()
    try:
        r = updater.release(str(tmp_path), "9.9.9", url="https://example.com/latest.json", notes="x")
    finally:
        open(updater.VERSION_FILE, "w").write(cur + "\n")
    z = zipfile.ZipFile(r["zip"])
    names = z.namelist()
    assert "clipbot/clipbot.py" in names and "clipbot/VERSION" in names
    assert not any(n.startswith("clipbot/.venv/") or "__pycache__" in n or n.endswith("ledger.jsonl") for n in names)
    assert json.loads(z.read("clipbot/config.json"))["update_url"] == "https://example.com/latest.json"
    m = json.load(open(r["manifest"]))
    assert m["version"] == "9.9.9" and len(m["sha256"]) == 64


def test_wetransfer_link_and_zip(demo, tmp_path, monkeypatch):
    """WeTransfer: short link -> /downloads/<id>/<hash> -> CSRF + POST -> direct link -> zip with the video."""
    import http.server
    import zipfile
    from cb import fetch
    real_is_wt = fetch.is_wetransfer
    z = tmp_path / "transfer.zip"
    with zipfile.ZipFile(z, "w") as zf:
        zf.writestr("notes.txt", "hi")
        zf.write(demo["src"], "folder/stream vod.mp4")
    seen = {}

    class H(http.server.BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def do_GET(self):
            if self.path.startswith("/t-short"):
                self.send_response(302)
                self.send_header("Location", base + "/downloads/abc123/sechash99")
                self.end_headers()
            elif self.path in ("/", "/downloads/abc123/sechash99"):
                b = b'<html><meta name="csrf-token" content="tok42"></html>'
                self.send_response(200)
                self.send_header("Set-Cookie", "wt_session=1")
                self.send_header("Content-Length", str(len(b)))
                self.end_headers()
                self.wfile.write(b)
            elif self.path == "/files/transfer.zip":
                data = z.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", "application/zip")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
            else:
                self.send_response(404)
                self.end_headers()

        def do_POST(self):
            body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
            seen.update(body=body, csrf=self.headers.get("X-CSRF-Token"), cookie=self.headers.get("Cookie"),
                        path=self.path)
            ok = body.get("security_hash") == "sechash99"
            out = json.dumps({"direct_link": base + "/files/transfer.zip"} if ok else {"message": "expired"}).encode()
            self.send_response(200)
            self.send_header("Content-Length", str(len(out)))
            self.end_headers()
            self.wfile.write(out)
    httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), H)
    base = "http://127.0.0.1:%d" % httpd.server_address[1]
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    monkeypatch.setattr(fetch, "WT_BASE", base)
    monkeypatch.setattr(fetch, "is_wetransfer", lambda u: u.startswith(base))
    try:
        p, kind, msg = fetch.download_direct(base + "/t-short", str(tmp_path / "w"))
        assert kind is None and p and probe(p)["duration"] > 60, msg
        assert seen["path"] == "/api/v4/transfers/abc123/download" and seen["csrf"] == "tok42"
        assert seen["body"] == {"intent": "entire_transfer", "security_hash": "sechash99"} and "wt_session" in seen["cookie"]
        p, kind, msg = fetch.download_direct(base + "/downloads/abc123/rcpt/badhash", str(tmp_path / "w2"))
        assert p is None and kind == "bad_link" and "WeTransfer" in msg and "expired" in msg
    finally:
        httpd.shutdown()
    assert real_is_wt("https://we.tl/t-abc") and real_is_wt("https://wetransfer.com/downloads/a/b")
    assert not real_is_wt("https://www.dropbox.com/s/x/y.mp4")


def test_publish_to_repo_files(tmp_path):
    """clipbot publish: zip + latest.json committed to the downloads repo (a local bare repo stands in for GitHub)."""
    import subprocess as sp
    from cb import updater
    bare = tmp_path / "releases.git"
    sp.run(["git", "init", "-q", "--bare", "-b", "main", str(bare)], check=True)
    cur = updater.current_version()
    try:
        r = updater.publish_github("7.0.1", "me/clipbot-releases", notes="hello", workdir=str(tmp_path / "wd"),
                                   remote=str(bare), feedback_url="https://script.google.com/macros/s/x/exec")
        r2 = updater.publish_github("7.0.2", "me/clipbot-releases", workdir=str(tmp_path / "wd"), remote=str(bare))
    finally:
        open(updater.VERSION_FILE, "w").write(cur + "\n")
    assert r["update_url"] == "https://raw.githubusercontent.com/me/clipbot-releases/main/latest.json"
    log = sp.run(["git", "--git-dir", str(bare), "log", "--oneline", "main"], capture_output=True, text=True).stdout
    assert "Clipbot 7.0.2" in log and "Clipbot 7.0.1 - hello" in log
    m = json.loads(sp.run(["git", "--git-dir", str(bare), "show", "main:latest.json"], capture_output=True, text=True).stdout)
    assert m["version"] == "7.0.2" and m["zip"] == "https://github.com/me/clipbot-releases/raw/main/clipbot-beta.zip"
    assert r2["sha256"] == m["sha256"]
    with pytest.raises(ValueError):
        updater.publish_github("1.0.0", "not a repo")


def test_streamer_signals_rank_reactions_over_housekeeping(demo, tmp_path):
    """Research-driven signals: 'chat clip that' reactions / awkward moments beat intros and 'hit follow'."""
    from cb.moments import find_candidates
    from cb.score import score_candidate
    lines = ["What's up chat, welcome back to the stream, make sure you hit follow.",
             "Let me know in the chat what we should play today, turn on notifications.",
             "Today's sponsor is a great energy drink, use my code at checkout.",
             "Okay so I queue up and the first guy I see is just standing there.",
             "And then he turns around and hits me with the craziest shot from across the map.",
             "Bro what, ain't no way, chat did you see that, somebody clip that right now.",
             "I'm actually crying, that is the most embarrassing thing that has ever happened to me.",
             "Are you kidding me, this game is rigged, I hate this so much.",
             "Anyway that's it for today, see you guys tomorrow, hit follow."]
    ws, t = [], 0.0
    for ln in lines:
        for w in ln.split():
            ws.append([round(t, 2), round(t + 0.3, 2), w, 0.95])
            t += 0.34
        t += 0.8
    z = np.zeros(int(t / 0.5) + 10)
    cands = find_candidates(ws, demo["src"], str(tmp_path), top_k=3, energy=(z, 0.5), min_len=8, max_len=25)
    best = cands[0]
    text = " ".join(s for _, s in best["sentences"]).lower()
    assert "clip that" in text and "welcome back" not in text
    assert best["tags"].get("reaction") and best["chrome"] == 0
    q = score_candidate(best)
    assert any("reaction" in w for w in q["why"])
    intro = find_candidates(ws[:40], demo["src"], str(tmp_path), top_k=1, energy=(z, 0.5), min_len=5, max_len=20)
    if intro:
        assert intro[0]["chrome"] >= 1 and score_candidate(intro[0])["score"] < q["score"]


def test_style_weights_and_similarity():
    from cb import style
    st = {"clips": 10, "dur": [20.0, 28.0, 40.0], "wps": 3.0,
          "share": {"reaction": 0.8, "rage": 0.0, "awkward": 0.1, "humor": 0.5, "drama": 0.0, "shock": 0.4,
                    "story": 0.2, "stakes": 0.3, "events": 0.0, "burst": 0.6}, "openers": {"reaction": 6, "plain": 4}}
    w = style.kind_weights(st)
    assert w["reaction"] == 1.6 and w["rage"] == 0.75 and 0.75 <= w["story"] <= 1.6
    assert style.kind_weights(dict(st, clips=3))["reaction"] < 1.6          # few examples -> gentler
    assert style.length_range(st) == (16.0, 50.0) and style.length_range(dict(st, clips=2)) is None
    assert "Learned from 10 clips" in style.describe(st) and "big reactions" in style.describe(st)


def test_vod_links_times_and_errors(monkeypatch, tmp_path):
    from cb import fetch
    v = fetch.vod_url
    assert v("https://www.twitch.tv/videos/2283491234?t=1h2m3s")[0] == "https://www.twitch.tv/videos/2283491234"
    assert v("twitch.tv/videos/123")[0] == "https://www.twitch.tv/videos/123"
    assert v("https://m.twitch.tv/videos/555")[0] == "https://www.twitch.tv/videos/555"
    assert v("https://player.twitch.tv/?video=v777&parent=x")[0] == "https://www.twitch.tv/videos/777"
    assert v("https://kick.com/xqc/videos/0b5c3c1e-1234-4abc-9def-0123456789ab")[0] == \
        "https://kick.com/xqc/videos/0b5c3c1e-1234-4abc-9def-0123456789ab"
    url, note = v("https://kick.com/video/0b5c3c1e-1234-4abc-9def-0123456789ab")
    assert note and "Videos page" in note
    assert fetch.parse_time("1:02:03") == 3723 and fetch.parse_time("62:03") == 3723
    assert fetch.parse_time("1h2m3s") == 3723 and fetch.parse_time("90") == 90 and fetch.parse_time("") is None
    assert fetch.hms(3723) == "1:02:03"
    cases = {"ERROR: [twitch:vod] 123: This video is only available to subscribers": "sub_only",
             "ERROR: [twitch:vod] 9: Video 9 does not exist": "gone",
             "ERROR: [kick:vod] x: HTTP Error 403: Forbidden (caused by Cloudflare)": "blocked"}
    for err, want in cases.items():
        class R:
            returncode, stderr, stdout = 1, err, ""
        monkeypatch.setattr(fetch, "run", lambda *a, **k: R())
        monkeypatch.setattr(fetch, "update_ytdlp", lambda: False)
        p, kind, msg = fetch.download("https://www.twitch.tv/videos/123", str(tmp_path / want))
        assert p is None and kind == want and want in fetch.FRIENDLY


def test_vod_section_download_and_trim(demo, tmp_path):
    """Only part of a long video: yt-dlp downloads just the section; local files are trimmed once."""
    import http.server
    import shutil
    from cb.autoclip import run
    from cb.fetch import download
    srv = tmp_path / "srv"
    srv.mkdir()
    # an HLS VOD like Twitch/Kick serve (playlist + segments), downloaded through yt-dlp
    ffmpeg(["-i", demo["src"], "-c:v", "libx264", "-preset", "ultrafast", "-g", "60", "-c:a", "aac", "-f", "hls",
            "-hls_time", "4", "-hls_playlist_type", "vod", str(srv / "index.m3u8")])
    h = lambda *a, **k: http.server.SimpleHTTPRequestHandler(*a, directory=str(srv), **k)  # noqa: E731
    httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), h)
    httpd.RequestHandlerClass.log_message = lambda *a: None
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    try:
        p, kind, msg = download("http://127.0.0.1:%d/index.m3u8" % httpd.server_address[1], str(tmp_path / "dl"),
                                section=(10, 40))
        assert p and kind is None, msg
        assert 25 <= probe(p)["duration"] <= 36
    finally:
        httpd.shutdown()
    src = tmp_path / "long.mp4"
    shutil.copy(demo["src"], src)
    shutil.copy(os.path.join(demo["dir"], "words.json"), tmp_path / "words.json")
    st = run(str(src), str(tmp_path / "root"), "part", manual=True, section=(20.0, 50.0))
    assert st["state"] == "done"
    d = os.path.join(str(tmp_path / "root"), "part")
    assert 28 <= probe(os.path.join(d, "source.mp4"))["duration"] <= 38      # keyframe-aligned fast cut


def test_downloader_self_updates_once(monkeypatch, tmp_path):
    from cb import fetch
    calls = {"n": 0, "upd": 0}

    class R:
        returncode, stdout = 1, ""
        stderr = "ERROR: [youtube] abc: nsig extraction failed: Some formats may be missing"

    def fake_run(cmd, **k):
        calls["n"] += 1
        if calls["upd"]:             # after the update the download "works"
            open(os.path.join(str(tmp_path / "yt"), "source.mp4"), "wb").write(b"x")
            R.returncode = 0
        return R()
    monkeypatch.setattr(fetch, "run", fake_run)
    monkeypatch.setattr(fetch, "update_ytdlp", lambda: calls.__setitem__("upd", calls["upd"] + 1) or True)
    monkeypatch.setattr(fetch, "_ensure_mp4_with_audio", lambda src, wd: src)
    monkeypatch.setattr(fetch, "_find_source", lambda wd: os.path.join(wd, "source.mp4")
                        if os.path.exists(os.path.join(wd, "source.mp4")) else None)
    p, kind, msg = fetch.download("https://www.youtube.com/watch?v=abc", str(tmp_path / "yt"))
    assert p and kind is None and calls["upd"] == 1
    assert fetch.js_runtime() is None or fetch.js_runtime().split(":")[0] in ("deno", "node", "bun")


def test_learning_loop_and_insights(tmp_path, monkeypatch):
    from cb import learn
    monkeypatch.setattr(learn, "_dir", lambda: str(tmp_path))

    def spec(i, tags, dur=30):
        return {"name": "c%d" % i, "start": 0, "end": dur, "orig": [0, dur - 3], "headline": "h", "headline_orig": "h",
                "candidate": {"tags": {t: 1 for t in tags}, "sentences": [[0, "secret words"]]},
                "quality": {"score": 7.0, "parts": {"hook": 2}}}
    for i in range(6):
        learn.record("rated", spec(i, ["reaction"]), "/p", rating=1, reasons=["great_hook"])
    for i in range(6, 12):
        learn.record("rated", spec(i, ["story"]), "/p", rating=-1, reasons=["slow_start"])
    for i in range(12, 18):
        learn.record("rendered", spec(i, ["reaction"]), "/p")
    L = learn.learned()
    assert L["active"] and L["labelled"] == 18
    assert L["adjust"]["kind_w"]["reaction"] > 1.0 > L["adjust"]["kind_w"]["story"]
    assert L["adjust"]["hook_boost"] == 1.3 and L["trim"]["end"] == 3.0 and L["adjust"]["len_shift"] >= 1.5
    text = " ".join(learn.insights(L))
    assert "big reactions" in text and "extend the ending" in text and "slow start" in text
    rep = learn.build_report(include_text=False)
    assert rep["events"] and all("_text" not in e for e in rep["events"]) and "secret" not in json.dumps(rep)
    assert "secret" in json.dumps(learn.build_report(include_text=True))


def test_connections_feedback_and_webhook(tmp_path, monkeypatch):
    import http.server
    from cb import connect, learn
    monkeypatch.setattr(connect, "_path", lambda: str(tmp_path / "connections.json"))
    monkeypatch.setattr(learn, "_dir", lambda: str(tmp_path / "learn"))
    os.makedirs(str(tmp_path / "learn"))
    got = []

    class H(http.server.BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def do_POST(self):
            got.append((self.path, json.loads(self.rfile.read(int(self.headers["Content-Length"])))))
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b'{"ok":true}')
    httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), H)
    base = "http://127.0.0.1:%d" % httpd.server_address[1]
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    try:
        with pytest.raises(ValueError):
            connect.save({"webhook": {"url": "ftp://nope"}})
        r = connect.save({"ai": {"provider": "anthropic", "key": "sk-ant-secret-1234", "model": "m"},
                          "webhook": {"url": base + "/hook", "events": ["clip_rendered"]},
                          "feedback": {"enabled": True, "url": base + "/report"}})
        assert r["ai"]["key"] == "" and r["ai"]["key_hint"] == "…1234"
        connect.save({"ai": {"key": ""}})                     # blank = keep the stored key
        assert connect.get()["ai"]["key"] == "sk-ant-secret-1234" and connect.ai_ready()
        assert connect.fire("clip_rendered", {"name": "c1", "title": "t"}) and not connect.fire("other", {})
        learn.record("rated", {"name": "x", "start": 0, "end": 20}, "/p", rating=1)
        assert learn.send_report(force=True)["sent"]
        import time as _t
        for _ in range(50):
            if len(got) >= 2:
                break
            _t.sleep(0.1)
        paths = sorted(p for p, _ in got)
        assert paths == ["/hook", "/report"]
        rep = [b for p, b in got if p == "/report"][0]
        assert rep["app"] == "clipbot" and rep["events"][0]["kind"] == "rated" and "summary" in rep
        assert "sk-ant" not in json.dumps(rep)
    finally:
        httpd.shutdown()


def test_ai_rerank_uses_learning_and_learns_its_weight(tmp_path, monkeypatch):
    from cb import ai_rank, learn
    monkeypatch.setattr(learn, "_dir", lambda: str(tmp_path))

    def spec(i, ai, rating):
        return {"name": "c%d" % i, "start": 0, "end": 30,
                "candidate": {"tags": {"reaction": 1}, "sentences": [[0, "liked words %d" % i if rating > 0 else "boring words %d" % i]],
                              "ai_score": ai}, "quality": {"score": 7.0}}
    # the AI's favourites are the ones this user keeps -> its weight goes up
    for i in range(6):
        learn.record("rated", spec(i, 9, 1), "/p", rating=1, reasons=["great_payoff"])
    for i in range(6, 12):
        learn.record("rated", spec(i, 3, -1), "/p", rating=-1, reasons=["not_funny"])
    L = learn.learned()
    assert L["ai"]["clips"] == 12 and L["ai"]["keep_high"] > L["ai"]["keep_low"]
    assert L["ai"]["weight"] > ai_rank.DEFAULT_W
    assert "your AI rated highly" in " ".join(learn.insights(L))

    cands = [{"start": i * 40, "end": i * 40 + 30, "quality": {"score": s}, "sentences": [[0, t]]}
             for i, (s, t) in enumerate([(8.0, "a plain bit"), (7.0, "the best moment ever"), (6.5, "meh")])]
    seen = {}

    def fake(msg, system="", max_tokens=0):
        seen["msg"] = msg
        return 'Sure: [{"id": 0, "score": 3, "why": "no payoff"}, {"id": 1, "score": 10, "why": "huge reaction"}, ' \
               '{"id": 2, "score": 99}]'
    info = ai_rank.rerank(cands, streamer="Tester", prof={"names": ["Orangie"], "notes": "loves coins"},
                          complete=fake, weight=0.5)
    assert info["used"] and info["scored"] == 2               # out-of-range score ignored
    assert cands[0]["sentences"][0][1] == "the best moment ever" and cands[0]["ai"]["why"] == "huge reaction"
    m = seen["msg"]
    assert "Orangie" in m and "loves coins" in m and "Tester" in m
    assert "LIKED" in m and "liked words" in m and "REJECTED" in m and "not funny" in m   # learned taste goes in
    # unreadable answer or failure: order untouched, never raises
    c2 = [dict(c) for c in cands]
    assert not ai_rank.rerank(c2, complete=lambda *a, **k: "no idea", weight=0.5)["used"]
    assert not ai_rank.rerank(c2, complete=lambda *a, **k: (_ for _ in ()).throw(RuntimeError("rate limited")), weight=0.5)["used"]
    assert [c["start"] for c in c2] == [c["start"] for c in cands]
    # feature carried into learning
    assert learn.features({"candidate": {"ai_score": 8.5}, "start": 0, "end": 10})["ai_score"] == 8.5


def test_autoclip_with_ai_second_opinion(demo, monkeypatch, tmp_path):
    from cb import connect
    from cb.autoclip import run
    monkeypatch.setattr(connect, "_path", lambda: str(tmp_path / "connections.json"))
    connect.save({"ai": {"provider": "anthropic", "key": "sk-test", "model": "m"}})
    calls = []

    def fake(msg, system="", max_tokens=0, timeout=0):
        calls.append(msg)
        n = msg.count("\n#") + (1 if msg.startswith("#") else 0)
        return json.dumps([{"id": i, "score": 10 - i, "why": "pick %d" % i} for i in range(n)])
    monkeypatch.setattr(connect, "ai_complete", fake)
    st = run(demo["src"], demo["root"], "demo_ai", clips=2, min_score=6.0, draft=True)
    assert st["state"] == "done" and calls, st
    assert st["ai_rank"]["used"], st["ai_rank"]
    specs = [s for s in json.load(open(os.path.join(demo["root"], "demo_ai", "specs.json"))) if s["name"].endswith("_clip")]
    assert specs and all(s["candidate"]["ai_score"] is not None and s["candidate"]["ai_why"] for s in specs)
    assert all(s["quality"]["score"] >= 6.0 for s in specs)          # the AI can't push a clip under the bar in
    connect.save({"ai": {"rerank": False}})
    calls.clear()
    st = run(demo["src"], demo["root"], "demo_ai2", clips=1, min_score=6.0, draft=True)
    assert st["state"] == "done" and not calls and not st.get("ai_rank")


def test_chat_replay_formats_and_spike_signal(demo, tmp_path):
    import random
    from cb import chat, moments
    random.seed(3)
    sents = moments.sentences_from_words(demo["words"])
    hot = sents[len(sents) // 2]                     # chat explodes right after this line
    msgs = [(t + random.random(), "chatting") for t in range(int(demo["words"][-1][1]) + 20) for _ in range(2)]
    msgs += [(hot["end"] + 2 + random.random() * 5, random.choice(["KEKW", "LUL", "LMAO 💀", "OMEGALUL"])) for _ in range(120)]
    msgs.sort()
    # TwitchDownloader json, YouTube live_chat.json, plain text all read the same
    td = tmp_path / "td.json"
    td.write_text(json.dumps({"comments": [{"content_offset_seconds": t, "message": {"body": b}} for t, b in msgs]}))
    yt = tmp_path / "yt.json"
    yt.write_text("\n".join(json.dumps({"replayChatItemAction": {"videoOffsetTimeMsec": str(int(t * 1000)), "actions": [
        {"addChatItemAction": {"item": {"liveChatTextMessageRenderer": {"message": {"runs": [{"text": b}]}}}}}]}})
        for t, b in msgs))
    tx = tmp_path / "c.txt"
    tx.write_text("0:01:23, W\n[1:02:03] KEKW lol\n12.5\thello\n")
    assert len(chat.parse(str(td))) == len(chat.parse(str(yt))) == len(msgs)
    assert chat.parse(str(tx)) == [(12.5, "hello"), (83.0, "W"), (3723.0, "KEKW lol")]
    with pytest.raises(ValueError):
        (tmp_path / "bad.json").write_text('{"nope": 1}')
        chat.parse(str(tmp_path / "bad.json"))
    act = chat.Activity(chat.parse(str(td)))
    z, mood = act.reaction(hot["start"], hot["end"])
    assert z >= 3 and mood == "laugh"
    assert act.reaction(sents[1]["start"], sents[1]["end"])[0] < 3 or sents[1] is hot
    # sections: offsets shift
    assert chat.shift([(100.0, "a"), (50.0, "b")], 60.0, 100) == [(40.0, "a")]
    # the moment with the chat explosion gets the chat tag, a reason, and ranks up
    cands = moments.find_candidates(demo["words"], demo["src"], demo["dir"], top_k=50, chat=act, pick=False)
    with_chat = [c for c in cands if c["tags"].get("chat")]
    # credited to lines just before the explosion (chat lags 1-10 s), never to distant ones
    assert with_chat and all(c["end"] >= hot["end"] - 8 and c["start"] <= hot["end"] for c in with_chat)
    assert len(with_chat) < len(cands)
    from cb.score import score_candidate
    q = score_candidate(with_chat[0])
    assert any("chat exploded" in w and "laughing" in w for w in q["why"])
    # autoclip picks the chat file up from the project folder and reports it
    d = os.path.join(demo["root"], "demo_chat")
    os.makedirs(d, exist_ok=True)
    from cb.autoclip import run
    st = run(demo["src"], demo["root"], "demo_chat", clips=1, min_score=0, render=False, chat_file=str(td))
    assert st["chat"]["used"] and st["chat"]["messages"] == len(msgs)
    specs = json.load(open(os.path.join(d, "specs.json")))
    assert "chat_z" in specs[0]["candidate"]


def test_channel_watch_settles_before_clipping(tmp_path, monkeypatch):
    from cb import watch
    monkeypatch.setattr(watch, "_path", lambda: str(tmp_path / "watches.json"))
    assert watch.channel("twitch.tv/SomeStreamer/videos")[:2] == ("twitch", "https://www.twitch.tv/somestreamer")
    assert watch.channel("https://kick.com/abc")[0] == "kick"
    assert watch.channel("https://www.youtube.com/@Handle")[1] == "https://www.youtube.com/@Handle"
    with pytest.raises(ValueError):
        watch.channel("https://www.twitch.tv/videos/123")
    feed = {"entries": [{"id": "v100", "title": "old stream", "duration": 3600}]}
    lister = lambda url, n, cfg: list(feed["entries"])            # noqa: E731
    w = watch.add("https://www.twitch.tv/somestreamer", clips=3, _lister=lister)
    assert w["seen"] == ["tw100"]                                  # backlog skipped
    with pytest.raises(ValueError):
        watch.add("twitch.tv/somestreamer", _lister=lister)
    done = []
    clipper = lambda v, w: done.append(v["url"]) or {"project": "/p"}  # noqa: E731
    feed["entries"].insert(0, {"id": "v101", "title": "live now", "duration": 1200})
    assert watch.check(clipper, _lister=lister) == [] and not done       # first sighting: wait
    feed["entries"][0]["duration"] = 2400                                  # still growing (stream live)
    assert watch.check(clipper, _lister=lister) == [] and not done
    assert watch.check(clipper, _lister=lister) and done == ["https://www.twitch.tv/videos/101"]  # settled
    assert watch.check(clipper, _lister=lister) == [] and len(done) == 1   # never twice
    w = watch.load()[0]
    assert w["done"][-1]["title"] == "live now" and w["error"] is None
    def broken(url, n, cfg):
        raise RuntimeError("Twitch said no")
    watch.check(clipper, _lister=broken)
    assert "Twitch said no" in watch.load()[0]["error"]
    # latest=True: the newest finished VOD is clipped on the next check
    watch.add("https://kick.com/abc", latest=True, _lister=lambda u, n, c: [{"id": "u1", "url": "https://kick.com/abc/videos/u1", "duration": 99}])
    got = []
    watch.check(lambda v, w: got.append(v["id"]), _lister=lambda u, n, c: (
        [{"id": "u1", "url": "https://kick.com/abc/videos/u1", "duration": 99}] if "kick" in u else list(feed["entries"])))
    assert got == ["kku1"]
    assert watch.remove("https://kick.com/abc") == 1 and len(watch.load()) == 1


def test_outside_scorer_presets_and_run_reports(tmp_path, monkeypatch):
    import http.server
    from cb import ai_rank, connect, learn
    monkeypatch.setattr(connect, "_path", lambda: str(tmp_path / "connections.json"))
    monkeypatch.setattr(learn, "_dir", lambda: str(tmp_path / "learn"))
    os.makedirs(str(tmp_path / "learn"))
    seen = []

    class H(http.server.BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def do_POST(self):
            req = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
            seen.append((self.headers.get("Authorization"), req))
            out = [{"id": c["id"], "score": 9.5 if "jackpot" in c["text"] else 2, "why": "jackpot"} for c in req["candidates"]]
            self.send_response(200)
            self.end_headers()
            self.wfile.write(json.dumps({"scores": out + [{"id": 99, "score": 5}]}).encode())
    httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), H)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    try:
        connect.save({"scorer": {"url": "http://127.0.0.1:%d/score" % httpd.server_address[1], "token": "tok-secret-9", "weight": 0.5}})
        assert connect.redacted()["scorer"]["token"] == "" and connect.redacted()["scorer"]["token_hint"] == "…et-9"
        cands = [{"start": 0, "end": 20, "quality": {"score": 8.0}, "sentences": [[0, "boring bit"]], "tags": {}},
                 {"start": 30, "end": 50, "quality": {"score": 7.0}, "sentences": [[30, "he hit the jackpot"]], "tags": {"reaction": 1}}]
        info = ai_rank.external(cands)
        assert info["used"] and info["scored"] == 2 and info["weight"] == 0.5
        assert cands[0]["ext"]["why"] == "jackpot" and seen[0][0] == "Bearer tok-secret-9"
        assert seen[0][1]["candidates"][1]["tags"] == ["reaction"]
    finally:
        httpd.shutdown()
    assert not ai_rank.external([dict(cands[0])])["used"]                 # scorer down -> skipped, no crash
    with pytest.raises(ValueError):
        connect.save({"scorer": {"url": "ftp://x"}})
    # local AI (Ollama) needs no key; other custom providers need a base URL
    connect.save({"ai": {"provider": "custom", "base_url": "http://localhost:11434/v1", "model": "llama"}})
    assert connect.ai_ready()
    with pytest.raises(ValueError):
        connect.save({"ai": {"provider": "custom", "base_url": "", "key": "k"}})
    # run reports: anonymous, no paths or links
    from cb import autoclip
    assert autoclip.source_kind("https://www.twitch.tv/videos/1") == "twitch" and autoclip.source_kind("/x/a.mp4") == "file"
    assert autoclip.error_kind("Download failed. The site may be blocking this network") == "blocked"
    learn.record("run", None, None, run={"source": "kick", "state": "done", "chat": 0, "error": None})
    rep = learn.build_report()
    assert rep["events"][-1]["kind"] == "run" and rep["events"][-1]["run"]["source"] == "kick"


def test_editor_starts_like_the_app_does(demo):
    """serve() itself (not just the handler): starts the channel-watch poller and answers."""
    from cb import editor_server
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    threading.Thread(target=editor_server.serve, args=(demo["root"], port), daemon=True).start()
    for _ in range(50):
        try:
            j = json.loads(urllib.request.urlopen("http://127.0.0.1:%d/api/watch" % port, timeout=2).read())
            break
        except Exception:
            time.sleep(0.2)
    assert j["watches"] == [] and j["minutes"] and editor_server.Ctx.poller is not None
    html = urllib.request.urlopen("http://127.0.0.1:%d/" % port, timeout=5).read().decode()
    assert 'id="wAdd"' in html and 'id="scUrl"' in html and 'id="acChat"' in html


def test_learns_per_connector(tmp_path, monkeypatch):
    from cb import ai_rank, connect, learn
    monkeypatch.setattr(connect, "_path", lambda: str(tmp_path / "connections.json"))
    monkeypatch.setattr(learn, "_dir", lambda: str(tmp_path))
    connect.save({"ai": {"provider": "custom", "base_url": "https://openrouter.ai/api/v1", "key": "sk-or-1", "model": "some/model"},
                  "webhook": {"url": "https://discord.com/api/webhooks/1/x"}, "cookies": {"browser": "firefox"}})
    assert connect.ai_source() == "openrouter/some/model"
    pr = connect.profile()
    assert pr == {"ai": "openrouter/some/model", "ai_rerank": True, "scorer": None, "webhook": "discord",
                  "cookies": "firefox", "reports": False}
    assert "sk-or" not in json.dumps(pr) and "webhooks/1" not in json.dumps(pr)      # kinds only, never secrets
    # the AI's scores remember which AI gave them
    cands = [{"start": 0, "end": 20, "quality": {"score": 7}, "sentences": [[0, "a"]]},
             {"start": 30, "end": 50, "quality": {"score": 7}, "sentences": [[30, "b"]]}]
    ai_rank.rerank(cands, complete=lambda *a, **k: '[{"id":0,"score":9},{"id":1,"score":2}]', weight=0.4)
    assert cands[0]["ai"]["src"] == "openrouter/some/model"
    # two AIs over time: one agrees with what this user keeps, the other doesn't
    def clip(i, src, ai, rating):
        learn.record("rated", {"name": "c%d" % i, "start": 0, "end": 30, "quality": {"score": 7},
                               "candidate": {"tags": {}, "ai_score": ai, "ai_src": src}}, "/p", rating=rating)
    for i in range(6):
        clip(i, "anthropic/claude-haiku-5-5", 9 if i % 2 else 3, 1 if i % 2 else -1)       # always right
        clip(100 + i, "ollama/llama3", 3 if i % 2 else 9, 1 if i % 2 else -1)              # always wrong
    L = learn.learned()
    s = L["ai"]["sources"]
    assert s["anthropic/claude-haiku-5-5"]["agree"] == 1.0 and s["ollama/llama3"]["agree"] == 0.0
    assert "anthropic/claude-haiku-5-5 agrees with your picks most" in " ".join(learn.insights(L))
    # which titles get picked
    learn.record("title_used", {"name": "c1"}, "/p", style="ai", src="anthropic/claude-haiku-5-5", supported=True, offered=8)
    learn.record("title_used", {"name": "c2"}, "/p", style="curiosity", supported=True, offered=8)
    assert learn.learned()["titles"] == {"ai:anthropic/claude-haiku-5-5": 1, "curiosity": 1}
    # it all goes into the report
    assert "sources" in learn.build_report()["summary"]["ai"]


def test_stream_panels_found_stacked_and_editable(demo, tmp_path):
    """A stream overlay (two video windows on an animated background) is stacked, not cut through."""
    from cb import panels
    from cb.render import make_clip
    src = str(tmp_path / "overlay.mp4")
    os.system(
        "ffmpeg -loglevel error -y -ss 40 -t 16 -i %s -filter_complex \"color=c=0x1d1150:s=1920x1080:r=30:d=16,"
        "noise=alls=6:allf=t[bg];[bg]drawbox=x='200+100*sin(t/3)':y=300:w=180:h=180:color=0x2a1a70:t=fill,"
        "drawbox=x=120:y=470:w=260:h=110:color=0xf5d020:t=fill[bg2];[0:v]split=2[a][b];[a]scale=1000:562[A];"
        "[b]hflip,scale=780:440[B];[bg2][A]overlay=860:60[o1];[o1][B]overlay=40:600[v]\" -map \"[v]\" -map 0:a "
        "-c:v libx264 -preset veryfast -c:a aac %s" % (demo["src"], src))
    got = panels.detect(src, 1920, 1080)
    want = [(860, 60, 1000, 562), (40, 600, 780, 440)]
    assert got and len(got) == 2
    for g, w in zip(got, want):
        assert all(abs(a - b) <= 8 for a, b in zip(g, w)), (got, want)
    assert panels.detect(demo["src"], 1920, 1080) is None          # a normal video is left alone
    res = make_clip({"name": "pn", "source": src, "start": 1.0, "end": 9.0, "headline": "Two windows",
                     "captions": "box"}, str(tmp_path / "out"), str(tmp_path / "work"), {})
    assert any("2 video windows" in x and "stacked" in x for x in res["layout_log"])
    pr = probe(res["out"])
    assert (pr["width"], pr["height"]) == (1080, 1920) and res["verify"]["ok"], res["verify"]
    # windows drawn by hand in the editor win over detection
    res = make_clip({"name": "pn2", "source": src, "start": 1.0, "end": 6.0, "layout": "panels", "captions": "none",
                     "panels": [[0.45, 0.05, 0.52, 0.52], [0.02, 0.55, 0.41, 0.41]]},
                    str(tmp_path / "out"), str(tmp_path / "work"), {})
    assert any("set in the editor" in x for x in res["layout_log"]) and res["verify"]["ok"]


def test_auto_clip_count_and_more_clips(demo):
    from cb.autoclip import auto_count, run
    assert auto_count(10 * 60) == 6 and auto_count(2 * 3600) == 15 and auto_count(10 * 3600) == 40
    st = run(demo["src"], demo["root"], "more_test", clips=1, min_score=0, render=False)
    d = os.path.join(demo["root"], "more_test")
    first = json.load(open(os.path.join(d, "specs.json")))
    assert st["state"] == "done" and len(first) == 1 and first[0]["name"] == "01_clip"
    assert st["opts"]["min_score"] == 0
    st2 = run(os.path.join(d, "source.mp4"), demo["root"], "more_test", clips=2, min_score=0, render=False, more=True)
    specs = json.load(open(os.path.join(d, "specs.json")))
    assert st2["state"] == "done" and specs[0] == first[0]                      # the first clip is kept as it was
    new = specs[1:]
    assert new and [s["name"] for s in new][:1] == ["02_clip"]                 # numbering continues
    a0, b0 = first[0]["start"], first[0]["end"]
    for s in new:                                                               # never the same moment again
        assert min(s["end"], b0) - max(s["start"], a0) <= 0.3 * (s["end"] - s["start"])


def test_live_steady_pace(monkeypatch):
    """Live clipping keeps producing: after a quiet stretch it takes a good (not standout) moment."""
    from cb import live, moments, score
    s = live.LiveSession.__new__(live.LiveSession)
    s.window, s.settle, s.cooldown, s.max_per_hour, s.niche, s.dir = 240.0, 8.0, 45.0, 20, (), "/tmp"
    s.words = [(float(i), float(i) + 0.4, "w") for i in range(300)]
    s.fired, s.fired_text, s.min_quality, s.min_score, s.cfg = [], [], 6.0, 14.0, {}
    s.history = [20.0] * 10                                # earlier moments set a high bar
    s._energy_z = lambda: None

    class Chat:
        kind = None

        def spike(self, *a):
            return 0.0
    s.chat = Chat()
    cand = {"start": 100.0, "end": 130.0, "score": 9.0, "tags": {"reaction": 1}, "sentences": [(100.0, "no way he did that")]}
    monkeypatch.setattr(moments, "find_candidates", lambda *a, **k: [dict(cand)])
    monkeypatch.setattr(score, "score_candidate", lambda c: {"score": 7.0, "why": []})
    s.steady_s, s.t_start = 8 * 60.0, time.time()
    assert s._detect(299.0) is None                        # just started: only standouts
    s.t_start = time.time() - 9 * 60
    got = s._detect(299.0)
    assert got and got["steady"]                           # 9 quiet minutes: a good moment gets clipped
    s.steady_s = 0.0
    assert s._detect(299.0) is None                        # "standouts only" keeps the old behaviour
    monkeypatch.setattr(score, "score_candidate", lambda c: {"score": 4.0, "why": []})
    s.steady_s = 8 * 60.0
    assert s._detect(299.0) is None                        # never below the quality bar


def test_updates_keep_user_edits_and_wait_for_jobs(tmp_path, monkeypatch):
    """A release fingerprints its files; the next update saves any the user changed. The editor loads the
    user's own _custom folder, and the Update button waits while something is running."""
    import shutil as _sh
    from cb import updater, editor_server, common
    app = tmp_path / "app"
    _sh.copytree(common.ROOT, str(app), ignore=_sh.ignore_patterns(".git", ".venv", "__pycache__", ".pytest_cache",
                                                                     "release", "_previous", "tests"))
    monkeypatch.setattr(updater, "ROOT", str(app))
    monkeypatch.setattr(updater, "VERSION_FILE", str(app / "VERSION"))
    monkeypatch.setattr(updater, "KEEP", updater.KEEP)
    wr = tmp_path / "work"
    monkeypatch.setattr(updater, "load_config", lambda: {"work_root": str(wr)})
    r = updater.release(str(tmp_path / "rel"), "9.0.0")
    import zipfile
    names = zipfile.ZipFile(r["zip"]).namelist()
    assert "clipbot/files.json" in names
    shipped = json.loads(zipfile.ZipFile(r["zip"]).read("clipbot/files.json"))
    assert "editor/index.html" in shipped and "config.json" not in shipped
    open(app / "files.json", "w").write(json.dumps(shipped))
    (app / "editor" / "index.html").write_text("<html>my own redesign</html>")
    kept = updater._keep_changed()
    assert kept["files"] == ["editor/index.html"]
    assert open(os.path.join(kept["dir"], "editor", "index.html")).read() == "<html>my own redesign</html>"
    # busy: a running job blocks the update
    monkeypatch.setitem(editor_server.JOBS, "x1", {"status": "running", "kind": "autoclip"})
    assert editor_server.busy() == ["autoclip"]
    editor_server.JOBS.pop("x1")
    # _custom: own css/js injected into the page
    monkeypatch.setattr(editor_server, "_custom_dir", lambda: str(tmp_path / "custom"))
    os.makedirs(tmp_path / "custom")
    (tmp_path / "custom" / "custom.css").write_text("body{outline:1px solid red}")

    class Fake:
        def __init__(self):
            self.out = io.BytesIO()

        def send_response(self, c):
            self.code = c

        def send_header(self, *a):
            pass

        def end_headers(self):
            pass
    f = Fake()
    f.wfile = f.out
    editor_server.H._page(f)
    html = f.out.getvalue().decode()
    assert '/custom/custom.css' in html and "Clipbot Studio" in html


def test_live_viewer_feed_and_hand_marked_clip(demo, tmp_path):
    """Watch-and-clip: the recording is served as a live HLS feed, and an in/out marked by hand is cut exactly."""
    from cb import editor_server
    from cb.live import LiveSession
    sess = LiveSession("https://kick.com/testchannel", outroot=str(tmp_path / "live"), render=False)
    run = os.path.join(sess.chunks_dir, "run000")
    os.makedirs(run)
    json.dump({"base": 0.0}, open(os.path.join(run, "base.json"), "w"))
    os.system("ffmpeg -loglevel error -y -ss 10 -t 60 -i %s -c:v libx264 -preset ultrafast -g 30 -c:a aac -f segment "
              "-segment_time 20 -segment_format mpegts -reset_timestamps 1 -segment_list %s -segment_list_type csv %s"
              % (demo["src"], os.path.join(run, "list.csv"), os.path.join(run, "seg_%05d.ts")))
    segs = sess.all_segments()
    assert len(segs) == 3 and segs[-1]["b"] > 45
    editor_server.LIVE["t1"] = sess
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    threading.Thread(target=editor_server.serve, args=(demo["root"], port), daemon=True).start()
    base = "http://127.0.0.1:%d" % port
    for _ in range(50):
        try:
            m3u = urllib.request.urlopen(base + "/api/live/hls.m3u8?id=t1", timeout=2).read().decode()
            break
        except Exception:
            time.sleep(0.2)
    assert m3u.startswith("#EXTM3U") and m3u.count("#EXTINF") == 3 and m3u.count("#EXT-X-DISCONTINUITY") == 2
    assert "#EXT-X-ENDLIST" not in m3u                                        # still live
    seg = urllib.request.urlopen(base + "/api/live/seg?id=t1&i=1", timeout=5).read()
    assert len(seg) > 10000 and seg[0] == 0x47                                # an MPEG-TS packet
    feed = json.loads(urllib.request.urlopen(base + "/api/live/feed?id=t1", timeout=5).read())
    assert len(feed["segments"]) == 3 and not feed["ended"]
    js = urllib.request.urlopen(base + "/ui/hls.light.min.js", timeout=5)
    assert "javascript" in js.headers["Content-Type"]

    class Pool:
        def submit(self, *a):
            self.job = a
    sess.pool = Pool()

    def post(path, body):
        req = urllib.request.Request(base + path, data=json.dumps(body).encode(), method="POST",
                                     headers={"Content-Type": "application/json", "X-Clipbot": "1"})
        try:
            return json.loads(urllib.request.urlopen(req, timeout=60).read())
        except urllib.error.HTTPError as e:
            return json.loads(e.read())
    assert "error" in post("/api/live/mark", {"id": "t1", "start": 30, "end": 30.4})     # too short
    r = post("/api/live/mark", {"id": "t1", "start": 15.0, "end": 41.0})               # spans two chunks
    assert r.get("clip"), r
    spec = sess.pool.job[2]
    from cb.common import probe
    dur = probe(os.path.join(r["dir"], "source.mp4"))["duration"]
    assert 38 <= dur <= 56                                     # the chunks it spans
    assert abs((spec["end"] - spec["start"]) - 26.0) < 0.6     # exactly the marked 26 s, no padding
    sess.stop.set()
    assert "#EXT-X-ENDLIST" in urllib.request.urlopen(base + "/api/live/hls.m3u8?id=t1", timeout=5).read().decode()
    editor_server.LIVE.pop("t1", None)


def test_presets_campaigns_and_sharing(tmp_path, monkeypatch):
    from cb import presets, lore
    monkeypatch.setattr(presets, "load_config", lambda: {"work_root": str(tmp_path)})
    monkeypatch.setattr(lore, "load_config", lambda: {"work_root": str(tmp_path)})
    spec = {"name": "c1", "start": 10, "end": 40, "headline": "keep me", "texts": [{"text": "keep"}], "captions": "box",
            "caption_font": "Anton", "caption_color": "#ffcc00", "banner": {"preset": "socials", "platform": "kick", "handle": "orangie"},
            "aspect": "9:16", "panels": [[0, 0, 1, 1]]}
    p = presets.save_preset("Orangie look", spec)
    assert set(p["style"]) == {"captions", "caption_font", "caption_color", "banner", "aspect"}   # look only
    with pytest.raises(ValueError):
        presets.save_preset("empty", {"name": "x", "start": 0})
    other = presets.apply({"name": "c2", "start": 0, "end": 20, "headline": "mine", "captions": "pro"}, "orangie look")
    assert other["captions"] == "box" and other["headline"] == "mine" and other["preset"] == "Orangie look"
    assert "texts" not in other and "panels" not in other
    with pytest.raises(ValueError):
        presets.save_campaign("bad", {"min_seconds": 60, "max_seconds": 10})
    presets.save_campaign("Pump Nov", {"min_seconds": 15, "max_seconds": 60, "aspect": "9:16", "captions": True,
                                       "banner_handle": "@Orangie", "hashtags": "#pump, #orangie", "title_words": ["Orangie"],
                                       "no_watermark": True}, preset="Orangie look")
    ch = {c["rule"]: c["ok"] for c in presets.check(dict(spec, title="Orangie loses it", hashtags="#pump"), "pump nov")}
    assert ch["At least 15s long"] and ch["At most 60s long"] and ch["Has captions"] and ch["Banner shows @orangie"]
    assert ch["Post text has #pump"] and not ch["Post text has #orangie"] and ch["Title mentions \"Orangie\""]
    short = {c["rule"]: c for c in presets.check(dict(spec, end=18, captions="none", banner=None), "pump nov")}
    assert not short["At least 15s long"]["ok"] and not short["Has captions"]["ok"] and not short["Banner shows @orangie"]["ok"]
    assert "timeline" in short["At least 15s long"]["detail"]
    # share: one file -> a teammate's empty install
    lore.save({"streamer": "Orangie", "names": ["Orangie"], "phrases": ["dev sold"]})
    data = presets.bundle(["Orangie look"], ["Pump Nov"], ["Orangie"])
    raw = json.dumps(data)
    other_root = tmp_path / "mate"
    monkeypatch.setattr(presets, "load_config", lambda: {"work_root": str(other_root)})
    monkeypatch.setattr(lore, "load_config", lambda: {"work_root": str(other_root)})
    r = presets.load_bundle(raw)
    assert sorted(r["added"]) == ["campaign Pump Nov", "lore Orangie", "preset Orangie look"]
    assert presets.load_bundle(raw)["skipped"] and not presets.load_bundle(raw)["added"]   # no silent overwrite
    assert lore.load("Orangie")["phrases"] == ["dev sold"]
    # hostile / broken files are refused, never executed
    for bad in ("not json", json.dumps({"x": 1}), "x" * (presets.MAX_FILE + 1), json.dumps([1, 2])):
        with pytest.raises(ValueError):
            presets.load_bundle(bad)
    evil = {"clipbot_share": 1, "presets": [{"name": "../../etc/passwd", "style": {"captions": "box", "__proto__": 1,
                                                                                   "rm -rf": "x"}}]}
    presets.load_bundle(json.dumps(evil))
    saved = os.listdir(other_root / "_presets")
    assert all("/" not in f and ".." not in f for f in saved)
    st = json.load(open(os.path.join(other_root, "_presets", [f for f in saved if "passwd" in f][0])))["style"]
    assert st == {"captions": "box"}                                                     # unknown keys dropped


def test_batch_queue_runs_links_in_order(demo, monkeypatch):
    from cb import editor_server, autoclip
    seen = []

    def fake_run(src, root, name, clips, *a, **k):
        seen.append(src)
        if "broken" in src:
            raise RuntimeError("site said no")
        return {"state": "done", "clips": [{"file": "/x.mp4"}, {"file": "/y.mp4"}]}
    monkeypatch.setattr(autoclip, "run", fake_run)
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    threading.Thread(target=editor_server.serve, args=(demo["root"], port), daemon=True).start()
    base = "http://127.0.0.1:%d" % port

    def post(path, body):
        req = urllib.request.Request(base + path, data=json.dumps(body).encode(), method="POST",
                                     headers={"Content-Type": "application/json", "X-Clipbot": "1"})
        for _ in range(50):
            try:
                return json.loads(urllib.request.urlopen(req, timeout=10).read())
            except urllib.error.HTTPError as e:
                return json.loads(e.read())
            except OSError:
                time.sleep(0.2)
    r = post("/api/batch", {"links": "https://kick.com/a/videos/1 not-a-link\nhttps://broken.example/v https://kick.com/a/videos/1, https://youtu.be/abcdefghijk"})
    assert r["total"] == 3 and r["skipped"] == ["not-a-link"]                 # duplicates dropped, junk reported
    for _ in range(100):
        j = json.loads(urllib.request.urlopen(base + "/api/job?id=" + r["id"]).read())
        if j["status"] != "running":
            break
        time.sleep(0.1)
    assert seen == ["https://kick.com/a/videos/1", "https://broken.example/v", "https://youtu.be/abcdefghijk"]
    states = [i["state"] for i in j["items"]]
    assert states == ["done", "error", "done"] and j["items"][1]["error"] == "site said no"   # one bad link never stops the rest
    assert post("/api/batch", {"links": "nothing here"}).get("error")


def test_phone_handoff_folder_and_view_tracking(tmp_path, monkeypatch, demo):
    from cb import post, learn, connect
    clip = tmp_path / "proj" / "renders" / "01_clip.mp4"
    os.makedirs(clip.parent)
    data = os.urandom(300000)
    clip.write_bytes(data)
    monkeypatch.setattr(post, "lan_ip", lambda: "127.0.0.1")
    r = post.start_handoff(str(clip), "Title\n\n#tag")
    page = urllib.request.urlopen(r["url"], timeout=5).read().decode()
    assert "Copy caption" in page and "#tag" in page and r["qr_svg"].startswith("<svg")
    furl = r["url"].replace("/p/", "/f/")
    req = urllib.request.Request(furl, headers={"Range": "bytes=1000-1999"})
    resp = urllib.request.urlopen(req, timeout=5)
    assert resp.status == 206 and resp.read() == data[1000:2000]
    assert urllib.request.urlopen(furl, timeout=5).read() == data
    for bad in (r["url"][:-3] + "xyz", r["url"].rsplit("/", 1)[0] + "/../../etc/passwd"):
        with pytest.raises(urllib.error.HTTPError):
            urllib.request.urlopen(bad, timeout=5)
    tok = r["url"].rsplit("/", 1)[1]
    post._HO["tokens"][tok]["exp"] = time.time() - 1                          # expired
    with pytest.raises(urllib.error.HTTPError):
        urllib.request.urlopen(r["url"], timeout=5)
    # posting folder
    folder = tmp_path / "drive"
    os.makedirs(folder)
    out = post.to_folder(str(clip), {"name": "01_clip", "title": "Big moment", "hashtags": "#a #b", "start": 1, "end": 21},
                         str(folder), "proj")
    assert open(out["caption"]).read().startswith("Big moment") and os.path.getsize(out["video"]) == len(data)
    assert not [f for f in os.listdir(folder) if f.endswith(".part")]
    with pytest.raises(ValueError):
        post.to_folder(str(clip), {}, str(tmp_path / "nope"))
    # tracking -> learning
    monkeypatch.setattr(post, "_posts_path", lambda: str(tmp_path / "posts.json"))
    monkeypatch.setattr(learn, "_dir", lambda: str(tmp_path))
    pdir = str(tmp_path / "proj")
    json.dump([{"name": "01_clip", "start": 0, "end": 20, "candidate": {"tags": {"reaction": 1}}}], open(os.path.join(pdir, "specs.json"), "w"))
    with pytest.raises(ValueError):
        post.track("tiktok.com/@x/video/1", pdir, "01_clip")
    post.track("https://www.tiktok.com/@x/video/1", pdir, "01_clip")
    assert post.posts()[0]["platform"] == "TikTok"
    counts = iter([1200, 5400])
    post.refresh(reader=lambda u: next(counts), now=time.time())
    assert post.refresh(reader=lambda u: 9, now=time.time() + 60) == []      # not due again yet
    post.refresh(reader=lambda u: next(counts), now=time.time() + 7 * 3600)
    p = post.posts()[0]
    assert p["views"] == 5400 and len(p["history"]) == 2
    evs = [e for e in learn.events() if e["kind"] == "performance"]
    assert [e["views"] for e in evs] == [1200, 5400] and evs[-1].get("auto")
    post.refresh(reader=lambda u: (_ for _ in ()).throw(RuntimeError("login needed")), force=True)
    assert post.posts()[0]["error"] == "login needed" and post.posts()[0]["views"] == 5400   # keeps last good count
    assert post.untrack("https://www.tiktok.com/@x/video/1") == 1


def test_youtube_upload_against_fake_google(tmp_path, monkeypatch):
    import http.server
    from cb import post, connect
    monkeypatch.setattr(connect, "_path", lambda: str(tmp_path / "connections.json"))
    connect.save({"youtube": {"client_id": "id.apps.googleusercontent.com", "client_secret": "sec"}})
    assert "client_id=id.apps" in post.yt_auth_url("http://127.0.0.1:1/oauth/youtube", "st8")
    got = {"chunks": []}

    class G(http.server.BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _send(self, code, body=b"", headers=()):
            self.send_response(code)
            for k, v in headers:
                self.send_header(k, v)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_POST(self):
            n = int(self.headers.get("Content-Length") or 0)
            body = self.rfile.read(n)
            if self.path.startswith("/token"):
                f = dict(urllib.parse.parse_qsl(body.decode()))
                got.setdefault("grants", []).append(f["grant_type"])
                j = {"access_token": "AT", "refresh_token": "RT"} if f["grant_type"] == "authorization_code" else {"access_token": "AT2"}
                return self._send(200, json.dumps(j).encode())
            got["meta"] = json.loads(body)
            got["auth"] = self.headers["Authorization"]
            self._send(200, b"", [("Location", "http://127.0.0.1:%d/up/session1" % self.server.server_address[1])])

        def do_PUT(self):
            n = int(self.headers.get("Content-Length") or 0)
            got["chunks"].append((self.headers["Content-Range"], len(self.rfile.read(n))))
            a, b, total = map(int, re.match(r"bytes (\d+)-(\d+)/(\d+)", self.headers["Content-Range"]).groups())
            if b + 1 < total:
                return self._send(308, b"", [("Range", "bytes=0-%d" % b)])
            self._send(200, json.dumps({"id": "VID12345678"}).encode())
    import re
    import urllib.parse
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), G)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    base = "http://127.0.0.1:%d" % srv.server_address[1]
    assert post.yt_finish_auth("CODE", "http://127.0.0.1:1/oauth/youtube", token_url=base + "/token")
    assert connect.redacted()["youtube"]["connected"] and connect.redacted()["youtube"]["refresh_token"] == ""
    vid = tmp_path / "c.mp4"
    vid.write_bytes(os.urandom(250000))
    r = post.yt_upload(str(vid), "My clip " * 30, "desc", ["#orangie", "pump"], publish_at="2026-12-01T18:00:00Z",
                       upload_url=base + "/upload", token_url=base + "/token", chunk=100000)
    assert r["id"] == "VID12345678" and r["url"].endswith("VID12345678")
    assert got["auth"] == "Bearer AT2" and len(got["meta"]["snippet"]["title"]) <= 100
    assert got["meta"]["status"] == {"privacyStatus": "private", "publishAt": "2026-12-01T18:00:00Z", "selfDeclaredMadeForKids": False}
    assert got["meta"]["snippet"]["tags"] == ["orangie", "pump"]
    assert [c[0] for c in got["chunks"]] == ["bytes 0-99999/250000", "bytes 100000-199999/250000", "bytes 200000-249999/250000"]
    srv.shutdown()


def test_translated_subtitles_and_phone_alerts(tmp_path, monkeypatch):
    import http.server
    from cb import subs, connect
    srt = tmp_path / "c.srt"
    srt.write_text("1\n00:00:00,000 --> 00:00:01,200\nNo way he did that\n\n2\n00:00:01,200 --> 00:00:02,500\nHe bought at $200K\n\n")
    calls = []

    def good(msg, system="", max_tokens=0):
        calls.append(msg)
        return '["No puede ser", "Compró a $200K"]'
    r = subs.translate_srt(str(srt), "es", complete=good)
    out = open(r["file"]).read()
    assert r["file"].endswith("c.es.srt") and "00:00:01,200 --> 00:00:02,500\nCompró a $200K" in out
    with pytest.raises(RuntimeError):
        subs.translate_srt(str(srt), "es", complete=lambda *a, **k: '["only one"]')     # never a file with lines missing
    with pytest.raises(ValueError):
        subs.translate_srt(str(srt), "xx", complete=good)
    # phone alert via an ntfy-style server
    got = []

    class N(http.server.BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def do_POST(self):
            got.append((self.path, self.headers["Title"], self.rfile.read(int(self.headers["Content-Length"])).decode()))
            self.send_response(200)
            self.end_headers()
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), N)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    monkeypatch.setattr(connect, "_path", lambda: str(tmp_path / "connections.json"))
    with pytest.raises(ValueError):
        connect.save({"notify": {"topic": "bad topic!"}})
    connect.save({"notify": {"topic": "clipbot-test123", "server": "http://127.0.0.1:%d" % srv.server_address[1]}})
    assert connect.notify("Clipbot", "3 clips ready")
    for _ in range(50):
        if got:
            break
        time.sleep(0.05)
    assert got == [("/clipbot-test123", "Clipbot", "3 clips ready")]
    srv.shutdown()


def test_big_creator_thumbnails(demo, tmp_path, monkeypatch):
    from PIL import Image
    from cb import thumbs
    fr = thumbs.frames(demo["src"], n=4, a=10, b=60)
    assert len(fr) == 4 and all(f["face"] for f in fr)
    assert all(abs(a["t"] - b["t"]) >= 0.6 for i, a in enumerate(fr) for b in fr[i + 1:])     # spread out

    def fake_cutout(rgb, face):                      # an ellipse around the face stands in for the model
        h, w = rgb.shape[:2]
        yy, xx = np.mgrid[0:h, 0:w]
        cx, cy = face[0] + face[2] / 2, face[1] + face[3] * 0.9
        return (((xx - cx) / (face[2] * 1.4)) ** 2 + ((yy - cy) / (face[3] * 1.6)) ** 2 < 1).astype(np.float32)
    monkeypatch.setattr(thumbs, "cutout", fake_cutout)
    r = thumbs.make(demo["src"], fr[0]["t"], str(tmp_path / "th"), text="He bought the top", emoji="😱",
                    arrow=True, circle=True)
    assert r["cutout"] and r["note"] is None and len(r["files"]) == 6
    for f in r["files"]:
        im = Image.open(f["file"])
        assert im.size == tuple(int(x) for x in f["size"].split("x"))
    pop = np.asarray(Image.open([f["file"] for f in r["files"] if f["style"] == "pop" and f["size"] == "1280x720"][0]))
    assert (pop[:, :640] > 240).all(-1).mean() > 0.01                   # white outline/text on the left half
    # no cutout available -> still makes thumbnails, and says why
    monkeypatch.setattr(thumbs, "cutout", lambda rgb, face: None)
    r = thumbs.make(demo["src"], fr[0]["t"], str(tmp_path / "th2"), text="x", styles=("pop",), sizes=((1280, 720),))
    assert len(r["files"]) == 1 and not r["cutout"] and "cutout" in r["note"]
    with pytest.raises(ValueError):
        thumbs.make(demo["src"], 99999, str(tmp_path / "th3"))
    assert set(thumbs.MODELS) == {"human", "small"} and all(len(h) == 64 for _, h in thumbs.MODELS.values())


# ------------------------------------------------------------------ 1.9.2: free AI, skills, prompt help, terms
def test_free_ai_default_and_rate_limit(tmp_path, monkeypatch):
    import http.server, threading as th
    from cb import connect
    monkeypatch.setattr(connect, "_path", lambda: str(tmp_path / "connections.json"))
    hits = []

    class H(http.server.BaseHTTPRequestHandler):
        def do_POST(self):
            body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
            hits.append(body)
            if len(hits) == 1:                       # first call: rate-limited, retry after 1 s
                self.send_response(402); self.send_header("Retry-After", "1"); self.end_headers(); return
            self.send_response(200); self.end_headers(); self.wfile.write(b'["a title", "another"]')

        def log_message(self, *a):
            pass
    httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), H)
    th.Thread(target=httpd.serve_forever, daemon=True).start()
    url = "http://127.0.0.1:%d/" % httpd.server_address[1]
    monkeypatch.setattr(connect, "load_config", lambda: {"work_root": str(tmp_path), "free_text_url": url})
    monkeypatch.setattr(connect, "FREE_GAP", 0.0)
    connect._FREE["last"] = 0.0
    assert connect.ai_cfg()["provider"] == "free" and connect.ai_ready() and connect.ai_source() == "free/pollinations"
    out = connect.ai_complete("hi", system="be short", wait=10)
    assert "a title" in out and len(hits) == 2 and hits[1]["messages"][0]["role"] == "system" and hits[1]["private"]
    monkeypatch.setattr(connect, "FREE_GAP", 60.0)
    with pytest.raises(RuntimeError, match="30 seconds"):
        connect.ai_complete("again", wait=0)         # the slot is used: interactive callers get told, not stuck
    connect.save({"ai": {"provider": "off"}})
    assert not connect.ai_ready()
    connect.save({"ai": {"provider": "anthropic", "key": None}})
    assert connect.ai_cfg()["provider"] == "free"    # a provider with no key falls back to the free AI
    connect.save({"ai": {"provider": "anthropic", "key": "sk-test"}})
    assert connect.ai_cfg()["provider"] == "anthropic"
    httpd.shutdown()


def test_skills_save_share_and_context(tmp_path, monkeypatch):
    from cb import presets, ai_rank, lore
    monkeypatch.setattr(presets, "load_config", lambda: {"work_root": str(tmp_path)})
    monkeypatch.setattr(lore, "load_config", lambda: {"work_root": str(tmp_path)})
    with pytest.raises(ValueError):
        presets.save_skill("empty")
    presets.save_skill("Degen clips", pick="payoff within 20 s", avoid="chart talk", titles="lowercase")
    assert [k["name"] for k in presets.list_skills()] == ["Degen clips"]
    ctx = ai_rank.context(skill=presets.load_skill("degen clips"))
    assert "payoff within 20 s" in ctx and "chart talk" in ctx
    b = presets.bundle(skills=["Degen clips"])
    other = tmp_path / "other"
    monkeypatch.setattr(presets, "load_config", lambda: {"work_root": str(other)})
    r = presets.load_bundle(json.dumps(b))
    assert r["added"] == ["skill Degen clips"] and presets.load_skill("Degen clips")["titles"] == "lowercase"
    assert presets.load_bundle(json.dumps(b))["skipped"] == ["skill Degen clips"]


def test_prompt_help(monkeypatch):
    from cb import prompt_help
    got = {}

    def fake(prompt, system="", max_tokens=0):
        got["system"] = system
        return '"every time he reads a donation over $100 out loud"\n'
    r = prompt_help.improve("clip", "donations", complete=fake)
    assert r["ai"] and r["prompt"].startswith("every time") and r["tips"] and "livestream" in got["system"]
    r = prompt_help.improve("skill", "big wins", complete=lambda *a, **k: 'Sure: {"pick": "wins", "avoid": "", "titles": "short"}')
    assert r["skill"] == {"pick": "wins", "avoid": "", "titles": "short"}
    assert prompt_help.improve("scene", "")["tips"]       # empty text -> just the tips, no AI call
    with pytest.raises(ValueError):
        prompt_help.improve("nope", "x")


def test_terms_accept(tmp_path, monkeypatch):
    from cb import terms
    monkeypatch.setattr(terms, "load_config", lambda: {"work_root": str(tmp_path)})
    st = terms.status()
    assert not st["accepted"] and "liable" in st["text"].lower() or "liability" in st["text"].lower()
    terms.accept()
    assert terms.accepted()
    monkeypatch.setattr(terms, "version", lambda: "changed00000")
    assert not terms.accepted()                        # new terms -> asked again


def test_tiktok_and_twitch_fake(tmp_path, monkeypatch):
    import http.server, threading as th, urllib.parse as up
    from cb import connect, social
    monkeypatch.setattr(connect, "_path", lambda: str(tmp_path / "connections.json"))
    seen = {"put": [], "init": None}

    class H(http.server.BaseHTTPRequestHandler):
        def _send(self, obj, code=200):
            b = json.dumps(obj).encode()
            self.send_response(code); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)

        def do_POST(self):
            raw = self.rfile.read(int(self.headers.get("Content-Length") or 0))
            p = self.path
            if p == "/v2/oauth/token/":
                f = up.parse_qs(raw.decode())
                assert f["grant_type"][0] in ("authorization_code", "refresh_token")
                if f["grant_type"][0] == "authorization_code":
                    assert f["code_verifier"][0] == "VER"
                return self._send({"access_token": "AT", "refresh_token": "RT2", "expires_in": 86400, "open_id": "u1", "scope": "video.upload"})
            if p == "/v2/post/publish/creator_info/query/":
                return self._send({"data": {"creator_nickname": "Sam", "creator_username": "sam", "privacy_level_options": ["SELF_ONLY"],
                                            "comment_disabled": True, "max_video_post_duration_sec": 600}, "error": {"code": "ok"}})
            if p in ("/v2/post/publish/inbox/video/init/", "/v2/post/publish/video/init/"):
                seen["init"] = (p, json.loads(raw))
                assert self.headers["Authorization"] == "Bearer AT"
                return self._send({"data": {"publish_id": "P1", "upload_url": "http://127.0.0.1:%d/up" % self.server.server_address[1]},
                                   "error": {"code": "ok"}})
            if p.startswith("/v2/video/query/"):
                assert "view_count" in p and json.loads(raw)["filters"]["video_ids"] == ["123"]
                return self._send({"data": {"videos": [{"id": "123", "view_count": 4567}]}, "error": {"code": "ok"}})
            if p == "/v2/post/publish/status/fetch/":
                return self._send({"data": {"status": "PUBLISH_COMPLETE", "publicaly_available_post_id": [123]}, "error": {"code": "ok"}})
            if p == "/oauth2/device":
                return self._send({"device_code": "D", "user_code": "ABCD", "verification_uri": "https://www.twitch.tv/activate", "interval": 5, "expires_in": 1800})
            if p == "/oauth2/token":
                return self._send({"access_token": "TW", "refresh_token": "TR", "expires_in": 14400})
            if p.startswith("/helix/clips?"):
                q = up.parse_qs(up.urlparse(p).query)
                assert q["broadcaster_id"] == ["42"] and q["duration"] == ["30.0"]
                return self._send({"data": [{"id": "Clip1", "edit_url": "https://clips.twitch.tv/Clip1/edit"}]}, 202)
            self._send({}, 404)

        def do_PUT(self):
            seen["put"].append((self.headers["Content-Range"], len(self.rfile.read(int(self.headers["Content-Length"])))))
            self._send({})

        def do_GET(self):
            if self.path.startswith("/helix/users"):
                return self._send({"data": [{"id": "42", "login": "sam"}]})
            self._send({}, 404)

        def log_message(self, *a):
            pass
    httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), H)
    th.Thread(target=httpd.serve_forever, daemon=True).start()
    base = "http://127.0.0.1:%d" % httpd.server_address[1]
    connect.save({"tiktok": {"client_key": "ck", "client_secret": "cs"}})
    url, ver = social.tt_auth_url("http://127.0.0.1:1/oauth/tiktok/", "S")
    q = up.parse_qs(up.urlparse(url).query)
    assert q["code_challenge"][0] == hashlib.sha256(ver.encode()).hexdigest() and q["state"] == ["S"]
    social.tt_finish_auth("CODE", "http://127.0.0.1:1/oauth/tiktok/", "VER", api=base)
    assert connect.get()["tiktok"]["refresh_token"] == "RT2"
    red = connect.redacted()["tiktok"]
    assert red["connected"] and not red["refresh_token"] and "access_token" not in red and red["client_secret"] == ""
    assert social.tt_creator(api=base)["privacy_options"] == ["SELF_ONLY"]
    vid = tmp_path / "c.mp4"
    vid.write_bytes(b"x" * 1000)
    r = social.tt_upload(str(vid), "draft", api=base)
    assert r["publish_id"] == "P1" and seen["init"][0].endswith("/inbox/video/init/") and seen["put"] == [("bytes 0-999/1000", 1000)]
    assert seen["init"][1]["source_info"] == {"source": "FILE_UPLOAD", "video_size": 1000, "chunk_size": 1000, "total_chunk_count": 1}
    with pytest.raises(ValueError):
        social.tt_upload(str(vid), "direct", {"title": "x"}, api=base)            # privacy must be chosen
    social.tt_upload(str(vid), "direct", {"title": "hey", "privacy_level": "SELF_ONLY", "disable_comment": True}, api=base)
    assert seen["init"][1]["post_info"] == {"privacy_level": "SELF_ONLY", "title": "hey", "disable_comment": True}
    assert social.tt_wait("P1", api=base, every=0)["post_ids"] == [123]
    assert social._chunks(200 * social.MB) == (10 * social.MB, 20)
    assert social.tt_views([123], api=base) == {"123": 4567}
    # Twitch
    connect.save({"twitch": {"client_id": "tid"}})
    d = social.tw_device_start(id_url=base + "/oauth2")
    assert d["user_code"] == "ABCD"
    assert social.tw_device_poll(id_url=base + "/oauth2", api=base + "/helix") == {"state": "connected", "login": "sam"}
    c = social.tw_create_clip("https://www.twitch.tv/Sam", duration=30, api=base + "/helix", id_url=base + "/oauth2")
    assert c["url"] == "https://clips.twitch.tv/Clip1"
    httpd.shutdown()


def test_edit_package(tmp_path):
    from cb import edit_publish
    ed = tmp_path / "edits"
    ed.mkdir()
    (ed / "vid.mp4").write_bytes(b"x")
    (ed / "vid_chapters.txt").write_text("0:00 The rug\n1:10 The comeback\n")
    json.dump({"title": "", "parts": [{"title": "The rug", "start": 0, "end": 5}, {"title": "The comeback", "start": 5, "end": 10}]},
              open(ed / "vid_plan.json", "w"))
    words = [[i * 0.5, i * 0.5 + 0.4, w] for i, w in enumerate("the coin rugged and the coin pumped again coin pumped".split())]
    json.dump(words, open(tmp_path / "words.json", "w"))
    with pytest.raises(ValueError):
        edit_publish.package(str(tmp_path), "../x")
    k = edit_publish.package(str(tmp_path), "vid", complete=lambda *a, **kw: '{"title": "He got rugged, then this", "summary": "A coin rug.", "tags": ["coin", "rug pull"]}')
    assert k["ai"] and k["title"] == "He got rugged, then this" and "0:00 The rug" in k["description"] and k["tags"] == ["coin", "rug pull"]
    k2 = edit_publish.package(str(tmp_path), "vid", use_ai=False)
    assert not k2["ai"] and k2["title"] == "The rug" and "coin" in k2["tags"] and "Chapters:" in k2["description"]
    assert edit_publish.saved(str(tmp_path), "vid")["title"] == "The rug"


def test_end_card(tmp_path):
    from cb import longform
    from cb.common import probe
    out = longform.end_card(str(tmp_path / "end.mp4"), 1280, 720, secs=1.0)
    pr = probe(out)
    assert abs(pr["duration"] - 1.0) < 0.2 and pr.get("width", 1280) == 1280

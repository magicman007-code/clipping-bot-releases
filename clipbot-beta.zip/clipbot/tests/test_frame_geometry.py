"""Reframe/crop math: whatever frame_geometry returns, the crop must fit inside the source and match the
target aspect. These invariants are what keep a reframed clip from showing black bars or a window that
runs off the edge."""
from cb.render import frame_geometry, ASPECTS


def _check(w0, h0, OW, OH, **kw):
    mode, cw, ch = frame_geometry(w0, h0, OW, OH, **kw)
    tgt = OW / OH
    assert mode in ("cover", "crop_x", "crop_y", "fit")
    # a crop never exceeds the source, and is an even size
    assert 0 < cw <= w0 and 0 < ch <= h0, (mode, cw, ch, w0, h0)
    assert cw % 2 == 0 and ch % 2 == 0
    if mode == "crop_x":
        assert abs(cw / ch - tgt) < 0.02, "crop_x aspect off: %s vs %s" % (cw / ch, tgt)
        assert ch == h0            # horizontal crop keeps full height
    if mode == "crop_y":
        assert abs(cw / ch - tgt) < 0.02, "crop_y aspect off"
        assert cw == w0            # vertical crop keeps full width
    if mode in ("cover", "fit"):
        assert cw == w0 and ch == h0
    return mode


def test_wider_source_to_vertical_crops_x_with_a_face():
    # 16:9 gameplay into 9:16, following a speaker -> horizontal crop
    assert _check(1920, 1080, 1080, 1920, have_face=True) == "crop_x"


def test_wider_source_no_face_falls_back_to_fit():
    # same but no face and the crop would be very aggressive -> blurred fit, never a bad crop
    assert _check(1920, 1080, 1080, 1920, have_face=False) == "fit"


def test_equal_aspect_is_cover():
    assert _check(1080, 1920, 1080, 1920) == "cover"


def test_blur_fit_layout_always_fits():
    assert _check(1920, 1080, 1080, 1920, layout="blur_fit") == "fit"


def test_mild_crop_keeps_most_of_the_frame():
    # 1200x1080 into 1:1 keeps >75% width -> crop_x even without a face
    assert _check(1200, 1080, 1080, 1080) == "crop_x"


def test_tall_source_to_wide():
    # a portrait source into 16:9 -> vertical crop or fit, never an over-crop
    assert _check(1080, 1920, 1920, 1080, have_face=True) in ("crop_y", "fit")


def test_every_aspect_preset_is_sane():
    for name, (OW, OH) in ASPECTS.items():
        for (w0, h0) in [(1920, 1080), (1080, 1920), (1280, 720), (720, 1280), (1080, 1080)]:
            _check(w0, h0, OW, OH, have_face=True)
            _check(w0, h0, OW, OH, have_face=False)


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    for fn in fns:
        fn(); print("ok", fn.__name__)
    print("PASS (%d tests)" % len(fns))

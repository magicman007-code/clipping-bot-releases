"""Auto-repair: plan() selection logic (pure), and a real verify -> repair -> re-verify round-trip
on a synthetic off-spec clip (needs ffmpeg)."""
import os
import shutil
import subprocess
import tempfile

from cb import repair


def test_plan_picks_only_repairable_codes_in_order():
    v = {"codes": ["NOT_FASTSTART", "LOUDNESS_OFF", "BLACK_FRAMES", "CAPTION_WER_HIGH", "CODEC_WRONG"]}
    # block-level (BLACK_FRAMES, CAPTION_WER_HIGH) dropped; repairs returned in fixed order
    assert repair.plan(v) == ["CODEC_WRONG", "LOUDNESS_OFF", "NOT_FASTSTART"]


def test_plan_empty_when_nothing_repairable():
    assert repair.plan({"codes": ["BLACK_FRAMES", "RES_MISMATCH"]}) == []
    assert repair.plan({"codes": []}) == []


def test_repair_file_noop_when_clean():
    r = repair.repair_file("/does/not/matter.mp4", {"codes": []})
    assert r["changed"] is False and r["applied"] == []


def _make_offspec_clip(path):
    """1080x1920 30fps h264/aac, 2s, muxed WITHOUT faststart (moov lands after mdat) and quiet
    (loudness well off -14). Moving source so freezedetect doesn't fire."""
    subprocess.run(
        ["ffmpeg", "-y", "-f", "lavfi", "-i", "testsrc2=size=1080x1920:rate=30:duration=2",
         "-f", "lavfi", "-i", "sine=frequency=300:duration=2",
         "-af", "volume=0.05", "-c:v", "libx264", "-preset", "veryfast", "-pix_fmt", "yuv420p",
         "-c:a", "aac", "-b:a", "128k", path],
        check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def test_verify_repair_reverify_roundtrip():
    if not shutil.which("ffmpeg"):
        print("skip: ffmpeg not available"); return
    from cb import verify as V
    d = tempfile.mkdtemp(prefix="repair_test_")
    try:
        clip = os.path.join(d, "clip.mp4")
        _make_offspec_clip(clip)

        before = V.verify_file(clip, check_wer=False)
        assert before["faststart"] is False, "fixture should not be faststart"
        assert "NOT_FASTSTART" in before["codes"]
        assert before["verdict"] == "repair", before["codes"]   # only repair-level issues on a clean testsrc
        assert not before["blocking"], "synthetic clip should have no block-level defects: %s" % before["blocking"]

        v = repair.finish(clip, check_wer=False)
        assert "NOT_FASTSTART" in v["repaired"]
        assert v["faststart"] is True, "repair must make it faststart"
        assert "NOT_FASTSTART" not in v["codes"]
        # loudness, if it was off and measurable, is pulled toward -14
        if "LOUDNESS_OFF" in before["codes"] and v.get("lufs") is not None:
            assert abs(v["lufs"] + 14) <= 2.0, "loudness not normalised: %s LUFS" % v["lufs"]
        assert not v["blocking"]
    finally:
        shutil.rmtree(d, ignore_errors=True)


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    for fn in fns:
        fn(); print("ok", fn.__name__)
    print("PASS (%d tests)" % len(fns))

"""X (Twitter) OAuth1 signing + chunked video upload + post, against a fake server (no real credentials)."""
import http.server
import json
import threading
import urllib.parse as up


CREDS = {"api_key": "CK", "api_secret": "CS", "access_token": "AT", "access_secret": "AS"}


class H(http.server.BaseHTTPRequestHandler):
    seen = {"append": 0, "auth_ok": True, "init": None, "tweet": None}

    def _send(self, obj, code=200):
        b = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def do_POST(self):
        ln = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(ln)
        auth = self.headers.get("Authorization", "")
        if not (auth.startswith("OAuth ") and 'oauth_signature="' in auth and 'oauth_consumer_key="CK"' in auth):
            H.seen["auth_ok"] = False
        if self.path.endswith("/media/upload.json"):
            ctype = self.headers.get("Content-Type", "")
            if "multipart/form-data" in ctype:
                H.seen["append"] += 1
                return self._send({}, 204)
            f = up.parse_qs(raw.decode())
            cmd = f.get("command", [""])[0]
            if cmd == "INIT":
                H.seen["init"] = f
                return self._send({"media_id_string": "M1"})
            if cmd == "FINALIZE":
                return self._send({"media_id_string": "M1"})   # no processing_info -> done
            return self._send({})
        if self.path.endswith("/2/tweets"):
            H.seen["tweet"] = json.loads(raw)
            return self._send({"data": {"id": "T1"}})
        self._send({}, 404)

    def log_message(self, *a):
        pass


def _clip(tmp_path):
    import subprocess
    p = tmp_path / "clip.mp4"
    # ~12 MB-ish so it spans multiple 5 MB append chunks
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "color=c=red:s=640x1138:d=2:r=24",
                    "-pix_fmt", "yuv420p", str(p)], check=True)
    with open(p, "ab") as f:            # pad past 10 MB so the upload spans several 5 MB chunks (server doesn't validate)
        f.write(b"\0" * (11 * (1 << 20)))
    return str(p)


def test_x_chunked_upload_and_post(tmp_path):
    H.seen = {"append": 0, "auth_ok": True, "init": None, "tweet": None}
    httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), H)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    base = "http://127.0.0.1:%d" % httpd.server_address[1]
    from cb import social
    r = social.x_publish(_clip(tmp_path), "big clip \U0001F525", creds=CREDS, api=base, upload_api=base)
    assert r["id"] == "T1" and r["url"].endswith("T1")
    assert H.seen["auth_ok"], "every request must carry a signed OAuth header"
    assert H.seen["append"] >= 2, "a >5MB video should upload in multiple chunks"
    assert H.seen["init"]["media_category"] == ["tweet_video"]
    assert H.seen["tweet"]["media"]["media_ids"] == ["M1"] and H.seen["tweet"]["text"].startswith("big clip")
    httpd.shutdown()


def test_x_requires_credentials(tmp_path, monkeypatch):
    from cb import connect, social
    monkeypatch.setattr(connect, "_path", lambda: str(tmp_path / "c.json"))
    try:
        social.x_publish(_clip(tmp_path), "x")
        assert False
    except ValueError as e:
        assert "X" in str(e)


def test_oauth_signature_is_deterministic_base():
    # signing the same base with the same nonce/timestamp inputs is stable (sanity on the HMAC path)
    import base64, hmac, hashlib
    from cb import social
    h = social._x_oauth("POST", "https://api.twitter.com/2/tweets", {}, CREDS)
    assert h.startswith("OAuth ") and "oauth_signature" in h

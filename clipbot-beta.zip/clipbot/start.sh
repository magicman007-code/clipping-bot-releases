#!/usr/bin/env bash
# Launch the Clipbot editor. First run creates a demo project so you can try everything immediately.
set -e
cd "$(dirname "$0")"
[ -f .clipbot_python ] || ./install.sh
PYBIN="$(cat .clipbot_python)"
ROOT="${CLIPBOT_PROJECTS:-$HOME/Clipbot}"
mkdir -p "$ROOT"
[ -d "$ROOT/demo" ] || "$PYBIN" clipbot.py demo "$ROOT/demo"
PORT="${PORT:-8765}"
echo "Projects folder: $ROOT  (put a video in a subfolder as source.mp4, or use: clipbot.py import <file>)"
"$PYBIN" clipbot.py editor --root "$ROOT" --port "$PORT" --open

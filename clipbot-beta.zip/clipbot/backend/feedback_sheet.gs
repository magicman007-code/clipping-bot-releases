/**
 * Clipbot learning reports -> Google Sheet. Free, runs on Google's servers, only you can see the sheet.
 * Setup (5 minutes): see FEEDBACK.md.
 *
 * Tabs it fills:
 *   events     one row per clip event from every tester (moment types, length, score, rating, reasons, views)
 *   summaries  one row per report: each install's overall keep rate and what it has learned
 */
const SECRET = '';   // optional: put the same text in the report link as ?k=... to ignore stray requests

function doPost(e) {
  if (SECRET && (!e.parameter || e.parameter.k !== SECRET)) return out_({ ok: false, error: 'bad key' });
  let r;
  try { r = JSON.parse(e.postData.contents); } catch (err) { return out_({ ok: false, error: 'not JSON' }); }
  if (!r || r.app !== 'clipbot') return out_({ ok: false, error: 'not a Clipbot report' });
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const ev = sheet_(ss, 'events', ['received', 'install', 'version', 'time', 'kind', 'clip', 'origin', 'tags', 'duration',
    'score', 'hook', 'payoff', 'energy', 'style_sim', 'rating', 'reasons', 'views', 'platform', 'start_delta',
    'end_delta', 'headline_edited', 'aspect', 'captions', 'text', 'ai_score', 'detail']);
  const now = new Date();
  const rows = (r.events || []).slice(0, 500).map(function (x) {
    const f = x.f || {}; const p = f.parts || {};
    return [now, r.install, x.v || r.version, new Date((x.t || 0) * 1000), x.kind, x.clip || '', f.origin || '',
      (f.tags || []).join(' '), f.dur || '', f.score || '', p.hook || '', p.payoff || '', p.energy || '',
      f.style_sim || '', x.rating || '', (x.reasons || []).join(' '), x.views || '', x.platform || '',
      f.start_delta || '', f.end_delta || '', f.headline_edited === undefined ? '' : f.headline_edited,
      f.aspect || '', f.captions || '', x._text || '', f.ai_score === undefined ? '' : f.ai_score, detail_(x)];
  });
  if (rows.length) ev.getRange(ev.getLastRow() + 1, 1, rows.length, rows[0].length).setValues(rows);
  const s = r.summary || {};
  const su = sheet_(ss, 'summaries', ['received', 'install', 'version', 'labelled', 'keep_rate', 'learning_active', 'ai_weight',
    'top_tags', 'trim_end_s', 'top_reason', 'raw']);
  const tags = Object.keys(s.tags || {}).sort(function (a, b) { return (s.tags[b].lift || 0) - (s.tags[a].lift || 0); });
  const reasons = Object.keys(s.reasons || {});
  su.appendRow([now, r.install, r.version, s.labelled || 0, s.keep_rate || '', !!s.active, (s.ai || {}).weight || '',
    tags.slice(0, 3).map(function (t) { return t + ' ' + s.tags[t].lift; }).join(', '),
    (s.trim || {}).end || '', reasons[0] || '', JSON.stringify(s).slice(0, 45000)]);
  return out_({ ok: true, rows: rows.length });
}

// everything else in the event (run reports: features used, timings, errors; chat / scorer numbers; future fields)
function detail_(x) {
  const skip = { t: 1, kind: 1, clip: 1, v: 1, rating: 1, reasons: 1, views: 1, platform: 1, _text: 1 };
  const o = {};
  Object.keys(x).forEach(function (k) { if (!skip[k] && k !== 'f') o[k] = x[k]; });
  const f = x.f || {};
  const cols = { origin: 1, tags: 1, dur: 1, score: 1, parts: 1, style_sim: 1, start_delta: 1, end_delta: 1,
    headline_edited: 1, aspect: 1, captions: 1, ai_score: 1 };
  Object.keys(f).forEach(function (k) {                 // every other clip fact (ai_src, chat_z, ext_score, new ones)
    if (!cols[k] && f[k] !== undefined && f[k] !== null) o[k] = f[k];
  });
  const s = JSON.stringify(o);
  return s === '{}' ? '' : s.slice(0, 45000);
}

function sheet_(ss, name, header) {
  let sh = ss.getSheetByName(name);
  if (!sh) { sh = ss.insertSheet(name); sh.appendRow(header); sh.setFrozenRows(1); }
  else if (sh.getLastColumn() < header.length) sh.getRange(1, 1, 1, header.length).setValues([header]);  // new columns
  return sh;
}

function out_(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }

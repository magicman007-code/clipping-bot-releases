# Clipbot vs Clipr AI — how we win

Written 2026-11-20. Clipr AI (cliprai.app) is the closest competitor: same core
job (long stream/VOD → short captioned vertical clips). This is where Clipbot is
stronger, where we're even, and the few places they can look better — with the
moves to pull ahead.

## The one-line position
**Clipbot is the only clipper that catches moments LIVE, while you stream,
automatically — and it runs on your own computer.** Everything else flows from
that. Clipr is a hosted "paste a past VOD and wait" tool; we're a live, always-on,
local clipping machine for people who actually stream.

## Where we already beat them (lean in)
- **Live clipping.** We clip the stream as it happens. Clipr only works on a
  finished broadcast or an uploaded file. This is a different category, not a
  feature gap.
- **Always-on auto-resume.** Flip it on and Clipbot clips every stream a channel
  does, forever, with zero effort (and now clearly shows it's waiting between
  streams — v3.4.17). Clipr has no equivalent.
- **Category Watch.** Clip the top live streams of a whole game at once. A
  single-VOD tool structurally can't do this. It's also a discovery/growth engine.
- **Local + private.** Footage never leaves the user's machine; no upload wait, no
  per-minute cloud bill, works offline. A hosted SaaS can't match this and will
  eventually have to meter minutes.
- **Depth:** learned styles from other creators, streamer lore for better
  moment-finding, trailer/hype edits, 7 framing modes, post scheduling. Clipr is
  deliberately shallow; our ceiling is higher.

## Where we're even (keep sharp — these are table stakes)
Moment detection, face tracking, word-by-word captions, vertical 1080p/4K export,
and plain-language editing ("Tell Clipbot what to change" = their "Ask Clipr").
We match all of it. Don't let these rot.

## Where they can look better (close these to win outright)
1. **First-run simplicity.** Their pitch is "paste a link, done." Our power can
   read as complexity. Keep the default path dead simple; tuck advanced behind it.
   (Started v3.5.1: hero leads with the live wedge; privacy line at the input.)
2. **Perceived speed + trust.** Hosted *feels* instant. Make "finding moments…"
   always show visible progress + a rough estimate so local never feels stuck.
3. **"Ask" quality.** Conversational editing is their flashy centerpiece. If ours
   reliably nails "start on the question, end on the laugh," we neutralize it.
4. **Onboarding proof.** A 30-second "watch it clip a live stream in real time"
   demo is something Clipr literally cannot film.

## The single highest-leverage move
Make the **live, automatic** story the front door — in product and in any
marketing. It's the thing Clipr can't copy without rebuilding their whole product,
and it already ships in ours.

## Shipped toward this
- v3.5.0 — one consistent accent look (less "clunky", more finished).
- v3.5.1 — Home hero leads with "catch your best moments, live" + always-on;
  "runs on your computer, footage never leaves it" stated at the point of action.

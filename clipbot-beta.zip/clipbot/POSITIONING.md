# Clipbot vs Clipr AI — how we win

Written 2026-11-20. Clipr AI (cliprai.app) is the closest competitor: same core
job (long stream/VOD → short captioned vertical clips). This is where Clipbot is
stronger, where we're even, and the few places they can look better — with the
moves to pull ahead.

## The one-line position
**Clipbot is the only clipper that catches moments LIVE, while you stream,
automatically — and it runs on your own computer.** Everything else flows from
that. Clipr is a hosted "paste a past VOD and wait" tool; we're a live, always-on,
local clipping machine for people who actually stream.

## Where we already beat them (lean in)
- **Live clipping.** We clip the stream as it happens. Clipr only works on a
  finished broadcast or an uploaded file. This is a different category, not a
  feature gap.
- **Always-on auto-resume.** Flip it on and Clipbot clips every stream a channel
  does, forever, with zero effort (and now clearly shows it's waiting between
  streams — v3.4.17). Clipr has no equivalent.
- **Category Watch.** Clip the top live streams of a whole game at once. A
  single-VOD tool structurally can't do this. It's also a discovery/growth engine.
- **Local + private.** Footage never leaves the user's machine; no upload wait, no
  per-minute cloud bill, works offline. A hosted SaaS can't match this and will
  eventually have to meter minutes.
- **Depth:** learned styles from other creators, streamer lore for better
  moment-finding, trailer/hype edits, 7 framing modes, post scheduling. Clipr is
  deliberately shallow; our ceiling is higher.

## Where we're even (keep sharp — these are table stakes)
Moment detection, face tracking, word-by-word captions, vertical 1080p/4K export,
and plain-language editing ("Tell Clipbot what to change" = their "Ask Clipr").
We match all of it. Don't let these rot.

## Where they can look better (close these to win outright)
1. **First-run simplicity.** Their pitch is "paste a link, done." Our power can
   read as complexity. Keep the default path dead simple; tuck advanced behind it.
   (Started v3.5.1: hero leads with the live wedge; privacy line at the input.)
2. **Perceived speed + trust.** Hosted *feels* instant. Make "finding moments…"
   always show visible progress + a rough estimate so local never feels stuck.
3. **"Ask" quality.** Conversational editing is their flashy centerpiece. If ours
   reliably nails "start on the question, end on the laugh," we neutralize it.
4. **Onboarding proof.** A 30-second "watch it clip a live stream in real time"
   demo is something Clipr literally cannot film.

## The single highest-leverage move
Make the **live, automatic** story the front door — in product and in any
marketing. It's the thing Clipr can't copy without rebuilding their whole product,
and it already ships in ours.

## Compare to the "22 GitHub repos" stack (the Clip Studio / VI reference)
Someone shared a 22-repo "build a clip tool" stack + an Opus-5.5 "CLIP STUDIO / VI"
mockup. Mapped against Clipbot's real dependencies, Clipbot already covers ~15 of
the 22 — with production-grade picks, not the vanilla ones:

- Downloading (01 yt-dlp): HAVE, hardened — yt-dlp + curl_cffi (Kick/Cloudflare)
  + yt-dlp-ejs/deno (YouTube JS challenges). More robust than plain yt-dlp.
- Transcription (07 Whisper / 08 whisper.cpp): HAVE faster-whisper (ctranslate2) —
  the fast local engine, better than vanilla Whisper.
- Vision/crop (03 OpenCV): HAVE cv2 + YuNet face detection (face-aware framing).
- Decode (22 PyAV): HAVE (av). Captions (15 pysubs2 / 16 libass): HAVE own styled
  renderer (resvg + ffmpeg). Timeline/edit/assemble (02 OpenCut, 17 Editly, 18
  Kdenlive, 19 Shotcut): HAVE our own editor. Highlights (05 AI Shorts): HAVE our
  own scorer. Record (04 OBS): N/A — we clip the live stream directly.
- Plus an on-screen-text reader (rapidocr) for "learn my style" that the list has no
  equivalent for — and live + always-on + local, which the stack doesn't include.

Genuine upgrade candidates worth cherry-picking from the list (quality, not parity):
1. **stable-ts (09)** — tighter word-level caption sync on top of faster-whisper. Best ROI.
2. **Norfair / Supervision (11,12)** — light subject tracking to smooth face-follow when
   people move, vs per-frame detection. Visible polish on active clips.
3. **DeepFilterNet (13)** — optional mic denoise for rough stream audio.
- pyannote.audio (10, speaker ID) is powerful but heavy + licensed — only if we do
  multi-speaker framing. Real-ESRGAN (20) / RIFE (21) upscale+interpolation: slow and
  off-brand for fast local clipping — skip.

Bottom line: the 22-repo list is basically the shopping list for building what Clipbot
already is. The mockup is a concept; Clipbot is the shipped, cross-platform, working
version — and already live + always-on + local.

## Compare to gtavi-aiproducer (OpusClip's Claude Code plugin)
What it is: OpusClip's own entry — a Claude Code *plugin* (16 skills + stdlib Python)
that pairs with AI Producer (their hosted agent, producer.opus.pro). Split model:
Claude Code scans/cuts long VODs locally (yt-dlp, ffmpeg, whisper.cpp) to beat AI
Producer's ~30-min source cap, then **uploads to AI Producer** for transcribe /
caption-editor / sound-effects / export, spending OpusClip credits. GTA6-launch-specific.

Where Clipbot wins:
- **Real app vs dev plugin.** Theirs needs Claude Code + a *gated* OpusClip account
  ("limited set of accounts") + brew-installed ffmpeg/yt-dlp/whisper-cpp + a model
  download. Tiny technical audience. Clipbot is a double-click GUI for any streamer.
- **Local + free vs cloud-funnel + paid.** Theirs uploads footage to AI Producer and
  spends credits; it funnels into a paid hosted editor. Clipbot stays on-device, no cost.
- **Live + always-on vs VOD-only.** They scan finished/post-live VODs (AI Producer
  can't ingest a live 20h stream). Clipbot clips live and auto-resumes. Structural edge.
- **Self-contained editor** vs dependence on OpusClip's editor, pricing and account gate.
- **General** vs GTA6-only (our Category Watch already generalises "a game's top streams").

Worth borrowing (real gaps this revealed):
1. **A money/campaign layer.** campaign_math.py = honest CPM/pool/target payout math
   ("most clips earn $0"), plus hooks, post-copy, scoreboard, launch-day. They tool the
   *economics* of clipping; we make clips but under-serve getting-paid/virality packaging.
2. **Brand-safety review flags on picks.** rank_windows flags profanity/sexual/spoiler
   (incl. Rockstar's "don't post endings") without changing score — check before posting
   to a campaign. Easy, valuable add to our scorer.
3. **Transparent moment scoring** — loudness z-score + reaction-cue lexicon + length, with
   whisper-loop de-hallucination. Worth comparing against our AI rerank.

Read: OpusClip using Claude Code as a local pre-processor to feed their paid cloud editor —
clever and timely, but a funnel into a gated paid product for technical users. Our bet
(local, free, live, GUI, any streamer) is the opposite and better for the mass market. Steal
the money layer + the safety flags.

## Shipped toward this
- v3.5.0 — one consistent accent look (less "clunky", more finished).
- v3.5.1 — Home hero leads with "catch your best moments, live" + always-on;
  "runs on your computer, footage never leaves it" stated at the point of action.
- v3.5.2 — calmer first run: before any projects exist, Home is one clear path
  (link box + "More tools"), closing competitive gap #1 (first-run simplicity).

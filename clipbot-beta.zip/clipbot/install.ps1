# Clipbot beta installer for Windows. Right-click -> "Run with PowerShell"
#   (or: powershell -ExecutionPolicy Bypass -File install.ps1). Safe to re-run.
$ErrorActionPreference = "Continue"   # native tools write to stderr; we check $LASTEXITCODE ourselves
Set-Location $PSScriptRoot
function Say($m) { Write-Host "`n==> $m" -ForegroundColor Yellow }
function Fail($m) { Write-Host "`n$m" -ForegroundColor Red; Read-Host "Press Enter to close"; exit 1 }

# --- Python: prefer a version every dependency ships wheels for (3.12 > 3.11 > 3.13 > 3.10)
Say "Finding Python"
$py = $null
if (Get-Command py -ErrorAction SilentlyContinue) {
  foreach ($v in "3.12", "3.11", "3.13", "3.10") {
    & py "-$v" -c "import sys" 2>$null
    if ($LASTEXITCODE -eq 0) { $py = @("py", "-$v"); break }
  }
}
if (-not $py -and (Get-Command python -ErrorAction SilentlyContinue)) {
  & python -c "import sys; sys.exit(0 if (3,10) <= sys.version_info[:2] <= (3,13) else 1)" 2>$null
  if ($LASTEXITCODE -eq 0) { $py = @("python") }
}
if (-not $py) {
  Fail "Python 3.10-3.13 not found. Install Python 3.12 from https://www.python.org/downloads/ (tick 'Add python.exe to PATH'), then run install.ps1 again."
}
Write-Host ("   using " + ($py -join " "))

# --- ffmpeg (winget), then reload PATH in this window so no restart is needed
if (-not (Get-Command ffmpeg -ErrorAction SilentlyContinue)) {
  Say "Installing ffmpeg (winget)"
  if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
    Fail "winget not found. Install ffmpeg manually (https://www.gyan.dev/ffmpeg/builds/ - 'release full'), add its bin folder to PATH, then re-run."
  }
  winget install --id Gyan.FFmpeg -e --accept-source-agreements --accept-package-agreements
  $env:Path = [Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [Environment]::GetEnvironmentVariable("Path", "User")
  if (-not (Get-Command ffmpeg -ErrorAction SilentlyContinue)) {
    Fail "ffmpeg was installed but isn't visible yet. Close this window and run install.ps1 once more."
  }
}

# --- virtual environment + packages
Say "Creating the Python environment (.venv)"
if (-not (Test-Path .venv\Scripts\python.exe)) {
  $exe = $py[0]; $rest = @(); if ($py.Count -gt 1) { $rest = $py[1..($py.Count - 1)] }
  & $exe @rest -m venv .venv
  if ($LASTEXITCODE -ne 0) { Fail "Could not create .venv (is the folder read-only or synced by OneDrive? Move it to C:\clipbot and retry)." }
}
$vpy = (Resolve-Path .venv\Scripts\python.exe).Path
Say "Installing packages (first time takes a few minutes)"
& $vpy -m pip install -q --upgrade pip
& $vpy -m pip install -q yt-dlp yt-dlp-ejs deno curl_cffi numpy opencv-python-headless pillow fonttools brotli websocket-client resvg-py segno ctranslate2 onnxruntime tokenizers huggingface_hub av
if ($LASTEXITCODE -ne 0) { Fail "Package install failed - see the messages above (internet connection? antivirus?)." }
& $vpy -m pip install -q --no-deps faster-whisper
if ($LASTEXITCODE -ne 0) { Fail "faster-whisper install failed." }
Set-Content -Path .clipbot_python -Value $vpy -Encoding ASCII

Say "Checks"
& $vpy clipbot.py setup | Out-Null
& $vpy clipbot.py doctor
Write-Host "`nDone. Double-click start.bat to open the editor." -ForegroundColor Green
Read-Host "Press Enter to close"

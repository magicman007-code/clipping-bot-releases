@echo off
rem Clipbot editor launcher (Windows). First run installs everything.
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
  if not exist .venv\Scripts\python.exe ( echo Install did not finish - see the messages above. & pause & exit /b 1 )
)
set "ROOT=%USERPROFILE%\Clipbot"
if not exist "%ROOT%" mkdir "%ROOT%"
if not exist "%ROOT%\demo\source.mp4" .venv\Scripts\python.exe clipbot.py demo "%ROOT%\demo"
echo.
echo Clipbot is starting. Keep this window open while you use it (close it to quit).
echo Projects folder: %ROOT%
echo.
.venv\Scripts\python.exe clipbot.py editor --root "%ROOT%" --port 8765 --open
pause

# Clip style reference (researched, not generic)

Sources: streamclipping.ai, clypse.ai, autoclip.dev, findclout.com blogs, plus direct
inspection of real clip pages on YouTube Shorts (N3on clips, StableRonaldo clips,
searched Sept 2026).

## Patterns observed directly on real clip pages

**N3on-style IRL clips** (@Plugclipping and similar N3on clip accounts):
- Footage is already vertical (phone/IRL), so no reframing needed.
- Bold WHITE rounded-rectangle box, black bold italic text, near the top third —
  this is an editorial "headline" caption describing the moment/context
  (e.g. "Lil Durk mom was CRYING on N3on live stream after..."), NOT a literal
  transcript line.
- A second, smaller plain caption (white text, black outline, no box) sits just
  above or below it — this IS the literal live spoken-word transcript.
- So there are two caption layers: an editorial hook/headline + the real transcript.

**StableRonaldo-style clips**:
- Bold ALL-CAPS colorful text (yellow or pink/magenta), black outline, casual
  rounded font, emoji included, e.g. "BRO ALWAYS KILLS THE VIBE 😂",
  "RON IS SO WRONG FOR THIS 🙄" / "WHY WOULD YOU DO THAT?" (top AND bottom banner).
- For multi-person/group streams: stacked facecam grid (each person's webcam as a
  full-width horizontal band, stacked to fill the vertical frame) rather than one
  big crop — this is how they keep everyone visible in 9:16.

**Gaming clip channels (CaseOh-style, per clypse.ai)**: split-screen, facecam top
40%, gameplay bottom 60% (or 50/50). Alternative: full gameplay with small facecam
corner overlay (20-25% width) when the game visuals matter more than the reaction.

## Hard rules that came up repeatedly across sources
1. **Never black-bar / never blind-crop out what's on screen.** If there's a chart,
   code, UI, or text on screen, cropping it away breaks the clip — reframe by
   repositioning/fitting, not by cutting. (Directly relevant to Orangie's
   trading-chart screenshare footage.)
2. **Full-frame vertical, always.** Blurred/zoomed background fill beats black bars.
3. **Hook = first 1-2 seconds.** Start at the moment tension/energy is already
   rising, not the wind-up. Cut dead air ruthlessly.
4. **Captions are mandatory** (most short-form video is watched muted). Short line
   lengths, large font, word/phrase-level emphasis on the key word.
5. **Editorial headline text** (colorful, ALL CAPS, emoji, describes the moment) is
   a distinct, separate layer from the literal spoken transcript captions — top
   clip channels use both.
6. **Punch-in zoom** (sudden ~15-25% scale increase, <150ms) sparingly (3-4 max in
   a 40s clip) on the emphatic word/reaction — never on screenshare/text/charts.
7. **Length**: 20-40s is the sweet spot for completion rate; up to ~60s fine for
   YouTube Shorts specifically (more tolerant of longer/narrative pacing than
   TikTok/Reels). Stableronaldo's biggest-ever clip ("nahh", 17M+ views) was just
   22 seconds of an understated reaction with plain captions — no fancy editing.
   Substance/moment-selection beats production polish.

## What this pipeline now does about it
- `layout` per channel/video type: `center_crop` (pure talking-head/webcam, safe),
  `blur_fit` (default/safe — never crops content, used for screenshare/charts),
  `split_facecam` (facecam top 40% / full un-cropped frame bottom 60%, for
  screenshare-with-facecam-corner content like Orangie's trading streams).
- Word-by-word transcript captions (bottom-center, safe TikTok zone) PLUS an
  optional editorial headline banner (top, bold colorful ALL-CAPS + emoji) that
  the workflow-runner writes per clip based on the transcript snippet — this is
  the "hook text" layer real clip pages use, and it needs human/model judgment to
  write well, so it's generated at workflow-run-time, not hardcoded.
- Default clip length tightened to 20-40s (was 30-60s).

# ▶ START HERE — next session action plan

Written 2026-11-18 ~03:50 PT. Read this + BUG-SWEEP.md first. Repo lives at
`/home/claude/clipping-bot`. Twitch is connected as `memegoddzs` (saved
server-side). Fixes for 3.3.1 are already staged but NOT published.

---

## ⚠️ Two decisions from Trevor needed up front (don't block on these — default noted)

1. **Category Watch permission stance — DECIDED (Trevor, 11-18).** Let it clip
   any top stream. Clipping is accepted ecosystem behaviour (Twitch's own Clips
   let anyone clip anyone). Implementation:
   - Replace the hard block with a **one-time acknowledgement**: "I confirm I
     have the right to clip these channels" (persist the ack).
   - Keep all clips landing in the **QC inbox** — nothing auto-posts. The ack
     covers *clipping*; the user decides what gets *published* (posting is where
     rights actually bite, not local clipping).
   - Reword the old API-string error into this plain acknowledgement flow.
   - Keep a per-channel opt-out if a streamer asks not to be clipped.
2. **Redesign rollout — DECIDED (Trevor deferred to best judgment, 11-18):
   INCREMENTAL.** Ship the high-impact de-clunk fixes first (Phase 3: Settings
   rename, rail feedback, Twitch wizard, plain errors, All-clips view) — fast,
   low-risk, renders untouched. Then roll the full prototype theme on a branch,
   pane by pane, screenshot-reviewed, renders kept pixel-identical, merged only
   when it matches (Phase 4). No big-bang drop while GTA is hot.

---

## Phase 1 — Ship 3.3.1 (the staged live-session fixes)  ~first 30 min

1. `cat VERSION` → should read `3.3.1`. Review staged diffs in `cb/live.py` and
   `cb/editor_server.py` (see BUG-SWEEP "Fixed this pass").
2. Add a regression test `tests/test_live_lifecycle.py`: start a session, set
   `ended=True`, assert it reaches `finished`, leaves `busy()`, and is pruned
   from `/api/live/sessions`.
3. Run `python3 tests/run_all.py` and `python3 tests/test_update.py`
   (+ `tests/test_update_button.py` — update flow was touched). Needs a Whisper
   model; in sandbox set the model override env to a local model folder.
4. If green: `clipbot publish 3.3.1 --repo magicman007-code/clipping-bot-releases
   --notes "Live sessions end cleanly — no more stuck 'live clipping'; updates
   no longer falsely blocked."`
5. Confirm Trevor's app offers the update and it applies without the false
   "still working" block.

## Phase 2 — Wider "stuck-state" audit  ~45 min
Work the BUG-SWEEP "bug-sweep targets" list: Category Watch sessions inherit the
ended→finished→prune behaviour; always-on respawn can always terminate; every
job error path sets a terminal status; token-expiry surfaces a clear reconnect
state instead of hanging. Add tests where cheap. Ship as 3.3.2 if anything found.

## ★ Standing principle across ALL phases: clean up everywhere
Trevor's mandate (11-18): "a clean up all around — don't want that clunkiness and
confusion." Every change leaves the app simpler than it found it. No clunk, no
confusion, anywhere. Apply to every pane, not just the known offenders.

## Phase 3 — Whole-app de-clunk pass  ~half a day
A holistic cleanup, pane by pane — not just the known offenders. For EVERY
screen (Home, Clip, Captions, Text, Export, Brand kit, Live, Find, Settings,
Results, Help): audit and fix.

Known high-impact fixes (do first):
- Rename rail "Connections, learning and updates" → **Settings** (plain gear).
- Clear active/hover states on every rail + tab button (they feel dead on click).
- **Connect-Twitch wizard**: one panel, labeled Client ID, Save→Connect→authorize
  walked step by step with the device code shown inline.
- Progressive disclosure: advanced options behind "Show all options" by default.
- Rewrite every API-string error as a plain sentence (start with Twitch perms).
- Prominent **"All clips"** gallery view (reveal-folder already exists).

Then the all-around cleanup checklist, every pane:
- [ ] Consistent naming — one word per concept everywhere (no "render" vs "clip"
      vs "export" drift); labels say what the thing does in plain language.
- [ ] Remove or merge duplicate / redundant controls and dead buttons.
- [ ] One clear primary action per screen; de-emphasize the rest.
- [ ] Consistent spacing, alignment, button styles, and section headers.
- [ ] Reduce on-screen density — group related options, collapse advanced ones.
- [ ] Every empty state explains what to do next (no blank panes).
- [ ] Every error/warning is a plain sentence with a next step.
- [ ] Consistent iconography + tooltips that actually say something.
- [ ] Logical tab/pane order; nothing buried more than one click deep.
Ship the high-impact fixes as 3.4.0; roll the per-pane cleanup out pane by pane
in small releases so nothing regresses.

## Phase 4 — UI redesign roll-in  (the big one)
Bring in the refined editor prototype (blue-slate #1d2130 + coral #ff5a4e,
cinematic preview, filmstrip, plain terminology). Keep Adam/Trevor's caption
style + renders pixel-identical. Do it on a branch, screenshot-review each pane,
merge when it matches the prototype and all tests pass. Update the demo/tour.

## Phase 5 — Features
Scheduled clipping / auto-resume UI → AI dubbing → Category Watch permission UI
→ (optional) MCP. See BUG-SWEEP for detail.

---
## Progress log
- 2026-11-18 AM: Phase 1 code-complete — live-lifecycle fix + regression tests
  (tests/test_live_lifecycle.py, 7/7) + batch-job hardening. 32 relevant tests
  green. Release bundle builds clean (3.3.1). **Publish still pending — must run
  on Trevor's Mac:** `python3 clipbot.py publish 3.3.1 --repo
  magicman007-code/clipping-bot-releases --notes "..."` (GH token invalid in
  sandbox). Phase 2 stuck-state audit DONE (see BUG-SWEEP). Both decisions made.

## Fast resume checklist
- [ ] Read NEXT-SESSION.md + BUG-SWEEP.md
- [x] Decisions made (Category Watch: acknowledge+clip; rollout: incremental)
- [~] Phase 1: fix + tests DONE; **Trevor runs the publish command** ↑
- [x] Phase 2: stuck-state audit done (+ batch hardening)
- [ ] Phase 3: whole-app de-clunk pass (start here next)
- [ ] Phases 4→5 after

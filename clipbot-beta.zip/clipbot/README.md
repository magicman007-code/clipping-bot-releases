# Clipbot (beta)

    python3 clipbot.py setup                  # deps + fonts
    python3 clipbot.py prep                   # scan channels -> download -> transcribe -> candidates.md
    python3 clipbot.py editor                 # browser editor at http://127.0.0.1:8765
    python3 clipbot.py render specs.json out/ # batch render + review.html + posts.md
    python3 clipbot.py done <video_id>

Code: `clipbot.py` (CLI) · `cb/` engine (fetch, transcribe, moments, speaker, render, effects, qa, montage,
review, editor_server, live, autoclip, banner, packaging) · `editor/index.html` (the editor UI).
Testers: start with **BETA_TESTING.md**.
Workflow for the agent: SKILL.md. What changed and why: CHANGES.md.

## The editor
Run `python3 clipbot.py editor --root <folder with video projects>` and open http://127.0.0.1:8765.
A project is any folder with `source.mp4` (+ `words.json` from `clipbot.py transcribe`).

- Left: clips list · AI picks (candidate finder) · searchable transcript (click = seek, shift-click = make clip)
- Centre: live 9:16 preview of every layout, captions, headline, text, stickers, progress bar.
  Drag captions/headline/text/stickers; drag the picture to move the crop; wheel resizes the selected layer.
- Bottom: timeline with waveform, jump-cut segments (drag edges, snaps to words), word lane
  (double-click to fix a word), text/sticker lanes.
- Right: Clip (layout, crop, speed, pacing toggles, segments) · Captions (4 styles or none, 25 fonts + uploads, bold/italic/shadow, colours, outline, spacing, size, .srt export/import,
  position, case, censor, word-by-word text+timing editor) · Text layers · Stickers (emoji + images) ·
  Audio (voice gain, music with auto-ducking, whoosh) · Look (presets, brightness/contrast/saturation/
  warmth/sharpen/vignette, progress bar, watermark) · Export (post copy, quick preview, final render + QA).
- Undo/redo, autosave to `specs.json`, keyboard shortcuts (press `?`).
The preview is a fast approximation; face-following, speaker cuts, tightening and audio processing
happen in the render ("Quick preview" renders the real thing at 540x960 in ~20s).

## Streamer banners (auto-injected credit)
Every clip can carry the streamer's credit automatically - set it once in config.json (`"banner"`), per clip in
specs, or in the editor (Look tab -> Streamer banner -> "Apply to all clips"). Live clips fill it in from the
stream URL (kick.com/x -> Kick icon + X, twitch.tv/x -> Twitch icon + X).

| preset | look |
|---|---|
| `socials` (default) | the account's platform icon + big italic outlined name in the platform colour |
| `kick_campaign` | big pill: Kick K + KICK.COM/NAME (the credit Kick-funded clips carry) |
| `kick_moving` | small K + /name watermark that hops between safe spots, like Kick's own downloads |
| `twitch_tag` | Twitch glitch + /name pill |
| uploaded banner | any PNG a campaign gives you: `clipbot.py banner add campaign.png --name xyz` or "Upload banner…" in the editor |

Add `"outro": true` for a 1.6s FOLLOW kick.com/name end card. Placement stays inside the TikTok/Reels/Shorts
safe band (y 240-1440, clear of the right-hand buttons), avoids faces and captions.
Platform icons come from the Simple Icons npm package (CC0 project; the marks belong to Kick/Twitch/etc. and are
used only to point viewers to the creator's channel - follow each platform's brand guidelines). Put your own
official file in `assets/logos/<platform>.png` to override.
Examples: `{"preset":"socials","platform":"kick","handle":"n3on"}` · `{"library":"campaign_x","width":640}`

// Clipbot Help center: every feature in plain words, searchable. Opened from the Help button (top bar), the rail,
// or the ? key. "Show me" closes Help, opens the right place and pulses the control.
(function(){
const $=id=>document.getElementById(id);
// [id, title, words people search with, html, show-me {sel, go}]
const A=[
["start","Start here: your first clip in 3 steps","begin new first quick start beginner how",`
<ol><li><b>Home → Auto-clip a video.</b> Paste a link (YouTube, Twitch, Kick VOD…) or drop a video file. Clipbot downloads it, listens to it and finds the best moments.</li>
<li><b>Click a clip</b> in the list on the left and press <b>Play</b>. The best ones are marked <b>Top 3</b>.</li>
<li><b>Press Render clip</b> (top right), then <b>Save to Downloads</b>. The video is in your Downloads → Clipbot folder.</li></ol>
<p>No video of your own yet? Home → <b>Open the demo project</b> lets you try everything on a ready-made stream.</p>
<p>Want it hands-on? Press <b>Guide</b> in the top bar: 11 small steps that tick themselves off as you do them.</p>`,{sel:"#railHome",go:()=>window.showHome&&showHome(true)}],

["mode","Simple mode and Pro mode (how to switch)","simple pro mode switch advanced more tools options hide show everything missing button where did",`
<p>The switch is in the top bar: <b>Simple | Pro</b>. Click either side. Nothing is lost when you switch: every clip and setting stays the same.</p>
<ul><li><b>Simple</b> (the default) shows only what you need: clips, the video, Captions, Text and Export, plus the "Tell Clipbot what to change" box.</li>
<li><b>Pro</b> adds every tool: the <b>Stickers</b>, <b>Audio</b> and <b>Look</b> tabs, <b>Find</b> (search moments by describing them), <b>Transcript</b>, <b>Lore</b> (names and running jokes), <b>Jobs</b> and the advanced settings.</li></ul>
<p>Can't find a button someone told you about? It's probably a Pro one: switch to Pro. Inside a tab, folded sections open with a click on their title, and <b>Show all options</b> at the top opens all of them.</p>`,{sel:".modeSw"}],

["guide","The Guide and the Tour","guide tour learn tutorial walkthrough steps lost",`
<p><b>Guide</b> (top bar) is a hands-on checklist on the demo project: watch a clip, change the headline, pick captions, add text, blur something, trim, tell it what to change, render, make a YouTube video, post, see results. <b>Show me</b> lights up the right button; each step ticks itself off when you do it.</p>
<p><b>Tour</b> (top bar) is a one-minute look around the screen: what each area does.</p>
<p>This Help is the full manual. Search it any time with the box at the top, or press <b>?</b>.</p>`,{sel:"#bGuide"}],

["make","Making clips from a stream or video","auto clip link url file upload download import vod twitch youtube kick how many clips score",`
<p><b>Home → Auto-clip a video</b>: paste a link or drop a file. Clipbot transcribes it, finds moments with a real payoff (a laugh, a reaction, a punchline), scores them out of 10 and renders the ones that reach your minimum score.</p>
<ul><li><b>How many clips:</b> on Auto it aims for about one per 8 minutes of video (6 to 40). Pick a number under <b>Options</b> on the New screen.</li>
<li><b>Several links:</b> paste one per line on the New screen to queue them.</li>
<li><b>Edit it myself</b> (Home) imports a video so you cut your own clips on the timeline.</li>
<li><b>More clips from this video</b> (above the clip list) finds the next-best moments without downloading or transcribing again.</li>
<li><b>Other moments it found</b> (under the clips) lists moments that weren't picked. Click one to watch it, or <b>Make a clip</b>.</li></ul>
<p>Small streams: Clipbot doesn't rely on chat. It listens for laughter, cheering and shouting in the room, and watches faces for reactions (a look to camera, a double take, shock), so quiet chats still get good picks.</p>`,{sel:"#hAuto",go:()=>window.showHome&&showHome(true)}],

["review","Picking the best clips","grade score top 3 thumbs up down like dislike review best which",`
<p>Each clip shows a grade out of 10. The best are marked <b>Top 3</b>. The grade is honest: a clip with no payoff can't score above 5, and one that's mostly silence can't score above 4.</p>
<p>Press 👍 or 👎 on a clip to teach Clipbot your taste. It learns from these and from how your posted clips do.</p>
<p>⧉ duplicates a clip (try a different version), ✕ removes it.</p>`,{sel:"#clipList",go:()=>window.switchTab&&switchTab("L","clips")}],

["edit","Editing a clip: trim, cut, headline, framing","trim cut shorten length start end split delete segment timeline headline title framing crop layout speaker follow",`
<ul><li><b>Trim:</b> drag the blue edges on the timeline at the bottom. Or press <b>I</b> / <b>O</b> to set the start / end at the playhead.</li>
<li><b>Cut out a part:</b> put the playhead there, press <b>Split</b> (or <b>S</b>), click the piece and press <b>Delete segment</b>.</li>
<li><b>Headline</b> (the big text at the top): click it on the video, or Clip tab → Headline. <b>Remove headline</b> takes it off.</li>
<li><b>Framing:</b> Clip tab → Framing → Layout. <i>Auto</i> follows whoever is talking. Others: follow one person, stacked split for two people, webcam over screen, full frame with blur, and split screen with your own video or picture. Drag the picture on the video to reframe it.</li>
<li><b>Pacing:</b> auto-remove pauses and filler words, speed, zooms.</li>
<li><b>Shape:</b> 9:16 (TikTok/Shorts/Reels), 4:5, 1:1 or 16:9. A 16:9 copy is made with every render.</li></ul>
<p>Every change can be undone: <b>Undo</b> in the top bar or Ctrl+Z.</p>`,{sel:"#f_layout",go:()=>{switchTab("R","clip");try{openSec("p-clip","Framing")}catch(e){}}}],

["ask","Tell Clipbot what to change (in words)","prompt type ask command words tell change editor instructions ai",`
<p>The green box at the top right is always there (press <b>/</b> to jump to it). Type what you want and press Enter or <b>Change</b>. Examples:</p>
<ul><li>"cut the first 4 seconds" · "end at 0:18" · "tighten it"</li>
<li>"follow the guy on the left" · "show both of them" · "go wide here"</li>
<li>"change the headline to HE ACTUALLY DID IT" · "shorter headline" · "remove the headline"</li>
<li>"change the caption 'there' to 'their'"</li></ul>
<p>Pick <b>This clip</b> or <b>All clips</b>. It says what it changed and what it couldn't do. One Undo puts everything back. <b>What can I say?</b> lists everything it understands.</p>`,{sel:"#askBox"}],

["captions","Captions: style, fixing words, quality","captions subtitles words style karaoke font colour size position wrong word fix srt accuracy",`
<ul><li><b>Style:</b> Captions tab → Pro (1-3 words, one keyword pops), Karaoke (the spoken word lights up), Box, Minimal, or None for a clean version.</li>
<li><b>Fix a wrong word:</b> double-click it on the timeline, or Captions → Words. Words you fix are never dropped.</li>
<li><b>Font, colour, size, position:</b> Captions → Font and colour / Size and position. Drag captions on the video to move them. Clipbot keeps them off faces.</li>
<li><b>Ease-out:</b> when the speaker pauses, the line stays readable for a moment, then fades instead of jumping off.</li>
<li><b>Accuracy check:</b> after a render, Clipbot shows the share of wrong words on screen (the bar is 8% or less) and the lines it wasn't sure about. Unsure lines are left out instead of shown wrong.</li>
<li><b>Subtitle file:</b> every render also makes an .srt file for YouTube/TikTok uploads.</li></ul>`,{sel:"#f_captions",go:()=>switchTab("R","cap")}],

["add","Text, images, emoji and blur","text image picture photo logo meme screenshot emoji sticker blur hide pixelate add overlay",`
<p>The <b>Add</b> bar above the video: <b>Text</b>, <b>Emoji</b>, <b>Image</b> and <b>Blur</b>.</p>
<ul><li><b>Image:</b> pick a picture (PNG with a see-through background works best for logos). It shows from the playhead to the end of the clip.</li>
<li><b>Move</b> anything by dragging it on the video. <b>Resize</b> by dragging its corner, or scroll over it.</li>
<li><b>When it shows:</b> select it and change the start/end in its layer (Text tab or Stickers tab).</li>
<li><b>Blur</b> hides faces, usernames, chat or anything else, only while you choose.</li>
<li><b>Remove:</b> click it on the video, then <b>Remove</b> in the bar that appears (or the Delete key).</li></ul>`,{sel:"#addBar"}],

["split","Split screen with your own picture or video","split screen picture image video gameplay broll b-roll top bottom half crayo stack",`
<ol><li>Clip tab → <b>Framing</b> → Layout: <b>Split screen + your video or picture</b>.</li>
<li>Press <b>Choose file</b>: a picture (screenshot, tweet, meme, product, chart) or a video (gameplay, b-roll). Videos loop with no sound; pictures stay the whole clip.</li>
<li>Choose where the streamer goes (top or bottom), the size (half and half, streamer bigger, or picture bigger), and whether the picture shows <b>all of it</b> (blurred edges fill the gap) or <b>fills the space</b> (edges cropped).</li></ol>
<p>The preview is exactly what the render looks like. Captions sit on the line between the halves.</p>`,{sel:"#f_layout",go:()=>{switchTab("R","clip");try{openSec("p-clip","Framing")}catch(e){}}}],

["export","Rendering and downloading your video","render download save export mp4 file where downloads folder find video get",`
<ol><li>Press <b>Render clip</b> (top right) or Export tab → <b>Render final</b>. <b>Quick preview</b> makes a fast half-size check first if you want one.</li>
<li>Press <b>Save to Downloads</b>. The vertical video, its 16:9 copy and the subtitles land in <b>Downloads → Clipbot</b>. <b>Show in folder</b> opens it.</li></ol>
<ul><li><b>Save all finished clips to Downloads</b> (Export tab) saves every clip you've rendered from this stream.</li>
<li><b>Render all</b> (top bar) renders every clip in the project.</li>
<li>Each render is checked: loudness, black or frozen frames, captions, and whether the speaker is on screen.</li>
<li>Prefer your browser's download? Use the small links under the Save button.</li></ul>`,{sel:"#bFinal2",go:()=>{switchTab("R","exp")}}],

["carousel","Carousels (swipeable image posts)","carousel slides instagram photo post linkedin swipe images quote cards",`
<p><b>Edits</b> (left bar) → <b>Carousel</b> → <b>Make carousel</b>. In seconds you get a cover with the hook and the streamer's face, one slide per best moment with their real words (the "um"s and "you know"s taken out, the amount highlighted), and a follow slide.</p>
<ul><li>Pick 5, 7 or 10 slides; 4:5 (Instagram), 1:1 or 9:16 (TikTok photo mode); Night, Paper or Bold red; and your @handle.</li>
<li>Change any heading or quote under its slide, remove slides, then <b>Redraw with my changes</b>.</li>
<li><b>Save to Downloads</b> saves the slides and the caption. Post them as a carousel on Instagram, TikTok (photo mode), LinkedIn or X.</li></ul>`,{sel:".tabs[data-for=L] button[data-p=edits]",go:()=>switchTab("L","edits")}],

["posts","Written posts: recap, YouTube description, thread, LinkedIn, blog","write posts recap show notes description chapters thread twitter x linkedin blog newsletter text copy",`
<p><b>Edits</b> → <b>Posts</b> → <b>Write my posts</b> drafts everything you'd type after a stream:</p>
<ul><li><b>Stream recap / show notes</b> with timestamps and the best lines</li><li><b>YouTube description</b> with chapters (YouTube turns the timestamps into chapters)</li>
<li><b>X / Threads thread</b>, one post per moment</li><li><b>LinkedIn post</b></li><li><b>Blog / newsletter draft</b></li></ul>
<p>Quotes are the streamer's real words. With an AI connected it also writes a summary; every sentence it writes is checked against the transcript and left out if it isn't supported. Edit, <b>Copy</b>, or <b>Save all as files</b>.</p>`,{sel:".tabs[data-for=L] button[data-p=edits]",go:()=>switchTab("L","edits")}],

["skills","Skills: teach the AI your kind of stream","skills starter gaming irl podcast casino crypto taste style ai instructions",`
<p>A skill tells Clipbot's AI what a great clip looks like for your kind of stream, what to skip and how to write titles. Starter skills come with Clipbot: <b>Gaming, IRL / Just Chatting, Podcast / Interview, Casino / Gambling, Crypto / Trading, Sports reaction, Comedy / Bits, Educational, Music / Studio, Drama / Debate</b>.</p>
<p>Pick one under <b>Options</b> on the New screen before auto-clipping. To change one, open Settings → Skills (Pro mode), press <b>Edit</b>, change the words and Save: that saves your own version. <b>Write it for me</b> drafts a new skill from a rough idea.</p>`,{sel:".tabs[data-for=L] button[data-p=settings]",go:()=>switchTab("L","settings")}],

["post","Posting: phone, YouTube, TikTok, scheduling","post upload youtube tiktok instagram phone send schedule week folder publish share",`
<ul><li><b>Send to my phone:</b> Export tab → shows a code to scan; the video opens on your phone ready to post anywhere (Instagram, TikTok, X…).</li>
<li><b>YouTube:</b> connect your channel once (Settings), then Export → <b>Upload</b> (public, unlisted, private or at a set time).</li>
<li><b>TikTok:</b> <b>Send as draft</b> puts it in your TikTok inbox to finish in the app, or <b>Post to TikTok…</b>.</li>
<li><b>Save to posting folder:</b> copies the clip and its caption text to a folder (Settings → Posting), handy with a sync app.</li>
<li><b>Schedule posts…</b> (under your clips) spreads clips over the coming days, e.g. 2 a day at 12:00 and 18:00. YouTube posts go out even if your computer is off.</li>
<li>Title, description and hashtags: Export → Post. Your AI can write ideas.</li></ul>`,{sel:"#bSched",go:()=>switchTab("L","clips")}],

["results","Results: how your clips are doing","results views analytics stats accounts track performance what works",`
<p><b>Results</b> (left bar) shows views for everything you've posted, new views in the last 24 hours, your scheduled posts, and what works for you (lengths, times, platforms).</p>
<p>Under <b>Accounts</b>, paste a YouTube, TikTok, Twitch or Kick profile to follow its public views, even one you can't connect. Paste links to posts you made elsewhere to track them too.</p>`,{sel:"#railRes"}],

["live","Clipping a live stream","live stream kick twitch real time vod watch channel always on",`
<p><b>Live</b> (left bar) → paste a Kick or Twitch channel → <b>Start live clipping</b>. Clipbot records at the best quality up to 1080p and clips standout moments as they happen. Watch along and mark your own clips too.</p>
<p><b>Watch channels</b> auto-clips every new VOD from a channel. When a recording or download gets cut off (sleep, internet drop), Clipbot rebuilds the video when it can, or tells you plainly.</p>`,{sel:".tabs[data-for=L] button[data-p=live]",go:()=>switchTab("L","live")}],

["edits","Long YouTube videos and trailers","youtube long video edit trailer hype chapters highlights compilation",`
<p><b>Edits</b> (left bar) turns a long stream into a YouTube video: pick a length and press <b>Make the edit</b>. It picks the best stories, adds a cold open, chapter cards and YouTube chapters. <b>Change parts</b> lets you drop or retitle pieces. Trailers and hype edits are here too. Each one has its own <b>Save to Downloads</b>.</p>`,{sel:".tabs[data-for=L] button[data-p=edits]",go:()=>switchTab("L","edits")}],

["settings","Settings: AI, phone alerts, connections","settings ai key openai claude gemini ollama phone alerts ntfy notifications connect accounts",`
<ul><li><b>Your AI:</b> the free built-in AI works with no key. Or pick Claude, OpenAI, Gemini, OpenRouter, Groq or local Ollama, paste a key, Save, Test.</li>
<li><b>Phone alerts:</b> install the free ntfy app, press Make my alert name, scan the code, Send a test. Your phone buzzes when clips are ready or something fails.</li>
<li><b>Connections:</b> YouTube, TikTok, Twitch and webhooks.</li>
<li><b>Help improve Clipbot:</b> anonymous learning reports, only if you say yes.</li></ul>`,{sel:".tabs[data-for=L] button[data-p=settings]",go:()=>switchTab("L","settings")}],

["app","Opening, closing and updating Clipbot","open close quit app applications start menu dock update version new install launch",`
<ul><li><b>Open:</b> Clipbot in Applications / Launchpad / Spotlight (Mac) or the Start menu / desktop (Windows). If you don't have the app yet, press <b>Add Clipbot</b> on the Home screen.</li>
<li><b>Close:</b> Cmd+Q on Mac, or <b>Quit Clipbot</b> at the bottom of the Home screen. Closing the window alone keeps Clipbot running; opening it again brings the window back.</li>
<li><b>Update:</b> when a new version is out, an <b>Update</b> button appears in the top bar. Your projects, settings and edits are kept.</li>
<li>Your projects live in your <b>Clipbot</b> folder (in your home folder).</li></ul>`,{sel:"#railHome",go:()=>window.showHome&&showHome(true)}],

["keys","Keyboard shortcuts","keyboard shortcuts keys hotkeys",`
<table class="hkeys"><tr><td><kbd>Space</kbd></td><td>play / pause</td></tr><tr><td><kbd>←</kbd> <kbd>→</kbd></td><td>one frame (with Shift: one second)</td></tr>
<tr><td><kbd>S</kbd></td><td>split at the playhead</td></tr><tr><td><kbd>Delete</kbd></td><td>delete the selected piece or layer</td></tr>
<tr><td><kbd>I</kbd> <kbd>O</kbd></td><td>set clip start / end</td></tr><tr><td><kbd>T</kbd></td><td>add text</td></tr><tr><td><kbd>D</kbd></td><td>quick preview</td></tr>
<tr><td><kbd>/</kbd></td><td>jump to "Tell Clipbot what to change"</td></tr><tr><td><kbd>?</kbd></td><td>this Help</td></tr>
<tr><td><kbd>Ctrl/Cmd+Z</kbd></td><td>undo (with Shift: redo)</td></tr><tr><td><kbd>Ctrl/Cmd+S</kbd></td><td>save</td></tr></table>`,null],

["trouble","Something went wrong","error failed problem broken not working bug render failed moov incomplete captions missing update certificate",`
<ul><li><b>"This video file is incomplete" / "moov atom not found":</b> the download or recording was cut off. Clipbot rebuilds it when it can; otherwise make the project again from the same link.</li>
<li><b>No Update button / "couldn't check for updates" (Mac):</b> open Applications → Python 3.x → Install Certificates.command, restart Clipbot. Or download the latest version from the release page.</li>
<li><b>Captions don't show in renders (Mac):</b> run the installer again; it installs the full ffmpeg captions need.</li>
<li><b>Someone is cut off:</b> change the Layout (Clip → Framing) or type "show both of them".</li>
<li><b>Still stuck:</b> Settings → send a bug report, or a screenshot of the message to whoever gave you Clipbot.</li></ul>`,null]
];

const css=`#helpC{position:fixed;inset:0;z-index:40;background:var(--bg,#0b0c10);display:none;color:var(--fg,#eee)}
#helpC.on{display:grid;grid-template-rows:auto 1fr}
#helpC .hTop{display:flex;gap:12px;align-items:center;padding:14px 22px;border-bottom:1px solid var(--line,#222)}
#helpC .hTop h1{font-size:20px;margin:0 8px 0 0;white-space:nowrap}
#helpC .hTop input{flex:1;max-width:560px;font-size:15px;padding:10px 14px;border-radius:10px}
#helpC .hBody{display:grid;grid-template-columns:280px 1fr;min-height:0}
#helpC nav{overflow:auto;padding:12px;border-right:1px solid var(--line,#222)}
#helpC nav button{display:block;width:100%;text-align:left;background:none;border:0;padding:9px 12px;border-radius:9px;color:var(--mut,#aaa);font-size:13.5px;line-height:1.3}
#helpC nav button:hover{background:var(--p2,#1a1b22);color:var(--fg,#fff)}#helpC nav button.on{background:var(--p2,#1a1b22);color:var(--fg,#fff);font-weight:600}
#helpC article{overflow:auto;padding:26px 36px 60px;max-width:760px;line-height:1.65;font-size:15px}
#helpC article h2{font-size:24px;margin:0 0 14px;line-height:1.25}#helpC article li{margin:6px 0}#helpC article p{margin:10px 0}
#helpC article .hSec{padding-bottom:22px;margin-bottom:22px;border-bottom:1px solid var(--line,#222)}
#helpC kbd{display:inline-block;border:1px solid var(--line2,#333);border-bottom-width:2px;border-radius:6px;padding:0 6px;font:12px/1.6 system-ui;background:var(--p2,#1a1b22)}
#helpC .hkeys td{padding:4px 14px 4px 0}#helpC .none{color:var(--mut,#999)}
#helpC mark{background:#ffd34a44;color:inherit;border-radius:3px}
.helpPulse{outline:3px solid #4ade80!important;outline-offset:3px;border-radius:8px;animation:hp 1s ease-in-out 3}
@keyframes hp{50%{outline-color:transparent}}
@media (max-width:760px){#helpC .hBody{grid-template-columns:1fr}#helpC nav{display:none}#helpC article{padding:18px 16px}}`;
const st=document.createElement("style");st.textContent=css;document.head.appendChild(st);
const box=document.createElement("section");box.id="helpC";box.setAttribute("role","dialog");box.setAttribute("aria-label","Help");
box.innerHTML=`<div class="hTop"><h1>Help</h1><input id="hcQ" type="search" placeholder="Search: e.g. download, simple mode, captions, split screen" aria-label="Search help"><button id="hcClose" class="ghost fx0">Back to Clipbot</button></div>
<div class="hBody"><nav id="hcNav" aria-label="Help topics"></nav><article id="hcArt"></article></div>`;
document.body.appendChild(box);
const strip=h=>h.replace(/<[^>]+>/g," ");
function score(a,q){const words=q.toLowerCase().split(/\s+/).filter(Boolean);if(!words.length)return 1;const hay=(a[1]+" "+a[2]+" "+strip(a[3])).toLowerCase();
  let s=0;for(const w of words){if(!hay.includes(w))return 0;s+=(a[1].toLowerCase().includes(w)?3:0)+(a[2].includes(w)?2:0)+1}return s}
function section(a){const d=document.createElement("div");d.className="hSec";d.id="hc-"+a[0];d.innerHTML="<h2></h2>"+a[3];d.querySelector("h2").textContent=a[1];
  if(a[4]){const b=document.createElement("button");b.className="pri sm";b.textContent="Show me";b.onclick=()=>showMe(a[4]);d.appendChild(b)}return d}
function render(q,focus){const N=$("hcNav"),R=$("hcArt");N.innerHTML="";R.innerHTML="";
  const list=A.map(a=>[score(a,q||""),a]).filter(x=>x[0]>0);if(q)list.sort((x,y)=>y[0]-x[0]);
  if(!list.length){R.innerHTML='<p class="none">Nothing found for that. Try another word, like "download", "captions" or "post".</p>';return}
  for(const[,a]of list){const b=document.createElement("button");b.textContent=a[1];b.onclick=()=>{document.getElementById("hc-"+a[0]).scrollIntoView({block:"start"});N.querySelectorAll("button").forEach(x=>x.classList.toggle("on",x===b))};N.appendChild(b);R.appendChild(section(a))}
  const tgt=focus&&document.getElementById("hc-"+focus);if(tgt)tgt.scrollIntoView({block:"start"});else R.scrollTop=0}
function showMe(m){close();try{m.go&&m.go()}catch(e){}
  setTimeout(()=>{const el=document.querySelector(m.sel);if(!el){return}el.scrollIntoView({block:"center",behavior:"smooth"});el.classList.remove("helpPulse");void el.offsetWidth;el.classList.add("helpPulse");setTimeout(()=>el.classList.remove("helpPulse"),3200)},250)}
function open(topic){box.classList.add("on");$("hcQ").value="";render("",topic);setTimeout(()=>$("hcQ").focus(),30)}
function close(){box.classList.remove("on")}
$("hcQ").addEventListener("input",e=>render(e.target.value.trim()));
$("hcClose").onclick=close;
box.addEventListener("keydown",e=>{if(e.key==="Escape"){e.stopPropagation();close()}});
window.helpOpen=open;window.helpClose=close;window.HELP_TOPICS=A;
})();

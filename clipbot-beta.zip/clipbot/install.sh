#!/usr/bin/env bash
# Clipbot beta installer for macOS and Linux. Safe to re-run.
set -euo pipefail
cd "$(dirname "$0")"
say() { printf "\n\033[1;33m==>\033[0m %s\n" "$*"; }
PY=${PYTHON:-python3}
command -v "$PY" >/dev/null || { echo "Python 3.9+ is required (macOS: brew install python, or python.org)"; exit 1; }
"$PY" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' || { echo "Python 3.9+ required, found $($PY --version)"; exit 1; }
if ! command -v ffmpeg >/dev/null; then
  say "Installing ffmpeg"
  if [[ "$(uname)" == "Darwin" ]]; then
    command -v brew >/dev/null || { echo "Install Homebrew first: https://brew.sh  (then re-run ./install.sh)"; exit 1; }
    brew install ffmpeg
  elif command -v apt-get >/dev/null; then sudo apt-get update -qq && sudo apt-get install -y -qq ffmpeg
  elif command -v dnf >/dev/null; then sudo dnf install -y ffmpeg
  else echo "Please install ffmpeg with your package manager, then re-run."; exit 1; fi
fi
say "Creating a Python environment"
PYBIN=""
for V in ".venv" "$HOME/.clipbot/venv"; do        # in-folder first; synced/mounted folders can't hold venvs
  if [ -x "$V/bin/python" ] || { rm -rf "$V"; mkdir -p "$(dirname "$V")"; "$PY" -m venv "$V" >/dev/null 2>&1; }; then
    PYBIN="$V/bin/python"; break
  fi
done
PIPFLAGS="-q"
if [ -z "$PYBIN" ]; then
  echo "  (no venv possible here - installing for this user instead)"
  PYBIN="$PY"; PIPFLAGS="-q --user"
  "$PY" -m pip install $PIPFLAGS --upgrade pip 2>/dev/null || PIPFLAGS="-q --user --break-system-packages"
fi
case "$PYBIN" in /*) ;; */*) PYBIN="$(cd "$(dirname "$PYBIN")" && pwd)/$(basename "$PYBIN")" ;; *) PYBIN="$(command -v "$PYBIN")" ;; esac
echo "$PYBIN" > .clipbot_python
"$PYBIN" -m pip install $PIPFLAGS --upgrade pip >/dev/null 2>&1 || true
say "Installing Python packages (first time takes a few minutes)"
"$PYBIN" -m pip install $PIPFLAGS yt-dlp numpy opencv-python-headless pillow fonttools brotli websocket-client resvg-py
"$PYBIN" -m pip install $PIPFLAGS ctranslate2 onnxruntime tokenizers huggingface_hub av
"$PYBIN" -m pip install $PIPFLAGS --no-deps faster-whisper
say "Fonts + checks"
"$PYBIN" clipbot.py setup >/dev/null 2>&1 || true
"$PYBIN" clipbot.py doctor || echo "  (doctor flagged something above - see 'fix' hints)"
say "Done. Start with:  ./start.sh        (opens the editor with a demo project)"

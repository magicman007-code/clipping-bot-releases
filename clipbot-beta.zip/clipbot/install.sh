#!/usr/bin/env bash
# Clipbot beta installer for macOS and Linux. Safe to re-run.
set -euo pipefail
cd "$(dirname "$0")"
say() { printf "\n\033[1;33m==>\033[0m %s\n" "$*"; }
okpy() { command -v "$1" >/dev/null 2>&1 && "$1" -c 'import sys; sys.exit(0 if (3, 10) <= sys.version_info[:2] <= (3, 13) else 1)' 2>/dev/null; }
PY=""
for C in ${PYTHON:-} python3.12 python3.13 python3.11 python3.10 /opt/homebrew/bin/python3.12 /usr/local/bin/python3.12 python3; do
  if okpy "$C"; then PY="$C"; break; fi
done
if [ -z "$PY" ] && [[ "$(uname)" == "Darwin" ]]; then    # macOS ships Python 3.9, which is too old
  command -v brew >/dev/null || { echo "Install Homebrew first: https://brew.sh  (then re-run ./install.sh)"; exit 1; }
  say "Installing Python 3.12 (the Mac's built-in Python is too old)"
  brew install python@3.12
  for C in python3.12 /opt/homebrew/bin/python3.12 /usr/local/bin/python3.12; do okpy "$C" && { PY="$C"; break; }; done
fi
[ -n "$PY" ] || { echo "Python 3.10-3.13 is required (found: $(python3 --version 2>&1)). Install Python 3.12 from python.org, then re-run."; exit 1; }
echo "  using $($PY --version) ($(command -v "$PY"))"
if ! command -v ffmpeg >/dev/null; then
  say "Installing ffmpeg"
  if [[ "$(uname)" == "Darwin" ]]; then
    command -v brew >/dev/null || { echo "Install Homebrew first: https://brew.sh  (then re-run ./install.sh)"; exit 1; }
    brew install ffmpeg
  elif command -v apt-get >/dev/null; then sudo apt-get update -qq && sudo apt-get install -y -qq ffmpeg
  elif command -v dnf >/dev/null; then sudo dnf install -y ffmpeg
  else echo "Please install ffmpeg with your package manager, then re-run."; exit 1; fi
fi
say "Creating a Python environment"
PYBIN=""
for V in ".venv" "$HOME/.clipbot/venv"; do        # in-folder first; synced/mounted folders can't hold venvs
  if [ -x "$V/bin/python" ] && ! okpy "$V/bin/python"; then rm -rf "$V"; fi   # made with an old Python: rebuild
  if [ -x "$V/bin/python" ] || { rm -rf "$V"; mkdir -p "$(dirname "$V")"; "$PY" -m venv "$V" >/dev/null 2>&1; }; then
    PYBIN="$V/bin/python"; break
  fi
done
PIPFLAGS="-q"
if [ -z "$PYBIN" ]; then
  echo "  (no venv possible here - installing for this user instead)"
  PYBIN="$PY"; PIPFLAGS="-q --user"
  "$PY" -m pip install $PIPFLAGS --upgrade pip 2>/dev/null || PIPFLAGS="-q --user --break-system-packages"
fi
case "$PYBIN" in /*) ;; */*) PYBIN="$(cd "$(dirname "$PYBIN")" && pwd)/$(basename "$PYBIN")" ;; *) PYBIN="$(command -v "$PYBIN")" ;; esac
echo "$PYBIN" > .clipbot_python
"$PYBIN" -m pip install $PIPFLAGS --upgrade pip >/dev/null 2>&1 || true
say "Installing Python packages (first time takes a few minutes)"
"$PYBIN" -m pip install $PIPFLAGS yt-dlp yt-dlp-ejs deno curl_cffi numpy opencv-python-headless pillow fonttools brotli websocket-client resvg-py
"$PYBIN" -m pip install $PIPFLAGS ctranslate2 onnxruntime tokenizers huggingface_hub av
"$PYBIN" -m pip install $PIPFLAGS --no-deps faster-whisper
say "Fonts + checks"
"$PYBIN" clipbot.py setup >/dev/null 2>&1 || true
"$PYBIN" clipbot.py doctor || echo "  (doctor flagged something above - see 'fix' hints)"
say "Done. Start with:  ./start.sh        (opens the editor with a demo project)"
